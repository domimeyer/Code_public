######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  main_hydro.py									
# Author: Robert Brose <robert.brose@mail.com>, 2016
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################
#Implementation of the Pluto-code as source of Hydro-data
#Main file to steer seperate hydro_runs

#v0.0.1: start of development

__version__='0.0.1'

from os import sys
from os import getenv
import patron.snrmod.snrevo.evoplu as evoplu
from numpy import array

m_p   = 1.673e-24						#proton mass in grams
mu    = 13./21.
yr    = 3.156e+7
pc    = 3.08567758e18


def main():
	#External parameters
	##################################################################
	outFileName="/lustre/fs17/group/that/rb/PyPluto/Run_01/Plutodata_"
	#Vikrams profiles
	#plutodll = getenv("PATRONDIR")+"/source/Pluto/pluto_vik.so" #replace later with setpar argument
	#Chevaliers  profiles
	plutodll = getenv("PATRONDIR")+"/lib/pluto_vik.so"
	##################################################################

	###############Creating output times
	#For testoutput:
	times_file = open("/afs/ifh.de/user/b/broserob/prog_files/CRaccel/patron/source/Pluto/history",'r')
	alllines=times_file.readlines()
	times_file.close()
	timesout=[]
	for i in range(len(alllines)):
		(vn,vt,vs)=alllines[i].split()
		timesout.append(float(vt)/yr)
	timesout=array(timesout)
	timesout=array([0,100,200,300,400,500,600,700,800,900])
	#timesout=array([0,10,20])
	time1  = 0
 	dtime1 = 100

	mhtran = evoplu.TransportEquation(plutodll,outFileName,timesout)
	mhtran.WriteMhd(mhtran.Mhd,mhtran.ConvTime(mhtran.g_time()),timesout,outFileName)

	while time1 < 500:
	 	mhtran.DoTimeIntervall(time1,time1+dtime1)
		mhtran.WriteMhd(mhtran.Mhd,mhtran.ConvTime(mhtran.g_time()),timesout,outFileName)
		time1 += dtime1
	
	mhtran.EndSimulation()

if __name__ == "__main__":sys.exit(main())
