/* ///////////////////////////////////////////////////////////////////// */
/*! 
  Supernova explosion 1-D spherical symetry
*/
/* ///////////////////////////////////////////////////////////////////// */
#include "pluto.h"

/* ********************************************************************* */
void Init (double *us, double x1, double x2, double x3)
/*
 *
 *
 *
 *********************************************************************** */
{
  double r_crit, vol, r, mu, T_ISM, M_ejecta, R_ejecta, Rho_ISM, E_Expl, Rho_crit, mass_fraction, v_0, kb, time;
  int n_ejecta;
  //double r_crit_2;


  double Msun=1.99e33;
  double A=1.2;
  double M=1.4*Msun;
  double g7=25./(21.*CONST_PI)*pow(g_inputParam[ENRG0],2.)/M;
  double q=g_inputParam[DNST0]*CONST_mp; //rho ISM
  double n=7.;
  double s=0.;


  time		= g_inputParam[TIME0];	//Starting time of simulation
  n_ejecta      = 7;
  g_gamma 	= g_inputParam[GAMMA];
  mu 		= 13.0/21.0;
  T_ISM 	= 1e4;
  M_ejecta	= 1.4*Msun/(UNIT_DENSITY*pow(UNIT_LENGTH,3));
  R_ejecta	= pow(A*g7/q,(1./(n-s)))*pow(time,((n-3.)/(n-s)))/UNIT_LENGTH;  //0.1*CONST_pc/UNIT_LENGTH;
  Rho_ISM	= g_inputParam[DNST0]*CONST_mp/UNIT_DENSITY;
  E_Expl	= g_inputParam[ENRG0]/(UNIT_DENSITY*UNIT_VELOCITY*UNIT_VELOCITY*UNIT_LENGTH*UNIT_LENGTH*UNIT_LENGTH);
  mass_fraction = 3./7.;
  kb		= 1.380658e-16;

		

  //print1 ("Konfiguration:\nEjecta_Masse = %f\n",M_ejecta);	
/* --------------------------------------------------
    dr is the size of the initial energy deposition 
    region: 2 ghost zones.
   -------------------------------------------------- */

  #if DIMENSIONS == 1
  	r_crit		= R_ejecta*pow((1.-mass_fraction*(3.-n_ejecta)*M_ejecta/(4.*CONST_PI*Rho_ISM*pow(R_ejecta,3.0))),(1./(3.-n_ejecta)));
	//r_crit_2	= pow((1-mass_fraction*(3-n_ejecta)*M_ejecta/(4*CONST_PI*Rho_ISM*pow(R_ejecta,3.0))),(1/(3.-n_ejecta)));
  	Rho_crit	= 3.*(1.-mass_fraction)*M_ejecta/(4.*CONST_PI*pow(r_crit,3.));
	v_0		= sqrt(E_Expl)/sqrt((2.*CONST_PI*Rho_crit*pow(r_crit,5.)/(5.*R_ejecta*R_ejecta))+2.*CONST_PI*Rho_ISM*pow(R_ejecta,3.)*(1.-pow((R_ejecta/r_crit),(n_ejecta-5.)))/(5.-n_ejecta));
  #else
   print1 ("! Init: geometrical configuration not allowed\n");
   QUIT_PLUTO(1);
  #endif

/* ---------------------------------------
     compute region volume 
   --------------------------------------- */

  /*#if (GEOMETRY == SPHERICAL   && DIMENSIONS == 1)
   vol = 4.0/3.0*CONST_PI*r_crit*r_crit*r_crit;
  #else
   print1 ("! Init: geometrical configuration not allowed\n");
   QUIT_PLUTO(1);
  #endif*/

  r = x1;

  /*print1("r_crit=%f \n",r_crit);	
  print1("R_ejecta=%f \n",R_ejecta);
  print1("Rho_crit=%f \n",Rho_crit);
  print1("Rho_ISM=%f \n",Rho_ISM);
  print1("v_0=%f \n",v_0);
  print1("E=%f \n",E_Expl);*/
  //QUIT_PLUTO(1);

  us[VX2] = 0.0;
  us[VX3] = 0.0;


  if (r<0){
	us[RHO] = Rho_crit;
	us[VX1] = v_0*(r/R_ejecta);
	us[PRS] = us[DN]*mu/KELVIN*T_ISM;
	}
  else if ((r>=0) && (r <= r_crit)){
		us[RHO] = Rho_crit; //4*g_inputParam[DNST0];
  		us[VX1] = v_0*(r/R_ejecta); //1e4*1e5/UNIT_VELOCITY;
		us[PRS] = us[DN]*mu/KELVIN*T_ISM; //(g_gamma - 1.0)*g_inputParam[ENRG0]/vol;
		}
  else if ((r > r_crit) && (r <= R_ejecta)){
		us[RHO] = Rho_crit*pow(r/r_crit,(-1.*n_ejecta)); //4*g_inputParam[DNST0];
  		us[VX1] = v_0*(r/R_ejecta); //1e4*1e5/UNIT_VELOCITY;
		us[PRS] = us[DN]*mu/KELVIN*T_ISM; //(g_gamma - 1.0)*g_inputParam[ENRG0]/vol;
		}
  else{          
		us[RHO] = Rho_ISM; //g_inputParam[DNST0];
		us[VX1] = 0.0;
		us[PRS] = us[DN]*mu/KELVIN*T_ISM; //us[DN]/mu/KELVIN*T_ISM;
		}

  us[TRC]  = 0.0;

/*ENRG0                1.905124786e18  
DNST0                4e-7  
GAMMA                1.6667*/
}
/* ********************************************************************* */
void Analysis (const Data *d, Grid *grid)
/* 
 *
 *
 *********************************************************************** */
{

}

/* ********************************************************************* */
void UserDefBoundary (const Data *d, RBox *box, int side, Grid *grid) 
/*
 *
 *
 *********************************************************************** */
{ 
  double r_crit, vol, r, mu, T_ISM, M_ejecta, R_ejecta, Rho_ISM, E_Expl, Rho_crit, mass_fraction, v_0, kb, time;
  int n_ejecta;
  //double r_crit_2;

  double Msun=1.99e33;
  double A=1.2;
  double M=1.4*Msun;
  double g7=25./(21.*CONST_PI)*pow(g_inputParam[ENRG0],2.)/M;
  double q=g_inputParam[DNST0]*CONST_mp; //rho ISM
  double n=7.;
  double s=0.;


  time		= g_inputParam[TIME0]+g_time*UNIT_LENGTH/UNIT_VELOCITY;	//Starting time of simulation
  n_ejecta      = 7;
  g_gamma 	= g_inputParam[GAMMA];
  mu 		= 13.0/21.0;
  T_ISM 	= 1e4;
  M_ejecta	= 1.4*Msun/(UNIT_DENSITY*pow(UNIT_LENGTH,3));
  R_ejecta	= pow(A*g7/q,(1./(n-s)))*pow(time,((n-3.)/(n-s)))/UNIT_LENGTH;  //0.1*CONST_pc/UNIT_LENGTH;
  Rho_ISM	= g_inputParam[DNST0]*CONST_mp/UNIT_DENSITY;
  E_Expl	= g_inputParam[ENRG0]/(UNIT_DENSITY*UNIT_VELOCITY*UNIT_VELOCITY*UNIT_LENGTH*UNIT_LENGTH*UNIT_LENGTH);
  mass_fraction = 3./7.;
  kb		= 1.380658e-16;

  //r = grid[0];

  r_crit	= R_ejecta*pow((1.-mass_fraction*(3.-n_ejecta)*M_ejecta/(4.*CONST_PI*Rho_ISM*pow(R_ejecta,3.0))),(1./(3.-n_ejecta)));
  Rho_crit	= 3.*(1.-mass_fraction)*M_ejecta/(4.*CONST_PI*pow(r_crit,3.));
  v_0		= sqrt(E_Expl)/sqrt((2.*CONST_PI*Rho_crit*pow(r_crit,5.)/(5.*R_ejecta*R_ejecta))+2.*CONST_PI*Rho_ISM*pow(R_ejecta,3.)*(1.-pow((R_ejecta/r_crit),(n_ejecta-5.)))/(5.-n_ejecta));
  //print1 ("Rhoc %e. %e \n", Rho_crit*UNIT_DENSITY,g_time*UNIT_LENGTH/UNIT_VELOCITY );

  int   i, j, k, nv;
  if (side == X1_BEG){
  /* -- select the boundary side -- */
  BOX_LOOP(box,k,j,i){
  /* -- Loop over boundary zones -- */
  d->Vc[RHO][k][j][i] = Rho_crit;
  d->Vc[VX1][k][j][i] = v_0*(grid[0].x[i]/R_ejecta);
  d->Vc[PRS][k][j][i] = Rho_crit*mu/KELVIN*T_ISM;
  }
}
}

