#include "pluto.h"
double min(double num1, double num2);
/* ***************************************************************** */
void Radiat (double *v, double *rhs)
/*!
 *   Provide r.h.s. for tabulated cooling.
 * 
 ******************************************************************* */
{
  int    klo, khi, kmid;
  static int ntab;
  double mu, T, Tmid, scrh, dT, prs;
  double mu_e, mu_H;
  static double *L_tab, *T_tab, E_cost;
  
  char *fname;
  FILE *fcool;

/* -------------------------------------------
        Read tabulated cooling function
   ------------------------------------------- */

  if (T_tab == NULL){
    print1 (" > Reading table from disk...\n");
    fname = getenv("PATRONDIR");
    strcat(fname,"/source/Pluto/cooltable.dat");
    fcool = fopen(fname,"r");
    if (fcool == NULL){
      print1 ("! Radiat: cooltable.dat could not be found.\n");
      QUIT_PLUTO(1);
    }
    L_tab = ARRAY_1D(20000, double);
    T_tab = ARRAY_1D(20000, double);

    ntab = 0;
    while (fscanf(fcool, "%lf  %lf\n", T_tab + ntab, 
                                       L_tab + ntab)!=EOF) {
      ntab++;
    }
    E_cost = UNIT_LENGTH/UNIT_DENSITY/pow(UNIT_VELOCITY, 3.0);
  }

/* ---------------------------------------------
            Get pressure and temperature 
   --------------------------------------------- */

  prs = v[RHOE]*(g_gamma-1.0);
  if (prs < 0.0) {
    prs     = g_smallPressure;
    v[RHOE] = prs/(g_gamma - 1.0);
  }
  //substituded	
  mu   = 13.0/21.0; //g_inputParam[MU];
  mu_e = 13.0/11.0;   //g_inputParam[MU_E];
  mu_H = 13.0/9.0; //g_inputParam[MU_H];
  T    = prs / v[RHO] * mu * KELVIN;

  if (T != T){
    printf (" ! Nan found in radiat \n");
    printf (" ! rho = %12.6e, prs = %12.6e\n",v[RHO], prs);
    QUIT_PLUTO(1);
  }

  if (T < g_minCoolingTemp) { 
    rhs[RHOE] = 0.0;
    return;
  }

/* ----------------------------------------------
        Table lookup by binary search  
   ---------------------------------------------- */

  klo = 0;
  khi = ntab - 1;

  if (T > T_tab[khi]){
  /*
    print (" ! T out of range   %12.6e\n",T);
    QUIT_PLUTO(1);
  */
  
  /* L \propto \sqrt{T} */
  /*  scrh  = L_tab[khi] * sqrt(T/T_tab[khi]);*/
    scrh = L_tab[khi] / sqrt(T/T_tab[khi]);
  }
  else {

    while (klo != (khi - 1)){
      kmid = (klo + khi)/2;
      Tmid = T_tab[kmid];
      if (T <= Tmid){
        khi = kmid;
      }else if (T > Tmid){
        klo = kmid;
      }
    }

  /* -----------------------------------------------
      Compute r.h.s
     ----------------------------------------------- */

    dT       = T_tab[khi] - T_tab[klo];
    scrh     = L_tab[klo]*(T_tab[khi] - T)/dT + L_tab[khi]*(T - T_tab[klo])/dT;
  }
    //rhs[RHOE] = -scrh*v[RHO]*v[RHO];  //Original statement
    rhs[RHOE] = -scrh*v[RHO]*v[RHO] * min(1.,pow((v[RHO]/(1.4*CONST_mp/UNIT_DENSITY*8.e9)),-0.45)); //Changed to account for optically thick cooling;
    
    scrh       = UNIT_DENSITY/CONST_amu;  
    rhs[RHOE] *= E_cost*scrh*scrh / (mu_e * mu_H);
  

}
/* ******************************************************************* */
double MeanMolecularWeight (double *V)
/*
 *
 *
 *
 ********************************************************************* */
{
  return (0.5);
/*
  return  ( (A_H + frac_He*A_He + frac_Z*A_Z) /
            (2.0 + frac_He + 2.0*frac_Z - 0.0));
*/
}

double min(double num1, double num2)
{
	return (num1>num2) ? num2 : num1;
}

