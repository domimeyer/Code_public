/* ///////////////////////////////////////////////////////////////////// */
/*! 
  Supernova explosion 1-D spherical symetry
*/
/* ///////////////////////////////////////////////////////////////////// */
#include "pluto.h"

/* ********************************************************************* */
void Init (double *us, double x1, double x2, double x3)
/*
 *
 *
 *
 *********************************************************************** */
{
  double r_crit, vol, r, mu, T_ISM, M_ejecta, R_ejecta, Rho_ISM, E_Expl, Rho_crit, kb, time, x, Rho_WB;
  double n_ej;

  double Msun=1.99e33;
  double pc = 3.086e18;
  double M=g_inputParam[MEJEC]*Msun;
  double n=g_inputParam[EEJEC];
  double s=g_inputParam[SDNST];
  double R_WB = g_inputParam[RWBUB]*pc/UNIT_LENGTH;
  double UNIT_TIME = UNIT_LENGTH/UNIT_VELOCITY;
  double UNIT_MASS = UNIT_DENSITY*pow(UNIT_LENGTH,3.);
  double Mshell = g_inputParam[MSHELL]*Msun/UNIT_MASS;
  double Dshell = g_inputParam[DSHELL]/2.*pc/UNIT_LENGTH;
  double Rshell = g_inputParam[RSHELL]*pc/UNIT_LENGTH;

  time		= g_inputParam[TIME0]/UNIT_TIME;	//Starting time of simulation
  n_ej      	= n;
  g_gamma 	= g_inputParam[GAMMA];
  
  T_ISM 	= 1e4;
  M_ejecta	= M/UNIT_MASS;
mu = 0.6190;


  Rho_ISM= g_inputParam[DNST0]*CONST_mp*1.4/UNIT_DENSITY;
  if (s==0){	
	Rho_WB = Rho_ISM;
	//print1 ("! Init: s=%f - No Wind Bubble. Density is constant.\n",s);
	}
  else if (s==2){
	Rho_WB = g_inputParam[MDNST]*Msun/(CONST_PI*1e7)/(4.*CONST_PI*g_inputParam[VDNST])/UNIT_MASS*UNIT_TIME*UNIT_VELOCITY;
	//print1 ("! Init: s=%f - Wind Bubble region considered. Make sure the size of the bubble makes sense\n",s);	
	}
  else{	  
	print1 ("! Init: Value s=%f not supported\n",s);
	QUIT_PLUTO(1);
	}
  E_Expl	= g_inputParam[ENRG0]/(UNIT_DENSITY*UNIT_VELOCITY*UNIT_VELOCITY*UNIT_LENGTH*UNIT_LENGTH*UNIT_LENGTH);
  kb		= 1.380658e-16;
		
  x		= g_inputParam[XPAR];

  #if DIMENSIONS == 1
  	r_crit		= sqrt(10./3.*E_Expl/M_ejecta*(n_ej-5.)/(n_ej-3)*(1.-3./n_ej*1./pow(x,(n_ej-3.)))/(1.-5./n_ej*1./pow(x,(n_ej-5.))))*time;//
	R_ejecta	= r_crit*x;
  	Rho_crit	= M_ejecta*3.*(n_ej-3.)/(n_ej*4.*CONST_PI)/pow(r_crit,3.);
  #else
   print1 ("! Init: geometrical configuration not allowed\n");
   QUIT_PLUTO(1);
  #endif

/*  Set initial shock-radius for boundary conditions*/ 	

/*SD*/
 g_front_shock_radius = R_ejecta;

/*setting coordinate*/
  r = x1;

  us[VX2] = 0.0;
  us[VX3] = 0.0;


  if (r<0){
	us[RHO] = Rho_crit;
	us[VX1] = (r/time);
	us[PRS] = us[DN]*mu/KELVIN*T_ISM;
	}
  else if ((r>=0) && (r <= r_crit)){
		us[RHO] = Rho_crit; //4*g_inputParam[DNST0];
  		us[VX1] = (r/time); //1e4*1e5/UNIT_VELOCITY;
		us[PRS] = us[DN]*mu/KELVIN*T_ISM; //(g_gamma - 1.0)*g_inputParam[ENRG0]/vol;
		}
  else if ((r > r_crit) && (r <= R_ejecta)){
		us[RHO] = Rho_crit*pow(r/r_crit,(-1.*n_ej)); //4*g_inputParam[DNST0];
  		us[VX1] = (r/time); //1e4*1e5/UNIT_VELOCITY;
		us[PRS] = us[DN]*mu/KELVIN*T_ISM; //(g_gamma - 1.0)*g_inputParam[ENRG0]/vol;
		}
  else if ((r > R_ejecta) && (r <= R_WB)){
		us[RHO] = Rho_WB*pow(1./r,s) + Mshell*1/(4*CONST_PI*r*r)*1/sqrt(2*CONST_PI*Dshell*Dshell)*exp(-(r-Rshell)*(r-Rshell)/(2*Dshell*Dshell));
		if (s == 2) us[VX1] = g_inputParam[VDNST]/UNIT_VELOCITY;
	        else us[VX1] = 0.0;
		us[PRS] = us[DN]*mu/KELVIN*T_ISM; //us[DN]/mu/KELVIN*T_ISM;
  		}
  else{          
		//us[RHO] = Rho_ISM*pow(1./r,s); //g_inputParam[DNST0];
		us[RHO] = Rho_WB; //g_inputParam[DNST0];
		us[VX1] = 0.0;
		us[PRS] = us[DN]*mu/KELVIN*T_ISM; //us[DN]/mu/KELVIN*T_ISM;
		}

  us[TRC]  = 0.0;

}
/* ********************************************************************* */
void Analysis (const Data *d, Grid *grid)
/* 
 *
 *
 *********************************************************************** */
{

}

/* ********************************************************************* */
void UserDefBoundary (const Data *d, RBox *box, int side, Grid *grid) 
/*
 *
 *
 *********************************************************************** */
{ 
  int   i, j, k, nv;
  double slp; //,*r1
  //r1 = grid[IDIR].x;
  if (side == X1_BEG){
  	/* -- select the boundary side -- */
  		BOX_LOOP(box,k,j,i){
		slp = grid[0].x[i]/grid[0].x[IBEG];
  	/* -- Loop over boundary zones -- */
		d->Vc[RHO][k][j][i] = d->Vc[RHO][k][j][IBEG]; 
  		d->Vc[VX1][k][j][i] = slp*d->Vc[VX1][k][j][IBEG]; 
  		d->Vc[PRS][k][j][i] = d->Vc[PRS][k][j][IBEG] ;
		}
  }
}

