######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  evoplu.py									
# Author: Robert Brose <robert.brose@mail.com>, 2016
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################
#Implementation of the Pluto-code as source of Hydro-data

#v0.0.1: start of development

__version__='0.0.1'

from os import sys
from os import getenv
import ctypes as C
from time import asctime
from time import localtime
from fipy.tools import parallel
from evoplu.classes import *
from evoplu.prototypes import *
from evoplu.functions import *
from mpi4py import MPI
from numpy import where

m_p   = 1.673e-24						#proton mass in grams
mu    = 13./21.
yr    = 3.156e+7
pc    = 3.08567758e18

outFileName="/lustre/fs17/group/that/rb/PLOTS/Jun_1996/Test_parallel/Plutodata_Test_"
shock_outFileName="/lustre/fs17/group/that/rb/PLOTS/Jun_1996/Test_parallel/Plutodata_Test_SHOCK"


#Import of pluto.so###############################################
#plutodll = C.CDLL(getenv("PATRONDIR")+"/lib/pluto.so")
plutodll = C.CDLL(getenv("PATRONDIR")+"/source/Pluto/pluto.so") #replace later with setpar argument
##################################################################

#get code-dimensions
UNIT_DENSITY  =  C.c_double.in_dll(plutodll,"pyUNIT_DENSITY").value	#Now global, change to self when modularised
UNIT_LENGTH   =  C.c_double.in_dll(plutodll,"pyUNIT_LENGTH").value
UNIT_VELOCITY =  C.c_double.in_dll(plutodll,"pyUNIT_VELOCITY").value
KELVIN	      =  C.c_double.in_dll(plutodll,"pyKELVIN").value
UNIT_TIME  	      =  UNIT_LENGTH/UNIT_VELOCITY

#Statics defined before compiling, e.g. in pluto.h
MAX_OUTPUT_TYPES = 11

#preprocessor statements:
PARABOLIC_FLUX		= C.c_int.in_dll(plutodll,"pyPARABOLIC_FLUX").value
SUPER_TIME_STEPPING	= C.c_int.in_dll(plutodll,"pySUPER_TIME_STEPPING").value
RK_CHEBYSHEV		= C.c_int.in_dll(plutodll,"pyRK_CHEBYSHEV").value
USE_ASYNC_IO		= C.c_int.in_dll(plutodll,"pyUSE_ASYNC_IO").value
PARALLEL		= C.c_int.in_dll(plutodll,"pyPARALLEL").value
SHOW_TIME_STEPS		= C.c_int.in_dll(plutodll,"pySHOW_TIME_STEPS").value
COOLING 		= C.c_int.in_dll(plutodll,"pyCOOLING").value
DIMENSIONS 		= C.c_int.in_dll(plutodll,"pyDIMENSIONS").value
DIMENSIONAL_SPLITTING 	= C.c_int.in_dll(plutodll,"pyDIMENSIONAL_SPLITTING").value
if parallel.procID == 0:
	print "Pluto preprocessor statements:"
	print "PARABOLIC_FLUX:\t\t",PARABOLIC_FLUX		
	print "SUPER_TIME_STEPPING:\t", SUPER_TIME_STEPPING	
	print "RK_CHEBYSHEV:\t\t",RK_CHEBYSHEV		
	print "USE_ASYNC_IO:\t\t",USE_ASYNC_IO		
	print "PARALLEL:\t\t",PARALLEL		
	print "SHOW_TIME_STEPS:\t",SHOW_TIME_STEPS		
	print "COOLING:\t\t",COOLING 		
	print "DIMENSIONS:\t\t",DIMENSIONS 		
	print "DIMENSIONAL_SPLITTING:\t",DIMENSIONAL_SPLITTING 

def main():
	#For testoutput:
	times_file = open("/afs/ifh.de/user/b/broserob/prog_files/CRaccel/patron/source/Pluto/history",'r')
	alllines=times_file.readlines()
	times_file.close()
	timesout=[]
	for i in range(len(alllines)):
		(vn,vt,vs)=alllines[i].split()
		timesout.append(float(vt)/yr)
	timesout=array(timesout)

#timesout=array([0,100,200,300,400,500,600,700,800,900])

	#/*!
	# * Start PLUTO, initialize functions, define data structures and 
	# * handle the main integration loop.
	# *
	# * \param [in] argc Argument counts. 
	# * \param [in] argv Array of pointers to the strings.
	# * \return This function return 0 on normal exit.
	# *
	# *********************************************************************** */
	argc = C.c_int(0)
	argv = C.POINTER(C.c_char)()	
	
	#Set globals originaly defined in globals.h
	C.c_double.in_dll(plutodll,"g_maxCoolingRate").value = 0.1  #/**< The maximum fractional variation due to cooling from one step to the next. */
	C.c_double.in_dll(plutodll,"g_minCoolingTemp").value = 50.0 #/**< The minimum temperature (in K) below which cooling is suppressed. */
	C.c_double.in_dll(plutodll,"g_smallDensity").value  = 1.e-12 #/**< Small value for density fix. */
	C.c_double.in_dll(plutodll,"g_smallPressure").value = 1.e-12 #/**< Small value for pressure fix. */


	#int    nv, idim, err;
	nv   = C.c_int()
	idim = C.c_int()
        err  = C.c_int()		
  	#char
	first_step = C.c_char("1")
	last_step  = C.c_char("0")
	#double scrh 		#Maximal mach number(?)
	scrh = C.c_double()
	#Data   data 		#Data structue
	data = Data()
	#time_t  tbeg, tend 	#time_t class
	time_t = C.c_uint64
	tbeg = time_t()
	tend = time_t()
	#Riemann_Solver *Solver #Pointer to solver
	Solver = C.POINTER(Riemann_Solver)()
	#Grid      grd[3]	#Grid definition
	grd = (Grid * 3)()   #To be figured out
	#Time_Step Dts
	Dts = Time_Step()		
	#Cmd_Line cmd_line	#?
	cmd_line = Cmd_Line()
	#Input  ini
	ini = Input()
	#Output *output	
	output = C.POINTER(Output)()

	prank = C.c_int()

	if PARALLEL:
   		AL_Init(argc, argv)
		
		pyMPI_1(C.byref(prank))
		C.c_int.in_dll(plutodll, "prank").value = prank.value
		#replaces #MPI_Comm_rank (MPI_COMM_WORLD, &prank);
		
  	Initialize(argc, argv, C.byref(data), C.byref(ini), grd, C.byref(cmd_line))
	#print data.Vc[0][0][0][75000] #Acsess initial conditions seems to work

	#double *dbl_pnt;
	dbl_pnt = C.POINTER(C.c_double)(C.c_double(1.0))
	#int    *int_pnt;
	int_pnt = C.POINTER(C.c_int)(C.c_int(1))
	if parallel.procID == 0:
		print "> Basic data type:\n"
		print "  sizeof (char)     = ", sys.getsizeof(C.c_char("c"))
		print "  sizeof (uchar)    = ", sys.getsizeof(C.c_ubyte(0))
		print "  sizeof (int)      = ", sys.getsizeof(C.c_int(1))
		print "  sizeof (*int)     = ", sys.getsizeof(int_pnt)
		print "  sizeof (float)    = ", sys.getsizeof(C.c_float(1.0))
		print "  sizeof (double)   = ", sys.getsizeof(C.c_double(1.0))
		print "  sizeof (*double)  = ", sys.getsizeof(dbl_pnt)
	
#/* -- initialize members of Time_Step structure -- */

	Dts.cmax     = Array1D(NMAX_POINT(), sys.getsizeof(C.c_double(1.0)), C.c_double)
	Dts.inv_dta  = 0.0
	Dts.inv_dtp  = 0.0
	Dts.dt_cool  = 1.e38
	Dts.cfl      = ini.cfl
	Dts.cfl_par  = ini.cfl_par
	Dts.rmax_par = ini.rmax_par
	Dts.Nsts     = Dts.Nrkc = 0

	Solver = SetSolver(ini.solv_type) #not sure whether type is correct...

  	time(C.byref(tbeg));
  	C.c_int.in_dll(plutodll,"g_stepNumber").value = 0;

# -- Setup done(?) --#

	#extracting run-relevant parameters
	RRES = 	C.c_int.in_dll(plutodll,"NX1_TOT").value #Includes Ghost-cells

#output to txt-file, PARALLEL conform?
	Mhd = GetMhdArrays(data, grd, RRES)
	comm = MPI.COMM_WORLD
	comm.Barrier
	Mhd=CombineMhdArrays(comm,Mhd,RRES)
	timesout=WriteMhd(Mhd,g_time()*UNIT_TIME/yr,timesout,outFileName)
		
#Variable for shock positions
	shock=[]
	rfs=0
	rrs=0
	rfs_old=0
	rrs_old=0
	time_old=0
	vfs=0
	vrs=0

#/* -- print additional information -- */
	if parallel.procID==0:
		print "Inner and outer boundarys #",parallel.procID,": ", Mhd[0][0], Mhd[0][-1]


#/* --------------------------------------------------------
#    Check if restart is necessary. 
#    If not, write initial condition to disk.
#   ------------------------------------------------------- */
   
	if cmd_line.restart == 1:
		Restart(C.byref(ini), cmd_line.nrestart, 1, grd)
	elif cmd_line.h5restart == 1:
		if parallel.procID==0:
			print "h5restart not supported...exit"
		sys.exit(0)
		#Restart(&ini, cmd_line.nrestart, 4, grd)
	elif (cmd_line.write):
		CheckForOutput(C.byref(data), C.byref(ini), grd)
		CheckForAnalysis(C.byref(data), C.byref(ini), grd)
	
	if parallel.procID==0:
		print "> Starting computation... \n\n"

#/* =====================================================================
#          M A I N      L O O P      S T A R T S      H E R E
#   ===================================================================== */
#ifndef USE_ASYNC_IO  /* -- Standard loop, don't use Asynchrouns I/O -- */

	while (int(last_step.value)!=1):
		#/* ------------------------------------------------------
		#    Check if this is the last integration step:
		#    - final tstop has been reached: adjust time step 
		#    - or max number of steps has been reached
		#   ------------------------------------------------------ */ 

		if ((g_time() + g_dt()) >= ini.tstop*(1.0 - 1.e-8)):
			C.c_double.in_dll(plutodll,"g_dt").value   = (ini.tstop - g_time())
			last_step.value = '1'
		  
		if (C.c_int.in_dll(plutodll,"g_stepNumber").value == cmd_line.maxsteps and cmd_line.maxsteps > 0):
			last_step.value = '1'
	
#  /* ------------------------------------------------------
#                Dump log information
#     ------------------------------------------------------ */

		if (C.c_int.in_dll(plutodll,"g_stepNumber").value % ini.log_freq == 0):
			if parallel.procID==0:
				sys.stdout.write('step:{0} ; t = {1:10.4e} ; dt = {2:10.4e} ; {3:d} % ; [{4:f}, {5:d}'.format(\
				C.c_int.in_dll(plutodll,"g_stepNumber").value,\
				g_time(),\
				g_dt(),\
				int(100.0*g_time()/ini.tstop),\
				C.c_double.in_dll(plutodll,"g_maxMach").value,\
				C.c_int.in_dll(plutodll,"g_maxRiemannIter").value))
		#/*      if (g_maxRootIter > 0) print1 (", root it. # = %d",g_maxRootIter);  */
			if (PARABOLIC_FLUX and SUPER_TIME_STEPPING):
				if parallel.procID==0:			       
					sys.stdout.write(", Nsts = ",Dts.Nsts)
			if (PARABOLIC_FLUX and RK_CHEBYSHEV):
				if parallel.procID==0:
					sys.stdout.write(", Nrkc = ",Dts.Nrkc)
			if parallel.procID==0:
				print ("]")      

#  /* ------------------------------------------------------
#       check if it's time to write or perform analysis
#     ------------------------------------------------------ */
		if ((not first_step) and  (not int(last_step.value)) and cmd_line.write):
			CheckForOutput(C.byref(data), C.byref(ini), grd)
			CheckForAnalysis(C.byref(data), C.byref(ini), grd)

		#MHD-output
		timesout=WriteMhd(Mhd,g_time()*UNIT_TIME/yr,timesout,outFileName)


		#Get shock properties
		if C.c_int.in_dll(plutodll,"g_stepNumber").value%1000 == 0: 
			if comm.Get_rank()==0:
				rfs,rrs,vfs,vrs,i,j=getShockProperties(Mhd,rfs_old,rrs_old,g_time()*UNIT_TIME,time_old)
				time_old=g_time()*UNIT_TIME
				rfs_old=rfs
				rrs_old=rrs
				shock.append([g_time()*UNIT_TIME/yr,rfs,rrs, vfs, vrs,i,j])

#  /* ------------------------------------------------------
#      Advance solution array by a single time step
#      g_dt() = dt(n)
#     ------------------------------------------------------ */

		if (cmd_line.jet != -1):
			SetJetDomain(C.byref(data), cmd_line.jet, ini.log_freq, grd) 
		err = Integrate(C.byref(data), Solver, C.byref(Dts), grd)
		if (cmd_line.jet != -1):
			UnsetJetDomain(C.byref(data), cmd_line.jet, grd) 

#  /* ------------------------------------------------------
#       Integration didn't go through. Step must
#       be redone from previously saved solution.
#     ------------------------------------------------------ */
#/*
		if (err != 0):
			if parallel.procID==0:
				print "! Step failed. exit... "
			sys.exit(0)
#			print  ("! Step failed. Re-trying\n")
#			zones with problems must be tagged with MINMOD_FLAG and HLL_FLAG
#			time step should be halved
#			GET_SOL(&data);
		    #*/

#  /* ------------------------------------------------------
#      Increment time, t(n+1) = t(n) + dt(n)
#     ------------------------------------------------------ */
		#check if time+timestep exceeds desired output time
		if g_time() + g_dt() > NextOutputTime(g_time(),timesout):
			C.c_double.in_dll(plutodll,"g_dt").value = NextOutputTime(g_time(),timesout)-g_time()
			if parallel.procID==0:
				print "Timestep changed...", g_time(), g_dt(), NextOutputTime(g_time(),timesout)
				#print timesout[18:23]

		C.c_double.in_dll(plutodll,"g_time").value += g_dt()

#  /* ------------------------------------------------------
#      Show the time step ratios between the actual g_dt
#      and the advection, diffusion and cooling time scales.
#     ------------------------------------------------------ */

    		if SHOW_TIME_STEPS == True:
			if (C.c_int.in_dll(plutodll,"g_stepNumber").value % ini.log_freq == 0):
				#double cg, dta, dtp, dtc;
				dta = 1.0/Dts.inv_dta
				if Dts.inv_dtp == 0:
					dtp = float('Inf')
				else:
					dtp = 0.5/Dts.inv_dtp
				dtc = Dts.dt_cool
				if PARALLEL:
					if parallel.procID==0:
						print "Not yet suported..."
					sys.exit(0)
					#complete later for mpi-support
					cg=0
					#MPI_Allreduce (&dta, &cg, 1, MPI_DOUBLE, MPI_MIN, MPI_COMM_WORLD);
					comm.allreduce(dta,cg,op=MPI.MIN)
					dta = cg;

					#MPI_Allreduce (&dtp, &cg, 1, MPI_DOUBLE, MPI_MIN, MPI_COMM_WORLD);
					comm.allreduce(dtp,cg,op=MPI.MIN)
					dtp = cg;

					#MPI_Allreduce (&dtc, &cg, 1, MPI_DOUBLE, MPI_MIN, MPI_COMM_WORLD);
					comm.allreduce(dtp,cg,op=MPI.MIN)
					dtc = cg;
	

#   print1 ("[dt/dt(adv) = %10.4e, dt/dt(par) = %10.4e, dt/dt(cool) = %10.4e]\n",
#                g_dt()/dta, g_dt()/dtp, g_dt()/dtc);
				if parallel.procID==0:
					sys.stdout.write('  dt(adv)  = cfl x {0:10.4e};\n'.format(dta))
					sys.stdout.write('  dt(par)  = cfl x {0:10.4e};\n'.format(dtp))
					sys.stdout.write('  dt(cool) =       {0:10.4e};\n'.format(dtc))


#  /* ------------------------------------------------------
#      Get next time step dt(n+1).
#      Do it every two steps if cooling or dimensional
#      splitting are used.
#     ------------------------------------------------------ */

		if (COOLING == False) and ((DIMENSIONS == 1) or (DIMENSIONAL_SPLITTING == False)):
			C.c_double.in_dll(plutodll,"g_dt").value = NextTimeStep(C.byref(Dts), C.byref(ini), grd)
		else:
			if (C.c_int.in_dll(plutodll,"g_stepNumber").value%2 == 1):
				C.c_double.in_dll(plutodll,"g_dt").value = NextTimeStep(C.byref(Dts), C.byref(ini), grd)
		
	

#  /* ------------------------------------------------------
#          Global MPI reduction operations
#     ------------------------------------------------------ */
  
		if PARALLEL == True:
			#MPI_Allreduce (&g_maxMach, &scrh, 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);
			#g_maxMach = scrh;
			#MPI_Allreduce (&g_maxRiemannIter, &nv, 1, MPI_INT, MPI_MAX, MPI_COMM_WORLD);
			#g_maxRiemannIter = nv;
			pyMPI_2(0)
			
    		C.c_int.in_dll(plutodll,"g_stepNumber").value = C.c_int.in_dll(plutodll,"g_stepNumber").value + 1
    
		first_step = 0
		
#  /* ------------------------------------------------------
#          Fill MHD-array 
#     ------------------------------------------------------ */ 	
		Mhd = GetMhdArrays(data, grd, RRES)		


		Mhd = GetMhdArrays(data, grd, RRES)
		comm = MPI.COMM_WORLD
		comm.Barrier
		Mhd=CombineMhdArrays(comm,Mhd,RRES)
#/* =====================================================================
 #         M A I N       L O O P      E N D S       H E R E 
 #  ===================================================================== */

	if (cmd_line.write):
		CheckForOutput(C.byref(data), C.byref(ini), grd)
		CheckForAnalysis (C.byref(data), C.byref(ini), grd)
		if USE_ASYNC_IO:
	#		Async_EndWriteData (&ini);
			if parallel.procID==0:
				print "USE_ASYNC_IO not supported"
			sys.exit(0)

#output to txt-file
	Mhd = GetMhdArrays(data, grd, RRES)
	comm = MPI.COMM_WORLD
	comm.Barrier
	Mhd=CombineMhdArrays(comm,Mhd,RRES)
	timesout=WriteMhd(Mhd,g_time()*UNIT_TIME/yr,timesout,outFileName)


#write shock positions to file
	if comm.Get_rank()==0:
	 	shock_file = open(shock_outFileName,'w')
		for i in range(len(shock)):
			shock_file.write(str(shock[i][0])+"\t"+str(shock[i][1])+"\t"+str(shock[i][2])+"\t"+str(shock[i][3])+"\t"+str(shock[i][4])+"\t"+str(shock[i][5])+"\t"+str(shock[i][6])+"\n")
		shock_file.close
#	print shock

	if PARALLEL:
		pyMPI_Barrier(0)
		if parallel.procID==0:
			sys.stdout.write('\n> Total allocated memory  {0:6.2f} Mb (proc #{1:d})\n'.format(float(C.c_int.in_dll(plutodll,"g_usedMemory").value/1.e6),prank.value));
		pyMPI_Barrier(0)

	else:
		sys.stdout.write('\n> Total allocated memory  {0:6.2f} Mb\n'.format(float(C.c_int.in_dll(plutodll,"g_usedMemory").value/1.e6)))

	time(C.byref(tend))
	C.c_double.in_dll(plutodll,"g_dt").value = tend.value - tbeg.value

	if parallel.procID==0:
		sys.stdout.write('> Elapsed time              {0}\n'.format(TotalExecutionTime(g_dt())))
		sys.stdout.write('> Average time/step       {0:10.2e}  (sec)  \n'.format((tend.value-tbeg.value)/float(C.c_int.in_dll(plutodll,"g_stepNumber").value)))
		sys.stdout.write('> Local time                {0}\n'.format(asctime(localtime(tend.value))));
		sys.stdout.write("> Done\n")

	FreeArray4D(data.Vc)
	if PARALLEL:
		pyMPI_Barrier(0)
		AL_Finalize()

	return(0);



if __name__ == "__main__":sys.exit(main())
