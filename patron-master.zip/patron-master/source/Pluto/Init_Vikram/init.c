/* ///////////////////////////////////////////////////////////////////// */
/*! 
  Supernova explosion 1-D spherical symetry
  following vikram dwarkadas 1998
*/
/* ///////////////////////////////////////////////////////////////////// */
#include "pluto.h"

/* ********************************************************************* */
void Init (double *us, double x1, double x2, double x3)
/*
 *
 *
 *
 *********************************************************************** */
{
  double ve, time, Rho_ISM, A, E_Expl, M_ejecta, g_gamma, T_ISM, mu, R_ejecta, kb,UNIT_TIME,r;


  double Msun=1.99e33;
  double M=1.4*Msun;
  UNIT_TIME=UNIT_LENGTH/UNIT_VELOCITY;


  time		= g_inputParam[TIME0]/UNIT_TIME;	//Starting time of simulation
  g_gamma 	= g_inputParam[GAMMA];
  mu 		= 13.0/21.0;
  T_ISM 	= g_inputParam[TISM];
  M_ejecta	= 1.4*Msun/(UNIT_DENSITY*pow(UNIT_LENGTH,3));
  Rho_ISM	= g_inputParam[DNST0]*CONST_mp/UNIT_DENSITY;
  E_Expl	= g_inputParam[ENRG0]/(UNIT_DENSITY*UNIT_VELOCITY*UNIT_VELOCITY*UNIT_LENGTH*UNIT_LENGTH*UNIT_LENGTH);
  
  kb		= 1.380658e-16;

		

  //print1 ("Konfiguration:\nEjecta_Masse = %f\n",M_ejecta);	
/* --------------------------------------------------
    dr is the size of the initial energy deposition 
    region: 2 ghost zones.
   -------------------------------------------------- */

  #if DIMENSIONS == 1
	ve 		= pow(E_Expl/(6*M_ejecta),1/2.);
	A		= pow(6,3/2.)/(8*CONST_PI)*pow(M_ejecta,5/2.)/pow(E_Expl,3/2.);
  	R_ejecta	= -ve*time*log(Rho_ISM*pow(time,3.)/A);  //0.1*CONST_pc/UNIT_LENGTH;
/*	print1 ("R: %f \n", R_ejecta);
	print1 ("A: %f \n", A);
	print1 ("v: %f \n", ve);	
	print1 ("rho: %f \n", Rho_ISM);
	print1 ("time: %f \n", time);
	print1 ("rho: %f \n", A*exp(-1000/(time*ve))*pow(time,-3.0));
	QUIT_PLUTO(1);*/

  #else
   print1 ("! Init: geometrical configuration not allowed\n");
   QUIT_PLUTO(1);
  #endif

/* ---------------------------------------
     compute region volume 
   --------------------------------------- */

  /*#if (GEOMETRY == SPHERICAL   && DIMENSIONS == 1)
   vol = 4.0/3.0*CONST_PI*r_crit*r_crit*r_crit;
  #else
   print1 ("! Init: geometrical configuration not allowed\n");
   QUIT_PLUTO(1);
  #endif*/

  r = x1;

  /*print1("r_crit=%f \n",r_crit);	
  print1("R_ejecta=%f \n",R_ejecta);
  print1("Rho_crit=%f \n",Rho_crit);
  print1("Rho_ISM=%f \n",Rho_ISM);
  print1("v_0=%f \n",v_0);
  print1("E=%f \n",E_Expl);*/
  //QUIT_PLUTO(1);

  us[VX2] = 0.0;
  us[VX3] = 0.0;


  if (r<0){
	us[RHO] = A*exp(-r/(time*ve))*pow(time,-3.0);
	us[VX1] = (r/time);
	us[PRS] = us[DN]*mu/KELVIN*T_ISM;
	}
  else if ((r>=0) && (r <= R_ejecta)){
		us[RHO] = A*exp(-r/(time*ve))*pow(time,-3.0); //4*g_inputParam[DNST0];
  		us[VX1] = (r/time); //1e4*1e5/UNIT_VELOCITY;
		us[PRS] = us[DN]*mu/KELVIN*T_ISM; //(g_gamma - 1.0)*g_inputParam[ENRG0]/vol;
		}
  else{          
		us[RHO] = Rho_ISM; //g_inputParam[DNST0];
		us[VX1] = 0.0;
		us[PRS] = us[DN]*mu/KELVIN*T_ISM; //us[DN]/mu/KELVIN*T_ISM;
		}

  us[TRC]  = 0.0;

/*ENRG0                1.905124786e18  
DNST0                4e-7  
GAMMA                1.6667*/
}
/* ********************************************************************* */
void Analysis (const Data *d, Grid *grid)
/* 
 *
 *
 *********************************************************************** */
{

}

/* ********************************************************************* */
void UserDefBoundary (const Data *d, RBox *box, int side, Grid *grid) 
/*
 *
 *
 *********************************************************************** */
{ 
  int   i, j, k, nv, revbin;
  double slp,A_rho,b_rho;
  if (grid[0].x[1]-grid[0].x[0] <= 1e14){revbin=10+90;}
  else if (grid[0].x[1]-grid[0].x[0] <= 1e15){revbin=10+10;}
  else {revbin = 10+5;}	 	

  if (side == X1_BEG){
  /* -- select the boundary side -- */
  BOX_LOOP(box,k,j,i){
	slp   = grid[0].x[i]/grid[0].x[IBEG];
	b_rho = log((d->Vc[RHO][k][j][IBEG+10])/(d->Vc[RHO][k][j][IBEG+revbin]) )/(grid[0].x[IBEG+10]-grid[0].x[IBEG+revbin]);
	A_rho = (d->Vc[RHO][k][j][IBEG+10] - d->Vc[RHO][k][j][IBEG+revbin])/(exp(b_rho*grid[0].x[IBEG+10])-exp(b_rho*grid[0].x[IBEG+revbin]));
        //print1 ("A and b, x(real), rho(real) %e. %e %e %e \n", A_rho*UNIT_DENSITY, b_rho/UNIT_LENGTH, grid[0].x[i]*UNIT_LENGTH,A_rho*UNIT_DENSITY*exp(b_rho*grid[0].x[i]) );
	/* -- Loop over boundary zones -- */
	d->Vc[RHO][k][j][i] = A_rho*exp(grid[0].x[i]*b_rho);
	d->Vc[VX1][k][j][i] = slp*d->Vc[VX1][k][j][IBEG]; 
	d->Vc[PRS][k][j][i] = d->Vc[PRS][k][j][IBEG];
  }
}
}

