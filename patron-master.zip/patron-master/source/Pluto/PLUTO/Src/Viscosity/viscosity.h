/* -----------------------------------------------
             Viscosity header
   ----------------------------------------------- */

void ViscousFlux (Data_Arr , double **, double **, double **, int, int, Grid *);
void Visc_nu(double *, double, double, double, double *, double *);

