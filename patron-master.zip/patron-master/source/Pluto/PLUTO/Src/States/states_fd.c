#include "pluto.h"

/* ************************************************************* */
void States (const State_1D *state, int beg, int end, Grid *grid)
/* 
 *  PURPOSE
 *    
 *    Empty function. Should be used with finite-difference    
 *
 **************************************************************** */
{


}
