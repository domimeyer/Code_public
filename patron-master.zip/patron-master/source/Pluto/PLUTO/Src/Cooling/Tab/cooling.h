/* ############################################################
      
     FILE:     cooling.h

     PURPOSE:  contains common definitions for the 
               whole CODE

   ############################################################ */

double GetMaxRate (double *, double *, double);
double MeanMolecularWeight  (double *);
void Radiat (double *, double *);










