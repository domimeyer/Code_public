/* ///////////////////////////////////////////////////////////////////// */
/*! 
  Supernova explosion 1-D spherical symetry
*/
/* ///////////////////////////////////////////////////////////////////// */
#include "pluto.h"

/* ********************************************************************* */
void Init (double *us, double x1, double x2, double x3)
/*
 *
 *
 *
 *********************************************************************** */
{
  double r_crit, vol, r, mu, T_ISM, M_ejecta, R_ejecta, Rho_ISM, E_Expl, Rho_crit, kb, time, x,B,f0,L;
  double n_ej;
  double R_wind, R_bubble, Pho_norm, Pho_const, Prs_norm, Prs_const, V_wind,Ml;
 
  double Msun=1.99e33;
  double M=g_inputParam[MEJEC]*Msun;
  double n=g_inputParam[EEJEC];
  double s=g_inputParam[SDNST];
 

  double UNIT_pc= UNIT_LENGTH/CONST_pc;
  double UNIT_TIME = UNIT_LENGTH/UNIT_VELOCITY;
  double UNIT_MASS = UNIT_DENSITY*pow(UNIT_LENGTH,3.);
  double UNIT_yr= 31536000/UNIT_TIME;
  double UNIT_PRESSURE = UNIT_DENSITY*UNIT_VELOCITY*UNIT_VELOCITY;


  time		= g_inputParam[TIME0]/UNIT_TIME;	//Starting time of simulation
  n_ej      	= n;
  g_gamma 	= g_inputParam[GAMMA];
  mu 		= 13.0/21.0;
  T_ISM 	= 1e4;
  M_ejecta	= M/UNIT_MASS;
  R_wind	= g_inputParam[RWIND]/UNIT_pc;
  R_bubble	= g_inputParam[RBUBBLE]/UNIT_pc;
  V_wind	= g_inputParam[VWIND]/UNIT_VELOCITY;
  Ml		= (g_inputParam[dMdt]*Msun/UNIT_yr)/UNIT_MASS;
  Prs_norm      = g_inputParam[NORMPRS]/UNIT_PRESSURE;
  Pho_const     = g_inputParam[CONSTDNS]*CONST_mp/UNIT_DENSITY;
  Prs_const     = g_inputParam[CONSTPRS]/UNIT_PRESSURE;

  Pho_norm    	= (Ml/(4*CONST_PI *V_wind));
  // B=g_inputParam[LOGISTICB];

  if (s==0){	
	 Rho_ISM= g_inputParam[DNST0]*CONST_mp*1.4/UNIT_DENSITY;} /// ????????????
  else if (s==2){
  	 Rho_ISM= g_inputParam[MDNST]*Msun/(CONST_PI*1e7)/(4.*CONST_PI*g_inputParam[VDNST])/	  UNIT_MASS*UNIT_TIME*UNIT_VELOCITY;}
  else if (s==3){
	Rho_ISM=g_inputParam[DNST0]*CONST_mp/UNIT_DENSITY;}
  else{	  
	 print1 ("! Init: Value s=%f not supported\n",s);
	 QUIT_PLUTO(1);}
  E_Expl	= g_inputParam[ENRG0]/(UNIT_DENSITY*UNIT_VELOCITY*UNIT_VELOCITY*UNIT_LENGTH*UNIT_LENGTH*UNIT_LENGTH);
  kb		= 1.380658e-16;
		
  x		= g_inputParam[XPAR];

  #if DIMENSIONS == 1
  	r_crit		= sqrt(10./3.*E_Expl/M_ejecta*(n_ej-5.)/(n_ej-3)*(1.-3./n_ej*1./pow(x,(n_ej-3.)))/(1.-5./n_ej*1./pow(x,(n_ej-5.))))*time;//
	R_ejecta	= r_crit*x;
  	Rho_crit	= M_ejecta*3.*(n_ej-3.)/(n_ej*4.*CONST_PI)/pow(r_crit,3.);
  #else
   print1 ("! Init: geometrical configuration not allowed\n");
   QUIT_PLUTO(1);
  #endif

/*  Set initial shock-radius for boundary conditions*/ 	
  //g_front_shock_radius = R_ejecta;

/*setting coordinate*/
  r = x1;

  us[VX2] = 0.0;
  us[VX3] = 0.0;


  if (r<0){
	us[RHO] = Rho_crit;
	us[VX1] = (r/time);
	us[PRS] = us[RHO]*mu/KELVIN*T_ISM;
	}
  else if ((r>=0) && (r <= r_crit)){
		us[RHO] = Rho_crit; //4*g_inputParam[DNST0];
  		us[VX1] = (r/time); //1e4*1e5/UNIT_VELOCITY;
		us[PRS] = us[RHO]*mu/KELVIN*T_ISM; //(g_gamma - 1.0)*g_inputParam[ENRG0]/vol;
		}
  else if ((r > r_crit) && (r <= R_ejecta)){
		us[RHO] = Rho_crit*pow(r/r_crit,(-1.*n_ej)); //4*g_inputParam[DNST0];
  		us[VX1] = (r/time); //1e4*1e5/UNIT_VELOCITY;
		us[PRS] = us[RHO]*mu/KELVIN*T_ISM; //(g_gamma - 1.0)*g_inputParam[ENRG0]/vol;
		}
  else if ((r > R_ejecta) && (r <= R_wind)){  //Free wind zone          
		us[RHO] = Pho_norm*pow(1./r,2); 
		us[VX1] = V_wind;
		us[PRS] = Prs_norm*pow(1./(r*UNIT_pc),10./3.);
		}
  else if ((r > R_wind) && (r <= R_bubble)){ //Bubble zone         
                us[RHO] = Pho_const;//+(Pho_norm*pow(1./R_wind,2)-); 
		us[VX1] = 0;//V_wind*exp(-(r*UNIT_pc)+R_wind);
		us[PRS] = Prs_const; 
		//	d->Vc[PRS][k][j][i] = cs*cs/g_gamma*pow(rho,g_gamma);
		}
  else {             //ISM
		us[RHO] = Rho_ISM; //g_inputParam[DNST0];
		us[VX1] = g_inputParam[VDNST]/UNIT_VELOCITY;
		us[PRS] = us[RHO]*mu/KELVIN*T_ISM; //us[DN]/mu/KELVIN*T_ISM;
		}
  /*
  if ((B!=0) && (abs(r-R_Wind)<0.1*R_Wind){
      if ( Pho_const > Pho_norm*pow(1./R_wind,2)  ){
	B=-abs(B);
	f0=Pho_norm*pow(1./R_wind,2);
	L=Pho_const-f0;
      }else{
	B=abs(B);
	f0=Pho_const;
	L=Pho_norm*pow(1./R_wind,2)-f0;
      }
      us[RHO]=f0+L/(1+exp(B*(r-R_wind)));
      us[VX1]=V_wind/(1+exp(abs(B)*(r-R_wind)))
      us[PRS]
  }

  us[TRC]  = 0.0;
  */
}
/* ********************************************************************* */
void Analysis (const Data *d, Grid *grid)
/* 
 *
 *
 *********************************************************************** */
{

}

/* ********************************************************************* */
void UserDefBoundary (const Data *d, RBox *box, int side, Grid *grid) 
/*
 *
 *
 *********************************************************************** */
{ 
  int i0,i,j,k,nv;
  double r_crit, vol, r, mu, T_ISM, M_ejecta, R_ejecta, Rho_ISM, E_Expl, Rho_crit, kb, time, x,r0,t0,t;
  
  double n_ej;
  double *x1 ;
  double Msun=1.99e33;
  double M=g_inputParam[MEJEC]*Msun;
  double n=g_inputParam[EEJEC];
  double s=g_inputParam[SDNST];
  double UNIT_TIME = UNIT_LENGTH/UNIT_VELOCITY;
  double UNIT_MASS = UNIT_DENSITY*pow(UNIT_LENGTH,3.);
  double UNIT_yr= 31536000/UNIT_TIME;
 


  time		= g_inputParam[TIME0]/UNIT_TIME;	//Starting time of simulation
  n_ej      	= n;
  g_gamma 	= g_inputParam[GAMMA];
  mu 		= 13.0/21.0;
  T_ISM 	= 1e4;
  M_ejecta	= M/UNIT_MASS;
  r0            = 195;
  i0            = 10481;
  x1            = grid[IDIR].xgc;
  t0            = 1.;
  t             = 2.;

  if (s==0){	
	 Rho_ISM= g_inputParam[DNST0]*1.4*CONST_mp/UNIT_DENSITY;} //???
  else if (s==2){
  	 Rho_ISM= g_inputParam[MDNST]*Msun/(CONST_PI*1e7)/(4.*CONST_PI*g_inputParam[VDNST])/UNIT_MASS*UNIT_TIME*UNIT_VELOCITY;}
  else if (s==3){
	Rho_ISM=g_inputParam[DNST0]*CONST_mp/UNIT_DENSITY;}
  else{	  
	 print1 ("! Init: Value s=%f not supported\n",s);
	 QUIT_PLUTO(1);}
  E_Expl	= g_inputParam[ENRG0]/(UNIT_DENSITY*UNIT_VELOCITY*UNIT_VELOCITY*UNIT_LENGTH*UNIT_LENGTH*UNIT_LENGTH);
  kb		= 1.380658e-16;
		
  x		= g_inputParam[XPAR];

  #if DIMENSIONS == 1
  	r_crit		= sqrt(10./3.*E_Expl/M_ejecta*(n_ej-5.)/(n_ej-3)*(1.-3./n_ej*1./pow(x,(n_ej-3.)))/(1.-5./n_ej*1./pow(x,(n_ej-5.))))*time;//
	R_ejecta	= r_crit*x;
  	Rho_crit	= M_ejecta*3.*(n_ej-3.)/(n_ej*4.*CONST_PI)/pow(r_crit,3.);
  #else
   print1 ("! Init: geometrical configuration not allowed\n");
   QUIT_PLUTO(1);
  #endif
   

  if (side == X1_BEG){
  /* -- select the boundary side -- */
  	BOX_LOOP(box,k,j,i){
  /* -- Loop over boundary zones -- */
		d->Vc[RHO][k][j][i] = Rho_crit*pow(r_crit/(r_crit+(r_crit/time)*g_time),3.); 
  		d->Vc[VX1][k][j][i] = r_crit/time*(grid[0].x[i]/(r_crit+(r_crit/time)*g_time)); 
  		d->Vc[PRS][k][j][i] = Rho_crit*pow(r_crit/(r_crit+(r_crit/time)*g_time),3.)*mu/KELVIN*T_ISM;
	}
  }
  if ((side == 0)){
    TOT_LOOP(k,j,i){
      // r  = x1[i];
      if (d->Vc[PRS][k][j][i] <1.e-7){
	d->Vc[PRS][k][j][i] =1.e-7;
	//d->flag[k][j][i]   |= FLAG_INTERNAL_BOUNDARY; 
      } 
    }
  }
}

