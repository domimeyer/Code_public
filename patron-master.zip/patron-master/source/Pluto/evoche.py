#contains Hydro-profiles of Chevalier (1982)

from numpy import array
from numpy import transpose
from numpy import savetxt
from numpy import zeros
from numpy import pi

Msun = 2.0e33
yr   = 3.156e7
pc   = 3.086e18
m_p  = 1.6726e-24
kb   = 1.380658e-16

#arrays with self-similar solutions
x=array([0.935,0.94,0.95,0.96,0.97,0.98,0.99,0.995,1.0,1.01,1.02,1.04,1.06,1.08,1.10,1.12,1.14,1.16,1.18,1.181])
rhorel=array([1.336,1.335,1.357,1.315,1.225,1.075,0.826,0.621,0.0,0.219,0.297,0.411,0.503,0.586,0.667,0.746,0.826,0.909,0.995,1.0])
prerel=array([0.471,0.504,0.564,0.615,0.660,0.697,0.727,0.739,0.744,0.748,0.755,0.774,0.796,0.821,0.849,0.880,0.915,0.954,0.997,1.0])
urel=array([1.253,1.237,1.211,1.189,1.171,1.155,1.141,1.135,1.129,1.117,1.105,1.084,1.065,1.049,1.035,1.023,1.013,1.006,1.0,1.0]) #/1.253

n_ism=1.0

def R_c(t):
	A=1.2
	M=1.4*Msun
	E=1e51
	g7=25./(21.*pi)*E**2/M
	q=n_ism*m_p #rho ISM
	n=7.
	s=0.
	t1=t*yr
	Rc=(A*g7/q)**(1./(n-s))*(t1)**((n-3.)/(n-s))
	return Rc

def RFS(t):
	return 1.181*R_c(t)

def RRS(t):
	return 0.935*R_c(t)

def UFS(t):
	t1=t*yr
	return RFS(t)*4/(7.*t1)

def URS(t):
	t1=t*yr
	return RRS(t)*4/(7.*t1)

t=500

print RFS(t)/pc, RRS(t)/pc
print UFS(t)/1e5
print n_ism*UFS(t)**2.*m_p*9/16.


outFileName="/lustre/fs17/group/that/rb/PLOTS/Jun_1996/Plutodata_Chev_"
TIME=str(t).zfill(5)

Mhd   = zeros((5,len(x)))
Mhd[0]= x*R_c(t)
Mhd[1]= rhorel*4*n_ism
Mhd[2]= urel*UFS(t)*3/4.
Mhd[3]= prerel*n_ism*UFS(t)**2.*m_p*3/4. #9/16.	#dynamic pressure?, 3/4?
Mhd[4]= Mhd[3]/(Mhd[1]*kb)

fname=outFileName+TIME
savetxt(fname, Mhd.transpose(), fmt='%.18e', delimiter=' ', newline='\n', header='r rho v prs T', footer='', comments='# ')
