#LD_PRELOAD=/usr/lib/libstdc++.so.6
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:${PWD}
rm pluto.so

#works, including original main
#mpicc adv_flux.o arrays.o boundary.o check_states.o cmd_line_opt.o entropy_switch.o findshock.o flag_shock.o flag.o flatten.o get_nghost.o init.o int_bound_reset.o input_data.o mappers3D.o parse_file.o plm_coeffs.o set_indexes.o set_geometry.o set_output.o tools.o var_names.o visc_flux.o  bin_io.o colortable.o initialize.o jet_domain.o main.o restart.o show_config.o set_image.o setup.o set_grid.o startup.o split_source.o userdef_output.o write_data.o write_tab.o write_img.o write_vtk.o  update_stage.o  math_lu_decomp.o math_qr_decomp.o math_misc.o math_ode.o math_quadrature.o math_root_finders.o math_table2D.o ppm_states.o ppm_coeffs.o rk_update.o ausm.o eigenv.o fluxes.o mappers.o  prim_eqn.o hll_speed.o hll.o  hllc.o rhs.o riemann.o set_solver.o tvdlf.o roe.o eos.o -lm -shared -o pluto.so

#new for parallel, including parallel libraries, works!!! :-)(parabolic)
#mpicc adv_flux.o arrays.o boundary.o check_states.o cmd_line_opt.o entropy_switch.o findshock.o flag_shock.o flag.o flatten.o get_nghost.o init.o int_bound_reset.o input_data.o mappers3D.o parse_file.o plm_coeffs.o set_indexes.o set_geometry.o set_output.o tools.o var_names.o visc_flux.o  bin_io.o colortable.o initialize.o jet_domain.o main.o restart.o show_config.o set_image.o setup.o set_grid.o startup.o split_source.o userdef_output.o write_data.o write_tab.o write_img.o write_vtk.o  update_stage.o  math_lu_decomp.o math_qr_decomp.o math_misc.o math_ode.o math_quadrature.o math_root_finders.o math_table2D.o ppm_states.o ppm_coeffs.o rk_update.o ausm.o eigenv.o fluxes.o mappers.o  prim_eqn.o hll_speed.o hll.o  hllc.o rhs.o riemann.o set_solver.o tvdlf.o roe.o eos.o al_alloc.o al_decompose.o al_finalize.o al_sort_.o al_sz_get.o al_sz_set.o al_boundary.o al_exchange_dim.o  al_init.o al_subarray_.o al_sz_init.o al_write_array_async.o al_decomp_.o al_exchange.o al_io.o al_sz_free.o al_szptr_.o -lm -shared -o pluto.so

#new for parallel, including parallel libraries, works!!! :-)(weno)
#mpicc adv_flux.o arrays.o boundary.o check_states.o cmd_line_opt.o entropy_switch.o findshock.o flag_shock.o flag.o flatten.o get_nghost.o init.o int_bound_reset.o input_data.o mappers3D.o parse_file.o plm_coeffs.o set_indexes.o set_geometry.o set_output.o tools.o var_names.o visc_flux.o  bin_io.o colortable.o initialize.o jet_domain.o main.o restart.o show_config.o set_image.o setup.o set_grid.o startup.o split_source.o userdef_output.o write_data.o write_tab.o write_img.o write_vtk.o  update_stage.o  math_lu_decomp.o math_qr_decomp.o math_misc.o math_ode.o math_quadrature.o math_root_finders.o math_table2D.o states_weno3.o rk_update.o ausm.o eigenv.o fluxes.o mappers.o  prim_eqn.o hll_speed.o hll.o  hllc.o rhs.o riemann.o set_solver.o tvdlf.o roe.o eos.o al_alloc.o al_decompose.o al_finalize.o al_sort_.o al_sz_get.o al_sz_set.o al_boundary.o al_exchange_dim.o  al_init.o al_subarray_.o al_sz_init.o al_write_array_async.o al_decomp_.o al_exchange.o al_io.o al_sz_free.o al_szptr_.o -lm -shared -o pluto.so

#Test...
mpicc *.o -lm -shared -o pluto.so

#Works in principle, still some unknown symbol(_Z12SetOutputDirPc)
#Src=/afs/ifh.de/user/b/broserob/prog_files/CRaccel/patron/source/Pluto/PLUTO/Src
#Par=/afs/ifh.de/group/that/soft/SL6/opt/pluto/4.1.0/PLUTO/Src/Parallel 
#Hd=/afs/ifh.de/group/that/soft/SL6/opt/pluto/4.1.0/PLUTO/Src/HD
#Id=/afs/ifh.de/group/that/soft/SL6/opt/pluto/4.1.0/PLUTO/Src/EOS/Ideal
#g++ -I${Src} -I${Par} -I${Hd} -I${Id} -Wall -fPIC -c -O2 setup.c
#g++ setup.o -W1 -shared -o pluto.so

#cp pluto.so ${PATRONDIR}/lib/pluto.so
