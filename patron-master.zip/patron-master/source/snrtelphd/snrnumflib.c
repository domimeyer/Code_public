//Author: Igor Telezhinsky. Based on original thesis code 2005 - 2007, revisited 2010, 2015

extern "C"
{
#include "snrnumflib.h"
}

double dabs(double in)
{
	if(in<0)
		return -in;
	else
		return in;
}

void systemrungekuttstep(double x, double h, int n, double *y)
{
    int i;
    
	double *yt = dvector(1,n);
	double *k1 = dvector(1,n);
	double *k2 = dvector(1,n);
	double *k3 = dvector(1,n);
	double *k4 = dvector(1,n);

//	ap::real_1d_array yt;	
//	ap::real_1d_array k1;
//	ap::real_1d_array k2;
//	ap::real_1d_array k3;
//	ap::real_1d_array k4;

//	yt.setbounds(1, n);
//	k1.setbounds(1, n);
//	k2.setbounds(1, n);
//	k3.setbounds(1, n);
//	k4.setbounds(1, n);

	for(i = 1; i <= n; i++)
	{
//		k1(i) = h*f(i, x, y);
		k1[i] = h*f(i, x, y);
	}
	for(i = 1; i <= n; i++)
	{
//		yt(i) = y(i)+0.5*k1(i);
		yt[i] = y[i]+0.5*k1[i];
	}
	for(i = 1; i <= n; i++)
	{
//		k2(i) = h*f(i, x+h*0.5, yt);
		k2[i] = h*f(i, x+h*0.5, yt);
	}
	for(i = 1; i <= n; i++)
	{
//		yt(i) = y(i)+0.5*k2(i);
		yt[i] = y[i]+0.5*k2[i];
	}
	for(i = 1; i <= n; i++)
	{
//		k3(i) = h*f(i, x+h*0.5, yt);
		k3[i] = h*f(i, x+h*0.5, yt);
	}
	for(i = 1; i <= n; i++)
	{
//		yt(i) = y(i)+k3(i);
		yt[i] = y[i]+k3[i];
	}
	for(i = 1; i <= n; i++)
	{
//		k4(i) = h*f(i, x+h, yt);
		k4[i] = h*f(i, x+h, yt);
	}
	for(i = 1; i <= n; i++)
	{
//		y(i) = y(i)+double(k1(i)+2.0*k2(i)+2.0*k3(i)+k4(i))/double(6);
		y[i] = y[i]+(k1[i]+2.0*k2[i]+2.0*k3[i]+k4[i])/(6.0);
	}
	
	free_dvector(yt,1,n);
	free_dvector(k1,1,n);
	free_dvector(k2,1,n);
	free_dvector(k3,1,n);
	free_dvector(k4,1,n);
}

void systemrungekutt(double x, double x1, int m, int n, double *y)
{
	double h;
	h=(x1-x)/(m);
	int i;

	for(i = 0; i <= m-1; i++)
	{
		systemrungekuttstep(x+(i*(x1-x))/(m), h, n, y);
	}
}

///////////////////////////////////////////////////////////////////////////////
float zbrent(float (*func)(float,float), float x1, float x2, float t, float zeta, float tol)
{
	int iter;
	float a=x1,b=x2,c=x2,d,e,min1,min2;
	float fa=(*func)(a,zeta)-t;
	float fb=(*func)(b,zeta)-t;
	float fc,p,q,r,s,tol1,xm;
	
	if ((fa > 0.0 && fb > 0.0) || (fa < 0.0 && fb < 0.0))
	{
//		cout<<"Error in zbrent!"<<endl;
		printf("Error in zbrent!\n");
		exit(1);
	}

	fc=fb;
	for (iter=1;iter<=ITMAX;iter++)
	{
		if((fb > 0.0 && fc > 0.0) || (fb < 0.0 && fc < 0.0))
		{
			c=a;								//Rename a, b, c and adjust bounding interval d.
			fc=fa;
			e=d=b-a;
		}

		if(fabs(fc) < fabs(fb))
		{
			a=b;
			b=c;
			c=a;
			fa=fb;
			fb=fc;
			fc=fa;
		}

		tol1=2.0*EPS*fabs(b)+0.5*tol;			//Convergence check.
		xm=0.5*(c-b);
		if(fabs(xm) <= tol1 || fb == 0.0) return b;
		if(fabs(e) >= tol1 && fabs(fa) > fabs(fb))
		{
			s=fb/fa;							//Attempt inverse quadratic interpolation.
			if(a == c)
			{
				p=2.0*xm*s;
				q=1.0-s;
			}
			else
			{
				q=fa/fc;
				r=fb/fc;
				p=s*(2.0*xm*q*(q-r)-(b-a)*(r-1.0));
				q=(q-1.0)*(r-1.0)*(s-1.0);
			}
			if(p > 0.0) q = -q;					//Check whether in bounds.
			p=fabs(p);
			min1=3.0*xm*q-fabs(tol1*q);
			min2=fabs(e*q);
			if(2.0*p < (min1 < min2 ? min1 : min2))
			{
				e=d;							//Accept interpolation.
				d=p/q;
			}
			else
			{
				d=xm;							//Interpolation failed, use bisection.
				e=d;
			}
		}
		else									//Bounds decreasing too slowly, use bisection.
		{
			d=xm;
			e=d;
		}
		a=b;									//Move last best guess to a.
		fa=fb;
		if(fabs(d) > tol1)						//Evaluate new trial root.
			b += d;
		else
			b += SIGN(tol1,xm);
		fb=(*func)(b,zeta)-t;
	}
//	nrerror(); //"Maximum number of iterations exceeded in zbrent"
	return 0.0;
}

///////////////////////////////////////////////////////////////////////////////
