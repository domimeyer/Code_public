//Author: Igor Telezhinsky. Based on original thesis code 2005 - 2007, revisited 2010, 2015

//The main calculations are made in several functions: Rads and SpDs (Runge-Kutta integration), and related ttr, tsf,
//aint (Brent method) astrphx/g. Since they need to be called many times (i.e., to build plasma profiles, fill 2D maps), 
//Rad and SpD functions as well as tightly connected ttr,tsf,aint,astrph were optimized (with interpolations between precomputed thetas)
//to work with solution at given time and varying theta (original file is in test_21 directory).
//Here these functions are modified to work with arbitrary times and angles (*2D) but it results in some delay at first call with given
//t because all structures are filled (for various thetas). Alternative optimizations (*1D) are implemented to work with various times
//but in a predifined direction.

extern "C"
{
#include "snrfunclib.h"
}

#include <iostream>

//functions
double ro00()
{
	return 2.3*nh0*mu*mp;
}

double rob()
{
	return 2.3*nhb*mu*mp;
}
//////////////////////////////////////////
double ro0(double X, double theta)
{
//	return ro00()*exp((-X*cos(theta))/H);
//	std::cout<<"rob()="<<rob()/2.34e-24<<" ro00="<<ro00()/2.34e-24<<std::endl;
	return rob() + ro00()*exp((-X*cos(theta))/H);
}

double ro0_dl(double X, double theta)
{
	return rob() + ro00()*exp(-X*cos(theta));
}

double m(double X)
{
//	return X*cos(MEMtheta)/H;
	return (X*cos(MEMtheta)/H)*(1-rob()/ro0(X,MEMtheta));
}

double m_dl(double X)
{
//	return X*cos(MEMtheta);
	return (X*cos(MEMtheta))*(1-rob()/ro0_dl(X,MEMtheta));
}

double ms(double X)
{
//	return -X*cos(MEMtheta)/H;
	return m(X)*((X*cos(MEMtheta)/H)-1);
}

double ms_dl(double X)
{
//	return -X*cos(MEMtheta);
	return m_dl(X)*(X*cos(MEMtheta)-1);
}
////////////////////////////////////////////
double k(double X)
{
	if(m(X)<=N+1)
		return 1/2.;
	else
		return 1/5.;
}

double k_dl(double X)
{
	if(m_dl(X)<=N+1)
		return 1/2.;
	else
		return 1/5.;
}

double tsc()
{
//	return sqrt((alphaA*ro00()*pow(H*pc,5.))/E0);
	return sqrt((alphaA*(ro00()+rob())*pow(H*pc,5.))/E0);
}

double tau(double t)
{
	return (t*year)/(double)tsc();
}

double startR(double t)
{
	return pow(tau(t),2/5.);
}

double startD(double t)
{
	return (2/5.)*pow(tau(t),-(3/5.));
}

double f(int i, double x, double *y)
{
	if(i==1)
	{
		return y[2];
	}
	else if(i==2)
	{
		return k_dl(y[1])*y[2]*y[2]/y[1]*(m_dl(y[1])-(N+1));
	}
	else
		return 0;
}

double Rads(double t, double theta)
{
//	if(Radius.timer==t && Radius.angle==theta)
//	{
//		return Radius.R;
//	}
//	else
//	{
//		Radius.timer=t;
//		Radius.angle=theta;
		MEMtheta=theta;			//needed for m(X) and k(X) functions. if properly f function should be modified and Runge revised
		if(t==1e+308)
		{
			return 1000;//1e+308;
		}
		else{
		double const t0=tau(6.);
		double t1=tau(t);
		int N;
		if(t<=50000)
			N=5000;
		else
			N=(int)(t/5);
		int n=2;
////		ap::real_1d_array y;
////		y.setbounds(1,n);
		double *y = dvector(1,n);
////		y(1)=startR(6.);
		y[1]=startR(6.);
////		y(2)=startD(6.);
		y[2]=startD(6.);
		systemrungekutt(t0,t1,N,n,y);
//		Radius.R=y(1)*H;
////		return y(1)*H;
		double rr = y[1]*H;
		free_dvector(y,1,n);
		return rr;
		}
//	}
}

double SpDs(double t, double theta)
{	
//	if(Speed.timer==t && Speed.angle==theta)
//	{
//		return Speed.D;
//	}
//	else
//	{
//		Speed.timer=t;
//		Speed.angle=theta;
		MEMtheta=theta;
		if(t==1e+308)
		{
			return 1000;//1e+308;
		}
		else{
		double const t0=tau(6.);
		double t1=tau(t);
		int N;
		if(t<=50000)
			N=5000;
		else
			N=(int)(t/5);
		int n=2;
////		ap::real_1d_array y;
////		y.setbounds(1,n);
		double *y = dvector(1,n);
////		y(1)=startR(6.);
		y[1]=startR(6.);
////		y(2)=startD(6.);
		y[2]=startD(6.);
		systemrungekutt(t0,t1,N,n,y);
//		Speed.D=sqrt(E0/(alphaA*ro00()*pow(H*pc,5.)))*(H*pc/kms)*y(2);
//		return sqrt(E0/(alphaA*ro00()*pow(H*pc,5.)))*(H*pc/kms)*y(2);
////		return sqrt(E0/(alphaA*(ro00()+rob())*pow(H*pc,5.)))*(H*pc/kms)*y(2);
		double dd = y[2];
		free_dvector(y,1,n);
		return sqrt(E0/(alphaA*(ro00()+rob())*pow(H*pc,5.)))*(H*pc/kms)*dd;
		}
//	}
}

double tc(double X, double theta)
{
//	double t0=29000.*pow(E0/(1.0e+51),4/17.)*pow(ro00()/(muh*mp),-9/17.);
//	return t0*exp(9.*X*cos(theta)/(17.*H));
	return 29000.*pow(E0/(1.0e+51),4/17.)*pow(ro0(X,theta)/(muh*mp),-9/17.);
}

double ttrs(double theta)
{
	double t;
	double prec=500;
	double lastdif=1000000;
	double seed=5000;
	int i;
	for(i=0;i<100;i++)
	{
		t=tc(Rads(seed,theta),theta);
		if(dabs(t-seed)<=prec)
		{
			return t;
			break;
		}
//		else if(abs(t-seed)>lastdif)
//		{
//			return 1e+308;
//			break;
//		}
		lastdif=dabs(t-seed);
		seed=t;
	}
}

void fill_tr()
{
	int i;
	for(i=0;i<=RES;i++)
	{
		Transition[i].theta=(pi/60.)*i;
		Transition[i].t=ttrs(Transition[i].theta);
	}
	FILLED_TR=1;
}

void fill_rd(double t)
{
	if(FILLED_TR == 0)
	{
		fill_tr();
	}
	int i;
	for(i=0;i<=RES;i++)
	{
		Radius[i].theta=(pi/60.)*i;
		Speed[i].theta=(pi/60.)*i;

		Radius[i].ttr=Transition[i].t;
		Speed[i].ttr=Transition[i].t;

		Radius[i].Rtr=Rads(Radius[i].ttr,Radius[i].theta);
		Speed[i].Dtr=SpDs(Speed[i].ttr,Speed[i].theta);

		Radius[i].t=t;
		Speed[i].t=t;

		Radius[i].R=Rads(t,Radius[i].theta);
		Speed[i].D=SpDs(t,Speed[i].theta);
	}

	FILLED_RD=1;
}

double ttr2D(double theta)
{
	if(FILLED_TR == 0)
	{
		//std::cout<<"snrlib: filling 2D transition time structure..."<<std::endl;
		fill_tr();
		//std::cout<<"snrlib: filling 2D transition time structure is done."<<std::endl;
	}

	int tlow=0;
	int i;
	for (i=0;i<=RES;i++)
	{
		if(theta==Transition[i].theta)
		{
			return Transition[i].t;
			break;
		}
		else if(Transition[i].theta<theta)
		{
			tlow=i;
		}
	}
	return Transition[tlow+1].t-((Transition[tlow+1].t-Transition[tlow].t)/
								 (Transition[tlow+1].theta-Transition[tlow].theta))*
								 (Transition[tlow+1].theta-theta);
}

double ttr1D(double theta_dir)
{
	if(Transition1D.t == 0)
	{
		//std::cout<<"snrlib: filling 1D transition time structure..."<<std::endl;
		Transition1D.theta = theta_dir;
		Transition1D.t     = ttrs(Transition1D.theta);
		//std::cout<<"snrlib: filling 1D transition time structure is done."<<std::endl;
	}
	return Transition1D.t;
}

double ttr(double theta)
{
	if      (DIMENSIONS == 1){return ttr1D(theta);}
	else if (DIMENSIONS == 2){return ttr2D(theta);}
}

double Rad2D(double t, double theta)
{
	MEMtheta=theta;
	if(FILLED_RD == 0 || ((Radius[0].t != t) && (t != ttr(theta))))
	{
		//std::cout<<"snrlib: filling 2D Radius/Speed structures..."<<std::endl;
		fill_rd(t);
		//std::cout<<"snrlib: filling 2D Radius/Speed structures is done."<<std::endl;
	}

	int tlow=0;
	int i;
	for (i=0;i<=RES;i++)
	{
		if(theta==Radius[i].theta && t==Radius[i].ttr)
		{
			return Radius[i].Rtr;
			break;
		}
		else if(theta==Radius[i].theta && t==Radius[i].t)
		{
			return Radius[i].R;
			break;
		}
		else if(Radius[i].theta<theta)
		{
			tlow=i;
		}
	}
	if(t==ttr(theta))
	{
		return Radius[tlow+1].Rtr-((Radius[tlow+1].Rtr-Radius[tlow].Rtr)/
								   (Radius[tlow+1].theta-Radius[tlow].theta))*
								   (Radius[tlow+1].theta-theta);
	}
	return Radius[tlow+1].R-((Radius[tlow+1].R-Radius[tlow].R)/
							 (Radius[tlow+1].theta-Radius[tlow].theta))*
							 (Radius[tlow+1].theta-theta);
}

double Rad1D(double t, double theta_dir)//here theta_dir means predefined direction wrt density gradient; the only motivated dirs are 0,pi/2, and pi.
{
	if(Radius1D.t != t && t != ttr(theta_dir) || Radius1D.ttr != ttr(theta_dir))
	{
		//std::cout<<"snrlib: filling 1D Radius/Speed structures..."<<std::endl;
		Radius1D.t     = t;
		Speed1D.t      = t;

		Radius1D.theta = theta_dir;
		Speed1D.theta  = theta_dir;

		Radius1D.ttr   = ttr(theta_dir);
		Speed1D.ttr    = ttr(theta_dir);

		Radius1D.Rtr   = Rads(Radius1D.ttr,Radius1D.theta);
		Speed1D.Dtr    = SpDs(Speed1D.ttr, Speed1D.theta);

		Radius1D.R     = Rads(t,Radius1D.theta);
		Speed1D.D      = SpDs(t,Speed1D.theta);
		//std::cout<<"snrlib: filling 1D Radius/Speed structures is done."<<std::endl;
	}
	if(t==ttr(theta_dir))
	{
		return Radius1D.Rtr;
	}
	return Radius1D.R;
}

double Rad(double t, double theta)
{
	if      (DIMENSIONS == 1){return Rad1D(t,theta);}
	else if (DIMENSIONS == 2){return Rad2D(t,theta);}
}

double SpD2D(double t, double theta)
{
	MEMtheta=theta;
	if(FILLED_RD == 0 || ((Speed[0].t != t) && (t != ttr(theta))))
	{
		//std::cout<<"snrlib: filling 2D Radius/Speed structures..."<<std::endl;
		fill_rd(t);
		//std::cout<<"snrlib: filling 2D Radius/Speed structures is done."<<std::endl;
	}

	int tlow=0;
	int i;
	for (i=0;i<=RES;i++)
	{
		if(theta==Speed[i].theta && t==Speed[i].ttr)
		{
			return Speed[i].Dtr;
			break;
		}
		else if(theta==Speed[i].theta && t==Speed[i].t)
		{
			return Speed[i].D;
			break;
		}
		else if(Speed[i].theta<theta)
		{
			tlow=i;
		}
	}
	if(t==ttr(theta))
	{
		return Speed[tlow+1].Dtr-((Speed[tlow+1].Dtr-Speed[tlow].Dtr)/
								  (Speed[tlow+1].theta-Speed[tlow].theta))*
								  (Speed[tlow+1].theta-theta);
	}
	return Speed[tlow+1].D-((Speed[tlow+1].D-Speed[tlow].D)/
							(Speed[tlow+1].theta-Speed[tlow].theta))*
							(Speed[tlow+1].theta-theta);
}

double SpD1D(double t, double theta_dir)//here theta_dir means predefined direction wrt density gradient; the only motivated dirs are 0,pi/2, and pi.
{
	if(Speed1D.t != t && t != ttr(theta_dir) || Speed1D.ttr != ttr(theta_dir))
	{
		//std::cout<<"snrlib: filling 1D Radius/Speed structures..."<<std::endl;
		Radius1D.t     = t;
		Speed1D.t      = t;

		Radius1D.theta = theta_dir;
		Speed1D.theta  = theta_dir;

		Radius1D.ttr   = ttr(theta_dir);
		Speed1D.ttr    = ttr(theta_dir);

		Radius1D.Rtr   = Rads(Radius1D.ttr,Radius1D.theta);
		Speed1D.Dtr    = SpDs(Speed1D.ttr, Speed1D.theta);

		Radius1D.R     = Rads(t,Radius1D.theta);
		Speed1D.D      = SpDs(t,Speed1D.theta);
		//std::cout<<"snrlib: filling 1D Radius/Speed structures is done."<<std::endl;
	}
	if(t==ttr(theta_dir))
	{
		return Speed1D.Dtr;
	}
	return Speed1D.D;
}

double SpD(double t, double theta)
{
	if      (DIMENSIONS == 1){return SpD1D(t,theta);}
	else if (DIMENSIONS == 2){return SpD2D(t,theta);}
}

double Vtots(double t)
{
	double theta;
	double V=0;
	int n=100;
	double theta_max=pi;
	double dtheta=theta_max/n;
	
	int i;
	for (i=0;i<=n;i++)
	{
		theta =theta_max*i/n;
		//std::cout<<t<<" "<<Rad(t,theta)<<std::endl;
		V=V+(pow(Rad(t,theta),3)*sin(theta)*dtheta);
	}

	return (2/3.)*pi*V;
}

double Vtot(double t)
{
	if(Volume[0].t != t && t < ttr(pi))
	{
		//std::cout<<"snrlib: filling Volume structure for Sedov stage for t="<<t<<"..."<<std::endl;
		Volume[0].t=t;
		Volume[0].V=Vtots(t);
		//std::cout<<"snrlib: filling Volume structure for Sedov stage is done. V[0]="<<Volume[0].V<<std::endl;
	}
	if(Volume[1].t != ttr(pi/2.))
	{
		//std::cout<<"snrlib: SNR is partially in transition to radiative stage at t="<<t<<std::endl;
		//std::cout<<"snrlib: filling Volume structure for transition stage ..."<<std::endl;
		Volume[1].t=ttr(pi/2.);
		Volume[1].V=Vtots(ttr(pi/2.));
		//std::cout<<"snrlib: filling Volume structure for transition stage is done. V[1]="<<Volume[1].V<<std::endl;
	}
	
	if(Volume[0].t == t)
	{
		//std::cout<<"called because Volume[0].t == t"<<std::endl;
		return Volume[0].V;
	}
	else if(t >= ttr(pi))
	{
		//std::cout<<"called because t >= ttr(pi)="<<ttr(pi)<<" V="<<Volume[1].V/pow((ttr(pi/2.)/t),(6/5.))<<std::endl;
		return Volume[1].V/pow((ttr(pi/2.)/t),(6/5.));
	}
	else
	{
		//std::cout<<"called with unknown condition: t="<<t<<" Volume[0].t="<<Volume[0].t<<" ttr(pi)="<<ttr(pi)<<std::endl;
		return 0.0;
	}
}

/*
double Vtots(double t)
{
	double V=0;
	double theta=pi;
	int n=100;
	int i;
	for (i=0;i<=n;i++)
	{
		V=V+(pow(Rads(t,theta*i/n),3)*sin(theta*i/n)*(theta/n));
	}

	return (2/3.)*pi*V;

}

void fill_vl(double t)
{
	if(ttr(pi)<=t && t<=ttr(0))
	{
		Volume[0].t=0;
		Volume[0].V=0;
		Volume[1].t=ttr(pi/2.);
		Volume[1].V=Vtots(ttr(pi/2.));
	}
	else
	{
		Volume[0].t=t;
		Volume[0].V=Vtots(t);
		Volume[1].t=ttr(pi/2.);
		Volume[1].V=Vtots(ttr(pi/2.));	
	}
	
	FILLED_VL=1;
}

double Vtot(double t)
{
	if(FILLED_VL == 0 || ((Volume[0].t != t) && (Volume[0].t != 0)))
	{
		std::cout<<"fill_vl at call: FILLED_VL ="<<FILLED_VL<<" Volume[0].t ="<<Volume[0].t<<std::endl;
		fill_vl(t);
		std::cout<<"fill_vl after  : FILLED_VL ="<<FILLED_VL<<" Volume[0].t ="<<Volume[0].t<<std::endl;
	}
	if(ttr(pi)<=t && t<=ttr(0))
	{
		std::cout<<"called because ttr(pi)<=t && t<=ttr(0)"<<std::endl;
		return Volume[1].V/pow((ttr(pi/2.)/t),(6/5.));
	}
	else if(t == Volume[0].t)
	{
		std::cout<<"called because t == Volume[0].t"<<std::endl;
		return Volume[0].V;
	}
	else
	{
		std::cout<<"somehow stupid 0"<<std::endl;
		return 0;
	}
}
*/
double C(double t, double theta)
{
	double Ca;
	if(gama==1.3&&N==0)
	{
		Ca=1.1244;
	}
	else if(gama==1.4&&N==0)
	{
		Ca=1.1429;
	}
	else if(gama==5/3.&&N==0)
	{
		Ca=1.167;
	}
	else if(gama==1.3&&N==1)
	{
		Ca=1.0721;
	}
	else if(gama==1.4&&N==1)
	{
		Ca=1.0863;
	}
	else if(gama==5/3.&&N==1)
	{
		Ca=1.1112;
	}
	else if(gama==1.3&&N==2)
	{
		Ca=1.0507;
	}
	else if(gama==1.4&&N==2)
	{
		Ca=1.0618;
	}
	else if(gama==5/3.&&N==2)
	{
		Ca=1.0833;
	}
//	return 1.15686;
//	return Ca*pow(((4*pi*pow(Rad(t,theta),N+1))/((N+1)*Vtot(t))),-1./(gama*(N+1)));
	return Ca*pow(((4*pi*pow(Rad(t,theta),N+1))/((N+1)*Vtots(t))),-1./(gama*(N+1)));
}

double xi(double a)
{
	return 1-a;
}

double B(double t, double theta)
{
	return k(Rad(t,theta))*(m(Rad(t,theta))-(N+1));
}

double q(double t, double theta)
{
	return 2*k(Rad(t,theta))*k(Rad(t,theta))*(m(Rad(t,theta))-(N+1))*(m(Rad(t,theta))-(N+1))-
		k(Rad(t,theta))*(ms(Rad(t,theta))+m(Rad(t,theta))-(N+1));
}

double ra()
{
	return 1-omega;
}

double raa(double t, double theta)
{
	return omega*(1-omega)*(3*B(t,theta)+N*(2-omega)-m(Rad(t,theta)));
}

double raaa(double t, double theta)
{
	return omega*(1-omega)*(3*(7-5*omega)*B(t,theta)*B(t,theta)+((-5*omega*omega+4*omega+8)*N+
		(4*omega-11)*m(Rad(t,theta)))*B(t,theta)+omega*(2*omega*omega-7*omega+6)*N*N+
		(omega*omega+omega-4)*N*m(Rad(t,theta))-omega*(2-omega)*N-(omega-2)*m(Rad(t,theta))*
		m(Rad(t,theta))+(2*omega-1)*m(Rad(t,theta))+(2*omega-1)*ms(Rad(t,theta))+(6*omega-4)*
		q(t,theta));
}

double alpha()
{
	return -ra()+x;
}

double betta(double t, double theta)
{
	return (raa(t,theta)-2*x*ra()+x*(x+1))/2.;
}

double lambda(double t, double theta)
{
	return (-raaa(t,theta)+3*x*raa(t,theta)-3*x*(1+x)*ra()+x*(x+1)*(x+2))/6.;
}

double delta(double t, double theta)
{
	return C(t,theta)-(1+alpha()+betta(t,theta)+lambda(t,theta));
}

double r(double a, double t, double theta)
{
//	std::cout<<"delta(t,theta)="<<delta(t,theta)<<std::endl;
//	std::cout<<"C(t,theta)="<<C(t,theta)<<" Vtot="<<Vtot(t)<<std::endl;
//	std::cout<<"Vtot="<<Vtot(t)<<" C(t,theta)="<<C(t,theta)<<std::endl;
//	std::cout<<"alpha()="<<alpha()<<std::endl;
//	std::cout<<"betta(t,theta)="<<betta(t,theta)<<std::endl;
//	std::cout<<"lambda(t,theta)="<<lambda(t,theta)<<std::endl;
//	std::cout<<"raaa(t,theta)="<<raaa(t,theta)<<std::endl;
//	std::cout<<"q(t,theta)="<<q(t,theta)<<std::endl;
//	std::cout<<"m(Rad(t,theta))="<<m(Rad(t,theta))<<std::endl;
	
	//return 1.0;
	
//	double rrrrrr=pow(a,x)*(1+alpha()*xi(a)+betta(t,theta)*xi(a)*xi(a)+lambda(t,theta)*xi(a)*xi(a)
//		*xi(a)+delta(t,theta)*xi(a)*xi(a)*xi(a)*xi(a));

//	std::cout<<"   a="<<a<<" r(a,t,theta)="<<rrrrrr<<std::endl;	
	return pow(a,x)*(1+alpha()*xi(a)+betta(t,theta)*xi(a)*xi(a)+lambda(t,theta)*xi(a)*xi(a)
		*xi(a)+delta(t,theta)*xi(a)*xi(a)*xi(a)*xi(a));
}

double rdera(double a, double t, double theta)
{
	return pow(a,x)*(x/a)*(1+alpha()*xi(a)+betta(t,theta)*xi(a)*xi(a)+lambda(t,theta)*xi(a)
		*xi(a)*xi(a)+delta(t,theta)*xi(a)*xi(a)*xi(a)*xi(a))+pow(a,x)*(-alpha()-2*betta(t,theta)
		*xi(a)-3*lambda(t,theta)*xi(a)*xi(a)-4*delta(t,theta)*xi(a)*xi(a)*xi(a));
}

double roR(double t, double theta)
{
	return ((gama+1)/(gama-1))*ro0(Rad(t,theta),theta);
}

double ro(double a, double t, double theta)
{
//	std::cout<<"theta="<<theta<<" ro0(a*Rad(t,theta),theta)="<<ro0(a*Rad(t,theta),theta)<<" (pow((a/r(a,t,theta)),N))="<<(pow((a/r(a,t,theta)),N))<<"(1/rdera(a,t,theta))"<<(1/rdera(a,t,theta))<<std::endl;
//	std::cout<<"t="<<t<<" (pow((a/r(a,t,theta)),N))="<<(pow((a/r(a,t,theta)),N))<<" (1/rdera(a,t,theta))"<<(1/rdera(a,t,theta))<<std::endl;
//	std::cout<<"-----------------------------------"<<std::endl;
//	std::cout<<"a="<<a<<" r(a,t,theta)="<<r(a,t,theta)<<std::endl;
	return ro0(a*Rad(t,theta),theta)*(pow((a/r(a,t,theta)),N))*(1/rdera(a,t,theta));
}

double R1(double theta)
{
	return (3*H)/cos(theta);
}

double DD(double a, double t, double theta)
{
	if(m(a*Rad(t,theta))<=N+1)
		return (2./(3+N))*sqrt(E0/(alphaA*ro0(a*Rad(t,theta),theta)))*pow((a*Rad(t,theta)*pc),
		(-(N+1)/2.));
	else
		return (2./(3+N))*sqrt(E0/(alphaA*ro0(R1(theta),theta)))*pow((R1(theta)*pc),-(N+1)/2.)*
		pow(((ro0(R1(theta),theta)*pow(R1(theta),(N+1)))/(ro0(a*Rad(t,theta),theta)*pow(a*Rad(t,theta),(N+1)))),1/5.);

}

double PR(double t, double theta)
{
	return (2*ro0(Rad(t,theta),theta)*SpD(t,theta)*SpD(t,theta)*kms*kms)/(gama+1);
}

double P(double a, double t, double theta)
{
	return PR(t,theta)*pow((ro0(a*Rad(t,theta),theta)/ro0(Rad(t,theta),theta)),(1-gama))*(DD(a,t,theta)/
		(SpD(t,theta)*kms))*(DD(a,t,theta)/(SpD(t,theta)*kms))*pow((ro(a,t,theta)/roR(t,theta)),
		gama);
}

double TR(double t, double theta)
{
	return (mu*PR(t,theta))/(Rg*roR(t,theta));
}


double T(double a, double t, double theta)
{
	return (mu*P(a,t,theta))/(Rg*ro(a,t,theta));
}

double tm()
{
	return pow((alphaA*ro0(0,pi/2.)*pow(H*pc,5)/E0),1/2.)/year;
}

double Rm()
{
	return H;
}

double rom()
{
	return ro0(0,pi/2.);
}

double Pm()
{
	return E0/(alphaA*pow(Rm()*pc,3));
}

double xis(double rs)
{
	return 1-rs;
}

double alphas()
{
	return (1./x)-(1./ra());
}

double deltas(double t, double theta)
{
	return pow(C(t,theta),-1./x)-(1+alphas());
}

double as(double rs, double t, double theta)
{
//	std::cout<<"I'm as "<<rs<<" "<<t<<" "<<theta<<std::endl;
//	std::cout<<"pow(rs,1./x) = "<<pow(rs,1./x)<<std::endl;
//	std::cout<<"alphas() = "<<alphas()<<std::endl;
//	std::cout<<"xis(rs) = "<<xis(rs)<<std::endl;
//	std::cout<<"deltas(t,theta) = "<<deltas(t,theta)<<std::endl;
//	std::cout<<"C(t,theta) = "<<C(t,theta)<<std::endl;
//	std::cout<<"Vtot(t) = "<<Vtot(t)<<std::endl;
//	std::cout<<"-------------------"<<std::endl;
		
	return pow(rs,1./x)*(1+alphas()*xis(rs)+deltas(t,theta)*xis(rs)*xis(rs));
}

double nh(double a, double t, double theta)
{
	return ro(a,t,theta)/(muh*mp);
}

double LAMBDA(double a, double t, double theta)
{
	return pow(10,-21.8)*pow((T(a,t,theta)/(1E+6)),-0.63)*exp(-1.4/(T(a,t,theta)/(1.0E+6)));
}

double LAMBDA01(double a, double t, double theta)
{
	return LAMBDA(a,t,theta)+pow(10,-24.4)*pow((T(a,t,theta)/(1.0E+6)),-0.8);
}

double ashell(double t, double theta)
{
	//return as(rshell,t,theta);
	return 0.7833;
}

double Vshell(double theta)
{
	return (1/2.)*SpD(ttr(theta),theta);
}

double mdert(double t, double theta)
{
//	return (cos(theta)/H)*SpD(t,theta)*CSI;		//bez polochki
	return m(Rad(t,theta))*((1/Rad(t,theta))-((cos(theta)*rob()*ro0(Rad(t,theta),theta))/H))*SpD(t,theta)*CSI;	//s polochkoj

}

double Bdert(double t, double theta)
{
	return mdert(t,theta)*k(Rad(t,theta));
}

double raadert(double t, double theta)
{
	return omega*(1-omega)*mdert(t,theta)*(3*k(Rad(t,theta))-1);
}

double raaadert(double t, double theta)
{
	return omega*(1-omega)*(Bdert(t,theta)*(6*(7-5*omega)*B(t,theta)+(-5*omega*omega+4*omega+8)*N
		+(4*omega-11)*m(Rad(t,theta)))+mdert(t,theta)*((4*omega-11)*B(t,theta)+(omega*omega
		+omega-4)*N-2*m(Rad(t,theta))*(omega-2)+(6*omega-4)*(4*k(Rad(t,theta))*k(Rad(t,theta))
		*(m(Rad(t,theta))-(N+1)))));
}

double bettadert(double t, double theta)
{
	return (1/2.)*raadert(t,theta);
}

double lambdadert(double t, double theta)
{
	return (-1/6.)*raaadert(t,theta)+(1/2.)*x*raadert(t,theta);
}

double deltadert(double t, double theta)
{
	return -bettadert(t,theta)-lambdadert(t,theta);
}

double vv(double a, double t, double theta)
{
	return pow((double)a,(double)x)*
		((1-x)*SpD(t,theta)*(1+alpha()*xi(a)+betta(t,theta)*xi(a)*xi(a)+lambda(t,theta)*
		xi(a)*xi(a)*xi(a)+delta(t,theta)*xi(a)*xi(a)*xi(a)*xi(a))+
		a*SpD(t,theta)*(alpha()+2*betta(t,theta)*xi(a)+3*lambda(t,theta)*xi(a)*xi(a)+
		4*delta(t,theta)*xi(a)*xi(a)*xi(a))+
		Rad(t,theta)*(bettadert(t,theta)*xi(a)*xi(a)+lambdadert(t,theta)*xi(a)*xi(a)*xi(a)+
		deltadert(t,theta)*xi(a)*xi(a)*xi(a)*xi(a)));
}

double v(double a, double t, double theta)
{
	if(a>aint(t,theta) && t>ttr(theta))
	{
//		std::cout<<"SMEAR_FACTOR(t,theta)="<<SMEAR_FACTOR(t,theta)<<" CompRatioShell(theta)="<<CompRatioShell(theta)<<std::endl;
		double EFFECT_COMPR = CompRatioShell(theta)/SMEAR_FACTOR(t,theta);
		double vsh;
		if(EFFECT_COMPR >= EFFECT_COMPR_MIN)
			vsh=Vshell(theta)*(1.0 - 1.0/EFFECT_COMPR);
		else
			vsh=Vshell(theta)*(1.0 - 1.0/EFFECT_COMPR_MIN);
		
		return 	vv(aint(t,theta),t,theta) + (vsh - vv(aint(t,theta),t,theta))*(a - aint(t,theta))/(1.0 - aint(t,theta));
	}
	else
	{
		return vv(a,t,theta);
	}
}

double vdera(double a, double t, double theta)
{
	return ((x*v(a,t,theta))/a)+
		pow((double)a,(double)x)*
		(x*SpD(t,theta)*(alpha()+2*betta(t,theta)*xi(a)+3*lambda(t,theta)*xi(a)*xi(a)+4*delta(t,theta)*xi(a)*xi(a)*xi(a))-
		a*SpD(t,theta)*(2*betta(t,theta)+6*lambda(t,theta)*xi(a)+12*delta(t,theta)*xi(a)*xi(a))-
		Rad(t,theta)*(2*bettadert(t,theta)+3*lambdadert(t,theta)*xi(a)*xi(a)+4*deltadert(t,theta)*xi(a)*xi(a)*xi(a)));
}

double deltattr(double theta)
{
//	std::cout<<ashell(ttr(theta),theta)<<std::endl;
//	std::cout<<"v="<<v(ashell(ttr(theta),theta),ttr(theta),theta)<<std::endl;
//	std::cout<<"V="<<Vshell(theta)<<std::endl;
//	std::cout<<"R="<<Rad(ttr(theta),theta)<<std::endl;
//	std::cout<<"___________"<<std::endl;
	
	return (1./CSI)*alphass*Rad(ttr(theta),theta)/(v(ashell(ttr(theta),theta),ttr(theta),theta)-Vshell(theta));
}

double tsfs(double theta)
{
	if(ttr(theta)==1e+308)
	{
		return 1e+308;
	}
//	std::cout<<deltattr(theta)<<std::endl;
	return ttr(theta)+deltattr(theta);
}

void fill_sf()
{
	int i;
	for(i=0;i<=RES;i++)
	{
		Shellform[i].theta=(pi/60.)*i;
		Shellform[i].t=tsfs(Shellform[i].theta);
	}
	FILLED_SF=1;
}

double tsf2D(double theta)
{
	if(FILLED_SF == 0)
	{
		//std::cout<<"snrlib: filling 2D shell formation time structure..."<<std::endl;
		fill_sf();
		//std::cout<<"snrlib: filling 2D shell formation time structure is done."<<std::endl;
	}

	int tlow=0;
	int i;
	for (i=0;i<=RES;i++)
	{
		if(theta==Shellform[i].theta)
		{
			return Shellform[i].t;
			break;
		}
		else if(Shellform[i].theta<theta)
		{
			tlow=i;
		}
	}
	return Shellform[tlow+1].t-((Shellform[tlow+1].t-Shellform[tlow].t)/
								 (Shellform[tlow+1].theta-Shellform[tlow].theta))*
								 (Shellform[tlow+1].theta-theta);
}

double tsf1D(double theta_dir)
{
	if(Shellform1D.t == 0)
	{
		//std::cout<<"snrlib: filling 1D shell formation time structure..."<<std::endl;
		Shellform1D.theta = theta_dir;
		Shellform1D.t     = tsfs(Shellform1D.theta);
		//std::cout<<"snrlib: filling 1D shell formation time structure is done."<<std::endl;
	}
	return Shellform1D.t;
}

double tsf(double theta)
{
	if      (DIMENSIONS == 1){return tsf1D(theta);}
	else if (DIMENSIONS == 2){return tsf2D(theta);}
}

double Rtrph(double t, double theta)
{
	if(t<=ttr(theta))
	{
		return Rad(t,theta);
	}
	else if(ttr(theta)<t && t<=tsf(theta))
	{
		return Rad(ttr(theta),theta)+Vshell(theta)*(t-ttr(theta))*CSI;
	}
	else
	{
		return 0;
	}
}

double Dtrph(double t, double theta)
{
	if(t<=ttr(theta))
	{
		return SpD(t,theta);
	}
	else if(ttr(theta)<t && t<=tsf(theta))
	{
		return Vshell(theta);
	}
	else
	{
		return 0;
	}
}

float tcool(float x, float theta)
{
	return (float)((Rad(ttr(theta),theta)*(1-r(x,ttr(theta),theta)))/((v(x,ttr(theta),theta)-Vshell(theta))*CSI)+ttr(theta));
}

double ain(double t, double theta)
{
	float tt=(float)t;
	float zeta=(float)theta;
	
	if(t<=ttr(theta))
	{
		return 1;
	}
	else if(ttr(theta)<t && t<=tsf(theta))
	{
		//return 0.9305640459060669;
		return zbrent(tcool, 0.78, 1, tt, zeta, 0.001);
	}
	else
	{
		return ashell(t,theta);
	}
}

void fill_ai(double t)
{
	int i;
	for(i=0;i<=RES;i++)
	{
		Ainter[i].theta=(pi/60.)*i;
		Ainter[i].t = t;
		Ainter[i].a=ain(t, Ainter[i].theta);
	}
	FILLED_AI=1;
}

double aint2D(double t, double theta)
{
	if(FILLED_AI==0 || (Ainter[0].t != t && ttr(theta)<t && t<=tsf(theta)))
	{
		//std::cout<<"snrlib: filling cooling layer \"a\" coordinate (aint) 2D structure..."<<std::endl;
		fill_ai(t);
		//std::cout<<"snrlib: filling cooling layer \"a\" coordinate (aint) 2D structure is done."<<std::endl;
	}
	if(t<=ttr(theta))
	{
		return 1;
	}
	else if(ttr(theta)<t && t<=tsf(theta))
	{
		int tlow=0;
		int i;
		for (i=0;i<=RES;i++)
		{
			if(theta==Ainter[i].theta)
			{
				return Ainter[i].a;
				break;
			}
			else if(Ainter[i].theta<theta)
			{
				tlow=i;
			}
		}
		return Ainter[tlow+1].a-((Ainter[tlow+1].a-Ainter[tlow].a)/
								 (Ainter[tlow+1].theta-Ainter[tlow].theta))*
								 (Ainter[tlow+1].theta-theta);
	}
	else
	{
		return ashell(t,theta);
	}
}

double aint1D(double t, double theta_dir)
{
	if(Ainter1D.t != t && ttr(theta_dir)<t && t<=tsf(theta_dir))
	{
		//std::cout<<"snrlib: filling cooling layer \"a\" coordinate (aint) 1D structure..."<<std::endl;
		Ainter1D.theta = theta_dir;
		Ainter1D.t     = t;
		Ainter1D.a     = ain(t, Ainter1D.theta);
		//std::cout<<"snrlib: filling cooling layer \"a\" coordinate (aint) 1D structure is done."<<std::endl;
	}
	if(t<=ttr(theta_dir))
	{
		return 1;
	}
	else if(ttr(theta_dir)<t && t<=tsf(theta_dir))
	{
		return Ainter1D.a;
	}
	else
	{
		return ashell(t,theta_dir);
	}
}

double aint(double t, double theta)
{
	if      (DIMENSIONS == 1){return aint1D(t,theta);}
	else if (DIMENSIONS == 2){return aint2D(t,theta);}
}

double rtrph(double a, double t, double theta)
{
	if(t<=ttr(theta))
	{
		return r(a,t,theta);
	}
	else if(0<=a && a<=aint(t,theta) && t>ttr(theta))
//	else if(0<=a && a<aint(t,theta) && t>ttr(theta))
	{
		double rr=r(a,ttr(theta),theta)*(Rad(ttr(theta),theta)/Rtrph(t,theta))+v(a,ttr(theta),theta)*(t-ttr(theta))*(CSI/Rtrph(t,theta));
		if(rr <= 1)
			return rr;
		else
			return 1;
	}
	else if(aint(t,theta)<a && a<=1  && t>ttr(theta))
//	else if(aint(t,theta)<=a && a<=1  && t>ttr(theta))
	{
		return 1; 
		//return (Rad(ttr(theta),theta)+Vshell(theta)*(t-ttr(theta))*CSI)/Rad(ttr(theta),theta);
	}
	else
	{
		return 0;
	}
}

double Cisoshell()
{
	return sqrt(Rg*Tshell/mu);
}

double Misoshell(double theta)
{
	return Vshell(theta)*kms/Cisoshell();
}

double CompRatioShell(double theta)
{
	//return mu*Vshell(theta)*Vshell(theta)*kms*kms/(Rg*Tshell);
	return Misoshell(theta)*Misoshell(theta);
}

double DELTA_TRUE(double t, double theta)
{
	return (1.0 - pow((r(aint(t,theta),ttr(theta),theta)*(Rad(ttr(theta),theta)/Rtrph(t,theta))),3))/CompRatioShell(theta);
}

double SMEAR_FACTOR(double t,double theta)
{
	//return 1.0;
	return DELTA/DELTA_TRUE(t,theta);
}

double rtrphart(double a, double t, double theta)
{
	if(t<=ttr(theta))
	{
		return r(a,t,theta);
	}
	else if(0<=a && a<=aint(t,theta) && t>ttr(theta))
//	else if(0<=a && a<aint(t,theta) && t>ttr(theta))
	{

		double rr=r(a,ttr(theta),theta)*(Rad(ttr(theta),theta)/Rtrph(t,theta))+v(a,ttr(theta),theta)*(t-ttr(theta))*(CSI/Rtrph(t,theta));
		double rrmin=1.0 - DELTA;
		//double rrmin=1.0 - DELTA_TRUE(t,theta);
		if(rr < rrmin)
			return rr;
		else
		{
			if(DeltaAmin.a == 0.0 || DeltaAmin.t != t || DeltaAmin.theta != theta)
			{
				DeltaAmin.theta = theta;
				DeltaAmin.t     = t;
				DeltaAmin.a     = a;
				//std::cout<<"snrlib: filling amin..."<<std::endl;
			}
			//return rrmin - 0.0001;
//			std::cout<<"amin="<<DeltaAmin.a<<" a="<<a<<" DELTA*((1.0-a)/(1-amin))="<<DELTA*((1.0-a)/(1-DeltaAmin.a))<<std::endl;
			return 1.0 - DELTA*((1.0-a)/(1.0-DeltaAmin.a));
		}
	}
	else if(aint(t,theta)<a && a<=1 && t>ttr(theta))
//	else if(aint(t,theta)<=a && a<=1 && t>ttr(theta))
	{
		//return 1.0;		
		//return 1.0 - DELTA;
		//return 1.0 - DELTA*((1-a)/(1-aint(t,theta)));
		//return 1.0 - DELTA_TRUE(t,theta)*((1-a)/(1-aint(t,theta)));
		return 1.0 - DELTA*((1.0-a)/(1.0-DeltaAmin.a));
	}
	else
	{
		return 0.0;
	}
}

void fill_astrphx(double t)
{
	int i;
	for(i=0;i<=RES;i++)
	{
		AstrphaseX[i].theta=(pi/60.)*i;
		AstrphaseX[i].t = t;
		int j;
		for(j=0;j<=100;j++)
		{
			AstrphaseX[i].a[j]=j/100.;
			AstrphaseX[i].r[j]=rtrph(AstrphaseX[i].a[j],t,AstrphaseX[i].theta);
		}
	}
	FILLED_ASX=1;
}

double astrphx2D(double rtr, double t, double theta)
{
	if(FILLED_ASX==0 || AstrphaseX[0].t != t)
	{
		//std::cout<<"snrlib: filling 2D astrphx structure..."<<std::endl;
		fill_astrphx(t);
		//std::cout<<"snrlib: filling 2D astrphx structure is done."<<std::endl;
	}
/*	if(rtr==1)
	{
		return 1;
	}
	else{
*/	int tlow=0;
	int rlow=0;
	int i;
	for(i=0;i<=RES;i++)
	{
		if(AstrphaseX[i].theta<theta)
		{
			tlow=i;
		}
	}
	
	int j;
	for(j=0;j<=100;j++)
	{
		if(AstrphaseX[tlow].r[j]<rtr)
		{
			rlow=j;
		}
	}

	double a1=AstrphaseX[tlow].a[rlow+1]-((AstrphaseX[tlow].a[rlow+1]-AstrphaseX[tlow].a[rlow])/
										  (AstrphaseX[tlow].r[rlow+1]-AstrphaseX[tlow].r[rlow]))*
										  (AstrphaseX[tlow].r[rlow+1]-rtr);

	double a2=AstrphaseX[tlow+1].a[rlow+1]-((AstrphaseX[tlow+1].a[rlow+1]-AstrphaseX[tlow+1].a[rlow])/
								    	    (AstrphaseX[tlow+1].r[rlow+1]-AstrphaseX[tlow+1].r[rlow]))*
										    (AstrphaseX[tlow+1].r[rlow+1]-rtr);
	
	return a2-((a2-a1)/(AstrphaseX[tlow+1].theta-AstrphaseX[tlow].theta))*
					   (AstrphaseX[tlow+1].theta-theta);
//	}
}

double astrphx1D(double rtr, double t, double theta_dir)
{
	if(AstrphaseX1D.t != t)
	{
		//std::cout<<"snrlib: filling 1D astrphx structure..."<<std::endl;
		AstrphaseX1D.theta = theta_dir;
		AstrphaseX1D.t     = t;
		int j;
		for(j=0;j<=100;j++)
		{
			AstrphaseX1D.a[j]=j/100.;
			AstrphaseX1D.r[j]=rtrph(AstrphaseX1D.a[j],t,AstrphaseX1D.theta);
		}
		//std::cout<<"snrlib: filling 1D astrphx structure is done."<<std::endl;
	}
	int rlow=0;
	int j;
	for(j=0;j<=100;j++)
	{
		if(AstrphaseX1D.r[j]<rtr)
		{
			rlow=j;
		}
	}
	
	return AstrphaseX1D.a[rlow+1]-((AstrphaseX1D.a[rlow+1]-AstrphaseX1D.a[rlow])/
										  (AstrphaseX1D.r[rlow+1]-AstrphaseX1D.r[rlow]))*
										  (AstrphaseX1D.r[rlow+1]-rtr);
}

double astrphx(double rtr, double t, double theta)
{
	if      (DIMENSIONS == 1){return astrphx1D(rtr,t,theta);}
	else if (DIMENSIONS == 2){return astrphx2D(rtr,t,theta);}
}

void fill_astrphg(double t)
{
	int i;
	for(i=0;i<=RES;i++)
	{
		AstrphaseG[i].theta=(pi/60.)*i;
		AstrphaseG[i].t = t;
		int j;
		for(j=0;j<=100;j++)
		{
			AstrphaseG[i].a[j]=j/100.;
			AstrphaseG[i].r[j]=rtrphart(AstrphaseG[i].a[j],t,AstrphaseG[i].theta); //!!!!
		}
	}
	FILLED_ASG=1;
}

double astrphg2D(double rtr, double t, double theta)
{
	if(FILLED_ASG==0 || AstrphaseG[0].t != t)
	{
		//std::cout<<"snrlib: filling 2D astrphg structure..."<<std::endl;
		fill_astrphg(t);
		//std::cout<<"snrlib: filling 2D astrphg structure is done."<<std::endl;
	}
/*	if(rtr==1)
	{
		return 1;
	}
	else{
*/	int tlow=0;
	int rlow1=0;
	int rlow2=0;

	int i;
	for(i=0;i<=RES;i++)
	{
		if(AstrphaseG[i].theta<theta)
		{
			tlow=i;
		}
	}

	int j;
	for(j=0;j<=100;j++)
	{
		if(AstrphaseG[tlow].r[j]<rtr)
		{
			rlow1=j;
		}
	}

	int k;
	for(k=0;k<=100;k++)
	{
		if(AstrphaseG[tlow+1].r[k]<rtr)
		{
			rlow2=k;
		}
	}

	double a1=AstrphaseG[tlow].a[rlow1+1]-((AstrphaseG[tlow].a[rlow1+1]-AstrphaseG[tlow].a[rlow1])/
										  (AstrphaseG[tlow].r[rlow1+1]-AstrphaseG[tlow].r[rlow1]))*
										  (AstrphaseG[tlow].r[rlow1+1]-rtr);

	double a2=AstrphaseG[tlow+1].a[rlow2+1]-((AstrphaseG[tlow+1].a[rlow2+1]-AstrphaseG[tlow+1].a[rlow2])/
								    	    (AstrphaseG[tlow+1].r[rlow2+1]-AstrphaseG[tlow+1].r[rlow2]))*
										    (AstrphaseG[tlow+1].r[rlow2+1]-rtr);
	
	return a2-((a2-a1)/(AstrphaseG[tlow+1].theta-AstrphaseG[tlow].theta))*
					   (AstrphaseG[tlow+1].theta-theta);
//	}
}

double astrphg1D(double rtr, double t, double theta_dir)
{
	if(AstrphaseG1D.t != t)
	{
		//std::cout<<"snrlib: filling 1D astrphg structure..."<<std::endl;
		AstrphaseG1D.theta = theta_dir;
		AstrphaseG1D.t     = t;
		int j;
		for(j=0;j<=100;j++)
		{
			AstrphaseG1D.a[j]=j/100.;
			AstrphaseG1D.r[j]=rtrphart(AstrphaseG1D.a[j],t,AstrphaseG1D.theta);
		}
		//std::cout<<"snrlib: filling 1D astrphg structure is done."<<std::endl;
	}
	int rlow=0;
	int j;
	for(j=0;j<=100;j++)
	{
		if(AstrphaseG1D.r[j]<rtr)
		{
			rlow=j;
		}
	}
	
	return AstrphaseG1D.a[rlow+1]-((AstrphaseG1D.a[rlow+1]-AstrphaseG1D.a[rlow])/
										  (AstrphaseG1D.r[rlow+1]-AstrphaseG1D.r[rlow]))*
										  (AstrphaseG1D.r[rlow+1]-rtr);
}

double astrphg(double rtr, double t, double theta)
{
	if      (DIMENSIONS == 1){return astrphg1D(rtr,t,theta);}
	else if (DIMENSIONS == 2){return astrphg2D(rtr,t,theta);}
}

double rtrphdera(double a, double t, double theta)
{
	return rdera(a,ttr(theta),theta)*(Rad(ttr(theta),theta)/Rtrph(t,theta))+
		   vdera(a,ttr(theta),theta)*(t-ttr(theta))*(CSI/Rtrph(t,theta));
}

double Pshell(double theta)
{
	return ro0(Rad(ttr(theta),theta),theta)*Vshell(theta)*Vshell(theta)*kms*kms;
}

double roshell(double theta)
{
	return (mu*Pshell(theta))/(Rg*Tshell);
}

double rotrph(double a, double t, double theta)
{
	if(t<=ttr(theta))
	{
		return ro(a,t,theta);
	}
	else if(0<=a && a<=aint(t,theta) && t>ttr(theta))
//	else if(0<=a && a<aint(t,theta) && t>ttr(theta))
	{
////////return ro0(a*Rad(ttr(theta),theta),theta)*(pow((a/r(a,t,theta)),N))*(1/rdera(a,t,theta));

////	return ro0(a*Rad(ttr(theta),theta),theta)*(pow((a/rtrph(a,t,theta)),N))*(1/rtrphdera(a,t,theta));	//old
//		std::cout<<"a="<<a<<" aint="<<aint(t,theta)<<" ttr="<<ttr(theta)<<std::endl;
//		std::cout<<"ro="<<ro(a,ttr(theta),theta)<<" pow="<<pow((Rad(ttr(theta),theta)/Rtrph(t,theta)),3.)<<std::endl;
		return ro(a,ttr(theta),theta)*pow((Rad(ttr(theta),theta)/Rtrph(t,theta)),3.);						//new
	}
	else if(aint(t,theta)<a && a<=1 && t>ttr(theta))
//	else if(aint(t,theta)<=a && a<=1 && t>ttr(theta))
	{
		double EFFECT_COMPR = CompRatioShell(theta)/SMEAR_FACTOR(t,theta);
		if(EFFECT_COMPR >= EFFECT_COMPR_MIN)
			return roshell(theta)/SMEAR_FACTOR(t,theta);
		else
			return roshell(theta)/SMEAR_FACTOR(t,theta)*EFFECT_COMPR_MIN;
			
	}
	else
	{
		return 0;
	}
}

double Ptrph(double a, double t, double theta)
{
	if(t<=ttr(theta))
	{
		return P(a,t,theta);
	}
	else if(0<=a && a<=aint(t,theta) && t>ttr(theta))
//	else if(0<=a && a<aint(t,theta) && t>ttr(theta))
	{
		return P(a,ttr(theta),theta)*pow((rotrph(a,t,theta)/ro(a,ttr(theta),theta)),gama);
	}
	else if(aint(t,theta)<a && a<=1 && t>ttr(theta))
//	else if(aint(t,theta)<=a && a<=1 && t>ttr(theta))
	{
		
		double EFFECT_COMPR = CompRatioShell(theta)/SMEAR_FACTOR(t,theta);
		if(EFFECT_COMPR >= EFFECT_COMPR_MIN)
			return Pshell(theta)/SMEAR_FACTOR(t,theta);
		else
			return Pshell(theta)/SMEAR_FACTOR(t,theta)*EFFECT_COMPR_MIN;
	}
	else
	{
		return 0;
	}
}

double Ttrph(double a, double t, double theta)
{
	if(t<=ttr(theta))
	{
		return T(a,t,theta);
	}
	else if(0<=a && a<=aint(t,theta) && t>ttr(theta))
//	else if(0<=a && a<aint(t,theta) && t>ttr(theta))
	{
		return (mu*Ptrph(a,t,theta))/(Rg*rotrph(a,t,theta));
	}
	else if(aint(t,theta)<a && a<=1 && t>ttr(theta))
//	else if(aint(t,theta)<=a && a<=1 && t>ttr(theta))
	{
		return Tshell;
	}
	else
	{
		return 0;
	}
}

double nhtrph(double a, double t, double theta)
{
	return rotrph(a,t,theta)/(muh*mp);
}

double LAMBDAtrph(double a, double t, double theta)
{
	if(0<=a && a<=aint(t,theta))
//	if(0<=a && a<aint(t,theta))
	{
		return pow(10,-21.8)*pow((Ttrph(a,t,theta)/(1.0E+6)),-0.63)*exp(-1.4/(Ttrph(a,t,theta)/(1.0E+6)));
	}
	else
	{
		return 0;
	}
}

double LAMBDA01trph(double a, double t, double theta)
{
	if(0<=a && a<=aint(t,theta))
//	if(0<=a && a<aint(t,theta))
	{
		return LAMBDAtrph(a,t,theta)+pow(10.,-24.4)*pow((Ttrph(a,t,theta)/(1.0E+6)),-0.8);
	}
	else
	{
		return 0;
	}
}
/////fillcell adiabatic x:
double fillcell_ad_x(int i, int j, int mc, double h, double t)
{
	double Rh;
	double zeta;
	double r;
	Rh=sqrt(((mc-i)*h-h/2.)*((mc-i)*h-h/2.)+(j*h+h/2.)*(j*h+h/2.));
	zeta=atan2((j*h+h/2.),((mc-i)*h-h/2.));

	r=Rh/Rad(t,zeta);

	if((Rh-Rad(t,zeta))>h/2.)
		return 0;
	else if(dabs(Rh-Rad(t,zeta))<=h/2.)
	{
//		return (1/(4.*pi))*LAMBDA01(1,t,zeta)*(muh/mue)*nh(1,t,zeta)*nh(1,t,zeta)*(h)*pc;
		return LAMBDA01(1,t,zeta)*(muh/mue)*nh(1,t,zeta)*nh(1,t,zeta)*h*h*h*pc*pc*pc;
	}
	else
	{
//		return (1/(4.*pi))*LAMBDA01(as(r,t,zeta),t,zeta)*(muh/mue)*
//		nh(as(r,t,zeta),t,zeta)*nh(as(r,t,zeta),t,zeta)*(h)*pc;
		return LAMBDA01(as(r,t,zeta),t,zeta)*(muh/mue)*
		nh(as(r,t,zeta),t,zeta)*nh(as(r,t,zeta),t,zeta)*h*h*h*pc*pc*pc;
	}
}

/////fillcell adiabatic gamma:
double Fgamma_ad(double E, double WCR, double ntarget)
{
//	double dkpc=1.15;
//	double G=-1.2;
	double A=(9e-11)*pow(dkpc,-2);
	return A*pow(E,G)*WCR*ntarget;
}

double fillcell_ad_g(int i, int j, int mc, double h, double t)
{
	double Rh;
	double zeta;
	double r;
	
	double Vh=h*h*h;
	double Wh=(Vh/Vtot(t))*(W/1.0e+51);
	double E=1.0;

	Rh=sqrt(((mc-i)*h-h/2.)*((mc-i)*h-h/2.)+(j*h+h/2.)*(j*h+h/2.));
	zeta=atan2((j*h+h/2.),((mc-i)*h-h/2.));

	r=Rh/Rad(t,zeta);

	if((Rh-Rad(t,zeta))>h/2.)
		return 0;
	else if(dabs(Rh-Rad(t,zeta))<=h/2.)
	{
//		return ((1.0e+6)/(h*h))*Fgamma_ad(E,Wh,nh(1,t,zeta));
		return Fgamma_ad(E,Wh,nh(1,t,zeta));
	}
	else
	{
//		return ((1.0e+6)/(h*h))*Fgamma_ad(E,Wh,nh(as(r,t,zeta),t,zeta));
		return Fgamma_ad(E,Wh,nh(as(r,t,zeta),t,zeta));
	}
}

/////fillcell transition x:
double fillcell_tr_x(int i, int j, int mc, double h, double t)
{
	double Rh;
	double zeta;
	double r;
	Rh=sqrt(((mc-i)*h-h/2.)*((mc-i)*h-h/2.)+(j*h+h/2.)*(j*h+h/2.));
	zeta=atan2((j*h+h/2.),((mc-i)*h-h/2.));

	r=Rh/Rtrph(t,zeta);

	if((Rh-Rtrph(t,zeta))>h/2.)
		return 0;
	else if(dabs(Rh-Rtrph(t,zeta))<=h/2.) //((Rtrph(t,zeta)-Rh)<=h/2.)
	{
		return LAMBDA01trph(aint(t,zeta),t,zeta)*(muh/mue)*
		nhtrph(aint(t,zeta),t,zeta)*nhtrph(aint(t,zeta),t,zeta)*h*h*h*pc*pc*pc;
	
//		return LAMBDA01trph(astrphx(1,t,zeta),t,zeta)*(muh/mue)*
//		nhtrph(astrphx(1,t,zeta),t,zeta)*nhtrph(astrphx(1,t,zeta),t,zeta)*h*h*h*pc*pc*pc;
//		return LAMBDA01trph(as(1,t,zeta),t,zeta)*(muh/mue)*
//		nhtrph(as(1,t,zeta),t,zeta)*nhtrph(as(1,t,zeta),t,zeta)*h*h*h*pc*pc*pc;
	}
	else
	{
		return LAMBDA01trph(astrphx(r,t,zeta),t,zeta)*(muh/mue)*
		nhtrph(astrphx(r,t,zeta),t,zeta)*nhtrph(astrphx(r,t,zeta),t,zeta)*h*h*h*pc*pc*pc;
//		return LAMBDA01trph(as(r,t,zeta),t,zeta)*(muh/mue)*
//		nhtrph(as(r,t,zeta),t,zeta)*nhtrph(as(r,t,zeta),t,zeta)*h*h*h*pc*pc*pc;
	}
}

/////below are functions taking arrays for faster(?) processing from python

double* rotrph_array(double* r, int len_a, double t, double theta)
{
	double* rho_array;
	rho_array = new double [len_a];
	
	for(int i=0;i<len_a;i++)
	{
		rho_array[i]=rotrph(as(r[i],t,theta),t,theta);
//		std::cout<<rho_array[i]<<std::endl;
	}
	return rho_array;
}
/*
void ResetMemoryVars2D()
{
	MEMtheta=0.0;
	FILLED_RD  = 0;
	FILLED_TR  = 0;
	FILLED_SF  = 0;
	FILLED_AI  = 0;
	FILLED_VL  = 0;
	FILLED_ASX = 0;
	FILLED_ASG = 0;
	Radius[RES+1]     = {0.0, 0.0, 0.0, 0.0, 0.0};
	Speed[RES+1]	  = {0.0, 0.0, 0.0, 0.0, 0.0};
	Transition[RES+1] = {0.0, 0.0};
	Shellform[RES+1]  = {0.0, 0.0};
	Ainter[RES+1]     = {0.0, 0.0, 0.0};
	Volume[2]	  = {0.0, 0.0};
	AstrphaseX[RES+1] = {0.0, 0.0, {0.0}, {0.0}};
	AstrphaseG[RES+1] = {0.0, 0.0, {0.0}, {0.0}};
}

void ResetMemoryVars()
{
	MEMtheta=0.0;
	
	Radius1D.theta = 0.0;
	Radius1D.ttr   = 0.0;
	Radius1D.Rtr   = 0.0;
	Radius1D.t     = 0.0;
	Radius1D.R     = 0.0;
	
	
	Speed1D.theta = 0.0;
	Speed1D.ttr   = 0.0;
	Speed1D.Dtr   = 0.0;
	Speed1D.t     = 0.0;
	Speed1D.D     = 0.0;
	
	Transition1D.theta = 0.0;
	Transition1D.t     = 0.0;
	
	Shellform1D.theta  = 0.0;
	Shellform1D.t      = 0.0;
	
	Ainter1D.theta	   = 0.0;
	Ainter1D.t	   = 0.0;
	Ainter1D.a	   = 0.0;
	
	Volume[0].t	   = 0.0;
	Volume[0].V	   = 0.0;
	Volume[1].t	   = 0.0;
	Volume[1].V	   = 0.0;
	
	
	AstrphaseX1D.theta = 0.0;
	AstrphaseX1D.t     = 0.0;
	for(int i=0;i<101;i++){AstrphaseX1D.a[i] = 0.0;}
	for(int i=0;i<101;i++){AstrphaseX1D.r[i] = 0.0;}

	AstrphaseG1D.theta = 0.0;
	AstrphaseG1D.t     = 0.0;
	for(int i=0;i<101;i++){AstrphaseG1D.a[i] = 0.0;}
	for(int i=0;i<101;i++){AstrphaseG1D.r[i] = 0.0;}
}

*/
