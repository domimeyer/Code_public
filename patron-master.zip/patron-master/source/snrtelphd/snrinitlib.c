//Author: Igor Telezhinsky. Based on original thesis code 2005 - 2007, revisited 2010, 2015

extern "C"
{
#include "snrfunclib.h"
}

//constants
double const year=3.156E+7;
double const pc=3.0857E+18;
double const kms=1.0E+5;
double const CSI=1.0E+5*3.156E+7/3.0857E+18; //double const CSI=kms*year/pc;
double const mp=1.6726E-24;
double const mu=0.609;
double const muh=1.4;
double const mue=1.17;
double const Rg=8.3143E+7;
double const pi=3.14159265358979323846;

//varables
int DIMENSIONS=2;
int N=2;
double gama=5/3.;
double omega=2/((5/3.)+1);
double x=((5/3.)-1)/(5/3.);

double E0=1.0E+51;
double nh0=1.0;
double nhb = 1.0E-3;
double H=1E6;
//double rob=nhb*mp*muh;

double nu=0.1;
double W=1.0E+50;
double Ecut=1000;
double dkpc=1.0;
double G=-1.2;
double VH=0.0;

//memory var
double MEMtheta=0.0;
int FILLED_RD  = 0;
int FILLED_TR  = 0;
int FILLED_SF  = 0;
int FILLED_AI  = 0;
int FILLED_VL  = 0;
int FILLED_ASX = 0;
int FILLED_ASG = 0;
struct radius Radius[RES+1]         = {0.0, 0.0, 0.0, 0.0, 0.0};
struct radius Radius1D              = {0.0, 0.0, 0.0, 0.0, 0.0};
struct speed Speed[RES+1]           = {0.0, 0.0, 0.0, 0.0, 0.0};
struct speed Speed1D                = {0.0, 0.0, 0.0, 0.0, 0.0};
struct transition Transition[RES+1] = {0.0, 0.0};
struct transition Transition1D      = {0.0, 0.0};
struct shellform Shellform[RES+1]   = {0.0, 0.0};
struct shellform Shellform1D        = {0.0, 0.0};
struct ainter Ainter[RES+1]         = {0.0, 0.0, 0.0};
struct ainter Ainter1D              = {0.0, 0.0, 0.0};
struct ainter DeltaAmin             = {0.0, 0.0, 0.0};
struct volume Volume[2]             = {0.0, 0.0};
struct astrphase AstrphaseX[RES+1]  = {0.0, 0.0, {0.0}, {0.0}};
struct astrphase AstrphaseX1D       = {0.0, 0.0, {0.0}, {0.0}};
struct astrphase AstrphaseG[RES+1]  = {0.0, 0.0, {0.0}, {0.0}};
struct astrphase AstrphaseG1D       = {0.0, 0.0, {0.0}, {0.0}};


//should be functions
double const alphaA=0.4936;
double const alphass=0.06;
double const DELTA=0.02;
double const EFFECT_COMPR_MIN=4.5;
double const Tshell=1.0e+4;

