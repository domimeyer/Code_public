//Author: Igor Telezhinsky. Based on original thesis code 2005 - 2007, revisited 2010, 2015

extern "C"
{
#include "snrnumflib.h"
}

//constants
extern double const year;
extern double const pc;
extern double const kms;
extern double const CSI; //double const CSI=kms*year/pc;
extern double const mp;
extern double const mu;
extern double const muh;
extern double const mue;
extern double const Rg;
extern double const pi;

//varables
extern int DIMENSIONS;

extern int N;
extern double gama;
extern double omega;
extern double x;

extern double E0;
extern double nh0;
extern double nhb;
extern double H;
//extern double rob;

extern double nu;
extern double W;
extern double Ecut;
extern double dkpc;
extern double G;
extern double VH;

//memory var
extern double MEMtheta;
#define RES 120 //extern int const RES=120;
extern int FILLED_RD;
extern int FILLED_TR;
extern int FILLED_SF;
extern int FILLED_AI;
extern int FILLED_VL;
extern int FILLED_ASX;
extern int FILLED_ASG;

struct radius
{
	double theta;
	double ttr;
	double Rtr;
	double t;
	double R;
};
extern struct radius Radius[RES+1];
extern struct radius Radius1D;

struct speed
{
	double theta;
	double ttr;
	double Dtr;
	double t;
	double D;
};
extern struct speed Speed[RES+1];
extern struct speed Speed1D;

struct transition
{
	double theta;
	double t;
};
extern struct transition Transition[RES+1];
extern struct transition Transition1D;

struct shellform
{
	double theta;
	double t;
};
extern struct shellform Shellform[RES+1];
extern struct shellform Shellform1D;

struct ainter
{
	double theta;
	double t;
	double a;
};
extern struct ainter Ainter[RES+1];
extern struct ainter Ainter1D;
extern struct ainter DeltaAmin;

struct volume
{
	double t;
	double V;
};
extern struct volume Volume[2]; 			//early was RES+2, now extrapolation is used

struct astrphase
{
	double theta;
	double t;
	double a[101];
	double r[101];
};
extern struct astrphase AstrphaseX[RES+1];
extern struct astrphase AstrphaseX1D;
extern struct astrphase AstrphaseG[RES+1];
extern struct astrphase AstrphaseG1D;

//should be functions
extern double const alphaA;
extern double const alphass;
extern double const DELTA;
extern double const EFFECT_COMPR_MIN;
extern double const Tshell;


//functions:

double ro00();					//initial density without density gradient

double rob();					//background (plateu) density

double ro0(double X, double theta);		//initial density with density gradient

double ro0_dl(double X, double theta);

double ms(double X);				//m'

double ms_dl(double X);		

double m(double X);

double m_dl(double X);

double k(double X);

double k_dl(double X);

double tsc();

double tau(double t);

double startR(double t);

double startD(double t);

double Rads(double t, double theta);

double SpDs(double t, double theta);

double tc(double X, double theta);

double ttrs(double theta);

void fill_tr();

void fill_rd(double t);

double ttr2D(double theta);

double ttr1D(double theta_dir);

double ttr(double theta);

double Rad2D(double t, double theta);

double SpD2D(double t, double theta);

double Rad1D(double t, double theta_dir);

double SpD1D(double t, double theta_dir);

double Rad(double t, double theta);

double SpD(double t, double theta);

double Vtotss(double t);

double Vtots(double t);

void fill_vl(double t);

double Vtot(double t);

double C(double t, double theta);

double xi(double a);

double B(double t, double theta);

double q(double t, double theta);

double ra();

double raa(double t, double theta);

double raaa(double t, double theta);

double alpha();

double betta(double t, double theta);

double lambda(double t, double theta);

double delta(double t, double theta);

double r(double a, double t, double theta);

double rdera(double a, double t, double theta);

double roR(double t, double theta);

double ro(double a, double t, double theta);

double R1(double theta);

double DD(double a, double t, double theta);

double PR(double t, double theta);

double P(double a, double t, double theta);

double TR(double t, double theta);

double T(double a, double t, double theta);

double tm();

double Rm();

double rom();

double Pm();

double xis(double rs);								//r`

double alphas();								//alpha`

double deltas(double t, double theta);						//delta`

double as(double rs, double t, double theta);					//a`(r`)

double nh(double a, double t, double theta);

double ashell(double t, double theta);

double Vshell(double theta);

double mdert(double t, double theta);

double Bdert(double t, double theta);

double raadert(double t, double theta);

double raaadert(double t, double theta);

double bettadert(double t, double theta);

double lambdadert(double t, double theta);

double deltadert(double t, double theta);

double v(double a, double t, double theta);

double vdera(double a, double t, double theta);

double deltattr(double theta);

double tsfs(double theta);

void fill_sf();

double tsf2D(double theta);

double tsf1D(double theta_dir);

double tsf(double theta);

double Rtrph(double t, double theta);

double Dtrph(double t, double theta);

float tcool(float x, float theta);

double ain(double t, double theta);

void fill_ai(double t);

double aint2D(double t, double theta);

double aint1D(double t, double theta_dir);

double aint(double t, double theta);

double rtrph(double a, double t, double theta);

double rtrphart(double a, double t, double theta);

void fill_astrphx(double t);

double astrphx2D(double rtr, double t, double theta);

double astrphx1D(double rtr, double t, double theta_dir);

double astrphx(double rtr, double t, double theta);

void fill_astrphg(double t);

double astrphg2D(double rtr, double t, double theta);

double astrphg1D(double rtr, double t, double theta_dir);

double astrphg(double rtr, double t, double theta);

double rtrphdera(double a, double t, double theta);

double Pshell(double theta);

double roshell(double theta);

double rotrph(double a, double t, double theta);

double Ptrph(double a, double t, double theta);

double Ttrph(double a, double t, double theta);

double nhtrph(double a, double t, double theta);

double LAMBDA(double a, double t, double theta);

double LAMBDA01(double a, double t, double theta);

double fillcell(int i, int j, int mc, double h, double t);

double LAMBDAtrph(double a, double t, double theta);

double LAMBDA01trph(double a, double t, double theta);

double fillcell_ad_x(int i, int j, int mc, double h, double t);

double Fgamma_ad(double E, double WCR, double ntarget);

double fillcell_ad_g(int i, int j, int mc, double h, double t);

double fillcell_tr_x(int i, int j, int mc, double h, double t);

double* rotrph_array(double* a, int len_a, double t, double theta);

void ResetMemoryVars();

double CompRatioShell(double theta);

double Cisoshell();

double Misoshell(double theta);

double DELTA_TRUE(double theta);

double SMEAR_FACTOR(double t,double theta);

double vv(double a, double t, double theta);
