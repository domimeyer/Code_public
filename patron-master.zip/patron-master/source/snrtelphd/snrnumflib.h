//Author: Igor Telezhinsky. Based on original thesis code 2005 - 2007, revisited 2010, 2015

extern "C"
{
#include "nrutil.h"
}
#define ITMAX 100
#define EPS 3.0e-8

double dabs(double in);

//double f(int i, double x, ap::real_1d_array y);
double f(int i, double x, double *y);

//void systemrungekuttstep(double x, double h, int n, ap::real_1d_array& y);
void systemrungekuttstep(double x, double h, int n, double *y);

//void systemrungekutt(double x, double x1, int m, int n, ap::real_1d_array& y);
void systemrungekutt(double x, double x1, int m, int n, double *y);

float zbrent(float (*func)(float,float), float x1, float x2, float t, float zeta, float tol);
