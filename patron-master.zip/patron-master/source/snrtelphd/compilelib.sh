#LD_PRELOAD=/usr/lib/libstdc++.so.6
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:${PWD}

g++ -I. -fpic -c nrutil.c
g++ -I. -fpic -c snrnumflib.c
g++ -I. -fpic -c snrfunclib.c #-std=c++0x
g++ -I. -fpic -c snrinitlib.c
g++ nrutil.o snrnumflib.o snrfunclib.o snrinitlib.o -fpic -shared -o snrtelphd.so

mv snrtelphd.so ${PATRONDIR}/lib/
