#!/bin/bash
######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  start-patron.sh									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2010 - 2015
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#script to launch patron code on local machine or cluster
#v1.0.0:script introduced
#v2.0.0:re-written to work with new parameters of patron 2.2.x and higher
#v2.1.0:adding crspe1 stage
#v2.1.1:adding crspe2 stage
#v2.2.0:adding snrrad stage
#v2.3.0:adding snrmap stage
#v2.3.1:some improvements are added
#v2.4.0:adding radm3d, mapspe, mapspe_parallel stage
#v2.5.0:adding evotru
#v2.5.1:re-arranging subdir
#v2.6.0:adding support for analytic and numerical turbulence choice
#v2.6.1:slight corrections: WHITE changed to BOHM and became subtype of MTAPPLIED=ANALYTIC
#v2.7.0:changing RUNMODE and CALCULATER order, introducing GETMSP par and implementing MAPINT support
#v2.7.1:re-arangements for more convenient setup
#v2.8.0:adding second oder params MOMDIFPOW, MOMDIFTAU; adding HDSIMNAME and INJSCLPAR params
#v2.8.1:adding support for writing down simulation/task parameters
#v2.8.2:minor bug fixes with directory naming
#v2.8.3:minor bug fixes with managing output times
#v2.9.0:git version of patron
#v2.10.0: adding crprof stage
#v2.10.1: added DAM-porfile parameters

VERSION="2.10.1"

#################EXAMPLE RUN LINES IN ORDER OF STAGES###################################################
#example run lines (parameters are explained below):
#you can copy and uncomment the steps in the modeling script
#
#RUN=YOUR_DESIRED_RUN_NAME
#MOD=YOUR_DESIRED_MF_MODEL_NAME
#MAP_ENERGY=1e12 #1e12-1e14	#map energy or energy interval in eV
#MAP_NAME=YOUR_DESIRED_MAP_NAME
#
# ./start-patron.sh LOCAL CRSPE0 ${RUN} ${MOD} PR FSA
# ./start-patron.sh LOCAL CRSPE1 ${RUN} ${MOD} PR FSA "01600"						#if "01600" (some given age) is not given, the program will produce spectra for all output ages
##./start-patron.sh LOCAL CRSPE2 ${RUN} ${MOD} PR FSA "01600"						#so far used to sum up FS and RS 
# ./start-patron.sh LOCAL RADSPE ${RUN} ${MOD} PR FSA "01600" PDR
# ./start-patron.sh LOCAL RADMAP ${RUN} ${MOD} PR FSA "01600" PDR "PDR:${MAP_ENERGY}:${MAP_NAME}:1D"
#
#########################################################################################################

echo "-----------------------------------------------------------------------------------------"
echo "THIS IS MAIN SCRIPT v.${VERSION} TO GENERATE PARAMETERS FOR PATRON RUN."
echo "-----------------------------------------------------------------------------------------"

#PATRONDIR=${HOME}/patron				#patron directory
echo ${PATRONDIR}
if [ "${PATRONDIR}" == "" ];then
	echo "PATRONDIR is not specified! Initialize PATRON first!"
	exit 1
fi

PATRON=${PATRONDIR}/main.py				#main program

HDDATAREP=${PATRONDIR}/data/snrmhd/hd			#repository of all hydro data
MFDATAREP=${PATRONDIR}/data/snrmhd/mf			#repository of precalculated MF data

SIMULATIONS="TESTS"						#Paper01,...
SIMDATDIR=/lustre/fs17/group/that/rb/output/simdat		#simulations data directory
TOPSIMDIR=/lustre/fs17/group/that/rb/output/${SIMULATIONS}		#top directory for location of all simulations output

NNUM=8							#number of processors to use in pax cluster per job

RUNMODE=${1:-""}					#LOCAL, CLUSTER

CALCULATE=${2:-""}					#CRSPE0: stage 0 calculation of CR spectra and creation of raw files, 
							#CRSPE1: stage 1 simple post-procession of raw files into ready-to-use data products applicable to FSH and FSA
							#CRSPE2: stage 2 proper post-procession of raw files (including summation of shock contributions) into ready-to-use data products 
							#CRPROF: calculation of cosmic rays profile
							#RADSPE: calculation of radiation spectra,
							#RADMAP: calculation of radiation maps,
							#RADM3D: calculation of 3D radiation maps
							#MAPSPE: calculation of radiation spectra from radiation maps.
							#MAPSPE_PARALLEL: !!!set RPFORMAPS parameter!!! this is same as MAPSPE, but each radmap is prepared at separate node and runs on CLUSTER only. Reqiures post-processing with getmsp
							#GETMSP: (not implemented yet) makes post-processing for MAPSPE_PARALLEL
							#MAPINT: calculation of energy band integrated radiation maps
							
RUNNAME=${3:-""}					#preferable RUNMODE==LOCAL
MFMODEL=${4:-""}					#preferable RUNMODE==LOCAL
SPECIES=${5:-""}					#preferable RUNMODE==LOCAL
SHTYPES=${6:-""}					#preferable RUNMODE==LOCAL
TIMELST=${7:-""}					#preferable RUNMODE==LOCAL
RSTYPES=${8:-""}					#preferable RUNMODE==LOCAL
RMTYPES=${9:-""}					#preferable RUNMODE==LOCAL

RPFORMAPS=""						#supported  RUNMODE==CLUSTER only! Radiation process for maps spectra extraction in MAPSPE_PARALLEL mode: THR,SYR,PDR,ICR

TIMESCOPY=0						#0 - do not copy times from the files (better for tests); 1 - copy times from files (better for real simulations)
TIMESTART=00020						#preferable RUNMODE==LOCAL
TIMEINTERVAL=110					#preferable RUNMODE==LOCAL
TIMEFINISH=00440					#preferable RUNMODE==LOCAL

ANS=1							#0 - hydro simulations,   1 - analytical solutions
CON=0							#0 - start from analytical solutions, 1 - continue with analytical solutions
USESEDSOL=1						#0 - free expansion solutions, 1 - Sedov solutions, 2 - semi-analytic Sedov and transition stage solutions

EXPLNTYPE="T1"						#SN explosion type T1: thermonuclear, T2: core-collapse
SNSUBTYPE="type1a"					#SN subtype type1a, type1c, type2p
HDSIMNAME=""						#HD simulation name (actual directory of the simulation within all HD simulations)

WINDBNCSM="FALSE"					#if TRUE density profile will be calculated from mass-loss rate and wind velocity, else from setup density
NHDENSITY=0.4						#density of the ISM in the explosion region 
EXPENERGY=1e51						#SN explosion energy (valid for analytical solutions)

RSHELLPC1=50.0						#near boundary of the dense shell/mc in parsec
RSHELLPC2=51.0						#far  boundary of the dense shell/mc in parsec
SHDENSITY=0.4						#shell/mc density

MFOFISMNA=5e-6						#MF of the ISM (Non-Amplified) in Gauss
MFINTPROF="PWLPL"					#the profile of the MF inside the stellar ejecta. FLAT: flat, PWLAW: power-law, usually r^(-2), PWLPL: power-law + plato starting at r corresponding to some flow velocity
MFDIRPREF="BRSP"					#MF directory name prefix used for precalculated MF profiles
MFINITCON=12.0						#initial value of the MF inside the stellar ejecta at the age of 5 days in Gauss
MFDAMPSCA=0.01						#Damping length for damped magnetic field profile
MFSCABINS=4.0						#Scaling factor in front of BISM(B0=BISM*MFSCABINS) for damped magnetic field profile

INJECTPAR=4.2						#multiple of thermal momentum for injected particles
INJSCLPAR=1.0						#injection linear scaling parameter (multiple of current injection efficiency set by INJECTPAR)
CRINITCON="NOBKG"					#CRBKG: presence of CR background, NOBKG: no CR background

LMAXBDIFF=1.00						#distance limit (maximum) in SNR radii units where Bohm diffusion applies
LMINGDIFF=2.00						#distance limit (minimum) in SNR radii units where Galactic diffusion applies
DIFFINTER="EXP"						#transition type in intermedium region between two limits above. "LIN": linear, "EXP": exponential
ETAOFBOHM=1.0						#if MTSPECTRA=="BOHM", possible to specify Bohm eta parameter (default is 1.0)

MOMDIFPOW=0.2						#momentum diffusion power parameter
MOMDIFTAU=2.7						#momentum diffusion time scale
MOMDIFFR1=0.999						#Rmin of SOFA "activity" (normally assumed downstream)
MOMDIFFR2=1.0						#Rmax of SOFA "activity"
MOMDIFSCLEL=0.0005                                      #max kinetic energy for isotrop particle distribution, provides p_0_el, in GeV
MOMDIFSCLPR=0.0005                                      #max kinetic energy for isotrop particle distribution, provides p_0_pr, in GeV

MTAPPLIED="ANALYTIC"					#NUMERIC: will use numeric module to generate and transport turbulence; ANALYTIC: using analytical formula to mimick spectral shape
MTSPECTRA="BOHM"					#if MTAPPLIED=="ANALYTIC", BOHM: same Bohm eta for all energies, KOLM: Kolmogorov, KRAI: Kraichnan, HAND: hand-made (default is BOHM)

MTINITCON="KOLM"					#KOLM: Kolmogorov type spectrum ~E^(1/3), EXP05: ~E^(1/2)

CRSENERGY=1000						#energy in GeV for production of cosmic rays profile

RADORIGIN="FSH"						#SUM/S: radiation from particles originated at both shocks, SUM/F: at forward shock only, SUM/R: at reverse shock only
RADOBJECT="SNR"						#SNR: radiation from snr, MCL: from molecular cloud, SHL: from shell
RADINTRES=200						#number of steps for radiation integration over r
RADNORMAX=1.0
SYNEMFUNC="STANDARD"					#synchrotron emissivity function: STANDARD, GAUSSIAN

STERADIAN="NO"						#SR: flux per cm^2 per steradian, NO - per cm^2
SNRDISTPC=1000.						#SNR distance in parsecs
CREATEMAP="TRUE"					#TRUE: creates surface map, FALSE: creates intensity profile scaled to max
HEMISPHER=""						#LHS: left hemisphere, RHS: right hemisphere, "": total
ROTMAPXYZ="0.,0.,0."
SCALEINPC=0.0						#map scale in pc. if 0.0 no scaling applied

SHOCKGEOM="SS"						#SS: spherically-symmetric, PP: plane-parallel
RCOORDMAXFS=5.0						#maximum in r-space (real maximum is (RCOORDMAX-1)**3+1) for calculations related to forward shock
RCOORDMAXRS=5.0						#maximum in r-space (real maximum is (RCOORDMAX-1)**3+1) for calculations related to reverse shock
RSTEPSNUMFS=400						#number of bins in r-space for calculations related to forward shock
RSTEPSNUMRS=400						#number of bins in r-space for calculations related to reverse shock
PCOORDMAX=28.0						#maximum in p-space is 0.75*PCOORDMAX
PSTEPSNUM=560						#number of bins in p-space
KSTEPSNUM=560						#number of bins in k-space for turbulence calculations

HDFILEOUT="HRAW"
MFFILEOUT="BRAW"
CRFILEOUT="NRAW"
MTFILEOUT="TRAW"		

ALLRUNDIR=${TOPSIMDIR}/${HDSIMNAME}			#out directory for all simulation runs
CURRUNDIR=${ALLRUNDIR}/${RUNNAME}			#current run directory

mkdir -p  ${SIMDATDIR}
mkdir -p  ${TOPSIMDIR}
#mkdir -p  ${TOPSIMDIR}/${EXPLNTYPE}
mkdir -p  ${ALLRUNDIR}
mkdir -p  ${CURRUNDIR}


if [ "${RUNMODE}" == "CLUSTER" ];then

	mkdir -p ${SIMDATDIR}/${SIMULATIONS}/outlst
	mkdir -p ${SIMDATDIR}/${SIMULATIONS}/models
	mkdir -p ${SIMDATDIR}/${SIMULATIONS}/crslst
	mkdir -p ${SIMDATDIR}/${SIMULATIONS}/shocks
	mkdir -p ${SIMDATDIR}/${SIMULATIONS}/shocks
	mkdir -p ${SIMDATDIR}/${SIMULATIONS}/spelst
	mkdir -p ${SIMDATDIR}/${SIMULATIONS}/maplst

	MLSTA=${SIMDATDIR}/${SIMULATIONS}/models/modellist
	TLSTA=${SIMDATDIR}/${SIMULATIONS}/outlst/timeslist
	TLST0=${SIMDATDIR}/${SIMULATIONS}/outlst/timeslist0
	TLST1=${SIMDATDIR}/${SIMULATIONS}/outlst/timeslist1
	CRLST=${SIMDATDIR}/${SIMULATIONS}/crslst/crspecies
	SLST0=${SIMDATDIR}/${SIMULATIONS}/shocks/shocklist0
	SLST1=${SIMDATDIR}/${SIMULATIONS}/shocks/shocklist1
	RSLST=${SIMDATDIR}/${SIMULATIONS}/spelst/rspeclist
	RMLST=${SIMDATDIR}/${SIMULATIONS}/maplst/rmapslist${RPFORMAPS}

	
	if [ ! -f ${TLSTA} ];then
		echo "NO SIMULATION TIMES LIST FOUND! WRITING TIMES LIST FROM COMMAND LINE INPUT!"
		echo ${TIMELST} > ${TLSTA}
	fi
	if [ ! -f ${TLSTA} ];then
		echo "NO SIMULATION TIMES LIST FOUND! WRITING TIMES LIST FROM COMMAND LINE INPUT!"
		echo ${TIMELST} > ${TLSTA}
	fi
	if [ ! -f ${TLST0} ];then
		echo "NO SIMULATION TIMES LIST FOUND! WRITING TIMES LIST FROM COMMAND LINE INPUT!"
		echo ${TIMELST} > ${TLST0}
	fi
	if [ ! -f ${MLST1} ];then
		echo "NO SIMULATION MF MODEL FOUND! WRITING MF MODEL FROM COMMAND LINE INPUT!"
		echo ${MFMODEL} > ${MLST1}
	fi
	if [ ! -f ${CRLST} ];then
		echo "NO SIMULATION CR SPECIES FOUND! WRITING CR SPECIES FROM COMMAND LINE INPUT!"
		echo ${SPECIES} > ${CRLST}
	fi
	if [ ! -f ${SLST0} ];then
		echo "NO SIMULATION SHOCK TYPE FOUND! WRITING SHOCK TYPE FROM COMMAND LINE INPUT!"
		echo ${SHTYPES} > ${SLST0}
	fi
	if [ ! -f ${SLST1} ];then
		echo "NO SIMULATION SHOCK TYPE FOUND! WRITING SHOCK TYPE FROM COMMAND LINE INPUT!"
		echo ${SHTYPES} > ${SLST1}
	fi
	
	if [ ! -f ${RSLST} ];then
		echo "NO SIMULATION RADIATION SPECTRA TYPE FOUND! WRITING RADIATION SPECTRA TYPE FROM COMMAND LINE INPUT!"
		echo ${RSTYPES} > ${RSLST}
	fi
	if [ ! -f ${RMLST} ];then
		echo "NO SIMULATION RADIATION MAP TYPE FOUND! WRITING RADIATION MAP TYPE FROM COMMAND LINE INPUT!"	
		echo ${RMTYPES} > ${RMLST}
	fi
	
elif [ "${RUNMODE}" == "LOCAL" ];then

	mkdir -p ${SIMDATDIR}/LocRun
	mkdir -p ${SIMDATDIR}/LocRun/models
	mkdir -p ${SIMDATDIR}/LocRun/outlst
	mkdir -p ${SIMDATDIR}/LocRun/crslst
	mkdir -p ${SIMDATDIR}/LocRun/shocks
	mkdir -p ${SIMDATDIR}/LocRun/spelst
	mkdir -p ${SIMDATDIR}/LocRun/maplst
	
	MLSTA=${SIMDATDIR}/LocRun/models/modellist.tmp
	TLSTA=${SIMDATDIR}/LocRun/outlst/timeslist.tmp
	TLST0=${SIMDATDIR}/LocRun/outlst/timeslist0.tmp
	TLST1=${SIMDATDIR}/LocRun/outlst/timeslist1.tmp
	CRLST=${SIMDATDIR}/LocRun/crslst/crspecies.tmp
	SLST0=${SIMDATDIR}/LocRun/shocks/shocklist0.tmp
	SLST1=${SIMDATDIR}/LocRun/shocks/shocklist1.tmp
	RSLST=${SIMDATDIR}/LocRun/spelst/rspeclist.tmp
	RMLST=${SIMDATDIR}/LocRun/maplst/rmapslist.tmp

	echo ${MFMODEL} > ${MLSTA}	
	echo ${SHTYPES} > ${SLST0}
	echo ${SHTYPES} > ${SLST1}
	echo ${SPECIES} > ${CRLST}
	echo ${TIMELST} > ${TLSTA}
	echo ${TIMELST} > ${TLST0}
	echo ${TIMELST} > ${TLST1}
	if [ "${TIMELST}" == "" ];then
		if [ ${TIMESCOPY} == 0 ];then
			echo "TIMES LISTS WILL BE FILLED AUTOMATICALLY!"
			TIMESTARTSEQ=`echo ${TIMESTART} ${TIMEINTERVAL} | awk '{if(($1+$2)%$2 != 0) print $1+$2-($1+$2)%$2}'`
			if [ "${TIMESTARTSEQ}" != "" ];then
				echo ${TIMESTART} > ${TLST0}
				echo ${TIMESTART} > ${TLST1}
				echo ${TIMESTART} > ${TLSTA}
				
				seq -w ${TIMESTARTSEQ} ${TIMEINTERVAL} ${TIMEFINISH} >> ${TLST0}
				seq -w ${TIMESTARTSEQ} ${TIMEINTERVAL} ${TIMEFINISH} >> ${TLST1}
				seq -w ${TIMESTARTSEQ} ${TIMEINTERVAL} ${TIMEFINISH} >> ${TLSTA}
			else
				seq -w ${TIMESTART} ${TIMEINTERVAL} ${TIMEFINISH} > ${TLST0}
				seq -w ${TIMESTART} ${TIMEINTERVAL} ${TIMEFINISH} > ${TLST1}
				seq -w ${TIMESTART} ${TIMEINTERVAL} ${TIMEFINISH} > ${TLSTA}
			fi
		elif [ ${TIMESCOPY} == 1 ];then	
			echo "TIMES LISTS WILL BE COPIED FROM SIMULATION FILES!"
			cp ${SIMDATDIR}/${SIMULATIONS}/outlst/timeslist  ${TLSTA}
			cp ${SIMDATDIR}/${SIMULATIONS}/outlst/timeslist0 ${TLST0}
			cp ${SIMDATDIR}/${SIMULATIONS}/outlst/timeslist1 ${TLST1}
		fi
	fi
	echo ${RSTYPES} > ${RSLST}
	if [ "${RSTYPES}" == "" ];then
		echo "WARNING! NO RADIATION SPECTRUM TYPE IS GIVEN! WILL RUN PDR SPECTRUM CALCULATION!"
		echo "PDR" > ${RSLST}
	fi
	echo ${RMTYPES} > ${RMLST}
	if [ "${RMTYPES}" == "" ];then
		echo "WARNING! NO RADIATION MAP TYPE IS GIVEN! WILL RUN PDR MAP AT 1 TeV CALCULATION!"
		echo "PDR:1e12:PDR:1D" > ${RMLST}
	fi
		 
elif [ "${RUNMODE}" == "" ];then
	echo "RUN MODE is not chosen! Exiting!"
	exit 1
fi


if [ $ANS == 0 ];then
	cp ${TLST0} ${CURRUNDIR}/timeslist0
	cp ${SLST0} ${CURRUNDIR}/shocklist
elif [ $ANS == 1 ];then
	if   [ $CON == 1 ];then
		cp ${TLST1} ${CURRUNDIR}/timeslist1
	elif [ $CON == 0 ];then
		touch ${CURRUNDIR}/timeslist0
		cp ${TLSTA} ${CURRUNDIR}/timeslist1
	fi
	cp ${SLST1} ${CURRUNDIR}/shocklist
fi

if   [ "$EXPLNTYPE" == "T1" ];then
	HDFILEINP="tycho"					#files' name of HD data supplied by Vikram
elif [ "$EXPLNTYPE" == "T2" ];then
	HDFILEINP="wrbub"					#files' name of HD data supplied by Vikram
fi

cp ${TLSTA} ${CURRUNDIR}/timeslist
cp ${MLSTA} ${CURRUNDIR}/modellist
cp ${CRLST} ${CURRUNDIR}/crspecies
cp ${RSLST} ${CURRUNDIR}/rspeclist
cp ${RMLST} ${CURRUNDIR}/rmapslist

MODELLIST=${CURRUNDIR}/modellist
CRAYSLIST=${CURRUNDIR}/crspecies
RSPECLIST=${CURRUNDIR}/rspeclist
RMAPSLIST=${CURRUNDIR}/rmapslist

for MODEL in `cat ${MODELLIST}`; do

		
	MFPROFILE=`echo ${MODEL} | awk -F"_" '{print $1}'`
	MFATSHOCK=`echo ${MODEL} | awk -F"_" '{print ($2+0)*1e-6}'`
	MFDIRATSH=`echo ${MODEL} | awk -F"_" '{if($2+0==0) print "" ;else print $2}'`
	MFAMPMODE=`echo ${MODEL} | awk -F"_" '{print $2}' | cut -b1-4 | awk '{if($1=="NAMP" || $1=="RAMP") print $1}'`
	MFAMPFACT=`echo ${MODEL} | awk -F"_" '{print $2}' | cut -c5- | awk '{print ($1+0)*1e-2}'`
	MFDIRFACT=`echo ${MODEL} | awk -F"_" '{print $2}' | cut -c5-`
	ALFVDRIFT=`echo ${MODEL} | awk -F"_" '{print $3}'`
	
	MFMOD=`echo $MODEL | sed 's/_//g'`
	
	ALLSUBDIR=${CURRUNDIR}/${MODEL}/ALLSUBSDIR/${CALCULATE}		#all submit directories
	SUBJOBLOC=${ALLSUBDIR}/JOBS					#job files location
	BASHEXECS=${ALLSUBDIR}/BASH					#bash scritpts location
	PARAMSDIR=${ALLSUBDIR}/PARS					#task parameter file location (for later reusage)
	
	echo "----------------------------------PREPARING SIMULATIONS----------------------------------"
	echo "Creating output data structure:"
	echo "Creating ${MODEL} directory..."
	mkdir -p ${CURRUNDIR}/${MODEL}
	echo "done!"
	
#	mkdir -p  ${CURRUNDIR}/${MODEL}/ALLSUBSDIR
	mkdir -p  ${ALLSUBDIR}
	mkdir -p  ${ALLSUBDIR}/logs
	mkdir -p  ${ALLSUBDIR}/errs
	mkdir -p  ${ALLSUBDIR}/host
	mkdir -p  ${SUBJOBLOC}
	mkdir -p  ${BASHEXECS}
	mkdir -p  ${PARAMSDIR}
	
	rm -rf ${SUBJOBLOC}/*
	rm -rf ${BASHEXECS}/*
	
	echo "Creating HDPROFILES directory..."
	mkdir -p ${CURRUNDIR}/${MODEL}/HDPROFILES
	HDDIR=${CURRUNDIR}/${MODEL}/HDPROFILES
	echo "done!"
	
	echo "Creating MFPROFILES directory..."
	mkdir -p ${CURRUNDIR}/${MODEL}/MFPROFILES
	MFDIR=${CURRUNDIR}/${MODEL}/MFPROFILES
	echo "done!"
	
	echo "Creating COSMICRAYS directory..."
	mkdir -p ${CURRUNDIR}/${MODEL}/COSMICRAYS
	CRDIR=${CURRUNDIR}/${MODEL}/COSMICRAYS
	echo "done!"
	
	echo "Creating TURBULENCE directory..."
	mkdir -p ${CURRUNDIR}/${MODEL}/TURBULENCE
	MTDIR=${CURRUNDIR}/${MODEL}/TURBULENCE
	echo "done!"
	
	echo "Creating RADIATIONS directory..."
	mkdir -p ${CURRUNDIR}/${MODEL}/RADIATIONS
	mkdir -p ${CURRUNDIR}/${MODEL}/RADIATIONS/SPE
	mkdir -p ${CURRUNDIR}/${MODEL}/RADIATIONS/MAP
	mkdir -p ${CURRUNDIR}/${MODEL}/RADIATIONS/MSP
	RPDIR=${CURRUNDIR}/${MODEL}/RADIATIONS
	echo "done!"

	for CRSPECIES in `cat ${CURRUNDIR}/crspecies`;do
		echo "Creating COSMICRAYS/${CRSPECIES} directory ..."
		mkdir -p ${CRDIR}/${CRSPECIES}
		echo "done!"
		
		echo "Creating TURBULENCE/${CRSPECIES} directory..."
		mkdir -p ${MTDIR}/${CRSPECIES}
		echo "done!"	
		
		echo "Creating cosmic rays SUM directories..."
		mkdir -p ${CRDIR}/${CRSPECIES}/SUM
		mkdir -p ${CRDIR}/${CRSPECIES}/SUM/R
		mkdir -p ${CRDIR}/${CRSPECIES}/SUM/F
		mkdir -p ${CRDIR}/${CRSPECIES}/SUM/S
		CRSUM=${CRDIR}/${CRSPECIES}/SUM
		echo "done!"
		
		echo "Creating cosmic rays ESC directories..."
		mkdir -p ${CRDIR}/${CRSPECIES}/ESC
		mkdir -p ${CRDIR}/${CRSPECIES}/ESC/R
		mkdir -p ${CRDIR}/${CRSPECIES}/ESC/F
		mkdir -p ${CRDIR}/${CRSPECIES}/ESC/S
		CRESC=${CRDIR}/${CRSPECIES}/ESC
		echo "done!"
		
		HDDATAOUT=${HDDIR}
		MFDATAOUT=${MFDIR}
		
		for SHOCKTYPE in `cat ${CURRUNDIR}/shocklist`;do						
			echo "Creating cosmic ray output directory directory..."
			mkdir -p ${CRDIR}/${CRSPECIES}/${SHOCKTYPE}
			echo "done!"

			echo "Creating turbulence output directory directory..."
			mkdir -p ${MTDIR}/${CRSPECIES}/${SHOCKTYPE}
			echo "done!"

			if   [ "${SHOCKTYPE}" == "FSH" ];then
				RCOORDMAX=${RCOORDMAXFS}
				RSTEPSNUM=${RSTEPSNUMFS}
			elif [ "${SHOCKTYPE}" == "RSH" ];then
				RCOORDMAX=${RCOORDMAXRS}
				RSTEPSNUM=${RSTEPSNUMRS}
			elif [ "${SHOCKTYPE}" == "FSA" ];then
				RCOORDMAX=${RCOORDMAXFS}
				RSTEPSNUM=${RSTEPSNUMFS}
			fi
			
			CRDATAOUT=${CRDIR}/${CRSPECIES}/${SHOCKTYPE}
			MTDATAOUT=${MTDIR}/${CRSPECIES}/${SHOCKTYPE}
			
			if [ "${CALCULATE}" == "CRSPE0" ];then
				HDDATAINP=${HDDATAREP}/${HDSIMNAME}
				MFDATAINP=${MFDATAREP}/${HDSIMNAME}/${MFDIRPREF}${MFDIRATSH}${MFAMPMODE}${MFDIRFACT}
				if [ $ANS == "0" ];then
					if [ "$(ls -A ${CRDATAOUT})" ]; then
						echo "Output directory ${CRDATAOUT} is not empty!!!"
						echo "Finding the last output file and time..."
						echo "Creating new timeslist0 file..."
						ls ${CRDATAOUT}/ | sed 's/'${CRFILEOUT}'//g' | grep -v "N" > ${CRDIR}/${CRSPECIES}${SHOCKTYPE}DN0.tmp
						comm -13 ${CRDIR}/${CRSPECIES}${SHOCKTYPE}DN0.tmp ${CURRUNDIR}/timeslist0 > ${CRDIR}/${CRSPECIES}${SHOCKTYPE}OT0.tmp
						echo "Printing new timeslist0 file:"
						cat    ${CRDIR}/${CRSPECIES}${SHOCKTYPE}OT0.tmp
						rm     ${CRDIR}/${CRSPECIES}${SHOCKTYPE}DN0.tmp
						
						TIMESLIST=${CRDIR}/${CRSPECIES}${SHOCKTYPE}OT0.tmp
						TIMEINOUT=`ls ${CRDATAOUT}/ | sed 's/'${CRFILEOUT}'//g' | tail -1`
						CRDATAINP=${CRDATAOUT}
						CRFILEINP=${CRFILEOUT}
						MTDATAINP=${MTDATAOUT}
						MTFILEINP=${MTFILEOUT}
					else
						TIMESLIST=${CURRUNDIR}/timeslist0
						TIMEINOUT=""
						CRDATAINP=""
						CRFILEINP=""
						MTDATAINP=""
						MTFILEINP=""
					fi
				elif [ $ANS == "1" ];then
					if [ "$(ls -A ${CRDATAOUT})" ]; then
						echo "Output directory ${CRDATAOUT} is not empty!!!"
						echo "Finding the last output file and time..."
						echo "Creating new timeslist1 file..."
						ls ${CRDATAOUT}/ | sed 's/'${CRFILEOUT}'//g' | grep -v "N" > ${CRDIR}/${CRSPECIES}${SHOCKTYPE}DN1.tmp
						comm -13 ${CRDIR}/${CRSPECIES}${SHOCKTYPE}DN1.tmp ${CURRUNDIR}/timeslist1 > ${CRDIR}/${CRSPECIES}${SHOCKTYPE}OT1.tmp
						echo "Printing new timeslist1 file:"
						cat    ${CRDIR}/${CRSPECIES}${SHOCKTYPE}OT1.tmp
						rm     ${CRDIR}/${CRSPECIES}${SHOCKTYPE}DN1.tmp
						
						TIMESLIST=${CRDIR}/${CRSPECIES}${SHOCKTYPE}OT1.tmp
						TIMEINOUT=`ls ${CRDATAOUT}/ | sed 's/'${CRFILEOUT}'//g' | tail -1`
						CRDATAINP=${CRDATAOUT}
						CRFILEINP=${CRFILEOUT}
						MTDATAINP=${MTDATAOUT}
						MTFILEINP=${MTFILEOUT}
					else
						TIMESLIST=${CURRUNDIR}/timeslist1
						if   [ $CON == "0" ];then
							TIMEINOUT=""
							CRDATAINP=""
							CRFILEINP=""
							MTDATAINP=""
							MTFILEINP=""
						elif [ $CON == "1" ];then
							TIMEINOUT=`cat ${CURRUNDIR}/timeslist0 | sed '/^$/d' | sed -n '$p'`
							CRDATAINP=${CRSUM}/S
							CRFILEINP=${CRFILEOUT}
							CRDATAOUT=${CRDATAINP}
							MTFILEINP=${MTFILEOUT}
							MTDATAOUT=${MTDATAINP}
						fi
					fi
				fi
				
				JOBNAME=${EXPLNTYPE}${MFMOD}${CRSPECIES}${SHOCKTYPE}${ANS}
				echo "Producing bash file:"
				echo ${BASHEXECS}/${JOBNAME}.sh
######################
cat > ${BASHEXECS}/${JOBNAME}.sh <<HERE
#!/bin/bash
export LD_LIBRARY_PATH=\${_LD_LIBRARY_PATH}
cp \$PE_HOSTFILE ${CURRUNDIR}/host_pax/\${JOB_NAME}.h\${JOB_ID}
#CRSPE0 STAGE
python ${PATRON} \
 --paramfile=${PARAMSDIR}/${JOBNAME}.par \
 --calculate=${CALCULATE} --usesedsol=${USESEDSOL} \
 --hddatainp=${HDDATAINP} --hdfileinp=${HDFILEINP} --hddataout=${HDDATAOUT} --hdfileout=${HDFILEOUT} \
 --mfdatainp=${MFDATAINP} --mffileinp=${MFFILEINP} --mfdataout=${MFDATAOUT} --mffileout=${MFFILEOUT} \
 --crdatainp=${CRDATAINP} --crfileinp=${CRFILEINP} --crdataout=${CRDATAOUT} --crfileout=${CRFILEOUT} \
 --mtdatainp=${MTDATAINP} --mtfileinp=${MTFILEINP} --mtdataout=${MTDATAOUT} --mtfileout=${MTFILEOUT} \
 --timeslist=${TIMESLIST} --timeinout=${TIMEINOUT} \
 --mfofismna=${MFOFISMNA} --mfatshock=${MFATSHOCK} --mfampfact=${MFAMPFACT} --mfampmode=${MFAMPMODE} \
 --mfprofile=${MFPROFILE} --mfintprof=${MFINTPROF} --mfinitcon=${MFINITCON} --alfvdrift=${ALFVDRIFT} \
 --explntype=${EXPLNTYPE} --snsubtype=${SNSUBTYPE} --shocktype=${SHOCKTYPE} \
 --windbncsm=${WINDBNCSM} --nhdensity=${NHDENSITY} --expenergy=${EXPENERGY} --rshellpc1=${RSHELLPC1} --rshellpc2=${RSHELLPC2} --shdensity=${SHDENSITY} \
 --crspecies=${CRSPECIES} --injectpar=${INJECTPAR} --injsclpar=${INJSCLPAR} --shockgeom=${SHOCKGEOM} --crinitcon=${CRINITCON} \
 --rstepsnum=${RSTEPSNUM} --pstepsnum=${PSTEPSNUM} --rcoordmax=${RCOORDMAX} --pcoordmax=${PCOORDMAX} \
 --lmaxbdiff=${LMAXBDIFF} --lmingdiff=${LMINGDIFF} --diffinter=${DIFFINTER} --etaofbohm=${ETAOFBOHM} \
 --momdifpow=${MOMDIFPOW} --momdiftau=${MOMDIFTAU} --momdiffr1=${MOMDIFFR1} --momdiffr2=${MOMDIFFR2} \
 --mtapplied=${MTAPPLIED} --mtspectra=${MTSPECTRA} \
 --mtinitcon=${MTINITCON} --kstepsnum=${KSTEPSNUM} --momdifsclel=${MOMDIFSCLEL} --momdifsclpr=${MOMDIFSCLPR} --mfdampsca=${MFDAMPSCA} --mfscabins=${MFSCABINS}

HERE
#######################
				chmod +x ${BASHEXECS}/${JOBNAME}.sh
				echo "Producing job file:"
				echo ${SUBJOBLOC}/${JOBNAME}
#######################
cat > ${SUBJOBLOC}/${JOBNAME} <<HERE
#!/bin/bash
#$ -j n
#
#$ -o ${ALLSUBDIR}/logs
#$ -e ${ALLSUBDIR}/errs
#
#reserve slots
#$ -R y
#                 
#
#(send mail on job's begin, end and abort)
#$ -m bae
#
#parallel environment
#$ -pe pax ${NNUM}
#$ -l h_vmem=3G
#$ -l h_rt=48:00:00
source ${HOME}/soft/script/login/login-fipy310.sh
export _LD_LIBRARY_PATH=$LD_LIBRARY_PATH
/usr/lib64/openmpi/bin/mpirun -np ${NNUM} --mca btl "^tcp" ${BASHEXECS}/${JOBNAME}.sh
HERE
########################
			elif [ "$CALCULATE" == "CRSPE1" ];then
				HDDATAINP=${HDDIR}
				if   [ $ANS == "0" ];then
					TIMESLIST=${CURRUNDIR}/timeslist0
					CRDATAINP=${CRDATAOUT}
					CRFILEINP=${CRFILEOUT}
				elif [ $ANS == "1" ];then
					TIMESLIST=${CURRUNDIR}/timeslist1
					if   [ $CON == "0" ];then
						CRDATAINP=${CRDATAOUT}
						CRFILEINP=${CRFILEOUT}
					elif [ $CON == "1" ];then
						CRDATAINP=${CRSUM}/S
						CRFILEINP=${CRFILEOUT}
					fi
				fi
				for TIMEINOUT in `cat $TIMESLIST`;do
					JOBNAME=${EXPLNTYPE}${MFMOD}${CRSPECIES}${SHOCKTYPE}${TIMEINOUT}
					echo "Producing bash file:"
					echo ${BASHEXECS}/${JOBNAME}.sh
################################
cat > ${BASHEXECS}/${JOBNAME}.sh <<HERE
#!/bin/bash
export LD_LIBRARY_PATH=\${_LD_LIBRARY_PATH}
cp \$PE_HOSTFILE ${CURRUNDIR}/host_pax/\${JOB_NAME}.h\${JOB_ID}
#CRSPE1 STAGE
python ${PATRON} \
 --paramfile=${PARAMSDIR}/${JOBNAME}.par \
 --calculate=${CALCULATE} \
 --hddatainp=${HDDATAINP} --crdatainp=${CRDATAINP} --crfileinp=${CRFILEINP} \
 --timeinout=${TIMEINOUT} \
 --crspecies=${CRSPECIES} \
 --rstepsnum=${RSTEPSNUM} --rcoordmax=${RCOORDMAX} --rshellpc1=${RSHELLPC1} --rshellpc2=${RSHELLPC2}
HERE
################################
					chmod +x ${BASHEXECS}/${JOBNAME}.sh
					echo "Producing job file:"
					echo ${SUBJOBLOC}/${JOBNAME}
################################
cat > ${SUBJOBLOC}/${JOBNAME}<<HERE
#!/bin/bash
#$ -j y
#
#$ -o ${ALLSUBDIR}/logs
#
#reserve slots
###$ -R y           
#
#$ -l h_vmem=3G
#$ -l h_rt=00:29:59
source ${HOME}/soft/script/login/login-fipy310.sh
export _LD_LIBRARY_PATH=$LD_LIBRARY_PATH
${BASHEXECS}/${JOBNAME}.sh
HERE
################################
				done	#closes the TIMESLIST loop
			fi		#closes run stage if (CRSPE0, CRSPE1)
		done			#closes SHOCKTYPE loop
		if [ "$CALCULATE" == "CRSPE2" ];then
		#	HDDATAINP=${HDDATAREP}/${HDSIMNAME}
			HDDATAINP=${HDDIR}
			TIMESLIST=${CURRUNDIR}/timeslist${ANS}
			CRDATAOUT=${CRDIR}/${CRSPECIES}
			CRDATAINP=${CRDATAOUT}
			CRFILEINP=${CRFILEOUT}
			for TIMEINOUT in `cat $TIMESLIST`;do
				JOBNAME=${EXPLNTYPE}${MFMOD}${CRSPECIES}${TIMEINOUT}
				echo "Producing bash file:"
				echo ${BASHEXECS}/${JOBNAME}.sh
########################
cat > ${BASHEXECS}/${JOBNAME}.sh <<HERE
#!/bin/bash
export LD_LIBRARY_PATH=\${_LD_LIBRARY_PATH}
cp \$PE_HOSTFILE ${CURRUNDIR}/host_pax/\${JOB_NAME}.h\${JOB_ID}
#CRSPE2 STAGE
python ${PATRON} \
 --paramfile=${PARAMSDIR}/${JOBNAME}.par \
 --calculate=${CALCULATE} \
 --hddatainp=${HDDATAINP} \
 --crdatainp=${CRDATAINP} --crfileinp=${CRFILEINP} --crdataout=${CRDATAOUT} --crfileout=${CRFILEOUT} \
 --timeinout=${TIMEINOUT} \
 --crspecies=${CRSPECIES} \
 --rstepsnumrs=${RSTEPSNUMRS} --rstepsnumfs=${RSTEPSNUMFS} \
 --rcoordmaxrs=${RCOORDMAXRS} --rcoordmaxfs=${RCOORDMAXFS} --pstepsnum=${PSTEPSNUM} \
 --rshellpc1=${RSHELLPC1}     --rshellpc2=${RSHELLPC2}
HERE
########################
				chmod +x ${BASHEXECS}/${JOBNAME}.sh
				echo "Producing job file:"
				echo ${SUBJOBLOC}/${JOBNAME}
########################
cat > ${SUBJOBLOC}/${JOBNAME}<<HERE
#!/bin/bash
#$ -j y
#
#$ -o ${ALLSUBDIR}/logs
#
#reserve slots
###$ -R y           
#
#$ -l h_vmem=3G
#$ -l h_rt=00:29:59
source ${HOME}/soft/script/login/login-fipy310.sh
export _LD_LIBRARY_PATH=$LD_LIBRARY_PATH
${BASHEXECS}/${JOBNAME}.sh
HERE
########################
			done	#closes the TIMESLIST loop
		fi		#closes run stage if (CRSPE2)
		
		if [ "$CALCULATE" == "CRPROF" ];then
			HDDATAINP=${HDDIR}
			TIMESLIST=${CURRUNDIR}/timeslist
			CRFILE="NER"
			CRDATAINP=${CRDIR}
			CRFILEINP=${CRSPECIES}/${RADORIGIN}/${CRFILE}
			for TIMEINOUT in `cat $TIMESLIST`;do
				JOBNAME=${EXPLNTYPE}${MFMOD}${CRSPECIES}PROF${TIMEINOUT}
				echo "Producing bash file:"
				echo ${BASHEXECS}/${JOBNAME}.sh
################################
cat > ${BASHEXECS}/${JOBNAME}.sh <<HERE
#!/bin/bash
export LD_LIBRARY_PATH=\${_LD_LIBRARY_PATH}
cp \$PE_HOSTFILE ${CURRUNDIR}/host_pax/\${JOB_NAME}.h\${JOB_ID}
#CRSPE1 STAGE
python ${PATRON} \
 --paramfile=${PARAMSDIR}/${JOBNAME}.par \
 --calculate=${CALCULATE} \
 --crsenergy=${CRSENERGY} \
 --hddatainp=${HDDATAINP} --crdatainp=${CRDATAINP} --crfileinp=${CRFILEINP} \
 --timeinout=${TIMEINOUT} \
 --crspecies=${CRSPECIES} \
 --rstepsnum=${RSTEPSNUM} --rcoordmax=${RCOORDMAX} --pstepsnum=${PSTEPSNUM}\
 --rshellpc1=${RSHELLPC1} --rshellpc2=${RSHELLPC2}
HERE
################################
					chmod +x ${BASHEXECS}/${JOBNAME}.sh
					echo "Producing job file:"
					echo ${SUBJOBLOC}/${JOBNAME}
################################
cat > ${SUBJOBLOC}/${JOBNAME}<<HERE
#!/bin/bash
#$ -j y
#
#$ -o ${ALLSUBDIR}/logs
#
#reserve slots
###$ -R y           
#
#$ -l h_vmem=3G
#$ -l h_rt=00:29:59
source ${HOME}/soft/script/login/login-fipy310.sh
export _LD_LIBRARY_PATH=$LD_LIBRARY_PATH
${BASHEXECS}/${JOBNAME}.sh
HERE
################################
			done	#closes the TIMESLIST loop
		fi 		#closes run stage if (CRPROF)
	done			#closes CRSPECIES loop
	if [ "$CALCULATE" == "RADSPE" ];then
		TIMESLIST=${CURRUNDIR}/timeslist
		HDDATAINP=${HDDATAREP}/${HDSIMNAME}
		HDDATAOUT=${HDDIR}		#remove when HD data write/read is implemented and HDDATAINP is $HDDIR
		MFDATAINP=${MFDIR}
		MFFILEINP=${MFFILEOUT}
		CRDATAINP=${CRDIR}
		RPDATAOUT=${RPDIR}/SPE
		for RADIATION in `cat ${CURRUNDIR}/rspeclist`;do
			if  [ "${RADIATION}" == "PDV" -o "${RADIATION}" == "PDR" ];then
				CRSPECIES="PR"
			else
				CRSPECIES="EL"
			fi
			
			if  [ ${RADIATION} == "SYR" -o ${RADIATION} == "ICR" -o "${RADIATION}" == "PDR" ];then
				CRFILE="NER"
			else
				CRFILE="NED"
			fi
			CRFILEINP=${CRSPECIES}/${RADORIGIN}/${CRFILE}
			RPFILEOUT=${RADIATION}
			for TIMEINOUT in `cat $TIMESLIST`;do
				JOBNAME=${EXPLNTYPE}${MFMOD}${RPFILEOUT}${TIMEINOUT}
				echo "Producing bash file:"
				echo ${BASHEXECS}/${JOBNAME}.sh
########################
cat > ${BASHEXECS}/${JOBNAME}.sh <<HERE
#!/bin/bash
export LD_LIBRARY_PATH=\${_LD_LIBRARY_PATH}
cp \$PE_HOSTFILE ${CURRUNDIR}/host_pax/\${JOB_NAME}.h\${JOB_ID}
#RADSPE STAGE
python ${PATRON} \
 --paramfile=${PARAMSDIR}/${JOBNAME}.par \
 --usesedsol=${USESEDSOL} \
 --calculate=${CALCULATE} --radiation=${RADIATION} --radobject=${RADOBJECT} \
 --hddatainp=${HDDATAINP} --hdfileinp=${HDFILEINP} --hddataout=${HDDATAOUT} \
 --mfdatainp=${MFDATAINP} --mffileinp=${MFFILEINP} \
 --crdatainp=${CRDATAINP} --crfileinp=${CRFILEINP} --rstepsnum=${RSTEPSNUM} --pstepsnum=${PSTEPSNUM} \
 --rpdataout=${RPDATAOUT} --rpfileout=${RPFILEOUT} \
 --timeinout=${TIMEINOUT} \
 --mfofismna=${MFOFISMNA} --mfatshock=${MFATSHOCK} --mfampfact=${MFAMPFACT} --mfampmode=${MFAMPMODE} \
 --explntype=${EXPLNTYPE} --snsubtype=${SNSUBTYPE} --shocktype=${SHOCKTYPE} \
 --windbncsm=${WINDBNCSM} --nhdensity=${NHDENSITY} --expenergy=${EXPENERGY} --rshellpc1=${RSHELLPC1} --rshellpc2=${RSHELLPC2} --shdensity=${SHDENSITY} \
 --synemfunc=${SYNEMFUNC} --steradian=${STERADIAN} --snrdistpc=${SNRDISTPC} \
 --radintres=${RADINTRES} --radnormax=${RADNORMAX} 
HERE
########################
				chmod +x ${BASHEXECS}/${JOBNAME}.sh
				echo "Producing job file:"
				echo ${SUBJOBLOC}/${JOBNAME}
########################
cat > ${SUBJOBLOC}/${JOBNAME}<<HERE
#!/bin/bash
#$ -j y
#
#$ -o ${ALLSUBDIR}/logs
#
#reserve slots
###$ -R y           
#
#$ -l h_vmem=3G
#$ -l h_rt=00:29:59
source ${HOME}/soft/script/login/login-fipy310.sh
export _LD_LIBRARY_PATH=$LD_LIBRARY_PATH
${BASHEXECS}/${JOBNAME}.sh
HERE
########################	
			done	#closes TIMESLIST loop
		done		#closes RADIATION loop
	elif [ "$CALCULATE" == "RADMAP" -o "$CALCULATE" == "RADM3D" -o "$CALCULATE" == "MAPSPE" -o "$CALCULATE" == "MAPSPE_PARALLEL" -o "$CALCULATE" == "MAPINT" ];then
		TIMESLIST=${CURRUNDIR}/timeslist
		HDDATAINP=${HDDATAREP}/${HDSIMNAME}
		HDDATAOUT=${HDDIR}		#remove when HD data write/read is implemented and HDDATAINP is $HDDIR
		MFDATAINP=${MFDIR}
		MFFILEINP=${MFFILEOUT}
		CRDATAINP=${CRDIR}
		if   [ "$CALCULATE" == "RADMAP" -o "$CALCULATE" == "RADM3D" -o "$CALCULATE" == "MAPINT" ];then
			RPDATAOUT=${RPDIR}/MAP
			REQEST_TIME="00:29:59"
		elif [ "$CALCULATE" == "MAPSPE" -o "$CALCULATE" == "MAPSPE_PARALLEL" ];then
			RPDATAOUT=${RPDIR}/MSP
#			REQEST_TIME="24:00:00"
			REQEST_TIME="00:29:59"
		fi
		for TIMEINOUT in `cat $TIMESLIST`;do
			for RMAP in `cat ${RMAPSLIST}`;do
				RADIATION=`echo $RMAP | awk -F":" '{print $1}'`
				MAPENERGY=`echo $RMAP | awk -F":" '{print $2}'`
				MAPENBAND=`echo $RMAP | awk -F":" '{print $2}'`
				RPFILEOUT=`echo $RMAP | awk -F":" '{print $3}'`
				MFCOMPDIM=`echo $RMAP | awk -F":" '{print $4}'`
				
				if  [ "${RADIATION}" == "PDR" ];then
					CRSPECIES="PR"
				else
					CRSPECIES="EL"
				fi

				CRFILE="NER"		
				CRFILEINP=${CRSPECIES}/${RADORIGIN}/${CRFILE}
				
				JOBNAME=${EXPLNTYPE}${MFMOD}${RPFILEOUT}${TIMEINOUT}
				echo "Producing bash file:"
				echo ${BASHEXECS}/${JOBNAME}.sh
######################## 
cat > ${BASHEXECS}/${JOBNAME}.sh <<HERE
#!/bin/bash
export LD_LIBRARY_PATH=\${_LD_LIBRARY_PATH}
cp \$PE_HOSTFILE ${CURRUNDIR}/host_pax/\${JOB_NAME}.h\${JOB_ID}
#RADMAP STAGE(s)
#--mapenband=${MAPENBAND}
python ${PATRON} \
 --paramfile=${PARAMSDIR}/${JOBNAME}.par \
 --usesedsol=${USESEDSOL} \
 --calculate=${CALCULATE} --radiation=${RADIATION} --radobject=${RADOBJECT} \
 --createmap=${CREATEMAP} --mapenergy=${MAPENERGY} --hemispher=${HEMISPHER} --rotmapxyz=${ROTMAPXYZ} --scaleinpc=${SCALEINPC} \
 --hddatainp=${HDDATAINP} --hdfileinp=${HDFILEINP} --hddataout=${HDDATAOUT} \
 --mfdatainp=${MFDATAINP} --mffileinp=${MFFILEINP} --mfcompdim=${MFCOMPDIM} \
 --crdatainp=${CRDATAINP} --crfileinp=${CRFILEINP} --rstepsnum=${RSTEPSNUM} --pstepsnum=${PSTEPSNUM} \
 --rpdataout=${RPDATAOUT} --rpfileout=${RPFILEOUT} \
 --timeinout=${TIMEINOUT} \
 --mfofismna=${MFOFISMNA} --mfatshock=${MFATSHOCK} --mfampfact=${MFAMPFACT} --mfampmode=${MFAMPMODE} \
 --explntype=${EXPLNTYPE} --snsubtype=${SNSUBTYPE} --shocktype=${SHOCKTYPE} \
 --windbncsm=${WINDBNCSM} --nhdensity=${NHDENSITY} --expenergy=${EXPENERGY} --rshellpc1=${RSHELLPC1} --rshellpc2=${RSHELLPC2} --shdensity=${SHDENSITY} \
 --synemfunc=${SYNEMFUNC} --steradian=${STERADIAN} --snrdistpc=${SNRDISTPC} \
 --radintres=${RADINTRES} --radnormax=${RADNORMAX} 
HERE
########################
				chmod +x ${BASHEXECS}/${JOBNAME}.sh
				echo "Producing job file:"
				echo ${SUBJOBLOC}/${JOBNAME}
########################
cat > ${SUBJOBLOC}/${JOBNAME}<<HERE
#!/bin/bash
#$ -j y
#
#$ -o ${ALLSUBDIR}/logs
#
#reserve slots
###$ -R y           
#
#$ -l h_vmem=3G
#$ -l h_rt=${REQEST_TIME}
source ${HOME}/soft/script/login/login-fipy310.sh
export _LD_LIBRARY_PATH=$LD_LIBRARY_PATH
${BASHEXECS}/${JOBNAME}.sh
HERE
########################
			done	#closes RMAPSLIST loop
		done		#closes TIMESLIST loop
	fi
done				#closes MODELLIST loop


echo "----------------------------------PREPARING SIMULATIONS IS DONE!-------------------------"
echo ""


JOBLIST=${ALLSUBDIR}/${CALCULATE}.joblist
if   [ "${RUNMODE}" == "CLUSTER" ];then
	echo "RUN MODE: CLUSTER"
	if   [ "$CALCULATE" == "CRSPE0" ];then
		source /usr/gridengine/pax/common/settings.sh
		ls ${SUBJOBLOC}/*${ANS}| awk -F"/" '{print $NF}' > ${JOBLIST}
		for JOB in `cat ${JOBLIST}`;do
			qsub ${SUBJOBLOC}/${JOB}
#			echo ${SUBJOBLOC}/${JOB}
		done
	elif [ "$CALCULATE" == "CRSPE1" -o  "$CALCULATE" == "CRSPE2" -o "$CALCULATE" == "CRPROF" -o  "$CALCULATE" == "RADSPE" -o "$CALCULATE" == "RADMAP" -o "$CALCULATE" == "RADM3D" -o "$CALCULATE" == "MAPSPE" -o "$CALCULATE" == "MAPSPE_PARALLEL" ];then
		source /usr/gridengine/default/common/settings.sh
		ls ${SUBJOBLOC}/* | awk -F"/" '{print $NF}' > ${JOBLIST}
		for JOB in `cat ${JOBLIST}`;do
			qsub ${SUBJOBLOC}/${JOB}
#			echo ${SUBJOBLOC}/${JOB}
		done
	fi
elif [ "${RUNMODE}" == "LOCAL" ];then
	echo "RUN MODE: LOCAL"
	if   [ "$CALCULATE" == "CRSPE0" ];then
		ls ${SUBJOBLOC}/*${ANS}| awk -F"/" '{print $NF}' > ${JOBLIST}
		echo ""
		for JOB in `cat ${JOBLIST}`;do
			cat ${BASHEXECS}/${JOB}.sh | grep -v "LIBRARY" | grep -v "HOSTFILE" > ${BASHEXECS}/${JOB}.tmp
			mv  ${BASHEXECS}/${JOB}.tmp ${BASHEXECS}/${JOB}.sh
			chmod +x ${BASHEXECS}/${JOB}.sh
			echo "STARTING: ${JOB}.sh"
			time -p mpirun -np ${NNUM} \
			${BASHEXECS}/${JOB}.sh
#			cat ${BASHEXECS}/${JOB}.sh
		done
	elif [ "$CALCULATE" == "CRSPE1" -o "$CALCULATE" == "CRSPE2" -o "$CALCULATE" == "CRPROF" -o  "$CALCULATE" == "RADSPE" -o "$CALCULATE" == "RADMAP" -o "$CALCULATE" == "RADM3D" -o "$CALCULATE" == "MAPSPE" -o "$CALCULATE" == "MAPINT" ];then
		ls ${SUBJOBLOC}/* | awk -F"/" '{print $NF}' > ${JOBLIST}
		for JOB in `cat ${JOBLIST}`;do
			cat ${BASHEXECS}/${JOB}.sh | grep -v "LIBRARY" | grep -v "HOSTFILE" > ${BASHEXECS}/${JOB}.tmp
			mv  ${BASHEXECS}/${JOB}.tmp ${BASHEXECS}/${JOB}.sh
			chmod +x ${BASHEXECS}/${JOB}.sh
			echo "STARTING: ${JOB}.sh"
			time -p ${BASHEXECS}/${JOB}.sh
#			cat ${BASHEXECS}/${JOB}.sh
		done
	fi
fi

