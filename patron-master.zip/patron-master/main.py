######################################################################################
### RATPaC - Radiation Acceleration Transport PArallel Code ###
#=====================================================================================
# File:	  main.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2010 - 2015
# 	  Robert Brose <robert.brose@mail.de>, 2015 - present
#         Iurii Sushch <iurii.sushch@desy.de>, 2017 - present
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#new version tracking start with 2.0.0; the last version of pspec2d is 19.2
#v2.0.0: move to objects/modules that are imported from dedicated modules
#v2.0.1: getting rid of function aliases where possible (Valf introduced)
#v2.1.0: introducing mhd profiles object
#v2.1.1: introducing mhd turbulence object
#v2.1.2: introducing setpar module; local adapt time func.is added; adapted to new params FSA, FSH, RSH
#v2.2.0: parameters changed to work with global setpar module, introducing shared solver module, adding main function
#v2.2.1: simple conversion of raw cr output to data added. Rpc2Rnorm conversion added
#v2.2.2: proper conversion of raw cr output to data added.
#v2.2.3: radiation production stage added
#v2.2.4: maps and profiles production stage is added
#v2.2.5: spectra from maps production stage is added
#v2.2.6: adding evotru support, cosmetic changes
#v2.3.0: adding mttran support
#v2.3.1: adding support for production of energy integrated maps
#v2.4.0: adding support for SOFA and injection scaling param to tecoef objects
#v2.4.1: adding support for writing down simulation/task parameters
#v2.5.0: transition to package architecture and git for version control
#v2.6.0: adding support of crprof
#v2.6.1: added DAM-profile parameters
#v2.6.2: Changed for use with setup-routine
#v2.7.0: Include possibility to run pluto as MHD-module
#v2.7.1: Adjustments for updated solver routine
#v2.8.0: Adjustments for new universal solver; changes which allow to simulate CR species together in one run.

__vesion__='2.8.0'


from patron.setpar import *

def main(argv=None):
	if argv is None: argv=sys.argv
	if len(argv) > 0:
		SP = SimParams()
		SetupSimParams(SP,argv[1:])
	else:
		print "main.py: No Parameter file given!"
		sys.exit(0)
	InitSimulation(SP)

        numspecies=0

        #if SP.speciespr == False and SP.speciesel == False:
        #        if parallel.procID == 0:
        #                print "RATPaC: Is it a joke? There are no particles to accelerate! I quit!"
        #        sys.exit(0)
        #        
        #if SP.speciespr == True:
        #        if parallel.procID == 0: 
        #                numspecies += 1
        #                print "RATPaC: CRspecies: We have PROTONS in the system!"
        #else:  	
        #        if parallel.procID == 0: print "RATPAC: CRspecies: I can't find any PROTONS! How about you inject some?"
	#
        #if SP.speciesel == True:
        #        if parallel.procID == 0: 
        #                numspecies += 1
        #                print "RATPaC: CRspecies: We have ELECTRONS in the system!"
        #else:  	
        #        if parallel.procID == 0: print "RATPAC: CRspecies: I can't find any ELECTRONS! Feed me some!"
        
                            

	
	if parallel.procID == 0:
        #        print "RATPaC: CRspecies: number of species is", numspecies
		print "RATPaC: seems like all important parameters are set, let's go!"
		print "RATPaC: runing on",parallel.Nproc, "processor(s)..."
        

        if  SP.CALCULATE == "CRSPE0":
		PrintSimParams(SP)
                CFSH = []
                for species in SP.CRSPECIES:
                        if species == "PR": injSclPar = SP.injsclparpr
                        elif species == "EL": injSclPar = SP.injsclparel
 			elif species == "HE": injSclPar = SP.injsclparhe
			elif species == "C": injSclPar = SP.injsclparc
 			elif species == "OX": injSclPar = SP.injsclparox
			elif species == "FE": injSclPar = SP.injsclparfe	
                        CFSH.append(tecoef.TranEqnCoeffFuncs(shockType=SP.SHOCKTYPE,\
                                                             nhDensity=SP.nhdensity,\
                                                             expEnergy=SP.expenergy,\
                                                             useSedSol=SP.usesedsol,\
                                                             crSpecies=species,\
                                                             injectPar=SP.injectpar,\
                                                             injSclPar=injSclPar,\
                                                             mfProfile=SP.MFPROFILE,\
                                                             alfvDrift=SP.ALFVDRIFT,\
                                                             hdDataInp=SP.HDDATAINP,\
                                                             hdFileInp=SP.HDFILEINP,\
                                                             mfDataInp=SP.MFDATAINP,\
                                                             mfFileInp=SP.MFFILEINP,\
                                                             SP=SP))	
                for i, species in enumerate(SP.CRSPECIES):
			if i > 0:
				if parallel.procID == 0:
					print "main: updating smhd of client processes" 
	                        CFSH[i].smhd = CFSH[0].smhd
                                                        
		CFFS=CFSH[0]
		if SP.SHOCKTYPE == "RSH":
			CFFS=tecoef.TranEqnCoeffFuncs(shockType="FSH",\
                                                      nhDensity=SP.nhdensity,\
                                                      expEnergy=SP.expenergy,\
                                                      useSedSol=SP.usesedsol,\
                                                      crSpecies=SP.CRSPECIES[0],\
                                                      injectPar=SP.injectpar,\
                                                      injSclPar=SP.injsclpar,\
                                                      mfProfile=SP.MFPROFILE,\
                                                      alfvDrift=SP.ALFVDRIFT,\
                                                      hdDataInp=SP.HDDATAINP,\
                                                      hdFileInp=SP.HDFILEINP,\
                                                      mfDataInp=SP.MFDATAINP,\
                                                      mfFileInp=SP.MFFILEINP,\
                                                      SP=SP)

		if SP.usesedsol != 5:
			Rpc2Rnorm(CFFS,SP.rshellpc1,SP.rshellpc2,SP.HDDATAOUT,SP.timeslist,SP.TIMESLIST)
			Rrsh2Rfsh(CFFS,SP.HDDATAOUT,SP.timeslist,SP.TIMESLIST)
		
                if   SP.SHOCKTYPE == "FSA" or SP.SHOCKTYPE == "FSH":
                        MFTE=mftran.TransportEquation(rStepsNum=250,\
							rCoordMax=1.0,\
							timeInit=SP.mfinitime,\
							mfIntProf=SP.MFINTPROF,\
							mfInitCon=SP.mfinitcon,\
							inFileName=SP.MFINPFN,\
							teCoeffFuncs=CFSH[0],\
							SP=SP)
							#timeInit changed to 0 from SP.mfinitime

#                if   SP.SHOCKTYPE == "FSA" or SP.SHOCKTYPE == "FSH":
#                        MFTE=mftran.TransportEquation(rStepsNum=SP.rstepsnum,\
#							rCoordMax=SP.rcoordmax,\
#							timeInit=SP.mfinitime,\
#							mfIntProf=SP.MFINTPROF,\
#							mfInitCon=SP.mfinitcon,\
#							inFileName=SP.MFINPFN,\
#							teCoeffFuncs=CFSH[0],\
#							SP=SP)
#							#timeInit changed to 0 from SP.mfinitime



		elif SP.SHOCKTYPE == "RSH":
			MFTE=mftran.TransportEquation(rStepsNum=250,\
							rCoordMax=1.0,\
							timeInit=SP.mfinitime,\
							mfIntProf=SP.MFINTPROF,\
							mfInitCon=SP.mfinitcon,\
							inFileName=SP.MFINPFN,\
							teCoeffFuncs=CFFS,\
							SP=SP)

                CRTE=[]
                for i, cfsh in enumerate(CFSH):
                        cfsh.MFR=MFTE.rc.globalValue
                        cfsh.MFB=MFTE.B.globalValue
                        
                        #if parallel.procID == 0: print "DEBUG: MFB = ", cfsh.MFB

                        CRTE.append(crtran.TransportEquation(rStepsNum=SP.rstepsnum,\
                                                             pStepsNum=SP.pstepsnum,\
                                                             rCoordMax=SP.rcoordmax,\
                                                             pCoordMax=SP.pcoordmax,\
                                                             timeInit=SP.timestart,\
                                                             shockGeom=SP.SHOCKGEOM,\
                                                             crInitCon=SP.CRINITCON,\
                                                             inFileName=SP.CRINPFN[i],\
                                                             teCoeffFuncs=cfsh))	


		MTTE=mttran.TransportEquation(rStepsNum=SP.rstepsnum,\
                                              pStepsNum=SP.pstepsnum,\
                                              kStepsNum=SP.kstepsnum,\
                                              rCoordMax=SP.rcoordmax,\
                                              pCoordMax=SP.pcoordmax,\
                                              timeInit=SP.timestart,\
                                              shockGeom=SP.SHOCKGEOM,\
                                              mtInitCon=SP.MTINITCON,\
                                              inFileName=SP.MTINPFN,\
                                              teCoeffFuncs=CFSH[0],\
                                              crNumDensity=CRTE[0].N,\
                                              setpar=SP)				
                
                HDTE = CFSH[0].HDTE
		#apply HDTE[0] to all species
		if SP.usesedsol == 5:		
			for i in range(len(CFSH)):
				if i > 0:
					CFSH[i].HDTE = CFSH[0].HDTE
					CFSH[i].ttr  = CFSH[0].HDTE.ttr
					CFSH[i].tsf  = CFSH[0].HDTE.tsf
					CFSH[i].RFS  = CFSH[0].HDTE.RFS
					CFSH[i].RRS  = CFSH[0].HDTE.RRS
					CFSH[i].Rsh  = CFSH[0].HDTE.Rsh
					CFSH[i].Vsh  = CFSH[0].HDTE.Vsh
					CFSH[i].Vinj = CFSH[0].HDTE.Vinj
					CFSH[i].VLHS = CFSH[0].HDTE.Vlhs_FS_I		#always without Alfvenic velocity
					CFSH[i].VRHS = CFSH[0].HDTE.Vrhs_FS_I		#always without Alfvenic velocity
					if   SP.ALFVDRIFT == "I": CFSH[i].Vlhs = CFSH[0].HDTE.Vlhs_FS_I; CFSH[i].Vrhs = CFSH[0].HDTE.Vrhs_FS_I
					elif SP.ALFVDRIFT == "A": CFSH[i].Vlhs = CFSH[0].HDTE.Vlhs_FS_A; CFSH[i].Vrhs = CFSH[0].HDTE.Vrhs_FS_A
					CFSH[i].nh     = CFSH[0].HDTE.nh
					CFSH[i].nh_u   = CFSH[0].HDTE.nh_u
					CFSH[i].nh_sh  = CFSH[0].HDTE.nh_sh
					CFSH[i].rho    = CFSH[0].HDTE.rho
					CFSH[i].rho_u  = CFSH[0].HDTE.rho_u
					CFSH[i].rho_sh = CFSH[0].HDTE.rho_sh
					CFSH[i].Pg     = CFSH[0].HDTE.Pg
					CFSH[i].Pg_sh  = CFSH[0].HDTE.Pg_sh
					CFSH[i].Tg     = CFSH[0].HDTE.Tg
					CFSH[i].Tg_sh  = CFSH[0].HDTE.Tg_sh
					CFSH[i].eta_i  = CFSH[0].eta_i_AN

                
                SolveEquationCR=solver.SolveEquationCRandHDandMTandMF

		if SP.PLUTOFLAG == "pure":
			#External parameters
			##################################################################
			#Vikrams profiles
			#plutodll = getenv("PATRONDIR")+"/source/Pluto/pluto_vik.so" #replace later with setpar argument
			#Chevaliers  profiles
			plutodll = SP.PLUTO_DLL  #os.getenv("PATRONDIR")+"/lib/pluto_vik.so"
			##################################################################

			HDTE = evoplu.TransportEquation(plutodll,SP.HDOUTFN,SP.timeslist,SP,inFileName=SP.HDINPFN)
			SolveEquationCR=solver.SolveEquationHD		

                # if SP.speciespr == True:
                #         #CRTE=CRTEPR
                #         SolveEquationCR(SP,CRTE[0],MFTE,MTTE,HDTE)
                # if SP.speciesel == True:
                #         #CRTE=CRTEEL
                #         SolveEquationCR(SP,CRTE[1],MFTE,MTTE,HDTE)

		SolveEquationCR(SP,CRTE,MFTE,MTTE,HDTE)
		
	elif SP.CALCULATE == "CRSPE1":
                for i, species in enumerate(SP.CRSPECIES):
                        dr=SP.rcoordmax/SP.rstepsnum
                        # crinpfn = SP.CRDATAINP + "/" + species + "/" + SP.SHOCKTYPE + "/" +SP.CRFILEINP1 + SP.TIMEINOUT
                        # crspe1.ConvertRaw2DatTDU(1.0,SP.rcoordmax,dr,inFileName=crinpfn,crSpecies=species,timeInOut=SP.TIMEINOUT)
                        crspe1.ConvertRaw2DatTDU(1.0,SP.rcoordmax,dr,inFileName=SP.CRINPFN[i],crSpecies=species,timeInOut=SP.TIMEINOUT)

                        
                        if SP.rspenorm1 == 0 and SP.rspenorm2 == 0:
                                #(SP.rspenorm1,SP.rspenorm2)=FindR12(hdDataInp=SP.HDDATAINP,timeInOut=SP.TIMEINOUT)
                                Rfs=FindRfs(hdDataInp=SP.HDDATAOUT,timeInOut=SP.TIMEINOUT)
                                if parallel.procID == 0: print "Rfs = ", Rfs
                                SP.rspenorm1 = SP.rshellpc1*pc/Rfs
                                SP.rspenorm2 = SP.rshellpc2*pc/Rfs
                                
                        crspe1.ConvertRaw2DatR12(SP.rspenorm1,SP.rspenorm2,dr,inFileName=SP.CRINPFN[i],crSpecies=species,timeInOut=SP.TIMEINOUT)

		
	elif SP.CALCULATE == "CRSPE2":
		RRS=FindRrs(hdDataInp=SP.HDDATAOUT,timeInOut=SP.TIMEINOUT)

                for i, species in enumerate(SP.CRSPECIES):
                        crspe2.ConvertRaw2DatSUM(inFileNameRS=SP.CRINPFNRS[i],\
                                                 inFileNameFS=SP.CRINPFNFS[i],\
                                                 crDataOut=SP.CRDATAOUT[i],\
                                                 crFileOut=SP.CRFILEOUT,\
                                                 crSpecies=species,\
                                                 rStepsNumRS=SP.rstepsnumrs,\
                                                 rStepsNumFS=SP.rstepsnumfs,\
                                                 rCoordMaxRS=SP.rcoordmaxrs,\
                                                 rCoordMaxFS=SP.rcoordmaxfs,\
                                                 pStepsNum=SP.pstepsnum,RRS=RRS,timeInOut=SP.TIMEINOUT)

        elif SP.CALCULATE == "CRSPE3":
		comm = MPI.COMM_WORLD
		size = comm.Get_size()
		rank = comm.Get_rank()
		if rank == 0:		
			data =array_split(SP.timeslist,size)
		else:
			data = None
		data = comm.scatter(data, root=0)
		comm.barrier()
		print "node=", rank, " times: ", data
		comm.barrier()
                for i, species in enumerate(SP.CRSPECIES):
                        for time in data:
                                timestr = str(float(time))

                                dr=SP.rcoordmax/SP.rstepsnum
                                # crinpfn = SP.CRDATAINP + "/" + species + "/" + SP.SHOCKTYPE + "/" +SP.CRFILEINP1 + SP.TIMEINOUT
                                # crspe1.ConvertRaw2DatTDU(1.0,SP.rcoordmax,dr,inFileName=crinpfn,crSpecies=species,timeInOut=SP.TIMEINOUT)
                                crspe3.ConvertRaw2DatTDU(1.0,SP.rcoordmax,dr,inFileName=(SP.CRINPFN[i]+timestr),crSpecies=species,timeInOut=timestr)

                                
                                
                                #(SP.rspenorm1,SP.rspenorm2)=FindR12(hdDataInp=SP.HDDATAINP,timeInOut=SP.TIMEINOUT)
                                Rfs=FindRfs(hdDataInp=SP.HDDATAOUT,timeInOut=timestr)
                                if parallel.procID == 0: print "Rfs = ", Rfs
                                # SP.rspenorm1 = SP.rshellpc1*pc/Rfs
                                # SP.rspenorm2 = SP.rshellpc2*pc/Rfs
                                SP.rspenorm1 = 0.99
                                SP.rspenorm2 = 0.999999
                                print SP.rspenorm1, SP.rspenorm2, dr

                                crspe3.ConvertRaw2DatR12(SP.rspenorm1,SP.rspenorm2,dr,inFileName=(SP.CRINPFN[i]+timestr),crSpecies=species,timeInOut=timestr)
		
	elif SP.CALCULATE == "CRPROF":
		if SP.rspenorm2 == 0:
			Rfs=FindRfs(hdDataInp=SP.HDDATAOUT,timeInOut=SP.TIMEINOUT)
			SP.rspenorm2 = SP.rcoordmax
			RM = SP.rspenorm2

                for i, species in enumerate(SP.CRSPECIES):
                        crprof.ProduceCRsProfile(0,RM,crsEnergy=SP.CRSENERGY,\
                                                 inFileName=SP.CRINPFN[i],\
                                                 rStepsNum=SP.rstepsnum,\
                                                 pStepsNum=SP.pstepsnum,\
                                                 timeInOut=SP.TIMEINOUT)

	##################################### RADSPE ALL ###############################

	elif SP.CALCULATE == "RADSPEALL":
		comm = MPI.COMM_WORLD
		size = comm.Get_size()
		rank = comm.Get_rank()
		if rank == 0:		
			data =array_split(SP.timeslist,size)
		else:
			data = None
		data = comm.scatter(data, root=0)
		comm.barrier()
		print "node=", rank, " times: ", data
		comm.barrier()
		for i ,species in enumerate(SP.CRSPECIES):
			if species == "PR": injSclPar = SP.injsclparpr
                        elif species == "EL": injSclPar = SP.injsclparel
 			elif species == "HE": injSclPar = SP.injsclparhe
			elif species == "FE": injSclPar = SP.injsclparfe
 		
			for time in data:#SP.timeslist:
				timestr = str(float(time))
		
				snrrad.Bf = 0.8
				snrrad.N  = SP.radintres
				
		        	d  = SP.snrdistpc*pc
				R  = mhdread.Rsh(SP.HDDATAINP,timestr)
		        	snrrad.V  = pi*R**3*(4/3.)
		
				if SP.RADOBJECT == "SNR":
					snrrad.R1 = 0.0			#SNR center
					snrrad.R2 = 1.0			#SNR forward-shock-normalized r
					if   SP.STERADIAN == "NO":
						snrrad.A = d**2
						snrrad.I = R**3/d**2
					elif SP.STERADIAN == "SR":
					       	snrrad.A = pi*R**2
					       	snrrad.I = R/(pi*(snrrad.R2**2-snrrad.R1**2))
				elif SP.RADOBJECT == "HALO":		#Newly introduced. Calculates emission from Shock onwards
					snrrad.R1 = 1.0			#SNR shock - assumed to be 1.0!
					snrrad.R2 = SP.radnormax	#SNR maximum coordinate
					if   SP.STERADIAN == "NO":
						snrrad.A = d**2
						snrrad.I = R**3/d**2
					elif SP.STERADIAN == "SR":
					       	snrrad.A = pi*R**2
					       	snrrad.I = R/(pi*(snrrad.R2**2-snrrad.R1**2))
				elif SP.RADOBJECT == "TOTAL":		#Newly introduced. Calculates emission from Shock onwards
					snrrad.R1 = 0.0			#SNR shock - assumed to be 1.0!
					snrrad.R2 = SP.radnormax	#SNR maximum coordinate
					if   SP.STERADIAN == "NO":
						snrrad.A = d**2
						snrrad.I = R**3/d**2
					elif SP.STERADIAN == "SR":
					       	snrrad.A = pi*R**2
					       	snrrad.I = R/(pi*(snrrad.R2**2-snrrad.R1**2))
					elif SP.RADOBJECT == "SHL":
						if SP.rspenorm1 == 0 and SP.rspenorm2 == 0:
						       	snrrad.R1 = SP.rshellpc1*pc/R
						       	snrrad.R2 = SP.rshellpc2*pc/R
						if   SP.STERADIAN == "NO":
						       	snrrad.A = d**2
						       	snrrad.I = R**3/d**2
				       		elif SP.STERADIAN == "SR":
				       			snrrad.A = pi*R**2
			       				snrrad.I = R/(pi*(snrrad.R2**2-snrrad.R1**2))
	       			elif SP.RADOBJECT == "MCL":
       					if SP.rspenorm1 == 0 and SP.rspenorm2 == 0:
					       	snrrad.R1 = SP.rshellpc1*pc/R
			       			snrrad.R2 = SP.rshellpc2*pc/R
		       			if   SP.STERADIAN == "NO":
	       					snrrad.A = d**2  			      
       						snrrad.I = (R**3*(snrrad.R2-snrrad.R1)**3)/(8.0*d**2*(snrrad.R2**3-snrrad.R1**3))
			       		elif SP.STERADIAN == "SR":
	       					snrrad.A = pi*R**2
	       					nrrad.I = R*(snrrad.R2-snrrad.R1)/(2.0*pi*(snrrad.R2**3-snrrad.R1**3))
		
				snrrad.ProduceRadSpectrum(radType=SP.RADIATION,\
							mhdInpFn=(SP.MHDINPFN+timestr),\
							crInpFn=(SP.CRINPFN[i]+timestr),\
							rsOutFn=(SP.RPOUTFN[i]+timestr),\
							crSpecies=species,\
							rStepsNum=SP.rstepsnum,\
							pStepsNum=SP.pstepsnum,\
							timeInOut=SP.timeinout,\
							SP=SP)
		
	
			
	##################################### RADSPE ###############################	
	elif SP.CALCULATE == "RADSPE":
		for i ,species in enumerate(SP.CRSPECIES):
			
			snrrad.Bf = 0.8
			snrrad.N  = SP.radintres
				
			d  = SP.snrdistpc*pc
			R  = mhdread.Rsh(SP.HDDATAINP,SP.timeinout)
			snrrad.V  = pi*R**3*(4/3.)
			
			if SP.RADOBJECT == "SNR":
				snrrad.R1 = 0.0			#SNR center
				snrrad.R2 = 1.0			#SNR forward-shock-normalized
				if   SP.STERADIAN == "NO":
					snrrad.A = d**2
					snrrad.I = R**3/d**2
				elif SP.STERADIAN == "SR":
					snrrad.A = pi*R**2
					snrrad.I = R/(pi*(snrrad.R2**2-snrrad.R1**2))
			elif SP.RADOBJECT == "HALO":		#Newly introduced. Calculates emission from Shock onwards
				snrrad.R1 = 1.0			#SNR shock - assumed to be 1.0!
				snrrad.R2 = SP.radnormax	#SNR maximum coordinate
				if   SP.STERADIAN == "NO":
					snrrad.A = d**2
					snrrad.I = R**3/d**2
				elif SP.STERADIAN == "SR":
				       	snrrad.A = pi*R**2
				       	snrrad.I = R/(pi*(snrrad.R2**2-snrrad.R1**2))
			elif SP.RADOBJECT == "TOTAL":		#Newly introduced. Calculates emission from Shock onwards
				snrrad.R1 = 0.0			#SNR shock - assumed to be 1.0!
				snrrad.R2 = SP.radnormax	#SNR maximum coordinate
				if   SP.STERADIAN == "NO":
					snrrad.A = d**2
					snrrad.I = R**3/d**2
				elif SP.STERADIAN == "SR":
				       	snrrad.A = pi*R**2
				       	snrrad.I = R/(pi*(snrrad.R2**2-snrrad.R1**2))
			elif SP.RADOBJECT == "SHL":
				if SP.rspenorm1 == 0 and SP.rspenorm2 == 0:
					snrrad.R1 = SP.rshellpc1*pc/R
					snrrad.R2 = SP.rshellpc2*pc/R
				if   SP.STERADIAN == "NO":
					snrrad.A = d**2
					snrrad.I = R**3/d**2
				elif SP.STERADIAN == "SR":
					snrrad.A = pi*R**2
					snrrad.I = R/(pi*(snrrad.R2**2-snrrad.R1**2))
			elif SP.RADOBJECT == "MCL":
				if SP.rspenorm1 == 0 and SP.rspenorm2 == 0:
					snrrad.R1 = SP.rshellpc1*pc/R
					snrrad.R2 = SP.rshellpc2*pc/R
				if   SP.STERADIAN == "NO":
					snrrad.A = d**2  			      
					snrrad.I = (R**3*(snrrad.R2-snrrad.R1)**3)/(8.0*d**2*(snrrad.R2**3-snrrad.R1**3))
				elif SP.STERADIAN == "SR":
					snrrad.A = pi*R**2
					nrrad.I = R*(snrrad.R2-snrrad.R1)/(2.0*pi*(snrrad.R2**3-snrrad.R1**3))
			snrrad.ProduceRadSpectrum(radType=SP.RADIATION,\
							mhdInpFn=SP.MHDINPFN,\
							crInpFn=SP.CRINPFN[i],\
							rsOutFn=SP.RPOUTFN[i],\
							crSpecies=species,\
							rStepsNum=SP.rstepsnum,\
							pStepsNum=SP.pstepsnum,\
							timeInOut=SP.timeinout,\
							SP=SP)
			
	elif SP.CALCULATE == "RADMAP" or SP.CALCULATE == "RADM3D" or\
 	     SP.CALCULATE == "MAPSPE" or SP.CALCULATE == "MAPSPE_PARALLEL" or\
	     SP.CALCULATE == "MAPINT":

		SP.timecont  = SP.timeinout
		SP.timestart = SP.timeinout

		#Only executed to create object and get radius
		snrmap.SNR=tecoef.TranEqnCoeffFuncs(shockType=SP.SHOCKTYPE,\
							nhDensity=SP.nhdensity,\
							expEnergy=SP.expenergy,\
							useSedSol=SP.usesedsol,\
						    	crSpecies=SP.CRSPECIES,\
							injectPar=SP.injectpar,\
							injSclPar=SP.injsclpar,\
               		 		            	mfProfile="TRA",\
							alfvDrift=SP.ALFVDRIFT,\
						    	hdDataInp=SP.HDDATAINP,\
							hdFileInp=SP.HDFILEINP,\
							mfDataInp=SP.MFDATAINP,\
							mfFileInp=SP.MFFILEINP,\
							SP=SP)

		snrmap.Bf = 0.8
		
		snrmap.RM = SP.radnormax
		snrmap.N  = SP.radintres
		snrmap.n  = int(snrmap.RM*snrmap.N)
		
		if   SP.RADOBJECT == "SNR" or SP.RADOBJECT == "SHL": snrmap.R  = snrmap.SNR.Rsh(SP.timeinout)
		elif SP.RADOBJECT == "MCL":
			snrmap.R    = 0.5*(SP.rshellpc2-SP.rshellpc1)*pc
			snrmap.Dmcl = SP.rshellpc1*pc + snrmap.R
			snrmap.Rsnr = snrmap.SNR.Rsh(SP.timeinout)
		
		d  = SP.snrdistpc*pc
		snrmap.h  = snrmap.R/snrmap.N
		if   SP.STERADIAN == "NO": snrmap.A = d**2
		elif SP.STERADIAN == "SR": snrmap.A = snrmap.h**2
		snrmap.V  = snrmap.h**3
		print snrmap.V
		snrmap.nmcl=SP.shdensity
		
#		if   SP.CALCULATE == "RADMAP" or SP.CALCULATE == "RADM3D" or SP.CALCULATE == "MAPSPE_PARALLEL":
#			snrmap.ProduceMapProfile(task=SP.CALCULATE,mapEnergy=SP.mapenergy,radType=SP.RADIATION,radObject=SP.RADOBJECT,\
#						 createMap=SP.CREATEMAP,hemiSpher=SP.HEMISPHER,steRadian=SP.STERADIAN,rotMapXYZ=SP.rotmapxyz,scaleInPC=SP.scaleinpc,\
#						 mfCompDim=SP.MFCOMPDIM,mfInpFn=SP.MFINPFN,crInpFn=SP.CRINPFN,rmOutFn=SP.RPOUTFN,\
#						 rStepsNum=SP.rstepsnum,pStepsNum=SP.pstepsnum,timeInOut=SP.timeinout)
#		#mapEnergy=SP.MAPENERGY
#		elif SP.CALCULATE == "MAPSPE" or SP.CALCULATE == "MAPINT":
		snrmap.ExecuteAnyMapTask(task=SP.CALCULATE,\
						mapEnergy=SP.MAPENERGY,\
						radType=SP.RADIATION,\
						radObject=SP.RADOBJECT,\
						createMap=SP.CREATEMAP,\
						hemiSpher=SP.HEMISPHER,\
						steRadian=SP.STERADIAN,\
						rotMapXYZ=SP.rotmapxyz,\
						scaleInPC=SP.scaleinpc,\
					 	mfCompDim=SP.MFCOMPDIM,\
						mfInpFn=SP.MFINPFN,\
						crInpFn=SP.CRINPFN,\
						rmOutFn=SP.RPOUTFN,\
					 	rStepsNum=SP.rstepsnum,\
						pStepsNum=SP.pstepsnum,\
						timeInOut=SP.timeinout,\
						SP=SP)
		
	else:
		if parallel.procID == 0: print "RATPaC: calculation step is not defined. Choose between CRSPE0, CRSPE1, CRSEP2, RADSPE, RADMAP, RADM3D, MAPSPE, MAPSPE_PARALLEL, MAPINT"



if __name__ == "__main__":sys.exit(main())
