echo "Setting up standard paths ..."
export LD_LIBRARY_PATH=/lib64:/usr/lib64:/usr/local/lib64:/lib:/usr/lib:/usr/local/lib

echo "Setting up THAT paths ..."
export THAT=/afs/ifh.de/group/that				#THAT group directory afs space
export LD_LIBRARY_PATH=${THAT}/soft/SL6/lib:${LD_LIBRARY_PATH}
export PATH=${THAT}/soft/SL6/bin:${PATH}

echo "Adding ATLAS ..."
export LD_LIBRARY_PATH=/usr/lib64/atlas:${LD_LIBRARY_PATH}

echo "Adding QT4 ..."
export LD_LIBRARY_PATH=/usr/lib64/qt4:${LD_LIBRARY_PATH}
export PATH=/usr/lib64/qt4/bin:$PATH

echo "Adding MPI ..."
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:/usr/lib64/openmpi/lib
export PATH=${PATH}:/usr/lib64/openmpi/bin
export OMPI_MCA_btl="^udapl,openib"
#export OMP_NUM_THREADS=1

echo "Adding VTK ..."
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:${THAT}/soft/SL6/opt/vtk/5.10.1/lib

echo "Adding Trilinos 11.2.3 with OpenMPI support..."
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:${THAT}/soft/SL6/opt/trilinos/11.2.3_openmpi_nocuda/lib

echo "Adding HDF5 ..."
#export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:${THAT}/soft/SL6/opt/hdf5/1.8.14/lib
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:${THAT}/soft/SL6/opt/hdf5/1.8.14/parallel/lib

echo "Adding HEAsoft ..."
export HEADAS=${THAT}/soft/SL6/opt/HEAsoft/6.13/x86_64-unknown-linux-gnu-libc2.12
source $HEADAS/headas-init.sh

echo "Adding PATRON ..."
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:${THAT}/soft/SL6/opt/patron

echo "Adding PLUTO 3.1.1 ..."
export PLUTO_DIR=${THAT}/soft/SL6/opt/pluto/3.1.1/PLUTO


export WORKON_HOME=/${THAT}/soft/SL6/THAT_VIRTUAL_ENV
source ${THAT}/soft/SL6/bin/virtualenvwrapper.sh

export PYTHONPATH=$PYTHONPATH:${THAT}/soft/SL6/opt/vtk/5.10.1/lib/python2.7/site-packages/
export PYTHONPATH=$PYTHONPATH:${THAT}/soft/SL6/opt/trilinos/11.2.3_openmpi_nocuda/lib/python2.7/site-packages
