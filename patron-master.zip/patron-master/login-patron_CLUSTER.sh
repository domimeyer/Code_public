#!/bin/bash
######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  login-patron.sh									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2014 - 2015
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v1.1.0: login (initialization) script for patron code
#v1.1.1: changed for cluster compability

USEMODE=${1}
PATHDIR=${2}

echo "USEMODE",${USEMODE}
echo "PATHDIR",${PATHDIR}

export PATRONDIR=`echo ${PATHDIR} | sed 's/--//g'`

echo "PATRONDIR",${PATRONDIR}
echo "THAT", ${THAT}

if [ "${THAT}" == "" ];then
	echo "---"
	echo "Please login to THAT group environment and initialize"
	echo "your Python Virtual Environment!"
	echo "---"
fi

unlink ${PATRONDIR}/data/snrmhd
unlink ${PATRONDIR}/data/hii

ln -s ${THAT}/data/snrmhd            ${PATRONDIR}/data/snrmhd
ln -s ${THAT}/data/cloudy/output/hii ${PATRONDIR}/data/hii


echo "PATRONDIR is set to ${PATRONDIR}"

export PYTHONPATH=$PYTHONPATH:${PATRONDIR}
echo "You will be running in Developer mode."
