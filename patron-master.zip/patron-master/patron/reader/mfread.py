######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  mfread.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2012 - 2015
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v2.0.0: working with patron modules starting with v.2.2.x and higher
#v2.1.0: version control added

__version__='2.1.0'

from os import sys
from numpy import *
from scipy import interpolate
from patron.snrmod.snrevo import evovik as evovik

class MF:
	def __init__(self,R,B,t):
		self.R=R
		self.B=B
		self.t=t

def fill_rbt(fname,MFCOMP,SHOCK,t,snr):
	try:
		f=open(fname,"r")
		alllines=f.readlines()
		f.close()
	except IOError:
		print "No file found:",fname
	
	L=len(alllines)
	
	RAD=arange(L,dtype=float)
	MFS=arange(L,dtype=float)
	
	RAD[0]=0.0
	MFS[0]=float(alllines[1].split()[-1])
	
	for i in range(1,L):
		(r,br,bt,b)=alllines[i].split()
		RAD[i]=float(r)
		if MFCOMP == "TOT":
			MFS[i]=float(b)
		elif MFCOMP == "RAD":
			MFS[i]=float(br)
		elif MFCOMP == "TAN":
			MFS[i]=float(bt)
	
	if SHOCK == "RSH":
		Rnorm=evovik.R_RS(t,snr)/evovik.R_ED(t,snr)
	else:
		Rnorm=1.0
	
	mfatt=MF(RAD/Rnorm,MFS,t)
	
	return mfatt


def fillMFevo(dpath,fname,hist,MFCOMP,SHOCK,snr):
	try:
		h=open(dpath+"/"+hist,"r")
		hlines=h.readlines()
		h.close()
	except IOError:
		print "No MF history file found!!!",dpath+"/"+hist
	
	L=len(hlines)
	
	MFevo=[] #arange(L,dtype=MF)
	
	for i in range(0,L):
		TIME=hlines[i][0:-1]
		time=float(TIME)
		fName=dpath+"/"+fname+TIME
		mft=fill_rbt(fName,MFCOMP,SHOCK,time,snr)
		MFevo.append(mft)
	
	return MFevo



