######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  psread.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2010 - 2015
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v2.0.0: working with patron modules starting with v.2.2.x and higher
#v2.1.0: version control added

__version__='2.1.0'

from os import sys
from numpy import *
from scipy import interpolate

class SPE:							#spectrum class
	def __init__(self,E,J):
		self.E=E
		self.J=J
I=0

def fill_ren(RRES,ERES,fname,SHSC=1.0):
	#SHSC=1.0	
	N=ndarray(shape=(ERES,RRES),dtype=float)
	R=arange(RRES,dtype=float)
	E=arange(ERES,dtype=float)
	
	try:
		print "psread: reading file",fname
		fn=open(fname,"r")
		FN=fn.readlines()
		fn.close()
	except IOError:
		print "psread: no input file",fname
	
	LEN = len(FN)
	if LEN == RRES*ERES:
		print "psread: file type is processed particle spectrum"
		for j in range(0,RRES):
			(a,b,c)=FN[j].split()
			R[j]=float(a)*SHSC
		
		for i in range(0,ERES):
			(a,b,c)=FN[i*RRES].split()
			E[i]=float(b)
			for j in range(0,RRES):
				(a,b,c)=FN[RRES*i+j].split()
				N[i][j]=float(c)
		print "psread: file is read."
			
	elif LEN != RRES*ERES:
		print "psread: file type is raw particle spectrum, dividing N column by E, transforming R coordinate"
		for j in range(0,RRES):
			(a,b,c)=FN[j+2].split()
			RSTAR=float(a)
			R[j]=(1.0+(RSTAR-1.0)**3)*SHSC
		
		for i in range(0,ERES):
			(a,b,c)=FN[i*RRES+2].split()
			lnp=float(b)
			E[i]=exp(lnp)
			for j in range(0,RRES):
				(a,b,c)=FN[RRES*i+j+2].split()
				N[i][j]=float(c)/E[i]
		print "psread: file is read."
	
	return R,E,N


def spe_vol(fname):						#filling array with values from volume integrated spe files
	f=open(fname,"r")
	spelines=f.readlines()
	f.close()

	L=len(spelines)
	
	E=arange(L,dtype=float)
	J=arange(L,dtype=float)
	
	for i in range(0,L):
		(a,b)=spelines[i].split()
		E[i]=float(a)
		J[i]=float(b)
	
	spe=SPE(E,J)			
	return spe		

def NatR(r,R,N):
#	lnN=log(N)
#	VAL=lnN.swapaxes(0,1)[0]
#	NatR=interpolate.interp1d(R,lnN,bounds_error=False, fill_value=-1e3)(r)
#	return exp(NatR)
	NatR=interpolate.interp1d(R,N,bounds_error=False, fill_value=0.0)(r)
	return NatR


def spe_dif(r,dr,(R,E,N)):					#filling array with values for the given r
	
	I=arange(0,len(R))
	
	r1=r-0.5*dr
	r2=r+0.5*dr
	
	I1=interpolate.interp1d(R,I,bounds_error=False,fill_value=0)(r1)
	I2=interpolate.interp1d(R,I,bounds_error=False,fill_value=0)(r2)
	
	CI1 = int(ceil(I1))
	FI2 = int(floor(I2))
	
	if CI1 == FI2:
		rr=array([r1,r2])
		NEW_N=NatR(r,R,N)
	else:
		RR=R[CI1:FI2+1]
		rr=concatenate((array([r1]),RR,array([r2])))
		NEW_N=NatR(rr,R,N).mean(1)
	
#	NEW_N=NatR(r,R,N)
	spe=SPE(E,NEW_N)
	return spe
