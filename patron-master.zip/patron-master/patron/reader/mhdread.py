######################################################################################
### RATPaC - Radiation Acceleration Transport Parallel Code ###
#=====================================================================================
# File:	  hdread.py									
# Author: Iurii Sushch <iurii.sushch@desy.de>, 2019 -
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v2.0.0: versioning is kinda bullshit at the moment though... We should start new versioning for RATPaC as soon as we have a stable version!

__version__='2.1.0'

from os import sys
from numpy import *
from scipy import interpolate


#m_p = 1.673e-24						#proton mass in grams
#muh = 1.4						#hydrogen molar weight

class HD:
	def __init__(self,r,B,nh,nhe,nc,nox,nfe,ne,T):
		self.r=r	#radius is Rsh units
		self.B=B	#magnetic field
		self.nh=nh	#hydrogen density
		self.nhe=nhe	#helium density
		self.nc=nc	#carbon density
		self.nox=nox	#oxygen density
		self.nfe=nfe	#ferum density
		self.ne=ne	#electron density
		self.T=T	#Temperature

def Rsh(hdDataInp,t):
	fname = hdDataInp+"/rpc2rnorm"
	try:
		f = open(fname, "r")		
		alllines = f.readlines()
		f.close()
	except IOError:
		print "No file found:",fname
	l = len(alllines)
	radii = []
	times = []
	for i in range(0,l):
		pars = alllines[i].split()
		radii.append(float(pars[0]))
		times.append(float(pars[3]))	
	for i,time in enumerate(times):
		if time == float(t): 
			rshock = radii[i]
			break		 
	return rshock



def fill_mhydro(fname,t):
	
	try:
		f=open(fname,"r")
		alllines=f.readlines()
		f.close()
	except IOError:
		print "No file found:",fname


	L=len(alllines)
	
	RAD=arange(L,dtype=float)
	MFD=arange(L,dtype=float)	
	DNSh=arange(L,dtype=float)
	DNShe=arange(L,dtype=float)
	DNSc=arange(L,dtype=float)
	DNSox=arange(L,dtype=float)
	DNSfe=arange(L,dtype=float)
	DNSe=arange(L,dtype=float)
	TMP=arange(L,dtype=float)


	
	RAD[0]=0.0
	MFD[0]=float(alllines[1].split()[1])
	DNSh[0]=float(alllines[1].split()[2])
	DNShe[0]=float(alllines[1].split()[3])
	DNSc[0]=float(alllines[1].split()[4])
	DNSox[0]=float(alllines[1].split()[5])
	DNSfe[0]=float(alllines[1].split()[6])
	DNSe[0]=float(alllines[1].split()[7])
	TMP[0]=float(alllines[1].split()[8])

	
	for i in range(1,L):
		(r,mfd,dnsH, dnsHe, dnsC, dnsOx, dnsFe, dnse, tmp)=alllines[i].split()
		RAD[i]=float(r)
		MFD[i]=float(mfd)
		DNSh[i]=float(dnsH)
		DNShe[i]=float(dnsHe)
		DNSc[i]=float(dnsC)
		DNSox[i]=float(dnsOx)
		DNSfe[i]=float(dnsFe)
		DNSe[i]=float(dnse)
		TMP[i]=float(tmp)
		
	mhdatt = HD(RAD,MFD,DNSh,DNShe,DNSc,DNSox,DNSfe,DNSe,TMP)
	
	return mhdatt
