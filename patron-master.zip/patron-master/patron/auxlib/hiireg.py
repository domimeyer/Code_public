######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  hiireg.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2015
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#module processing cloudy simulations for HII regions
#v1.0.0: basic functions and HIIregion class holding main information on HII region are implemented
#v1.0.1: re-arrangements of variables for convenience
#v1.0.2: adding Erebinned and dErebinned as class members
#v1.0.3: some function renaming to correspond to physical meaning
#v1.1.0: version control added

__version__='1.1.0'

from fipy.tools import parallel

from numpy import *
from scipy import interpolate
from scipy.ndimage.interpolation import zoom

c     = 2.998e10

class HIIregion:
	def __init__(self,OverviewData,OpacityData,TotOpacityDataZones,EmissivityDataZones,VolIntContinuumData):
		self.ZoneNr,self.R,self.dR,self.PhotonMFP = self.GetZoneNrRadiusBinPhotonMFP(OpacityData)
		self.Energy,self.nujnu                    = self.ReadZonesSpectralEmissivity(EmissivityDataZones)
		self.nuknuTotal,self.nuknuAbsrp           = self.ReadZonesSpectralTotOpacity(TotOpacityDataZones)
		self.nuLnuTotal,self.nuLnuLines           = self.ReadZonesVolumeIntContinuum(VolIntContinuumData)
#		self.Uoriginal                            = self.UoriginalArray()
		self.Erebinned,self.dErebinned            = self.ErebinnedArray(450)
		self.Urebinned                            = self.UrebinnedArray(450)
		

	
	def GetZoneNrRadiusBinPhotonMFP(self,fname):
		try :
			if parallel.procID == 0: print "hiireg: reading opacity data file to get zones info", fname
			fn=open(fname,"r")
			FN=fn.readlines()
			fn.close()
		except IOError:
			if parallel.procID == 0: print "hiireg: no opacity data file found!", fname
		
		LEN    = len(FN)-1
		ZoneNr = arange(0,LEN,dtype=int)
		Radius = arange(LEN,dtype=float)
		PhMFP  = arange(LEN,dtype=float)
		Depth  = arange(LEN,dtype=float)
		dR     = arange(LEN,dtype=float)
		
		for i in range(0,LEN):
			(radius,depth,nujnu,kappa_abs,kappa_sct)=FN[i+1].split()
			Radius[i] = float(radius)
			PhMFP[i]  = 1./float(kappa_abs)
			Depth[i]  = float(depth)
			if i == 0: dR[i] = 2.0* Depth[i]
			else:      dR[i] = 2.0*(Depth[i] - Depth[i-1]) - dR[i-1]
		
		return ZoneNr,Radius,dR,PhMFP
		
	def ReadZonesSpectralEmissivity(self,fname):
		try :
			if parallel.procID == 0: print "hiireg: reading emissivity data file to get zones emissivities", fname
			fn=open(fname,"r")
			FN=fn.readlines()
			fn.close()
		except IOError:
			if parallel.procID == 0: print "hiireg: no emissivity data file found!", fname
		
		nujnuData = array([line.split() for line in FN[1:]],dtype=float)
		
		return nujnuData[0],nujnuData[1:]
	
	def ReadZonesSpectralTotOpacity(self,fname):
		try :
			if parallel.procID == 0: print "hiireg: reading total opacity continuum data file", fname
			fn=open(fname,"r")
			FN=fn.readlines()
			fn.close()
		except IOError:
			if parallel.procID == 0: print "hiireg: no total opacity continuum data file found!", fname
		
		Ebins     = len(self.Energy)
		Zones     = len(self.ZoneNr)
		ZoneLines = Ebins+1
		
		opacityTot = ndarray(shape=(Zones+1,Ebins),dtype=float)
		opacityAbs = ndarray(shape=(Zones+1,Ebins),dtype=float)
		
		opacityTot[0] = array([line.split()[0:5] for line in FN[1:ZoneLines]],dtype=float)[:,0]
		opacityAbs[0] = opacityTot[0]

		for Zone in self.ZoneNr:
			ZoneRawData=array([line.split()[0:5] for line in FN[Zone*ZoneLines+1:(Zone+1)*ZoneLines]],dtype=float)
			opacityTot[Zone+1] = ZoneRawData[:,1]
			opacityAbs[Zone+1] = ZoneRawData[:,2]

		return opacityTot[1:],opacityAbs[1:]
	
	
	def ReadZonesVolumeIntContinuum(self,fname):
		try :
			if parallel.procID == 0: print "hiireg: reading volume integrated continuum data file", fname
			fn=open(fname,"r")
			FN=fn.readlines()
			fn.close()
		except IOError:
			if parallel.procID == 0: print "hiireg: no volume integrated continuum data file found!", fname
		
		Ebins     = len(self.Energy)
		Zones     = len(self.ZoneNr)
		ZoneLines = Ebins+1
		
		nuLnuTotal = ndarray(shape=(Zones+1,Ebins),dtype=float)
		nuLnuLines = ndarray(shape=(Zones+1,Ebins),dtype=float)
		
		nuLnuTotal[0] = array([line.split()[0:9] for line in FN[1:ZoneLines]],dtype=float)[:,0]
		nuLnuLines[0] = nuLnuTotal[0]
				
		for Zone in self.ZoneNr:
			ZoneRawData=array([line.split()[0:9] for line in FN[Zone*ZoneLines+1:(Zone+1)*ZoneLines]],dtype=float)
			nuLnuTotal[Zone+1] = ZoneRawData[:,3]
			nuLnuLines[Zone+1] = ZoneRawData[:,8]
		
		return nuLnuTotal[1:],nuLnuLines[1:]
	
	
	def OpticalDepthAbsUpToZoneNr(self,ZoneNr):
		tau=(self.nuknuAbsrp[:ZoneNr]*self.dR[:ZoneNr,None]).sum(0)
		return tau
	
	def SourceFunction_UpToZoneNr(self,ZoneNr):
		return (self.nujnu[:ZoneNr]/self.nuknuAbsrp[:ZoneNr]).sum(0)
	
	def nuLnuEmissAbsScUpToZoneNr(self,ZoneNr):
		FoPiR2dI   = 4.0*pi*self.R[ZoneNr-1,None]**2*(self.nujnu[ZoneNr-1]*self.dR[ZoneNr-1,None])
		#dExt = 1.0/(1.0 + self.nuknuAbsrp[ZoneNr-1]*self.dR[ZoneNr-1,None])
		dExt = exp(-self.nuknuAbsrp[ZoneNr-1]*self.dR[ZoneNr-1,None])
		if ZoneNr == 1: return FoPiR2dI*dExt
		else:           return (self.nuLnuEmissAbsScUpToZoneNr(ZoneNr-1)+FoPiR2dI)*dExt
	
	def nuLnuEmissAbsScFromZoneNr(self,ZoneNr):
		FoPiR2dI = 4.0*pi*self.R[ZoneNr-1,None]**2*(self.nujnu[ZoneNr-1]*self.dR[ZoneNr-1,None])
		
		#dExt = 1.0/(1.0 + self.nuknuAbsrp[ZoneNr-1]*self.dR[ZoneNr-1,None])
		dExt = exp(-self.nuknuAbsrp[ZoneNr-1]*self.dR[ZoneNr-1,None])

		ZoneLast = len(self.ZoneNr)
		if ZoneNr == ZoneLast: return FoPiR2dI*dExt
		else:                  return (self.nuLnuEmissAbsScFromZoneNr(ZoneNr+1)+FoPiR2dI)*dExt

	def nuUnuEmissAbsScUpToZoneNr(self,ZoneNr):
		return self.nuLnuEmissAbsScUpToZoneNr(ZoneNr)/(c*self.R[ZoneNr-1]**2)

	def nuUnuEmissAbsScFromZoneNr(self,ZoneNr):
		return self.nuLnuEmissAbsScFromZoneNr(ZoneNr)/(c*self.R[ZoneNr-1]**2)

#	def nuUnuCorrectedRadTransfer(self,ZoneNr):
#		ds = Jds*self.dR[ZoneNr-1,None])
#		dI = (self.nujnu[ZoneNr-1]*ds

	def UoriginalArray(self):
		if parallel.procID == 0: print "hiireg: filling original Unu array"
		Ebins     = len(self.Energy)
		Zones     = len(self.ZoneNr)
		Ufull     = ndarray(shape=(Zones,Ebins),dtype=float)
		for Zone in self.ZoneNr: Ufull[Zone]=self.nuUnuEmissAbsScFromZoneNr(Zone)/self.Energy #nuUnu -> Unu
		return Ufull
	
	def UrebinnedArray(self,EnewBins):
		if parallel.procID == 0: print "hiireg: filling rebinned Unu array"
		Ebins     = len(self.Energy)
		Zones     = len(self.ZoneNr)
		#EnewBins      = Ebins//Factor			#integer division
		Factor    = Ebins//EnewBins
		Ubinned   = ndarray(shape=(Zones,EnewBins),dtype=float)
		for Zone in self.ZoneNr: Ubinned[Zone] = rebin(self.nuUnuEmissAbsScFromZoneNr(Zone)[:EnewBins*Factor],EnewBins)/self.Erebinned #nuUnu -> Unu
		return Ubinned.transpose() 			#for future interpolation in r
	
	def ErebinnedArray(self,EnewBins):
		if parallel.procID == 0: print "hiireg: filling rebinned E,dE arrays"
		Ebins      = len(self.Energy)
		#Enewbins  = Ebins//Factor			#integer division
		Factor     = Ebins//EnewBins
		Erebinned  = rebin(self.Energy[:EnewBins*Factor],EnewBins)
		
		dErebinned = (0.5*diff(concatenate((array([0]), Erebinned)) 
		                     + concatenate((Erebinned, array([0])))))
		
		dErebinned[0]  =  2.0*(Erebinned[1]  - Erebinned[0])  - dErebinned[1]
		dErebinned[-1] =  2.0*(Erebinned[-1] - Erebinned[-2]) - dErebinned[-2]
		
		return Erebinned,dErebinned
	
	def Unu(self,r_cm):
		return interpolate.interp1d(self.R,self.Urebinned,bounds_error=False, fill_value=0.0)(r_cm)
	
	def nuLnuEmissivityUpToZoneNr(self,ZoneNr):
		L=4.0*pi*(self.R[:ZoneNr,None]**2*self.nujnu[:ZoneNr]*self.dR[:ZoneNr,None]).sum(0) 			#need additional axis to match shapes (Rbins,Ebins)*(Rbins,1)
		return L
	
	def nuLnuEmissivityFromZoneNr(self,ZoneNr):
		L=4.0*pi*(self.R[ZoneNr-1:,None]**2*self.nujnu[ZoneNr-1:]*self.dR[ZoneNr-1:,None]).sum(0)
		return L
	
	def nuLnuIntNormConUpToZoneNr(self,ZoneNr):
		#return self.nuLnuTotal[ZoneNr-1] - self.nuLnuLines[ZoneNr-1]
		return self.nuLnuTotal[ZoneNr-1]
	
	def nuLnuIntNormConFromZoneNr(self,ZoneNr):		#doesn't work because of absorption
		#ConLast = self.nuLnuTotal[-1]     - self.nuLnuLines[-1]
		#ConZone = self.nuLnuTotal[ZoneNr-1] - self.nuLnuLines[ZoneNr-1]
		#A = ConLast - ConZone
		TotLast = self.nuLnuTotal[-1] 
		TotZone = self.nuLnuTotal[ZoneNr-1]
		A = TotLast - TotZone
		return A
		#return where(A <= 0.0, nan, A)
	
	def WriteVariable(self,Variable,outFileName,t=0,timesOut=None):
		E=self.Energy
		f=open(outFileName,"w")
		for i in range(0,len(E)):
			f.write(str(E[i])+"\t"+str(Variable[i])+"\n")
		f.close()
	
	def WriteVariableRebinned(self,Variable,Factor,outFileName,t=0,timesOut=None):
		Lold = len(Variable)
		Lnew = Lold//Factor			#integer division
		subOldE = self.Energy[:Lnew*Factor]	#cuts out highest energies to make rebinning possible (input array length must be integer multiple of Factor)
		subOldV = Variable[:Lnew*Factor]
		E=rebin(subOldE, Lnew)
		V=rebin(subOldV, Lnew)

		f=open(outFileName,"w")
		for i in range(0,len(E)):
			f.write(str(E[i])+"\t"+str(V[i])+"\n")
		f.close()







	
def rebin(a, *args):
	'''rebin ndarray data into a smaller ndarray of the same rank whose dimensions
	are factors of the original dimensions. eg. An array with 6 columns and 4 rows
	can be reduced to have 6,3,2 or 1 columns and 4,2 or 1 rows.
	example usages:
	>>> a=rand(6,4); b=rebin(a,3,2)
	>>> a=rand(6); b=rebin(a,2)
	'''
	shape = a.shape
	lenShape = len(shape)
	factor = asarray(shape)/asarray(args)
	evList = ['a.reshape('] + \
		 ['args[%d],factor[%d],'%(i,i) for i in range(lenShape)] + \
		 [')'] + ['.sum(%d)'%(i+1) for i in range(lenShape)] + \
		 ['/factor[%d]'%i for i in range(lenShape)]
	#print ''.join(evList)
	return eval(''.join(evList))
	
def bin_ndarray(ndarray, new_shape, operation='sum'):
	"""
	Bins an ndarray in all axes based on the target shape, by summing or
	    averaging.
	Number of output dimensions must match number of input dimensions.
	Example
	-------
	>>> m = np.arange(0,100,1).reshape((10,10))
	>>> n = bin_ndarray(m, new_shape=(5,5), operation='sum')
	>>> print(n)
	[[ 22  30  38  46  54]
	 [102 110 118 126 134]
	 [182 190 198 206 214]
	 [262 270 278 286 294]
	 [342 350 358 366 374]]
	"""
	if not operation.lower() in ['sum', 'mean', 'average', 'avg']:
		raise ValueError("Operation not supported.")
	if ndarray.ndim != len(new_shape):
		raise ValueError("Shape mismatch: {} -> {}".format(ndarray.shape,new_shape))
	compression_pairs = [(d, c//d) for d,c in zip(new_shape,ndarray.shape)]
	flattened = [l for p in compression_pairs for l in p]
	ndarray = ndarray.reshape(flattened)
	for i in range(len(new_shape)):
		if operation.lower() == "sum": ndarray = ndarray.sum(-1*(i+1))
		elif operation.lower() in ["mean", "average", "avg"]: ndarray = ndarray.mean(-1*(i+1))
	return ndarray


def nuLnuEmissivityUpToRadius(Radius):
	return 0

def nuLnuEmissivityFromRadius(Radius):
	return 0

def nuLnuIntNormConUpToRadius(Radius):
	return 0

def nuLnuIntNormConFromRadius(Radius):
	return 0
