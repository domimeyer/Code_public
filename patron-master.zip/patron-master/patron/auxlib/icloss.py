######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  icloss.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2015
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v1.0.0: initial version for inverse Compton matrix operations
#v1.1.0: version control added

__version__='1.1.0'

from fipy.tools import parallel
from fipy.tools.numerix import exp
from fipy.tools.numerix import log
from fipy.tools.numerix import Inf as INF

from scipy.special import spence as LI2
from scipy.integrate import quad
from scipy import interpolate

import matplotlib.pyplot as mp
from numpy import *

pi    = 3.1415926
c     = 2.998e10
m_e   = 9.109e-28
p_e   = m_e*c
m_p   = 1.673e-24
p_p   = m_p*c
q     = 4.8e-10

kB    = 1.3807e-16 #*6.24e11 #in eV/K
hP    = 6.6261e-27 #*6.24e11 #in eV/s

Ucmb=4.0e-13; Tcmb=2.7					#in ergs/cm**3	#24867.959858108643*Ucmb==5e-4G
Ured=3.6e-13; Tred=25.0

eV2erg  = 1./6.24e11

#min_exp = -12.0
#max_exp = 4.0
#dif_exp = 0.05
#Eph_eV  = exp(arange(min_exp,max_exp,dif_exp))

#Eph     = Eph_eV*eV2erg
#dEph    = 0.5*diff(exp(arange(min_exp,max_exp+dif_exp,dif_exp)) + exp(arange(min_exp-dif_exp,max_exp,dif_exp)))*eV2erg
#Eph2d=Eph[:,None]
#dEph2d=dEph[:,None]

pStepsNum = 280
pmax      = 28.0
dp        = pmax/float(pStepsNum)
pf        = exp(arange(0.0,pmax+dp,0.5*dp) - pmax/4.)

def Li2(x):
	return -LI2(1.0/(1.0-x)) - 0.5*(log(1-x))**2

def g(b):
	return where(b<=0.01,b**3/9.0,(0.5*b + 6.0 + 6.0/b)*log(1.0 + b) - (11.0*b**3/12.0 + 6.0*b**2 + 9.0*b + 4.0)/(1.0 + b)**2 - 2.0 + 2.0*Li2(-b))

#full KN cross-section; Eph must be in ergs
def fKN(Eph,p):
	gamma = (1.0 + p**2)**0.5
	b = 4.0*(Eph/(m_e*c**2))*gamma 
	return 9.0*g(b)/b**3

def fKNmatrix():
	if parallel.procID == 0: print "icloss: filling fKN matrix"
	Lpf   = len(pf)
	Leph  = len(Eph)
	fmatr = ndarray(shape=(Lpf,Leph),dtype=float)
	
	for i in range(0,Lpf):
		for j in range(0,Leph):
			fmatr[i][j] = fKN(Eph[j],pf[i])
	return fmatr

#photon number density of b-b radiation normalized to have total energy density Utot in 1/(cm**3 erg)
def NphthNorm(Eph,T,Utot):
	kT=kB*T
	return (15.0*Utot*Eph**2)/((pi*kT)**4*(exp(Eph/kT)-1.0))

def UthTot(T,Utot):
	return (NphthNorm(Eph,T,Utot)*Eph*dEph).sum(0)

def Unuth(T,Utot):
	return NphthNorm(Eph,T,Utot)*Eph

def FKNxU(p,U):
	fKNxU=(fKNm*U*dEph).sum(1)
	return interpolate.interp1d(pf,fKNxU, bounds_error=False, fill_value=0.0)(p)



def kappa(p,T):
	eps   = kB*T/(p_e*c)
	gamma = (1.0+p**2)**0.5
	return  1.0/(1.0+gamma*eps)
#	return (3.0/8.0)*(0.5 + log(2.0*eps))/(eps*(1.0+gamma*eps))
	
def fKNxUth(r,p,t):
	return kappa(p,Tcmb)*Ucmb #+ kappa(p,Tred)*Ured









#fdata=getenv("PATRONDIR")+"/dat/fdata.dat"




#def fKNxUth(p,T,Utot):
#	return (fKN(Eph,p)*NphthNorm(Eph,T,Utot)*Eph*dEph).sum(0)
#
#def Uth2(Eph,T):
#	kT=kB*T
#	return (8.0*pi/(hP**2*c**3))*(Eph**3/(exp(Eph/kT)-1.0))
#
#def Utot1(T,Utot):
#	(I,err)=quad(Uth1,0,INF,args=(T,Utot),epsabs=1.5e-25)
#	return I
#
#
#def fKNxUth1(Eph,p,T,Utot):
#	return  fKN(Eph,p)*Eph*Nphthnorm(Eph,T,Utot)
#
#def FKNth1(p,T,Utot):
#	(I,err)=quad(fKNxUth1,0.0,INF,args=(p,T,Utot),epsabs=1.5e-15)
#	return I
#
#
#def fKNxUth2(Eph,p,T):
#	return  fKN(Eph,p)*Uth2(Eph,T)
#
#def FKNth2(p,T):
#	(I,err)=quad(fKNxUth2,0.0,INF,args=(p,T),epsabs=1.5e-15)
#	return I
