######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  speind.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2010 - 2015
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v1.0.0: initial version
#v1.1.0: version control added

__version__='1.1.0'

from numpy import *
from scipy import interpolate
import sys
import patron.reader import psread as psread

FILE=sys.argv[1]
#MOD_DIR=sys.argv[1]
#SHOCK=sys.argv[2]

#if SHOCK == "S":
#	DIR="sum"
#elif SHOCK == "F":
#	DIR="sum/f"
#elif SHOCK == "R":
#	DIR="sum/r"

fnameIPR=FILE
fnameSPR=FILE+"_SLOPE"
#fnameIPR=MOD_DIR+"/PR/"+DIR+"/NED"							#".../NED" VOLUME INTEGRATED, WARNING!!! CONTAINS 1/3.
#fnameIEL=MOD_DIR+"/EL/"+DIR+"/NED"							#".../NED" VOLUME INTEGRATED, WARNING!!! CONTAINS 1/3.
#fnameSPR=MOD_DIR+"/PR/"+DIR+"/S"
#fnameSEL=MOD_DIR+"/EL/"+DIR+"/S"
spePR=psread.spe_vol(fnameIPR)
#speEL=psread.spe_vol(fnameIEL)

L=len(spePR.J)
SPR=arange(L,dtype=float)
#SEL=arange(L,dtype=float)

fpr=open(fnameSPR,"w")
#fes=open(fnameSEL,"w")

for i in range(L):
	if i <= (L-2):
		SPR[i]=(log(spePR.J[i+1]) - log(spePR.J[i]))/(log(spePR.E[i+1]) - log(spePR.E[i]))
#		SEL[i]=(log(speEL.J[i+1]) - log(speEL.J[i]))/(log(speEL.E[i+1]) - log(speEL.E[i]))
	elif i == (L-1):
		SPR[i]=(log(spePR.J[i]) - log(spePR.J[i-1]))/(log(spePR.E[i]) - log(spePR.E[i-1]))
#		SEL[i]=(log(speEL.J[i]) - log(speEL.J[i-1]))/(log(speEL.E[i]) - log(speEL.E[i-1]))
	
	fpr.write(str(spePR.E[i])+" "+str(SPR[i])+"\n")
#	fes.write(str(speEL.E[i])+" "+str(SEL[i])+"\n")
	
#fes.close()
fpr.close()
