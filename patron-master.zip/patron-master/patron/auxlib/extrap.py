######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  extrap.py									
# Author: adapted from http://stackoverflow.com/a/2745496 by Igor Telezhinsky, 2010
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v1.0.0: adapted from http://stackoverflow.com/a/2745496
#v1.1.0: version control added

__version__='1.1.0'

from scipy.interpolate import interp1d
from scipy import array

def extrap1d(interpolator):
    xs = interpolator.x
    ys = interpolator.y

    def pointwise(x):
        if x < xs[0]:
            return ys[0]+(x-xs[0])*(ys[1]-ys[0])/(xs[1]-xs[0])
        elif x > xs[-1]:
            return ys[-1]+(x-xs[-1])*(ys[-1]-ys[-2])/(xs[-1]-xs[-2])
        else:
            return interpolator(x)

    def ufunclike(xs):
        return array(map(pointwise, array(xs)))

    return ufunclike
