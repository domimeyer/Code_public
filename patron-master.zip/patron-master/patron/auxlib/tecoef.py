######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  tecoef.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2010 - 2015
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#new version tracking start with 2.0.0; the last version of pspec2d is 19.2
#v2.0.0: functions used in transport equation coefficients are implemented here
#v2.1.0: switch to object
#v2.2.0: parameters renamed and reordered to comply with patron v2.2.0
#v2.3.0: adding evotru
#v2.4.0: re-arranging some parameters to add support of mttran, analytical turbulence
#v2.5.0: adding momentum diffusion coefficient and injection scaling parameter
#v2.6.0: inverse Compton losses in HII region added
#v2.7.0: version control added
#v2.7.1: P_0_el/pr to momentum diffusion coefficient added
#v2.7.2: Added Eta-parameter for KOLM-diffusion

__version__='2.7.2'

from os import getenv

import hiireg as hiir
import icloss as icls

from patron.snrmod import snrmhd as smhd

from patron.auxlib.constants import *

from fipy.tools import parallel
from fipy.tools.numerix import exp
from fipy.tools.numerix import log
from fipy.tools.numerix import size
from fipy.tools.numerix import diff
from fipy.tools.numerix import where
from fipy.tools.numerix import arange
from fipy.tools.numerix import sqrt
from fipy.tools.numerix import zeros
from scipy.integrate import quad
from scipy.interpolate import interp1d

from fipy.tools.numerix import sum
from fipy.tools.numerix import outer
from fipy.tools.numerix import array

# pi    = 3.1415926
# yr    = 3.156e+7						#years in seconds
# c     = 2.998e10						#speed of light in cm/s
# m_e   = 9.109e-28						#electron mass in grams
# p_e   = m_e*c							#electron momentum
# m_p   = 1.673e-24						#proton mass in grams
# p_p   = m_p*c							#proton momentum
# m_he  = 4*m_p							#helium mass
# p_he  = m_he*c							#helium momentum
# m_c   = 12*m_p							#carbon mass
# p_c   = m_c*c							#carbon momentum
# m_ox  = 16*m_p							#oxygen mass
# p_ox  = m_ox*c							#oxygen momentum
# m_fe  = 56*m_p							#iron mass
# p_fe  = m_fe*c							#iron momentum
# q     = 4.8e-10							#electron charge in statcoulons
# kB    = 1.3807e-16						#Boltzmann constant in ergs/K
# hP    = 6.6261e-27						#Planck constant in ergs*s
# E0_p  = m_p*c**2                                                #rest mass energy of proton
# E0_e  = m_e*c**2                                                #rest mass energy of electron
# E0_he = m_he*c**2						#rest mass energy of helium
# E0_c  = m_c*c**2					        #rest mass energy of carbon
# E0_ox = m_ox*c**2						#rest mass energy of oxygen
# E0_fe = m_fe*c**2						#rest mass energy of iron

s     = 2.75							#ISM cosmic-ray power-law index

xi    = 0.01							#intermediate diffusion coefficient as a fraction of Galactic difusion
delta = 1/3.							#diffusion type - Kolmogorov

DINT  = "LIN"							#type of interpolation between different diffusion types (zones)
l     = 1.99							#end of one zone
L     = 2.00							#start of the other zone

MTSPE = "BOHM"							#magnetic turbulence spectrum applied
eta   = 1.0							#eta of Bohm diffusion coefficient

mdp   = 0.0							#index of momentum dependence for momentum diffusion coefficient
tau   = 1.0							#acceleration time in years for momentum diffusion coefficient

r1    = 0.0
r2    = 1.0

Tgr = 100.0

eV2erg  = 1./6.24e11

overview = getenv("PATRONDIR")+"/dat/hii/hii_cloudy.ovr"
volumeEm = getenv("PATRONDIR")+"/dat/hii/hii_cloudy_VolumeEmissivityRadiusAt1p00eV.con"
totalOpZ = getenv("PATRONDIR")+"/dat/hii/hii_cloudy_TotalOpacitiesZones.opc"
difConEZ = getenv("PATRONDIR")+"/dat/hii/hii_cloudy_DiffuseContEmissCoeffAllZones.con"
volConIZ = getenv("PATRONDIR")+"/dat/hii/hii_cloudy_VolumeIntegratedNormContZones.con"

class TranEqnCoeffFuncs(smhd.PlasmaMHDProfiles):

	#def __init__(self,shockType="FSA",nhDensity=1.0,expEnergy=1e51,useSedSol=1.0,crSpecies="PR",speciesPR=True,speciesEL=True,injectPar=0.0,injSclPar=0.0,mfProfile="CON",alfvDrift="I",hdDataInp="",hdFileInp="",mfDataInp="",mfFileInp=""):
        def __init__(self,shockType="FSA",nhDensity=1.0,expEnergy=1e51,useSedSol=1.0,crSpecies="PR",injectPar=0.0,injSclPar=0.0,mfProfile="CON",alfvDrift="I",hdDataInp="",hdFileInp="",mfDataInp="",mfFileInp="",SP=""):

		if parallel.procID == 0: print "tecoef: initializing coefficient functions object..."
                		
		self.SP = SP
		self.smhd = smhd
                self.mfProfile = mfProfile
		self.smhd.PlasmaMHDProfiles.__init__(self,shockType,nhDensity,expEnergy,useSedSol,mfProfile,alfvDrift,hdDataInp,hdFileInp,mfDataInp,mfFileInp,SP)
		#if parallel.procID == 0: print "DEBUG: magnetic field ", self.B0(t)		
		

		self.InP = injectPar
		if parallel.procID == 0: print "tecoef: injection parameter is initialized to", self.InP
		self.ScP = injSclPar
		self.injSclPar = injSclPar
		if parallel.procID == 0: print "tecoef: source function scaling parameter is initialized to", self.ScP
		
		self.crSpecies = crSpecies
		if self.crSpecies == "EL":
			self.pmom  = p_e
			self.Q0    = self.Q0_EL
			self.pinj  = self.pinj_EL
			self.Dx    = self.Dx_EL
			self.Dx_GAL= self.Dx_GAL_EL
			self.Dp    = self.Dp_EL
			self.Ls    = self.Ls_EL
			self.Lc    = self.Lc_EL
			self.Fbkg  = self.Fbkg_EL
			self.Nbkg  = self.Nbkg_EL
			if parallel.procID == 0: print "tecoef: cosmic-ray particles are set to electrons"
		elif self.crSpecies == "PR":
			self.pmom  = p_p
			self.Q0    = self.Q0_PR
			self.pinj  = self.pinj_PR
			self.Dx    = self.Dx_PR
			self.Dx_GAL= self.Dx_GAL_PR
			self.Dp    = self.Dp_PR
			self.Ls    = self.Ls_PR
			self.Lc    = self.Lc_PR
			self.Fbkg  = self.Fbkg_PR
			self.Nbkg  = self.Nbkg_PR
			if parallel.procID == 0: print "tecoef: cosmic-ray particles are set to protons"
		elif self.crSpecies == "HE":
			self.pmom  = p_he
			self.Q0    = self.Q0_HE
			self.pinj  = self.pinj_HE
			self.Dx    = self.Dx_HE
			self.Dx_GAL= self.Dx_GAL_HE
			self.Dp    = self.Dp_HE
			self.Ls    = self.Ls_HE
			self.Lc    = self.Lc_HE
			self.Fbkg  = self.Fbkg_HE
			self.Nbkg  = self.Nbkg_HE
			if parallel.procID == 0: print "tecoef: cosmic-ray particles are set to helium"
                elif self.crSpecies == "C":
			self.pmom  = p_c
			self.Q0    = self.Q0_C
			self.pinj  = self.pinj_C
			self.Dx    = self.Dx_C
			self.Dx_GAL= self.Dx_GAL_C
			self.Dp    = self.Dp_C
			self.Ls    = self.Ls_C
			self.Lc    = self.Lc_C
			self.Fbkg  = self.Fbkg_C
			self.Nbkg  = self.Nbkg_C
			if parallel.procID == 0: print "tecoef: cosmic-ray particles are set to carbon"
		elif self.crSpecies == "OX":
			self.pmom  = p_ox
			self.Q0    = self.Q0_OX
			self.pinj  = self.pinj_OX
			self.Dx    = self.Dx_OX
			self.Dx_GAL= self.Dx_GAL_OX
			self.Dp    = self.Dp_OX
			self.Ls    = self.Ls_OX
			self.Lc    = self.Lc_OX
			self.Fbkg  = self.Fbkg_OX
			self.Nbkg  = self.Nbkg_OX
			if parallel.procID == 0: print "tecoef: cosmic-ray particles are set to oxygen"

		elif self.crSpecies == "FE":
			self.pmom  = p_fe
			self.Q0    = self.Q0_FE
			self.pinj  = self.pinj_FE
			self.Dx    = self.Dx_FE
			self.Dx_GAL= self.Dx_GAL_FE
			self.Dp    = self.Dp_FE
			self.Ls    = self.Ls_FE
			self.Lc    = self.Lc_FE
			self.Fbkg  = self.Fbkg_FE
			self.Nbkg  = self.Nbkg_FE
			if parallel.procID == 0: print "tecoef: cosmic-ray particles are set to iron"
		
		#self.HII   = hiir.HIIregion(overview,volumeEm,totalOpZ,difConEZ,volConIZ)
		#icls.Eph   = self.HII.Erebinned #*eV2erg
		#icls.dEph  = self.HII.dErebinned#*eV2erg
		#icls.fKNm  = icls.fKNmatrix()
		
		if parallel.procID == 0: print "tecoef: coefficient functions object is initialized."


###injection momentum###########################################
	def pinj_EL(self,t):
		#K=2.0*kB*self.Tg_sh(r,t)*m_e
		#pth=K**0.5/p_e
		K=2.0*kB*self.Tg_sh(t)/(p_e*c)
		pth=K**0.5
		return self.InP*pth
	
	def pinj_PR(self,t):							#injection momentum of protons analytic solutions
		# K=2.0*kB*self.Tg_sh(t)*m_p
		# pth=K**0.5/p_p
		K=2.0*kB*self.Tg_sh(t)/(p_p*c)
		pth=K**0.5
		return self.InP*pth

	def pinj_HE(self,t):
		K=2.0*kB*self.Tg_sh(t)/(p_he*c) #(E0_he)?
		pth=K**0.5
		return self.InP*pth
	
	def pinj_C(self,t):
		K=2.0*kB*self.Tg_sh(t)/(p_c*c) #(E0_he)?
		pth=K**0.5
		return self.InP*pth

	def pinj_OX(self,t):
		K=2.0*kB*self.Tg_sh(t)/(p_ox*c) #(E0_he)?
		pth=K**0.5
		return self.InP*pth
	
	def pinj_FE(self,t):
		K=2.0*kB*self.Tg_sh(t)/(p_fe*c) #(E0_he)?
		pth=K**0.5
		return self.InP*pth

	
###source function##############################################
	def Q0_EL(self,t):								#source function; when divided by dr is in 1/[cm^3][tsyr];
		return self.ScP*self.eta_i(t,self.InP)*self.ne_u(t)*self.Vinj(t)	#N of particles injected in the shell of thickness dr will be:
											#(Q0/dr)*4pi*r^2*dr = Q0*4pi*r^2 = a(t)^2*Q0*4pi
	def Q0_PR(self,t):
		return self.ScP*self.eta_i(t,self.InP)*self.nh_u(t)*self.Vinj(t)
                
	def Q0_HE(self,t):
		return self.ScP*self.eta_i(t,self.InP)*self.nhe_u(t)*self.Vinj(t)
	
	def Q0_C(self,t):
		return self.ScP*self.eta_i(t,self.InP)*self.nc_u(t)*self.Vinj(t)
	
	def Q0_OX(self,t):
		return self.ScP*self.eta_i(t,self.InP)*self.nox_u(t)*self.Vinj(t)

	def Q0_FE(self,t):
		return self.ScP*self.eta_i(t,self.InP)*self.nfe_u(t)*self.Vinj(t)
	
	
###synchrotron losses function##################################
	def Ls_EL(self,r,p,t):							#synchrotron losses function
		b=(4.0*(q**4)*(self.B(r,t)**2))/(9.0*(c**6)*(m_e**4))		#synchrotron losses "constant b" in g^(-1)*cm^(-1); when multiplied by p^2 is in [p]/s					
		return b*p*p_e*yr						#note, as we solve for dN/dlnp we multiply by p and not p^2
	
	def Ls_PR(self,r,p,t):
		return 0.0

	def Ls_HE(self,r,p,t):
		return 0.0
	def Ls_C(self,r,p,t):
		return 0.0

	def Ls_OX(self,r,p,t):
		return 0.0

	def Ls_FE(self,r,p,t):
		return 0.0

###inverse Compton losses function##############################
	def _FKNxUthr(self,r,p,t):
		return icls.FKNxU(p,icls.Unuth(icls.Tcmb,icls.Ucmb))
	
	def _FKNxUhii(self,r,p,t):
		return icls.FKNxU(p,self.HII.Unu(self.Rsh(t)))
	
	def Lc_EL(self,r,p,t):				#Inverse Compton losses function
		#Old stuff					
		#Unu=icls.Unuth(icls.Tcmb,icls.Ucmb)
		#Unu=self.HII.Unu(self.Rsh(10.0))
		#b=32.0*pi*q**4*icls.FKNxU(p,Unu)/(9.0*(c**6)*(m_e**4))		#IC losses "constant b" in g^(-1)*cm^(-1); when multiplied by p^2 is in [p]/s

		#new stuff
		GeV2erg = 1.60218e-3
		sigT	 = 6.652458558e-25 # Thompson corss section
		Uph   = self.SP.ucmb*GeV2erg #energy in photon field; here value for CMB only
		Ustar = self.SP.ustarlight*GeV2erg
		Udust = self.SP.udust*GeV2erg
		Tc    = self.SP.Tcmb	#2.7
		Td    = self.SP.Tdust  #1.4e2
		Ts    = self.SP.Tstar  #2.e5
		gamma = array(p)
		#print shape(gamma)
		steps = 50
		q0=arange(1./steps,1+1./steps,1.0/steps)
		dq0=1.0/steps

		#Integrate over photon energies
		#CMB		
		epsilon = Tc*kB 
		gammae= gamma*4.*epsilon/(m_e*c**2.)

		Integral = sum(dq0*outer(gammae**2.,q0)/(1.+outer(gammae,q0))**3.*(2.*outer(gammae/gammae,q0*log(q0))+outer(gammae/gammae,(1.+2.*q0)*(1.-q0))+(outer(gammae,q0))**2.*outer(gammae/gammae,(1.-q0))/(2.*(1.+outer(gammae,q0)))), axis=1)
		Integral = Integral*3.*sigT*m_e**2.*c**4./4./epsilon**2./(gamma*m_e*c)		
		bcmb  = Integral*Uph		#Loss-term for CMB
		#Dust
		epsilon = Td*kB 
		gammae= gamma*4.*epsilon/(m_e*c**2.)
		Integral = sum(dq0*outer(gammae**2.,q0)/(1.+outer(gammae,q0))**3.*(2.*outer(gammae/gammae,q0*log(q0))+outer(gammae/gammae,(1.+2.*q0)*(1.-q0))+(outer(gammae,q0))**2.*outer(gammae/gammae,(1.-q0))/(2.*(1.+outer(gammae,q0)))), axis=1)
		Integral = Integral*3.*sigT*m_e**2.*c**4./4./epsilon**2./(gamma*m_e*c)		
		bdust = Integral*Udust		#Loss-term for IR-radiation
		#Starlight
		epsilon = Ts*kB 
		gammae= gamma*4.*epsilon/(m_e*c**2.)
		Integral = sum(dq0*outer(gammae**2.,q0)/(1.+outer(gammae,q0))**3.*(2.*outer(gammae/gammae,q0*log(q0))+outer(gammae/gammae,(1.+2.*q0)*(1.-q0))+(outer(gammae,q0))**2.*outer(gammae/gammae,(1.-q0))/(2.*(1.+outer(gammae,q0)))), axis=1)
		Integral = Integral*3.*sigT*m_e**2.*c**4./4./epsilon**2./(gamma*m_e*c)
		bstar = Integral*Ustar		#Loss-term for starlight
		#Total loss
		b = bcmb+bdust+bstar
		#if parallel.procID == 0: print "tecoef: bnew", b[0]*yr, b[1000]*yr, p[0],p[1000]
		return b*yr
		#Old calculation
		Uph = self.SP.ucmb*GeV2erg #energy in photon field; here value for CMB only: 0.25eV/cm^3 Longair 1974
		b=32.0*pi*q**4*Uph/(9.0*(c**6)*(m_e**4))				
		#return b*p*p_e*yr
		#if parallel.procID == 0: print "tecoef: bold", b*p[0]*p_e*yr, b*p[1000]*p_e*yr, p[0],p[1000]
		#sys.exit(0)
		return where(r<=1.0,0.0,b*p*p_e*yr)				#note, as we solve for dN/dlnp we multiply by p and not p^2
	
	def Lc_PR(self,r,p,t):
		return 0.0

	def Lc_HE(self,r,p,t):
		return 0.0
	def Lc_C(self,r,p,t):
		return 0.0
	def Lc_OX(self,r,p,t):
		return 0.0
	
	def Lc_FE(self,r,p,t):
		return 0.0

###diffusion coefficient function###############################
	def __pmax_evo(self,t):
		#return (self.Rsh(t)*self.Vsh(t))/(self.Rsh(2.0)*self.Vsh(2.0))
	#	return 1e6
		if   t <= Tgr: return 1e6*(t/Tgr)		#first linearly grows
		elif t >  Tgr: return 1e6*(t/Tgr)**(-0.2) 	#then sedov scaling
#		elif t >  Tgr: return 1e6*(t/Tgr)**(-0.5)

	def __Fs_normal_from_t(self,t):
		Br = 20.0
		Nr = 12.0
		if   t <= Tgr:                 return Nr*(t/Tgr)**(0.1)
		elif t >  Tgr and t <= Br*Tgr: return Nr*(t/Tgr)**(-0.8)
		elif t >  Br*Tgr:              return Nr*(Br)**(2.0-0.8)*(t/Tgr)**(-2.0)
	
	def __F_normal_from_t(self,t):
		Br = 20.0
		
		#Nr = 12.0
		#if   t <= Tgr:                 return Nr*(t/Tgr)**(0.1)
		#elif t >  Tgr and t <= Br*Tgr: return Nr*(t/Tgr)**(-0.8)
		#elif t >  Br*Tgr:              return Nr*(Br)**(2.0-0.8)*(t/Tgr)**(-2.0)

		#flat: constant
		#Nr = 50e-1 
		#return Nr
		
		#flat: exponential growth - linear decay
		Nr = 5e-1 
		if   t <= Tgr: return Nr*exp(t/(0.2*Tgr))
#		elif t >  Tgr: return 148.0*Nr*(t/Tgr)**(-1.0)
		elif t >  Tgr: return 148.0*Nr*(t/Tgr)**(-3./5.)
		


	def __K41_normal_from_t(self,t):
		Br = 20.0
		
		#intensity as in simulations
		#Nr = 5e-10
		#if   t <= Tgr:                 return Nr*(t/Tgr)**(0.1)
		#elif t >  Tgr and t <= Br*Tgr: return Nr*(t/Tgr)**(-0.8)
		#elif t >  Br*Tgr:              return Nr*(Br)**(2.0-0.8)*(t/Tgr)**(-2.0)
		
		#intensity with sedov scaling of max energy
		#Nr = 0.4e-10
		#if   t <= Tgr: return Nr*(t/Tgr)**(1.0)
		#elif t >  Tgr: return Nr*(t/Tgr)**(-0.2)
		
		#kolm: const
		#Nr = 50.0e-12 
		#return Nr

		#kolm: exponential growth - linear decay
		Nr = 3.0e-12 
		if   t <= Tgr: return Nr*exp(t/(0.2*Tgr))
		#elif t >  Tgr: return 148.0*Nr*(t/Tgr)**(-1.0)
		elif t >  Tgr: return 148.0*Nr*(t/Tgr)**(-3./5.)
		
		#kolm: exponential growth - quadratic decay
		#Nr = 5.0e-12 
		#if   t <= Tgr: return Nr*exp(t/(0.2*Tgr))
		#elif t >  Tgr: return 148.0*Nr*(t/Tgr)**(-2.0)


	def __KIR_normal_from_t(self,t):
		Br = 20.0
		
		#intensity as in simulations
		#Nr = 5e-10
		#if   t <= Tgr:                 return Nr*(t/Tgr)**(0.1)
		#elif t >  Tgr and t <= Br*Tgr: return Nr*(t/Tgr)**(-0.8)
		#elif t >  Br*Tgr:              return Nr*(Br)**(2.0-0.8)*(t/Tgr)**(-2.0)
		
		#intensity with sedov scaling of max energy
		#Nr = 0.4e-10
		#if   t <= Tgr: return Nr*(t/Tgr)**(1.0)
		#elif t >  Tgr: return Nr*(t/Tgr)**(-0.2)
		
		#krai: const
		#Nr = 30.0e-9
		#return Nr
		
		#krai: exponential growth - linear decay
		#Nr = 3e-9 corresponds to 5e-12 of kolm
		Nr = 3.0e-9 
		if   t <= Tgr: return Nr*exp(t/(0.2*Tgr))
		#elif t >  Tgr: return 148.0*Nr*(t/Tgr)**(-1.0)
		elif t >  Tgr: return 148.0*Nr*(t/Tgr)**(-3./5.)
		
		#krai: exponential growth - quadratic decay
		#Nr = 3.0e-9
		#if   t <= Tgr: return Nr*exp(t/(0.2*Tgr))
		#elif t >  Tgr: return 148.0*Nr*(t/Tgr)**(-2.0)

		
	
	def __cut_min_k_pow_t(self,t):
		return 5.00*t**(-0.3)
	
	def __C_normal_from_t(self,t):
		return 25.4*t**(-0.24)
	
	def __C_normal_from_k(self,k):
		return (k/1e-16)**0.1
	
	def __B_normal_from_t(self,t):
		return 0.20*t**0.15
	
	def __B_normal_from_k(self,k):
		return (k/1e-16)**(-0.15)
	
	def rg_PR(self,r,p,t):
		return (p*p_p*c)/(q*self.B(r,t))
	
	def rg_EL(self,r,p,t):
		return (p*p_e*c)/(q*self.B(r,t))

	def rg_HE(self,r,p,t):
		return (p*p_he*c)/(2.*q*self.B(r,t))
	def rg_C(self,r,p,t):
		return (p*p_c*c)/(6.*q*self.B(r,t))


	def rg_OX(self,r,p,t):
		return (p*p_ox*c)/(8.*q*self.B(r,t))

	def rg_FE(self,r,p,t):
		return (p*p_fe*c)/(26.*q*self.B(r,t))

	def Ew_GAL_PR(self,r,p,t):
		v  = yr*c #yr*p*c/(p_p**2 + p**2)**0.5
		return 4.0*v*self.rg_PR(r,p,t)/(3.0*pi*self.Dx_GAL_PR(r,p,t))

	def Ew_GAL_EL(self,r,p,t):
		v  = yr*c #yr*p*c/(p_p**2 + p**2)**0.5
		return 4.0*v*self.rg_EL(r,p,t)/(3.0*pi*self.Dx_GAL_EL(r,p,t))
	
	def Ew_GAL_HE(self,r,p,t):
		v  = yr*c #yr*p*c/(p_p**2 + p**2)**0.5
		return 4.0*v*self.rg_HE(r,p,t)/(3.0*pi*self.Dx_GAL_HE(r,p,t))
	def Ew_GAL_C(self,r,p,t):
		v  = yr*c #yr*p*c/(p_p**2 + p**2)**0.5
		return 4.0*v*self.rg_C(r,p,t)/(3.0*pi*self.Dx_GAL_C(r,p,t))

	def Ew_GAL_OX(self,r,p,t):
		v  = yr*c #yr*p*c/(p_p**2 + p**2)**0.5
		return 4.0*v*self.rg_OX(r,p,t)/(3.0*pi*self.Dx_GAL_OX(r,p,t))

	def Ew_GAL_FE(self,r,p,t):
		v  = yr*c #yr*p*c/(p_p**2 + p**2)**0.5
		return 4.0*v*self.rg_FE(r,p,t)/(3.0*pi*self.Dx_GAL_FE(r,p,t))



	#magnetic turbulence spectrum: W(k)*k
	def Ew_EL(self,r,p,t):							
		pmin = (2.0*kB*self.Tg_sh(t)/(p_e*c))**0.5			#pmin equals to thermal momnetum
		pmax = self.__pmax_evo(t)					#pmax is evolving in time according to pmax_evo
		kmin = 1.0/self.rg_EL(r,pmax,t)
		kcut = 5e3/self.rg_EL(r,pmax,t)
		kmax = 1.0/self.rg_EL(r,pmin,t)
		k    = 1.0/self.rg_EL(r,p,t)
		
		if   MTSPE == "BOHM":
			return 1.0/eta
		elif MTSPE == "KOLM":
			Kw_0 = 4e-13
			#return Kw_0*k**(-2./3.)*exp(-(k/kmin)**(-2))*exp(-(k/kmax)**2)/eta+self.Ew_GAL_PR(r,p,t)
			return Kw_0*k**(-2./3.)/eta+self.Ew_GAL_EL(r,p,t)
		elif MTSPE == "KRAI":
			return 0.0

	def Ew_PR(self,r,p,t):							
		pmin = (2.0*kB*self.Tg_sh(t)/(p_p*c))**0.5			#pmin equals to thermal momnetum
		pmax = self.__pmax_evo(t)					#pmax is evolving in time according to pmax_evo
		kmin = 1.0/self.rg_PR(r,pmax,t)
		kcut = 5e3/self.rg_PR(r,pmax,t)
		kmax = 1.0/self.rg_PR(r,pmin,t)
		k    = 1.0/self.rg_PR(r,p,t)

		#if parallel.procID == 0: print "tecoef: kmin=", kmin, " kmax=", kmax
		
		if   MTSPE == "BOHM":
			return 1.0/eta
		elif MTSPE == "KOLM":
			Kw_0 = 4e-13/eta
			return Kw_0*k**(-2./3.)+self.Ew_GAL_PR(r,p,t)
			return Kw_0*k**(-2./3.)*exp(-(k/kmin)**(-2))*exp(-(k/kmax)**2)+self.Ew_GAL_PR(r,p,t)
		elif MTSPE == "KRAI":
			return 0.0
		elif MTSPE == "HAND":
			Ewgal = self.Ew_GAL_PR(r,p,t)
		elif MTSPE == "NDSA":
			kbreak = 1.0/self.rg_PR(r,1e3,t) #kink spectrum at ~ 1TeV
			kmax   = 1.0/self.rg_PR(r,1e3,t) #value at 1GeV	
			return where(p>1e3,1.0/eta,p*1e-3/eta) #Ensures that eta(1GeV)=1e3 and eta(1e3)=1 

###IC443 FEB 2015################################################			
			cmkpt = self.__cut_min_k_pow_t(t)
			Cnort = self.__C_normal_from_t(t)
			Cnork = self.__C_normal_from_k(k)
			Bnort = self.__B_normal_from_t(t)
			Bnork = self.__B_normal_from_k(k)
			
		#	FSw_0  =  self.__Fs_normal_from_t(t)
		#	Fw_0   =  self.__F_normal_from_t(t)
			K41w_0 =  self.__K41_normal_from_t(t)
		#	KIRw_0 =  self.__KIR_normal_from_t(t)

			C = Cnork*Cnort
			B = Bnork*Bnort
			
		#	EflatS = FSw_0*exp(-(k/kmin)**(-cmkpt))*exp(-(k/kcut)**(0.2)) #*exp(-(k/kmax)**2)
		#	Eflat = Fw_0*exp(-(k/kmin)**(-2))*exp(-(k/kmax)**2)
			Ekolm = K41w_0*k**(-2./3.)*exp(-(k/kmin)**(-2))*exp(-(k/kmax)**2)
		#	Ekrai = KIRw_0*k**(-1./2.)*exp(-(k/kmin)**(-2))*exp(-(k/kmax)**2)

		#	return  EflatS*where(r<=1.0,1.0,exp(-C*(r-1.0)**B)) + Ewgal #*100.0
		#	return  Eflat + Ewgal			
			return  Ekolm + Ewgal
		#	return  Ekrai + Ewgal


	def Ew_HE(self,r,p,t):							
		pmin = (2.0*kB*self.Tg_sh(t)/(p_he*c))**0.5			
		pmax = self.__pmax_evo(t)	
		kmin = 1.0/self.rg_HE(r,pmax,t)
		kcut = 5e3/self.rg_HE(r,pmax,t)
		kmax = 1.0/self.rg_HE(r,pmin,t)
		k    = 1.0/self.rg_HE(r,p,t)
		return 1.0/eta
	def Ew_C(self,r,p,t):							
		pmin = (2.0*kB*self.Tg_sh(t)/(p_c*c))**0.5			
		pmax = self.__pmax_evo(t)	
		kmin = 1.0/self.rg_C(r,pmax,t)
		kcut = 5e3/self.rg_C(r,pmax,t)
		kmax = 1.0/self.rg_C(r,pmin,t)
		k    = 1.0/self.rg_C(r,p,t)
		return 1.0/eta
	def Ew_OX(self,r,p,t):							
		pmin = (2.0*kB*self.Tg_sh(t)/(p_ox*c))**0.5			
		pmax = self.__pmax_evo(t)	
		kmin = 1.0/self.rg_OX(r,pmax,t)
		kcut = 5e3/self.rg_OX(r,pmax,t)
		kmax = 1.0/self.rg_OX(r,pmin,t)
		k    = 1.0/self.rg_OX(r,p,t)
		return 1.0/eta

	def Ew_FE(self,r,p,t):							
		pmin = (2.0*kB*self.Tg_sh(t)/(p_fe*c))**0.5			
		pmax = self.__pmax_evo(t)	
		kmin = 1.0/self.rg_FE(r,pmax,t)
		kcut = 5e3/self.rg_FE(r,pmax,t)
		kmax = 1.0/self.rg_FE(r,pmin,t)
		k    = 1.0/self.rg_FE(r,p,t)
		return 1.0/eta
		
	def eta_b_EL(self,r,p,t):
		return 1.0/self.Ew_EL(r,p,t)					#turbulence spectrum same as for protons
	
	def eta_b_PR(self,r,p,t):
		return 1.0/self.Ew_PR(r,p,t)
	
	def eta_b_HE(self,r,p,t):
		return 1.0/self.Ew_HE(r,p,t)
	def eta_b_C(self,r,p,t):
		return 1.0/self.Ew_C(r,p,t)
	def eta_b_OX(self,r,p,t):
		return 1.0/self.Ew_OX(r,p,t)

	def eta_b_FE(self,r,p,t):
		return 1.0/self.Ew_FE(r,p,t)

	def Dx_EL(self,r,p,t):							#spatial diffusion coefficient (dimensionless momentum and magnetic field dependent) in cm^2/s
		v=p*c/(1.0+p**2)**0.5						#particle velocity
		return self.eta_b_EL(r,p,t)*self.rg_EL(r,p,t)*v/3.0*yr
	
	def Dx_PR(self,r,p,t):							#spatial diffusion coefficient (dimensionless momentum and magnetic field dependent) in cm^2/s
		v=p*c/(1.0+p**2)**0.5						#particle velocity
		return self.eta_b_PR(r,p,t)*self.rg_PR(r,p,t)*v/3.0*yr

	def Dx_HE(self,r,p,t):							#spatial diffusion coefficient (dimensionless momentum and magnetic field dependent) in cm^2/s
		v=p*c/(1.0+p**2)**0.5						#particle velocity
		return self.eta_b_HE(r,p,t)*self.rg_HE(r,p,t)*v/3.0*yr
	def Dx_C(self,r,p,t):							#spatial diffusion coefficient (dimensionless momentum and magnetic field dependent) in cm^2/s
		v=p*c/(1.0+p**2)**0.5						#particle velocity
		return self.eta_b_C(r,p,t)*self.rg_C(r,p,t)*v/3.0*yr
	def Dx_OX(self,r,p,t):							#spatial diffusion coefficient (dimensionless momentum and magnetic field dependent) in cm^2/s
		v=p*c/(1.0+p**2)**0.5						#particle velocity
		return self.eta_b_OX(r,p,t)*self.rg_OX(r,p,t)*v/3.0*yr

	def Dx_FE(self,r,p,t):							#spatial diffusion coefficient (dimensionless momentum and magnetic field dependent) in cm^2/s
		v=p*c/(1.0+p**2)**0.5						#particle velocity
		return self.eta_b_FE(r,p,t)*self.rg_FE(r,p,t)*v/3.0*yr
	
###galactic diffusion coefficient function######################
	def Dx_GAL_EL(self,r,p,t):						#Galactic diffusion coeficient
		return 1.0e29*(p*p_e*c*0.624e2)**delta*(self.B(r,t)/3.0e-6)**(-delta)*yr
	
	def Dx_GAL_PR(self,r,p,t):
		return 1.0e29*(p*p_p*c*0.624e2)**delta*(self.B(r,t)/3.0e-6)**(-delta)*yr

	def Dx_GAL_HE(self,r,p,t):
		return 1.0e29*(p*p_he*c*0.624e2)**delta*(self.B(r,t)/3.0e-6)**(-delta)*yr
	def Dx_GAL_C(self,r,p,t):
		return 1.0e29*(p*p_c*c*0.624e2)**delta*(self.B(r,t)/3.0e-6)**(-delta)*yr
	def Dx_GAL_OX(self,r,p,t):
		return 1.0e29*(p*p_ox*c*0.624e2)**delta*(self.B(r,t)/3.0e-6)**(-delta)*yr

	def Dx_GAL_FE(self,r,p,t):
		return 1.0e29*(p*p_fe*c*0.624e2)**delta*(self.B(r,t)/3.0e-6)**(-delta)*yr

###empiric transitions betwen Bohm and galactic diffusion coefficient	
	def D1(self,r,p,t,PAR,l,L):
		DX=self.Dx(r,p,t)
		DG=self.Dx_GAL(r,p,t)
		if PAR == "LIN":
			INT=where(r<=l,DX,DX+(DG-DX)*(r-l)/(L-l))
			return where(r<=L,INT,DG)
		elif PAR == "EXP":
			INT=where(r<=l,DX,DX*exp(log(DG/DX)*(r-l)/(L-l)))
			return where(r<=L,INT,DG)
	
	def D2(self,r,p,t,PAR,l1,l2,L1,L2,xi):
		DX=self.Dx(r,p,t)
		DG=self.Dx_GAL(r,p,t)
		if PAR == "LIN":
			INT1=where(r<=l1,DX,DX+(xi*DG-DX)*(r-l1)/(l2-l1))
			SNRV=where(r<=l2,INT1,xi*DG)
			INT2=where(r<=L1,SNRV,xi*DG+(DG-xi*DG)*(r-L1)/(L2-L1))
			return where(r<=L2,INT2,DG)
		elif PAR == "EXP":
			INT1=where(r<l1,DX,DX*exp(log(xi*DX/DX)*(r-l1)/(l2-l1)))
			SNRV=where(r<=l2,INT1,xi*DG)
			INT2=where(r<=L1,SNRV,xi*DG*exp(log(1.0/xi)*(r-L1)/(L2-L1)))
			return where(r<=L2,INT2,DG)
	
####momentum diffusion coefficient#########################################################	
        def Dp_EL(self,r,p,t):							#momentum diffusion coefficient devided by p^2
		Ekin=0.0016*P_0_el
		p_0=((Ekin+E0_e)**2-E0_e**2)**(1./2.)/(E0_e)					
		return where(p>=p_0,(p/p_0)**(-mdp)/tau,1.0/tau)
	
        def Dp_PR(self,r,p,t):							#momentum diffusion coefficient devided by p^2
               	Ekin=0.0016*P_0_pr                                              #kinetic energy in erg
		p_0=((Ekin+E0_p)**2-E0_p**2)**(1./2.)/(E0_p)			#corresponding dimensionless momentum #CHANGE LATER!!!  100/1836 MeV !
                return where(p>=p_0,(p/p_0)**(-mdp)/tau,1.0/tau)

	def Dp_HE(self,r,p,t):							#momentum diffusion coefficient devided by p^2
               	Ekin=0.0016*P_0_he                                              #kinetic energy in erg
		p_0=((Ekin+E0_he)**2-E0_he**2)**(1./2.)/(E0_he)			#corresponding dimensionless momentum #CHANGE LATER!!!  100/1836 MeV !
                return where(p>=p_0,(p/p_0)**(-mdp)/tau,1.0/tau)
	def Dp_C(self,r,p,t):							#momentum diffusion coefficient devided by p^2
               	Ekin=0.0016*P_0_c                                              #kinetic energy in erg
		p_0=((Ekin+E0_c)**2-E0_c**2)**(1./2.)/(E0_c)			#corresponding dimensionless momentum #CHANGE LATER!!!  100/1836 MeV !
                return where(p>=p_0,(p/p_0)**(-mdp)/tau,1.0/tau)
	def Dp_OX(self,r,p,t):							#momentum diffusion coefficient devided by p^2
               	Ekin=0.0016*P_0_ox                                              #kinetic energy in erg
		p_0=((Ekin+E0_ox)**2-E0_ox**2)**(1./2.)/(E0_ox)			#corresponding dimensionless momentum #CHANGE LATER!!!  100/1836 MeV !
                return where(p>=p_0,(p/p_0)**(-mdp)/tau,1.0/tau)

	def Dp_FE(self,r,p,t):							#momentum diffusion coefficient devided by p^2
               	Ekin=0.0016*P_0_fe                                              #kinetic energy in erg
		p_0=((Ekin+E0_fe)**2-E0_fe**2)**(1./2.)/(E0_fe)			#corresponding dimensionless momentum #CHANGE LATER!!!  100/1836 MeV !
                return where(p>=p_0,(p/p_0)**(-mdp)/tau,1.0/tau)


###empiric region of active SOFA downstream of the SNR##########################
	def D1p(self,r,p,t,r1,r2):
		return where((r>r1)&(r<=r2),self.Dp(r,p,t),0.0)
		
###ISM cosmic ray flux#########################################!NB: this is F*p to account for solution variable dN/dlnp
#	def Fbkg_EL(self,p):							#ISM cosmic-ray electron flux, power-law in momentum
#		return 0.01*2.2*p**(-s+1)
	
	# def Fbkg_EL(self,p):							#ISM cosmic-ray electron flux, power-law in momentum x beta
	# 	return 0.01*2.2*p**(-s+1)*(p/(1.0+p**2)**0.5)
	
	def Fbkg_EL(self,p):							#ISM cosmic-ray electron flux, power-law in momentum x beta
		#return 0.01*self.Fbkg_PR(p)
		#Flux extracted from Jaffe et. al 2018 for a Galactic radius of 8.5kpc
		#Flux fitted as log-normal + power law at high energies in GeV vs 1/(GeV*sr*m^2)
		#Fit parameters
		GeV 	= 624.151	#1erg in GeV
		m2	= 1e4		
		E	= m_e*c**2.*sqrt(1.+p**2.)*GeV		

		EB  	= 5.03211301
		N0  	= 40.5
		s2  	= 3.036
		s1  	= 1.77436862	
		Delta	= 1197.06475671
		EC	= 2.89010269
		return where(E>EB,N0*(E/EB)**-s2/EB**2, 1/E*1/(s1*sqrt(2*pi))*exp(-(log(E)-EC)**2./(2*s1**2.))*Delta/E**2.)*GeV/m2*p*m_e*c**2

#	def Fbkg_EL(self,p):							#ISM cosmic-ray electron flux, power-law in total energy
#		return 0.01*2.2*sqrt(1.0+p**2)**(-s)*(p**2/(1.0+p**2)**0.5)
	
#	def Fbkg_PR(self,p):							#ISM cosmic-ray proton flux, power-law in momentum
#		return 2.2*p**(-s+1)
	
#	def Fbkg_PR(self,p):							#ISM cosmic-ray proton flux, power-law in momentum x beta
#		return 2.2*p**(-s+1)*(p/(1.0+p**2)**0.5)
	
#	def Fbkg_PR(self,p):							#test energy to momentum
#		return 2.46*(p**2 + 1.)**(-s/2)*p*(p/(1.0 + p**2)**0.5)

	def Fbkg_PR(self,p):
		#Normalization factor taken from Moskalenko, Strong et. al 2002; 2000(GeV/m^2 sr s) at 10GeV --> 20 (1/Gev m^2 sr s) at 10GeV
		GeV 	= 624.151	#1erg in GeV
		m2	= 1e4	
		N0 	= 20*GeV/m2#*10**2.75
		#return N0*sqrt(p**2 + 1.)**(-s+1)*(p/sqrt(1.0 + p**2))		#power law in Etot x beta --> Martin complained

		return where(p>1,N0*(p)**(-s+1),N0*(p)**(-1.5+1)) #Ekin^-1.5 --> Ekin**-2.75 at 1GeV		


#	def Fbkg_PR(self,p):							#ISM cosmic-ray proton flux, power-law in total energy
#		return 2.2*sqrt(1.0+p**2)**(-s)*(p**2/(1.0+p**2)**0.5)

	def Fbkg_HE(self,p):
		return 0.0
	def Fbkg_C(self,p):
		return 0.0
	def Fbkg_OX(self,p):
		return 0.0

	def Fbkg_FE(self,p):
		return 0.0	

###ISM cosmic-ray number density################################!NB: dN/dlnp
	def Nbkg_EL(self,p):							#ISM cosmic-ray electron density
		return (4.0*pi/c)*self.Fbkg_EL(p)
	
	def Nbkg_PR(self,p):							#ISM cosmic-ray proton density
		return (4.0*pi/c)*self.Fbkg_PR(p)

	def Nbkg_HE(self,p):							
		return (4.0*pi/c)*self.Fbkg_HE(p)
	def Nbkg_C(self,p):							
		return (4.0*pi/c)*self.Fbkg_C(p)
	def Nbkg_OX(self,p):							
		return (4.0*pi/c)*self.Fbkg_OX(p)

	def Nbkg_FE(self,p):							
		return (4.0*pi/c)*self.Fbkg_FE(p)
	
	
#quantities depending on ln(p) and rstar per year
###LHS plasma velocity
	def Vlhsrs(self,rstar,t):
		r=(rstar-1.0)**3+1.0
		return self.Vlhs(r,t)
	
###RHS plasma velocity
	def Vrhsrs(self,rstar,t):
		r=(rstar-1.0)**3+1.0
		return self.Vrhs(r,t)

###Alfven velocity
	def Valfrs(self,rstar,t):
		r=(rstar-1.0)**3+1.0
		return self.Valf(r,t)
	
###cosmic ray flux per year
	def Fbkgln(self,lnp):
		return self.Fbkg(exp(lnp))
	
###cosmic ray number density
	def Nbkgln(self,lnp):
		return self.Nbkg(exp(lnp))
	
###synchrotron losses
	def Lsln(self,rstar,lnp,t):
		r=(rstar-1.0)**3+1.0
		return self.Ls(r,exp(lnp),t)

###inverse Compton losses
	def Lcln(self,rstar,lnp,t):
		r=(rstar-1.0)**3+1.0
		return self.Lc(r,exp(lnp),t)

###bohm spatial diffusion
	def Dxln(self,rstar,lnp,t):
		r=(rstar-1.0)**3+1.0
		return self.Dx(r,exp(lnp),t)
	
###galactic spatial diffusion
	def Dgln(self,rstar,lnp,t):
                r=(rstar-1.0)**3+1.0
                return self.Dx_GAL(r,exp(lnp),t)
	
###bohm -> galactic spatial diffusion
	def D1ln(self,rstar,lnp,t,PAR,l,L):
		r=(rstar-1.0)**3+1.0
		return self.D1(r,exp(lnp),t,PAR,l,L)
	
###bohm -> intermediate -> galactic spatial diffusion
	def D2ln(self,rstar,lnp,t,PAR,l1,l2,L1,L2,xi):
		r=(rstar-1.0)**3+1.0
		return self.D2(r,exp(lnp),t,PAR,l1,l2,L1,L2,xi)

###SOFA diffusion coeff.inside SNR		
	def D1pln(self,rstar,lnp,t,r1,r2):
		r=(rstar-1.0)**3+1.0
		return self.D1p(r,exp(lnp),t,r1,r2)
		
###diffusion function used in transport equation must depend on 3 parameters only
###diffusion coefficient in space
	def Dln(self,rstar,lnp,t):
                #if parallel.procID == 0: print "DEBUG: tecoef: Dln: crspecies ==", self.crSpecies
#		r=(rstar-1.0)**3+1.0
#		return self.D1(r,exp(lnp),t,DINT,l*self.RFS(t),L*self.RFS(t))
		return self.D1ln(rstar,lnp,t,DINT,l*self.RFS(t),L*self.RFS(t))

###diffusion coefficient in momentum space	
        def Dpln(self,rstar,lnp,t):
		r=(rstar-1.0)**3+1.0
		return self.D1p(r,exp(lnp),t,r1*self.RFS(t),r2*self.RFS(t))
		#return self.Dp(rstar,exp(lnp),t)

###########################
	def SetInjectPar(self,injectPar):
		self.InP = injectPar
		if parallel.procID == 0: print "tecoef: injection parameter is set to", self.InP
		
	def SetSrcSclPar(self,srcSclPar):
		self.ScP = srcSclPar
		if parallel.procID == 0: print "tecoef: source function scaling parameter is set to", self.ScP
	
	def WriteMHDData(self,mhdParameterFuncList,rStepsNum,rCoordMax,t,timesOut,outFileName,MHDOutFile):
		for time in timesOut:
			if round(time - t,5) == 0:
				#TIME=str(int(time)).zfill(5)
				TIME=str(time)
				fname=outFileName+TIME
				fnameMHD=MHDOutFile+TIME
				if parallel.procID == 0: print "tecoef: writing file", fname
				#rmax = (rCoordMax - 1.0)**3 + 1.0									
				dr=rCoordMax/rStepsNum
				r=arange(0,rCoordMax,dr)+dr
				dr2 = 1e-6
				r_hr  = arange(0,rCoordMax,dr2)+dr2
#				B=mhdParameterFuncList[0](r,t)
				B=mhdParameterFuncList[0]((r-1.0)**3+1.0,t)
#				nh=mhdParameterFuncList[1](r,t)
#				Tg=mhdParameterFuncList[2](r,t)
				nh_hr = interp1d(r_hr, mhdParameterFuncList[1]((r_hr-1.)**3.+1,t),fill_value='extrapolate')
				nh = zeros(len(r))
				for i in arange(len(r)):
					nh[i] = quad(nh_hr,r[i]-dr/2.,r[i]+dr/2.)[0]/dr 
				#nh=mhdParameterFuncList[1]((r-1.0)**3+1.0,t)
				nhe=mhdParameterFuncList[2]((r-1.0)**3+1.0,t)
				nc=mhdParameterFuncList[3]((r-1.0)**3+1.0,t)
				nox=mhdParameterFuncList[4]((r-1.0)**3+1.0,t)
				nfe=mhdParameterFuncList[5]((r-1.0)**3+1.0,t)
				ne=mhdParameterFuncList[6]((r-1.0)**3+1.0,t)
				Tg=mhdParameterFuncList[7]((r-1.0)**3+1.0,t) 
				f=open(fname,"w")
				#fR = open(fnameR,"w")
				fMHD = open(fnameMHD,"w")
				f.write("x B B B\n")
				#fR.write("x B B B\n")	
				fMHD.write("x B nh nhe nc nox nfe ne Tg\n")				
				for i in range(0,rStepsNum):
					if size(B) == 1:
						#f.write(str(r[i])+" "+str(B)+" "+str(B)+" "+str(B)+"\n")
						f.write(str((r[i]-1.0)**3+1.0)+" "+str(B)+" "+str(B)+" "+str(B)+"\n")
						fMHD.write(str((r[i]-1.0)**3+1.0)+" "+str(B)+" "+str(nh)+" "+str(nhe)+" "+str(nc)+" "+str(nox)+" "+str(nfe)+" "+str(ne)+" "+str(Tg)+"\n")
					else:
						#f.write(str(r[i])+" "+str(B[i])+" "+str(B[i])+" "+str(B[i])+"\n")
						f.write(str((r[i]-1.0)**3+1.0)+" "+str(B[i])+" "+str(B[i])+" "+str(B[i])+"\n")
						fMHD.write(str((r[i]-1.0)**3+1.0)+" "+str(B[i])+" "+str(nh[i])+" "+str(nhe[i])+" "+str(nc[i])+" "+str(nox[i])+" "+str(nfe[i])+" "+str(ne[i])+" "+str(Tg[i])+"\n")
				f.close()
				fMHD.close()
				

