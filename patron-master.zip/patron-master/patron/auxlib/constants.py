from numpy import pi as pi

c		= 2.998e10						# speed of light in cm/s
yr		= 3.1556952e+7						# 1 year in seconds
pc		= 3.0857e18						# parsec in cm
km		= 1e5							# km in cm
kB		= 1.3807e-16						# Boltzmann constant in ergs/K
hP    		= 6.6261e-27						# Planck constant in ergs*s
Rg		= 8.314463e7						# Ideal gas constant in g*cm**2/K/mol/s**2
q     		= 4.8e-10						# electron charge in statcoulons
R_sun		= 6.957e+10						# solar radius in cm
M_sun 		= 1.989e33						# solar mass in g

#Mass numbers
Ah		= 1.00784     						# Hydrogen
Ahe		= 4.002602						# Helium
Ac		= 12.0107						# Carbon
Aox		= 15.999						# Oxygen
Afe		= 55.845						# Ferum

#ISM abundances (mass fraction)
abunH_ISM	= 0.71							# Hydrogen
abunHe_ISM	= 0.28							# Helium
abunC_ISM	= 2e-3							# Carbon
abunOx_ISM	= 2.06e-3						# Oxygen
abunFe_ISM	= 4e-4							# Ferum

#Mean molecular weights of the ISM composition
muh_ISM		= Ah/abunH_ISM						# Hydrogen
muhe_ISM	= Ahe/abunHe_ISM					# Helium
muc_ISM		= Ac/abunC_ISM						# Carbon
muox_ISM	= Aox/abunOx_ISM					# Oxygen
mufe_ISM	= Afe/abunFe_ISM					# Ferum
mue_ISM		= 2./(1+Ah)						# electrons - assuming Zh = Ah (Z is the atomic number) and for all other elements Zi = Ai/2.
mu_ISM		= (1./muh_ISM + 1./muhe_ISM + 1./muc_ISM + 1./muox_ISM + 1./mufe_ISM + 1./mue_ISM)**(-1.)

mass_unit 	= 1.660539040e-24    
m_e   		= 9.10938356e-28					# electron mass
m_p   		= 1.6726219e-24						# proton mass 
m_he		= Ahe * mass_unit					# helium mass
m_c		= Ac * mass_unit					# carbon mass
m_ox		= Aox * mass_unit					# oxygen mass
m_fe		= Afe * mass_unit					# iron mass

p_e   		= m_e*c							# electron momentum
p_p   		= m_p*c							# proton momentum
p_he  		= m_he*c						# helium momentum
p_c   		= m_c*c							# carbon momentum
p_ox  		= m_ox*c						# oxygen momentum
p_fe  		= m_fe*c						# iron momentum


E0_p  		= m_p*c**2                                              # rest mass energy of proton
E0_e  		= m_e*c**2                                              # rest mass energy of electron
E0_he 		= m_he*c**2						# rest mass energy of helium
E0_c  		= m_c*c**2					        # rest mass energy of carbon
E0_ox 		= m_ox*c**2						# rest mass energy of oxygen
E0_fe 		= m_fe*c**2						# rest mass energy of iron
