######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  sumpro.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2010 - 2015
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v1.0.0: initial version
#v1.1.0: version control added

__version__='1.1.0'

import sys
from smooth import *

PROF=sys.argv[1]
WINL=sys.argv[2]
WINT=sys.argv[3]
winl=int(WINL)

try:
	prof=open(PROF,"r")
	alllines=prof.readlines()
	prof.close()
except IOError:
	print "No file found:", PROF

L=len(alllines)-1

x=numpy.arange(L,dtype=float)
s=numpy.arange(L,dtype=float)

for i in range(0,L):
	(X,S)=alllines[i+1].split()
	x[i]=float(X)
	s[i]=float(S)

s_new=smooth(s,winl,WINT)

ratio=s.max()/s_new.max()
s_new=s_new*ratio

PROFS=PROF+"s"
f=open(PROFS,"w")

for i in range(0,L):
	f.write(str(x[i])+" "+str(s_new[i])+"\n")

f.close()
