######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  bremss.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2014 - 2015
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v1.0.0: initial version
#v1.1.0: version control added

__version__='1.1.0'

from scipy import log
from scipy import log10
from scipy import exp
from scipy import sqrt
from scipy import pi

from scipy import interpolate
from scipy.integrate import quad
from scipy.integrate import romb
from numpy import inf as INF

from os import sys

c    = 3.0e10
Ee0  = 5.11e-4		#GeV
h    = 6.62e-27
h_ev = 4.1375e-15
m_e  = 9.11e-28
e    = 4.8e-10
Me   = m_e*c**2

alpha=1/137.

r0=2.82e-13		#cm - classical electron radius = e**2/m_e*c**2
k=8.617e-14		#GeV/K

BREMSSTYP = ""
KE2P=0.0
NORM=0.0
SPIN=0.0
ECUT=0.0
spe=0 	#!!!NEEDS TO BE FILLED FROM SIMULATED DATA

def RXJ(E):
	return (E/50000.)**0.05*KE2P*NORM*E**(-SPIN)*exp(-(E/ECUT))
	
def J_e(E):								
	return interpolate.interp1d(spe.E,spe.J, bounds_error=False, fill_value=0.0)(E)
	
def gamma(Ee):
	return Ee/Ee0

def phi_u(Ee,Eph):
	eps=Eph/Ee0
	return 4.0*log(2.0*gamma(Ee)*(gamma(Ee)/eps - 1.0)) - 2.0

def sigma(Ee,Eph):
	eps=Eph/Ee0
	return (4.0/3.0)*(alpha*r0**2/eps)*phi_u(Ee,Eph)*(1.0 - eps/gamma(Ee) + 0.75*(eps/gamma(Ee))**2)

def Eeth(Eph):
	eps=Eph/Ee0
	return 0.5*Eph*(1.0+(1.0+4.0*Ee0/Eph)**0.5)

def JJ(Ee,Eph):
	return J_e(Ee)*sigma(Ee,Eph)/Ee0

def Q(Eph,n):
	A=c*n
	Emin=Eeth(Eph)
	(I1,tmp)=quad(JJ,Emin,100.0*Emin,args=(Eph),epsabs=1.5e-5)
	(I2,tmp)=quad(JJ,100.0*Emin,1e4*Emin,args=(Eph),epsabs=1.5e-5)
	(I3,tmp)=quad(JJ,1e4*Emin,INF,args=(Eph),epsabs=1.5e-5)
	return (I1+I2+I3)*A	
	
def F_atE_vol_intBR(EN=1.0e12,n=1.0,V=0,A=1.0):
	ENGEV=EN/1.0e9
#	CONST=1.6e-3*V/(4.0*pi*A)		#in ergs/cm2 s sr, x in GeV
	CONST=V/(4.0*pi*A)			#in 1/ GeV cm2 s sr
#	return CONST*Q(ENGEV)*ENGEV**2		#in ergs/cm2 s sr, x in GeV
	return CONST*Q(ENGEV,n)			#in 1/(GeV cm2 s) sr if A=d**2 and 1/(GeV cm2 s sr) if A=pi*D**2, x in GeV


#===========deer=========================================================
def F_spe_vol_int(n=1.0,V=0,A=1.0,fname=""):
        CONST=V/(4.0*pi*A)			#in 1/ GeV cm2 s sr
	
	fbr=open(fname,"w")						#file object (opens/creates file)
	#i=-8.0
	i=-2.0
	#i=1.0
	#i = 6.1							#start of log for photon energies. the value 15.1 comes from the limitation of the relativistic electrons(gamma>=3). Recalculation of Eph via Emin (Emin=Eeth(Eph); Emin>=3Ee0) gives result for i=15.1 (9/4Ee0*1e9=1.14975e15=1e(15.1))
	#for step in range(171):
        for step in range(111):
	#for step in range(30):						#number of bins; i is increased slightly with new bin. The range is reduced from 171 to 30 due to restriction of the calculation for relativistic electrons: i_start=15.1 and i_last=18 => steps=(18-15.1)*10+1=30
		EN=10**i							#in GeV
		Fbr=CONST*Q(EN,n)						#sync flux in 1/GeV cm^2 s sr
		fbr.write(str(EN)+" "+str(Fbr)+"\n") 			#writing to file: X energy, synchrotron flux
		i=i+0.1 #0.02							#bin size in log scale
	fbr.close()
#======deer=end=====================================================

