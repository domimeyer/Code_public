######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  synchr.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2008 - 2015
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v2.2.0: uses pure B in all functions; standard synchrotron emissivity function
#v2.3.0: uses pure B in all functions; modified synchrotron emissivity function
#v2.4.0: uses pure B in all functions; emissivity function choice added (joins v2.2&v2.3)
#v2.5.0: version control added

__version__='2.5.0'

from scipy import log
from scipy import log10
from scipy import exp
from scipy import sqrt
from scipy import pi

from scipy import interpolate
from scipy.integrate import quad
from scipy.integrate import romb
from numpy import inf as INF
#from scipy.integrate import Inf as INF
#from especlog import *

from os import sys

c    = 3.0e10
Ee0  = 5.11e5
h    = 6.62e-27
h_ev = 4.1375e-15
m_e  = 9.11e-28
e    = 4.8e-10
NH   = 6.5e21

SYNEMFUNC = ""
KE2P=0.0
NORM=0.0
SPIN=0.0
ECUT=0.0
spe=0 	#!!!NEEDS TO BE FILLED FROM SIMULATED DATA

def RXJ17(E):
	return (EGEV/50000.)**0.05*1.0e-9*KE2P*NORM*EGEV**(-SPIN)*exp(-(EGEV/ECUT))

def J_e(E):								#in eV^(-1)*cm^(-3); particle spectrum; this procedure turns array with spectral records into function
	EGEV=E*1.0e-9							#X in SPE is in GeV
	return 1.0e-9*interpolate.interp1d(spe.E,spe.J, bounds_error=False, fill_value=0.0)(EGEV)
#	return 1.0e-9*5.2e-9*EGEV**(-1.965)*exp(-EGEV/0.8e4)



def gamma(Ee):
	return Ee/Ee0

def nu_c(Ee,B):									#crytical frequency
	return 4.192e6*B*gamma(Ee)**2
	
def FF(Ee,Eph,B):								#special function
	F=(Eph/h_ev)/nu_c(Ee,B)
	if   SYNEMFUNC == "STANDARD":
		return 1.8*F**(1/3.)*exp(-F)
	elif SYNEMFUNC == "GAUSSIAN":
		return 1.8*(2.0/pi)**0.5*F**(1/3.)*(1.0+1.13*F**(1/3.))**(0.67)*exp(-(3/2.)*F**(2/3.))
#		return 1.8*(2.0/pi)**0.5*F**(1/3.)*(1.0+0.65*F**(4/9.))**(0.50)*exp(-(3/2.)*F**(2/3.))

def tau(Eph):									#absorption
	eps=Eph/1000.0
	if eps<0.1:
		return 0
	else:
		return 2.0e-22*NH*eps**(-8/3.)


def ffj(E,Eph,B):								#function to integrate over particle energies (because particle spectrum and special f.  
	return J_e(E)*FF(E,Eph,B)						#are both particle energy dependent) in sync spectrum calculation step.

def Q_sync(Eph,B):								#synchrotron photon spectrum in erg^(-1)*cm^(-3)*s^(-1)
	A=((3**(1/2.))*(e**3)*B)/((h**2)*(Eph/h_ev)*m_e*c**2)			#magnetic field dependent "constant"
	(I0, tmp1) = quad(ffj, 1e7, 1e9,args=(Eph,B),epsabs=1.5e-10)
	(I1, tmp1) = quad(ffj, 1e9,1e11,args=(Eph,B),epsabs=1.5e-10)		#integral over particle energies of particle spectrum*spec.f.
	(I2, tmp2) = quad(ffj,1e11,1e13,args=(Eph,B),epsabs=1.5e-10)		#divided into 3 interval to overcome the difficulty of
	(I3, tmp3) = quad(ffj,1e13,1e15,args=(Eph,B),epsabs=1.5e-10)		#integration over large energy range. numerical recepies advice.
	return A*(I0+I1+I2+I3)

def Q_sync_int(Eph,B):								#function to integrate over photon energies to find integral luminosity
	return Q_sync(Eph,B)*Eph

def F_vol_int(a=100,b=2400,B=0.00001, V=0,A=1.0):			#volume and energy integrated flux (synchrotron only)
	CONST=(V/(4*pi*A))*(1.6e-12)**2						#erg/cm^2 s sr
	(F, tmp) = quad(Q_sync_int,a,b,B,epsabs=1.5e-5)				#integral luminosity of cm3
	return CONST*F
	
def F_spe_vol_int(B=0.00001,V=0,A=1.0,fname=""):				#volume integrated spectral flux (energy differential synchrotron flux)
	CONST=(V/(4.0*pi*A))*1.6e-3						#1/GeV cm2 s (sr)
	fsy=open(fname,"w")							#file object (opens/creates file)
	i=-9.0									#start of log for photon energies
	for step in range(171):							#number of bins; i is increased slightly with new bin
		EN=10**i							#in eV for sync
		Fsy=CONST*Q_sync(EN,B)						#sync flux in 1/GeV cm^2 s sr
		fsy.write(str(EN/1e9)+" "+str(Fsy)+"\n") 			#writing to file: X energy, synchrotron flux
		i=i+0.1 #0.02							#bin size in log scale
	fsy.close()

def F_atE_vol_intSY(EN=3000,B=0.00001,V=0,A=1.0):
#	CONST=(V/(4.0*pi*A))*(1.6e-12)**2					#erg/cm2 s sr
	CONST=(V/(4.0*pi*A))*1.6e-3						#1/GeV cm2 s sr
#	return CONST*Q_sync(EN,B)*EN**2						#erg/cm2 s sr
	return CONST*Q_sync(EN,B)						#1/GeV cm2 s sr

def F_atE_atR_SY(EN=3000,B=0.00001):	
#	CONST=(1.6e-12)**2							#erg/cm3 s
	CONST=1.6e-3								#1/GeV cm3 s
#	return CONST*Q_sync(EN,B)*EN**2						#erg/cm3 s
	return CONST*Q_sync(EN,B)						#1/GeV cm3 s






#########
def F_atE_vol_intIC(EN=1.0e12,B=0.00001,V=0,A=1.0,region="tot"):
	CONST=(V/(4.0*pi*A))*(1.6e-12)**2
	ENsy=(EN*(B*10**5))/(0.02*1.0e12)				#in eV for ic (is rescaled according to B and shifted right)
	Fsy=CONST*Q_sync(ENsy,B)*ENsy**2				#sync flux in erg/cm^2 s sr
	Fic=Fsy*0.1*(B*10**5)**(-2)					#ic flux in erg/cm^2 s sr
	return Fic

def F_atE_atR_IC(EN=1.0e12,B=0.00001):	
	CONST=(1.0)*(1.6e-12)**2					#erg*cm^(-3)*s^(-1)
	ENsy=(EN*(B*10**5))/(0.02*1.0e12)				#in eV for ic (is rescaled according to B and shifted right)
	Fsy=CONST*Q_sync(ENsy,B)*ENsy**2				#sync flux in erg/cm^2 s sr
	Fic=Fsy*0.1*(B*10**5)**(-2)					#ic flux in erg/cm^2 s sr
	return Fic

