######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  neutrinodecay.py
# Author: Guadaupe Canas Herrera <g.canas.herrera@umail.leidenuniv.nl>, Summer 2016
#
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
##################################################################################

#v1.0.0: initial version


__version__='1.0.0'

from os import sys
from os import getenv
from numpy import *
from scipy import interpolate

#These Lepton Production Matrix are from http://cherenkov.physics.iastate.edu/lepton-prod/

nu_e_data=getenv("PATRONDIR")+"/data/neutrinodecay/espectra_eneutrino.decay.p.matrix.final.data"
nu_e_bar_data=getenv("PATRONDIR")+"/data/neutrinodecay/espectra_eneutrinobar.decay.p.matrix.final.data"
nu_muon_data=getenv("PATRONDIR")+"/data/neutrinodecay/espectra_muonneutrino.decay.p.matrix.final.data"
nu_muon_bar_data=getenv("PATRONDIR")+"/data/neutrinodecay/espectra_muonneutrinobar.decay.p.matrix.final.data"

#These is the cross-section --> indicates ratio

cdata=getenv("PATRONDIR")+"/data/piondecay/cdata.dat"

#Save into variables and catch errors in case they may pop up
#Set up delimiter in files (no white spaces)

delimiter=374*[15]


try:
    nu_e_matr=genfromtxt(nu_e_data, delimiter=delimiter).reshape(201,374)
except IOError:
    print "No file found:",nu_e_data

try:
    nu_e_bar_matr=genfromtxt(nu_e_bar_data, delimiter=delimiter).reshape(201,374)
except IOError:
    print "No file found:",nu_e_bar_data

try:
    nu_muon_matr=genfromtxt(nu_muon_data, delimiter=delimiter).reshape(201,374)
except IOError:
    print "No file found:",nu_muon_data

try:
    nu_muon_bar_matr=genfromtxt(nu_muon_bar_data, delimiter=delimiter).reshape(201,374)
except IOError:
    print "No file found:",nu_muon_bar_data

try:
    cmatr=fromfile(cdata, sep=' ', count=-1, dtype=float)	#.reshape(201,374)
except IOError:
    print "No file found:",cdata


neutrino_e_matr=nu_e_bar_matr+nu_e_matr
neutrino_muon_matr=nu_muon_matr+nu_muon_bar_matr


pi=3.1415926
c=2.998e10
m=1.673e-24
p=m*c

NORM=0.0
SPIN=0.0
ECUT=0.0
spe=0

def IC443P(P):
	b=0.1
	s1=2.36
	s2=3.1
	Pbr=239.0
	N0=1.4e-7
	J=N0*P**(-s1)*(1.0+(P/Pbr)**((s2-s1)/b))**(-b)
	return J

def IC443E(E):
	P=sqrt(((E/624.0+m*c**2)**2)/(m**2*c**4)-1.0)
	N=IC443P(P)/p
	return N/(624.0*((P*p*c**2)/sqrt(P**2*p**2*c**2 + m**2*c**4)))

def GJ(E):
	return 0

def RXJ17(E):
#	return NORM*(E+1.0)**(-SPIN)*exp(-(E/ECUT))
	return (E/50000.)**0.05*NORM*(E+0.938)*(E**2+1.88*E)**(-0.5*(SPIN+1.0))*exp(-(E/ECUT))


#particle spectrum in 1/(GeV cm**3) 
def J(E):
	return interpolate.interp1d(spe.E,spe.J, bounds_error=False, fill_value=0.0)(E)
#	return 4.0*pi*2.2*(E+1.0)**(-2.75)/c						#galactic CR spectrum E in GeV
#	return IC443P(E+1.0)


#################################################################################
cmatr=cmatr*1.0e-27			#cross-section vector
ep=arange(374,dtype=float)		#energy of protons in GeV
for i in range(0,374):
	ep[i]=1.24*1.05**i

dep=0.0488*ep
betac=(3.0e10)*(1.0 - 0.880354/(ep**2))**(1/2.)
c=3.0e10
eph=arange(201,dtype=float)			#energy of photons in GeV

e_pions=ep
e_muons=ep
e_neutrinos=ep
X=0


for i in range(0,201):
	eph[i]=0.01*(10.0**(10.0*(0.5+i)/201.0))

def FI_neutrino_e():					#emissivity in 1/(GeV s cm**3) for number density 1/cm**3
    nprot=J(ep)
    return (nprot*dep*betac*cmatr*neutrino_e_matr).sum(1)

def FI_neutrino_mu():					#emissivity in 1/(GeV s cm**3) for number density 1/cm**3
    nprot=J(ep)
    return (nprot*dep*betac*cmatr*neutrino_muon_matr).sum(1)

def J_pion_theo(E):					#emissivity in 1/(GeV cm**3) for number density 1/cm**3
    nprot=J(ep)
    pions_matr=0
    for energy_proton in ep:
        #X_1=e_pions/energy_proton
	X_1=where(e_pions/energy_proton>1, 1, e_pions/energy_proton)

	a_prime=(1.-X_1)
	a=1.22*pow(a_prime, 3.5)	
	b=0.98*exp(-18.*X_1)
	d=(1. + 0.4/(e_pions-0.14))
	
	
	
	#print b
        pions_matr_element= (1./X_1)*(a+b)*(1./d)*(1./energy_proton)

	pions_matr_element=interpolate.interp1d(X_1*energy_proton, pions_matr_element, bounds_error=False, fill_value=0)(ep)

        pions_matr=pions_matr+pions_matr_element

	#max_number=max(pions_matr_element)
	#print energy_proton, pions_matr_element.sum() 
	#print pions_matr
	#print 'here'
    
    return (nprot*pions_matr*dep)


def J_muon_theo(E):#emissivity in 1/(GeV cm**3) for number density 1/cm**3
    npion=J_pion_theo(ep)
    muon_matr=0
    m_muon=0.105658369 #in GeV
    m_pion=0.13957018 #in GeV
    mass_constant=(m_muon/m_pion)**2
    for energy_pions in e_pions:
        X_2=where(e_muons/energy_pions>1, 1, e_muons/energy_pions) 
	#X_2=e_pions/energy_muons
        heaviside=X_2-mass_constant
	#print heaviside
        muon_matr_element= 2/(1.-mass_constant)*piecewise(heaviside, [heaviside<0, heaviside>=0], [0, 1])*(1/energy_pions)
	
	#print max((X_2)*(energy_pions))
	#print min((X_2)*(energy_pions))
	#print max(muon_matr_element)
	#print min(muon_matr_element)
	#print max(ep)
	#print min(ep)

	muon_matr_element=interpolate.interp1d(X_2*energy_pions, muon_matr_element, bounds_error=False, fill_value=0)(ep)

        muon_matr=muon_matr+muon_matr_element
	#print energy_pions, muon_matr_element.sum() 
 
    return (npion*muon_matr*dep)

def FI_neutrino_m_1_theo():#emissivity in 1/(GeV s cm**3) for number density 1/cm**3
    npion=J_pion_theo(ep)
    neutrino_matr=0
    m_muon=0.105658369 #in GeV
    m_pion=0.13957018 #in GeV
    mass_constant=(m_muon/m_pion)**2
    for energy_pions in e_pions:
        X_2=where(e_muons/energy_pions>1, 1, e_muons/energy_pions)
	#X_prime=X_2
	X_prime=(1-X_2)

	#print X_prime
        heaviside=X_prime-mass_constant
	#print heaviside
        neutrino_matr_element= 2/(1-mass_constant)*piecewise(heaviside, [heaviside<0, heaviside>=0], [0, 1])*(-1/energy_pions)

	#print (energy_pions-e_muons)
	
	x_axis=(energy_pions-e_muons)*X_prime
	
	#print min(X_prime)
	#print max(X_2)

	#print max((X_prime)*(energy_pions))
	#print min((X_prime)*(energy_pions))
	#print max(neutrino_matr_element)
	#print min(neutrino_matr_element)
	#print max(ep)
	#print min(ep)	

	#neutrino_matr_element=interpolate.interp1d(x_axis, neutrino_matr_element, bounds_error=False, fill_value=0)(X_2)
	neutrino_matr_element=interpolate.interp1d(X_2*energy_pions, neutrino_matr_element, bounds_error=False, fill_value=0)(ep)

	#print neutrino_matr_element

        neutrino_matr=neutrino_matr+neutrino_matr_element
    return (npion*c*neutrino_matr*cmatr*dep)


def FI_neutrino_m_2_theo():#emissivity in 1/(GeV s cm**3) for number density 1/cm**3
    nmuon=J_muon_theo(ep)
    neutrino_m_matr=0
    
    for energy_muons in e_muons:
        X_3=where(e_neutrinos/energy_muons>1., 1., e_neutrinos/energy_muons) 
        neutrino_m_matr_element= 4.*(5./3.-3*X_3**2+4./3.*X_3**3)*(1./energy_muons)
	#print len(neutrino_m_matr_element)
	#neutrino_m_matr_element= 4*(5/3-3*X_3**2+4/3*X_3**3)

	neutrino_m_matr_element=interpolate.interp1d(X_3*energy_muons, neutrino_m_matr_element, bounds_error=False, fill_value=0)(ep)

        neutrino_m_matr=neutrino_m_matr+neutrino_m_matr_element

	#print '\n\n\n'
    	#print nmuon
	#print len(dep*nmuon*c*neutrino_m_matr*cmatr)

    return (nmuon*c*neutrino_m_matr*cmatr*dep)




def FI_neutrino_e_theo():	#emissivity in 1/(GeV s cm**3) for number density 1/cm**3
    nmuon=J_muon_theo(ep)
    neutrino_e_matr=0
    
    for energy_muons in e_muons:
        X_3=where(e_neutrinos/energy_muons>1, 1, e_neutrinos/energy_muons) 
        neutrino_e_matr_element= 4.*(2.-6.*X_3**2.+4.*X_3**3)*(1./energy_muons)
	#neutrino_e_matr_element= 4*(2-6*X_3**2+4*X_3**3)

	neutrino_e_matr_element=interpolate.interp1d(X_3*energy_muons, neutrino_e_matr_element, bounds_error=False, fill_value=0)(ep)

        neutrino_e_matr=neutrino_e_matr+neutrino_e_matr_element
	X=X_3
    
    return (nmuon*c*neutrino_e_matr*cmatr*dep)



##################################################################################

#gspec=arange(201,dtype=float)
#for i in range(0,201):
#	gspec[i]=nism*(gmatr[i]*nprot*dep*betac*cmatr).sum()

def F_spe_vol_int_neutrino(n=1,V=0,A=1.0,fname=""):
    CONST=V/(4.0*pi*A) #in 1/ GeV cm2 s sr, x in GeV
    F_neutrino_e=n*CONST*FI_neutrino_e()
    F_neutrino_mu=n*CONST*FI_neutrino_mu()
    f=open(fname,"w")
    for i in range(0,201):
        f.write(str(eph[i])+" "+str(F_neutrino_e[i])+" "+str(F_neutrino_mu[i])+"\n")
    f.close()

#Theoretical Neutrino Spectra (not from Monte Carlo Simulation)

def F_spe_vol_int_neutrino_theo(n=1,V=0,A=1.0,fname=""):
    CONST=V/(4.0*pi*A) #in 1/ GeV cm2 s sr, x in GeV
    F_prot=J(ep)
    F_neutrino_e=n*CONST*FI_neutrino_e_theo()
    F_neutrino_mu_1=n*CONST*FI_neutrino_m_1_theo()
    F_neutrino_mu_2=n*CONST*FI_neutrino_m_2_theo()
    f=open(fname,"w")
    #print len(F_neutrino_e)
    for i in range(0,374):
        f.write(str(ep[i])+" "+str(F_neutrino_e[i])+" "+str(F_neutrino_mu_1[i])+" "+str(F_neutrino_mu_2[i])+" "+str(F_prot[i])+"\n")
    f.close()

def F_atE_vol_intPD(EN=1.0e12,n=1,V=0,A=1.0):
	ENGEV=EN/1.0e9
	gspec=FI_g()
	FatE=interpolate.interp1d(eph,gspec,bounds_error=False, fill_value=0.0)(ENGEV)
#	CONST=1.6e-3*V/(4.0*pi*A)		#in ergs/cm2 s sr, x in GeV
	CONST=V/(4.0*pi*A)			#in 1/ GeV cm2 s sr, x in GeV
#	return n*CONST*FatE*ENGEV**2		#in ergs/cm2 s sr, x in GeV
	return n*CONST*FatE			#in 1/(GeV cm2 s) if A=d**2 and 1/(GeV cm2 s sr) if A=pi*R**2, x in GeV

def F_atE_atR_PD(EN=1.0e12,n=1):
	ENGEV=EN/1.0e9
#	CONST=1.6e-3
	gspec=FI_g()
	FatE=interpolate.interp1d(eph,gspec,bounds_error=False, fill_value=0.0)(ENGEV)
#	return n*CONST*FatE*ENGEV**2
	return n*FatE				#in 1/ GeV cm**3 s
	
