######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  incomp.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2012 - 2015
#         Martin Pohl, 2021  
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v1.0.0: initial version for arbitrary bkg field with full integration
#v1.0.1: minor changes
#v1.3.0: Replacement of grey body with three delta functionals at kT, 3 kT, and 5 kT
#       

from scipy import log
from scipy import log10
from scipy import exp
from scipy import sqrt
from scipy import pi

from scipy import interpolate
from scipy.integrate import quad
from scipy.integrate import romb
from numpy import Inf as INF

from os import sys

c = 3.0e10
Ee0 = 5.11e-4		#GeV
h = 6.62e-27
h_ev = 4.1375e-15
m_e = 9.11e-28
e = 4.8e-10
Me=m_e*c**2

r0=2.82e-13		#cm - classical electron radius = e**2/m_e*c**2
k=8.617e-14		#GeV/K

#CMB
global Tc #=2.7			#K		Temperature of thermal photon field
#U=2.6e-10		#GeV/cm^3    Energy density of thermal photon field
global Uc #=setpar.ucmb		#2.6e-6

#Dust
global Td #=1.4e2		#K		Temperature of thermal photon field
#U=1.0e-9		#GeV/cm^3    Energy density of thermal photon field
global Ud #=setpar.udust	#0.0

#Starlight
global Ts #=1.e4		#K		Temperature of thermal photon field
#U=1.e-9		#GeV/cm^3    Energy density of thermal photon field
global Us #=setpar.ustarlight 	#0.0

#T=Tc

# photon energy in GeV
def Eta_c():
	return k*Tc
def Etb_c():
	return 3.*Eta_c()
def Etc_c():
	return 5.*Eta_c()
def Eta_d():
	return k*Td
def Etb_d():
	return 3.*Eta_d()
def Etc_d():
	return 5.*Eta_d()
def Eta_s():
	return k*Ts
def Etb_s():
	return 3.*Eta_s()
def Etc_s():
	return 5.*Eta_s()

# weights of delta functionals in n(et)/et
def na_c():
	return 0.097*Uc/Eta_c()**2
def nb_c():
	return 0.68*Uc/Etb_c()**2
def nc_c():
	return 0.223*Uc/Etc_c()**2
def na_d():
	return 0.097*Ud/Eta_d()**2
def nb_d():
	return 0.68*Ud/Etb_d()**2
def nc_d():
	return 0.223*Ud/Etc_d()**2
def na_s():
	return 0.097*Us/Eta_s()**2
def nb_s():
	return 0.68*Us/Etb_s()**2
def nc_s():
	return 0.223*Us/Etc_s()**2

KE2P=0.0
NORM=0.0
SPIN=0.0
ECUT=0.0
spe=0 	#!!!NEEDS TO BE FILLED FROM SIMULATED DATA

def RXJ17(E):
	return (E/50000.)**0.05*KE2P*NORM*E**(-SPIN)*exp(-(E/ECUT))
	
def J_e(E):								
	return interpolate.interp1d(spe.E,spe.J, bounds_error=False, fill_value=0.0)(E)
	
def gamma(Ee):
	return Ee/Ee0

def Ga(Ee,Eta):
	return 4.0*Eta*Ee/(Ee0)**2

def Gb(Ee,Etb):
	return 4.0*Etb*Ee/(Ee0)**2

def Gc(Ee,Etc):
	return 4.0*Etc*Ee/(Ee0)**2

def qa(Ee,Eta,Eph):
	return Eph/(Ga(Ee,Eta)*(Ee-Eph))

def qb(Ee,Etb,Eph):
	return Eph/(Gb(Ee,Etb)*(Ee-Eph))

def qc(Ee,Etc,Eph):
	return Eph/(Gc(Ee,Etc)*(Ee-Eph))

def Gq(Ee,Eph):
	return Eph/(Ee-Eph)

def Eetha(Eta,Eph):
	return 0.5*Eph*(1.0+(1.0+Ee0**2/(Eta*Eph))**0.5)

def Eethb(Etb,Eph):
	return 0.5*Eph*(1.0+(1.0+Ee0**2/(Etb*Eph))**0.5)

def Eethc(Etc,Eph):
	return 0.5*Eph*(1.0+(1.0+Ee0**2/(Etc*Eph))**0.5)


def Fca(Ee,Eta,Eph):
	return 2.0*qa(Ee,Eta,Eph)*log(qa(Ee,Eta,Eph)) + (1.0+2.0*qa(Ee,Eta,Eph))*(1.0-qa(Ee,Eta,Eph)) + 0.5*Gq(Ee,Eph)**2*(1.0-qa(Ee,Eta,Eph))/(1.0+Gq(Ee,Eph))

def Fcb(Ee,Etb,Eph):
	return 2.0*qb(Ee,Etb,Eph)*log(qb(Ee,Etb,Eph)) + (1.0+2.0*qb(Ee,Etb,Eph))*(1.0-qb(Ee,Etb,Eph)) + 0.5*Gq(Ee,Eph)**2*(1.0-qb(Ee,Etb,Eph))/(1.0+Gq(Ee,Eph))

def Fcc(Ee,Etc,Eph):
	return 2.0*qc(Ee,Etc,Eph)*log(qc(Ee,Etc,Eph)) + (1.0+2.0*qc(Ee,Etc,Eph))*(1.0-qc(Ee,Etc,Eph)) + 0.5*Gq(Ee,Eph)**2*(1.0-qc(Ee,Etc,Eph))/(1.0+Gq(Ee,Eph))

def JJa(Ee,Eta,Eph):
	return J_e(Ee)*Ee**(-2)*Fca(Ee,Eta,Eph)

def JJb(Ee,Etb,Eph):
	return J_e(Ee)*Ee**(-2)*Fcb(Ee,Etb,Eph)

def JJc(Ee,Etc,Eph):
	return J_e(Ee)*Ee**(-2)*Fcc(Ee,Etc,Eph)

def Q(Eph,target):#
	if target=="CMB":
		Eta = Eta_c()
		Etb = Etb_c()
		Etc = Etc_c()
		na  = na_c()
		nb  = nb_c()
		nc  = nc_c()
	elif target=="dust":
		Eta = Eta_d()
		Etb = Etb_d()
		Etc = Etc_d()
		na  = na_d()
		nb  = nb_d()
		nc  = nc_d()
	elif target=="starlight":
		Eta = Eta_s()
		Etb = Etb_s()
		Etc = Etc_s()
		na  = na_s()
		nb  = nb_s()
		nc  = nc_s()
	A=2.0*pi*c*r0**2*Ee0**2
	Emina=Eetha(Eta,Eph)
	(I1,tmp)=quad(JJa,Emina,10.*Emina,args=(Eta,Eph),epsabs=1.5e-5)
	Eminb=Eethb(Etb,Eph)
	(I2,tmp)=quad(JJb,Eminb,10.*Eminb,args=(Etb,Eph),epsabs=1.5e-5)
	Eminc=Eethc(Etc,Eph)
	(I3,tmp)=quad(JJc,Eminc,10.*Eminc,args=(Etc,Eph),epsabs=1.5e-5)
	return A*(na*I1+nb*I2+nc*I3)



def F_spe_vol_int(V=0,A=1.0,fname=""):
	CONST=V/(4.0*pi*A)			#in 1/ GeV cm2 s sr, x in GeV
	f=open(fname,"w")			#file object (opens/creates file)
	i=5.0					#start of log for photon energies
	for step in range(101):			#number of bins; i is increased slightly with new bin
		E=10**i	
		ENGEV=E/1.0e9
		Fc=0
		Fd=0
		Fs=0
		if Uc != 0.0:	
			Fc=CONST*Q(ENGEV,"CMB")
		if Ud != 0.0:	
			Fd=CONST*Q(ENGEV,"dust")
		if Us != 0.0:	
			Fs=CONST*Q(ENGEV,"starlight")
		F=Fc+Fd+Fs	
		f.write(str(ENGEV)+" "+str(F)+"\n")
		i=i+0.1
	f.close()

def F_atE_vol_intIC(EN=1.0e12,V=0,A=1.0):
	ENGEV=EN/1.0e9
#	CONST=1.6e-3*V/(4.0*pi*A)		#in ergs/cm2 s sr, x in GeV
	CONST=V/(4.0*pi*A)			#in 1/ GeV cm2 s sr, x in GeV
#	return CONST*Q(ENGEV)*ENGEV**2		#in ergs/cm2 s sr, x in GeV
	Qc=0
	Qd=0
	Qs=0
	if Uc !=0.0:	
		Qc=Q(ENGEV,"CMB")
	if Ud != 0.0:	
		Qd=Q(ENGEV,"dust")
	if Us != 0.0:	
		Qs=Q(ENGEV,"starlight")
	Qt=Qc+Qd+Qs
	return CONST*Qt			#in 1/ GeV cm2 s sr, x in GeV

def F_atE_atR_IC(EN=1.0e12):
	ENGEV=EN/1.0e9
	Qc=0
	Qd=0
	Qs=0
	if Uc !=0.0:
		Qc=Q(ENGEV,"CMB")
	if Ud != 0.0:	
		Qd=Q(ENGEV,"dust")
	if Us != 0.0:	
		Qs=Q(ENGEV,"starlight")
	Qt=Qc+Qd+Qs
	return Qt

#print F_atE_atR_IC(1.0e12)


#check func:
#def nFn(fname):
#	fic=open(fname,"w")
#	i=3.0
#	for step in range(121):
#		EN=10**i
#		Fic=incom.F_atE_vol_intIC(EN,V=1e58,A=1e38)
#		fic.write(str(EN)+" "+str(Fic)+"\n")
#		i=i+0.1
#		print "#####POINT ",(i-3.0)/0.1,"IN SPE IS DONE!#####"
#	fic.close()


