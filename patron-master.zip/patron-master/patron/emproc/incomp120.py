######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  incomp.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2012 - 2015
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v1.0.0: initial version for arbitrary bkg field with full integration
#v1.0.1: minor changes
#v1.1.0: simplified to be used just with CMB
#v1.1.1: minor changes
#v1.2.0: version control added

__version__='1.2.0'

from scipy import log
from scipy import log10
from scipy import exp
from scipy import sqrt
from scipy import pi

from scipy import interpolate
from scipy.integrate import quad
from scipy.integrate import romb
from numpy import Inf as INF

from os import sys

c    = 3.0e10
Ee0  = 5.11e-4	#GeV
h    = 6.62e-27
h_ev = 4.1375e-15
m_e  = 9.11e-28
e    = 4.8e-10
Me   = m_e*c**2

r0=2.82e-13	#cm - classical electron radius = e**2/m_e*c**2
k=8.617e-14	#GeV/K

#CMB
Et=6.62e-13	#CMB photon energy in GeV
T=2.7		#K
U=2.6e-10	#GeV/cm^3

#DO NOT USE DUST STARLIGHT! USE INVCOMP100 where integration over radiation spectrum is performed
#Dust
#Et=1.24e-11
#T=1.364e2
#U=2.3e-10	#GeV/cm^3

#Starlight
#Et=1.24e-9
#T=1.364e4	#K
#U=1e-8		#GeV/cm^3


spe=0 	#!!!NEEDS TO BE FILLED FROM SIMULATED DATA

NORM=0.0

def J_e(E):								
	return interpolate.interp1d(spe.E,spe.J, bounds_error=False, fill_value=0.0)(E)

def gamma(Ee):
	return Ee/Ee0

def G(Ee,Et):
	return 4.0*Et*Ee/(Ee0)**2

def q(Ee,Et,Eph):
	return Eph/(G(Ee,Et)*(Ee-Eph))

def Gq(Ee,Eph):
	return Eph/(Ee-Eph)

def Eeth(Et,Eph):
	return 0.5*Eph*(1.0+(1.0+Ee0**2/(Et*Eph))**0.5)

def n(Et):
	return (15.0*U/(pi*k*T)**4)*(Et**2/(exp(Et/(k*T))-1.0))

def Fc(Ee,Et,Eph):
	return 2.0*q(Ee,Et,Eph)*log(q(Ee,Et,Eph)) + (1.0+2.0*q(Ee,Et,Eph))*(1.0-q(Ee,Et,Eph)) + 0.5*Gq(Ee,Eph)**2*(1.0-q(Ee,Et,Eph))/(1.0+Gq(Ee,Eph))

def JJ(Ee,Et,Eph):
	return J_e(Ee)*Ee**(-2)*Fc(Ee,Et,Eph)

def Q(Eph):
	A=0.475*5.0*U*c*r0**2*Ee0**2/(pi*(k*T)**2)
	Emin=Eeth(Et,Eph)
	(I1,tmp)=quad(JJ,Emin,100.0*Emin,args=(Et,Eph),epsabs=1.5e-5)
	(I2,tmp)=quad(JJ,100.0*Emin,1e4*Emin,args=(Et,Eph),epsabs=1.5e-5)
	(I3,tmp)=quad(JJ,1e4*Emin,INF,args=(Et,Eph),epsabs=1.5e-5)
	return (I1+I2+I3)*A

def F_spe_vol_int(V=0,A=1.0,fname=""):
	CONST=V/(4.0*pi*A)			#in 1/ GeV cm2 s sr, x in GeV
	f=open(fname,"w")			#file object (opens/creates file)
	i=5.0					#start of log for photon energies
	for step in range(101):			#number of bins; i is increased slightly with new bin
		E=10**i	
		ENGEV=E/1.0e9
		F=CONST*Q(ENGEV)
		f.write(str(ENGEV)+" "+str(F)+"\n")
		i=i+0.1
	f.close()

def F_atE_vol_intIC(EN=1.0e12,V=0,A=1.0):
	ENGEV=EN/1.0e9
#	CONST=1.6e-3*V/(4.0*pi*A)		#in ergs/cm2 s sr, x in GeV
	CONST=V/(4.0*pi*A)			#in 1/ GeV cm2 s sr
#	return CONST*Q(ENGEV)*ENGEV**2		#in ergs/cm2 s sr, x in GeV
	return CONST*Q(ENGEV)			#in 1/(GeV cm2 s) sr if A=d**2 and 1/(GeV cm2 s sr) if A=pi*D**2, x in GeV

def F_atE_atR_IC(EN=1.0e12):
	ENGEV=EN/1.0e9
#	CONST=1.6e-3
#	return CONST*Q(ENGEV)*ENGEV**2
	return Q(ENGEV)				##in 1/ GeV cm3 s

#print F_atE_atR_IC(1.0e12)
