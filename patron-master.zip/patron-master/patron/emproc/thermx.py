#\cond
######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  thermx.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2007 - 2015
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################
#\endcond

##@package patron.emproc.thermx
#Subroutine containing all functions for the calculation of thermal X-ray emission
#
#The functions are based on eqs 14 and 15 in Hnatyk, Petruk (1999) (https://ui.adsabs.harvard.edu/abs/1999A%26A...344..295H/abstract).

#v1.0.0: initial version
#v1.1.0: version control added

__version__='1.1.0'

from numpy import *

NH=2.22e22

def tau(Eph):									#absorption
	eps=Eph	#/1000.0
	if eps<0.1:
		return 0
	else:
		return 2.0e-22*NH*eps**(-8/3.)

pi=3.1415926
def F_atE_vol_intTH(EN=1.0e3,ne=1.0,T=1.0e7,V=0,D=1.0):
#	CONST=V/(4.0*pi*D**2)		#ergs/cm^2 s sr
	CONST=0.625e15*V/(4.0*pi*D**2)	#1/GeV cm^2 s
	TMKEL=T/1.0e6
	ENKEV=EN/1.0e3
	G=27.83*(TMKEL + 0.65)**(-1.33) + 0.35*ENKEV**(-0.34)*TMKEL**(0.422)
	F=1.652e-23*ne**2*G*TMKEL**(-0.5)*exp(-11.59*(ENKEV/TMKEL))
#	return CONST*F*ENKEV		#ergs/cm^2 s sr
	return CONST*F/ENKEV		#1/GeV cm^2 s sr
	

def F_atE_atR_TH(EN=1.0e3,ne=1.0,T=1.0e7):
	CONST=0.625e15			#1/GeV cm^3 s
	TMKEL=T/1.0e6	#MUST BE 1.0e6!!!
	ENKEV=EN/1.0e3
	G=27.83*(TMKEL + 0.65)**(-1.33) + 0.35*ENKEV**(-0.34)*TMKEL**(0.422)
	F=1.652e-23*ne**2*G*TMKEL**(-0.5)*exp(-11.59*(ENKEV/TMKEL))	#*exp(-tau(ENKEV))	#last exp is absorption
#	return F*ENKEV			#ergs/cm^3 s
	return CONST*F/ENKEV		#1/GeV cm^3 s 

def L_01to24(T):
	TMKEL=T/1.0e6
	return 10**(-21.8)*TMKEL**(-0.63)*exp(-1.4/TMKEL)

def L_Gth24(T):
	TMKEL=T/1.0e6
	return 10**(-24.4)*TMKEL**(0.8)

def L_Gth45(T):
	TMKEL=T/1.0e6
	return 10**(-22.42)*exp(-39.5/TMKEL**(0.77))

def L_24to45(T):
	return L_Gth24(T)-L_Gth45(T)


