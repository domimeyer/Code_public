######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  pdecay.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2010 - 2015
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v1.0.0: initial version
#v1.0.1: some re-arrangements to data file paths
#v1.1.0: version control added

__version__='1.1.0'

from os import sys
from os import getenv
from numpy import *
from scipy import interpolate
from patron.auxlib.constants import *


target = []
gmatr = []
cmatr = []



global SP


def m(cr):
        if	cr == "PR":
                return m_p
	elif	cr == "HE": 
                return m_he
	elif	cr == "C": 
                return m_c
 	elif	cr == "OX": 
                return m_ox
 	elif	cr == "FE": 
                return m_fe


NORM=0.0
SPIN=0.0
ECUT=0.0
spe=0

def en_conversion(ep,cr):
        Ek = m(cr)/mass_unit * (ep - 624.151*mass_unit * c**2) #conversion from total energy per nucleon (used for matrices) to kinetic energy per nucleus (used in the RATPaC)
        return Ek


#particle spectrum in 1/(GeV cm**3) 
def J(E):
	return interpolate.interp1d(spe.E,spe.J, bounds_error=False, fill_value=0.0)(E)
#	return 4.0*pi*2.2*(E+1.0)**(-2.75)/c						#galactic CR spectrum E in GeV
#	return IC443P(E+1.0)

#################################################################################
#                  Energy binning
#################################################################################
ep=arange(374,dtype=float)			#energy of a projectile CR in GeV (total energy per nucleon)
for i in range(0,374):
	ep[i]=1.24*1.05**i

dep=0.0488*ep
eph=arange(201,dtype=float)			#energy of photons in GeV
for i in range(0,201):
	eph[i]=0.01*(10.0**(10.0*(0.5+i)/201.0))

##################################################################################


def betac(cr):
#	return c*(1.0 - (m(cr)*c**2)**2/(ep**2))**(1/2.)
	return c*(1.0 - (mass_unit*c**2)**2/(ep**2))**(1/2.)


def FI_g(cr,i):					#emissivity in 1/(GeV s cm**3) for number density 1/cm**3

        ek = en_conversion(ep, cr)

	# nprot=J(ep)
	# return (nprot*dep*betac(cr)*cmatr[i]*gmatr[i]).sum(1)

        nprot= m(cr)/mass_unit * J(ek)
	return (nprot*dep*betac(cr)*cmatr[i]*gmatr[i]).sum(1)
        
	
##################################################################################


#def F_spe_vol_int(n=1,V=0,A=1.0,fname="",cr=""):
def F_spe_vol_int(n,V,A,fname,cr):
        #	CONST=1.6e-3*V/(4.0*pi*A)		#in ergs/cm2 s sr, x in GeV
	CONST=V/(4.0*pi*A)			#in 1/ GeV cm2 s sr, x in GeV
		
        F = []
	for i,tar in enumerate(target):
                gspec = FI_g(cr,i)
                F.append(CONST*n[i]*gspec)
                #F=n*CONST*(FI_g(cr,0) + (muh()/muhe())*FI_g(cr,1) + (muh()/muc())*FI_g(cr,2) +(muh()/muox())*FI_g(cr,3))
        Fspe = asarray(F).sum(0)

  	f=open(fname,"w")
        for i in range(0,201):
		f.write(str(eph[i])+" "+str(Fspe[i])+"\n")
	f.close()

def F_atE_vol_intPD(EN=1.0e12,n=1,V=0,A=1.0,cr="PR"):
	ENGEV=EN/1.0e9
      	totFatE = []
	#cr = "PR"
	for i,tar in enumerate(target):	
		gspec=FI_g(cr,i)
		FatE=interpolate.interp1d(eph,gspec,bounds_error=False, fill_value=0.0)(ENGEV)
		totFatE.append(n[i]*FatE)
#	CONST=1.6e-3*V/(4.0*pi*A)		#in ergs/cm2 s sr, x in GeV
	CONST=V/(4.0*pi*A)			#in 1/ GeV cm2 s sr, x in GeV
	return asarray(totFatE).sum()			#in 1/ GeV cm**3 s
#	return n*CONST*FatE*ENGEV**2		#in ergs/cm2 s sr, x in GeV
#	return n*CONST*FatE			#in 1/(GeV cm2 s) if A=d**2 and 1/(GeV cm2 s sr) if A=pi*R**2, x in GeV

def F_atE_atR_PD(EN,cr,n):
	ENGEV=EN/1.0e9
#	CONST=1.6e-3
        totFatE = []
	for i,tar in enumerate(target):
		gspec=FI_g(cr,i)
#		FatE.append(interpolate.interp1d(eph,gspec,bounds_error=False, fill_value=0.0)(ENGEV))
		FatE = (interpolate.interp1d(eph,gspec,bounds_error=False, fill_value=0.0)(ENGEV))
                totFatE.append(n[i]*FatE)
#	return n*CONST*FatE*ENGEV**2	
#	return n*FatE[0]+(muh()/muhe())*n*FatE[1]+(muh()/muc())*n*FatE[2]+(muh()/muox())*n*FatE[3]			#in 1/ GeV cm**3 s
	return asarray(totFatE).sum()			#in 1/ GeV cm**3 s


##################################################################################
###   Some special cases #########################################################

def IC443P(P):
	b=0.1
	s1=2.36
	s2=3.1
	Pbr=239.0
	N0=1.4e-7
	J=N0*P**(-s1)*(1.0+(P/Pbr)**((s2-s1)/b))**(-b)
	return J

def IC443E(E):
        p=m_p*c
	P=sqrt(((E/624.0+m("PR")*c**2)**2)/(m("PR")**2*c**4)-1.0)
	N=IC443P(P)/p
	return N/(624.0*((P*p*c**2)/sqrt(P**2*p**2*c**2 + m("PR")**2*c**4)))

def GJ(E):
	return 0

def RXJ17(E):
#	return NORM*(E+1.0)**(-SPIN)*exp(-(E/ECUT))
	return (E/50000.)**0.05*NORM*(E+0.938)*(E**2+1.88*E)**(-0.5*(SPIN+1.0))*exp(-(E/ECUT))

	
