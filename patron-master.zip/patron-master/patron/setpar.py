######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  setpar.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2010 - 2015
# 	  Robert Brose <robert.brose@mail.de>, 2015 - 2016
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v1.0.0: setpar modules introduced
#v2.0.0: significant re-arrangement of all parameters
#v2.0.1: added new parameters to work with crspe2, and simultaneous run of two shocks
#v2.1.0: added support of snrrad, some other parameters re-arranged
#v2.2.0: added support of snrmap, some other parameters added
#v2.3.0: added support of evotru
#v2.4.0: added support of mttran
#v2.4.1: added support of analytical turbulence
#v2.4.2: added support for production of energy integrated maps
#v2.5.0: added support for SOFA and injection scaling parameters
#v2.5.1: added initialization with paramfile
#v2.6.0: added support of evotel
#v2.7.0: version control added
#v2.8.0: added support of crprof
#v2.8.1: added support for DAMP parameters
#v2.8.2: Changed for use with setup-routine
#v2.9.0: added support of evoplu
#v2.9.1: Added reggriding parameters; Radiation-output files now contain radorigin
#v2.9.2: Reading CR species parameters from the parameter file
 
__version__='2.9.2'

import os
import sys
import time
import math
import pickle
import getopt
import cProfile

from numpy import pi
from numpy import exp
from numpy import sqrt
from numpy import size
from numpy import arange
from numpy import copy
from numpy import array_split


from fipy.tools import parallel
from mpi4py import MPI

from patron.snrmod import snrmhd as snrmhd
from patron.emproc import pdecay as pdecay
from patron.snrmod.snrevo import evotru as evotru	#analytic approximations for free expansion stage Trulove & McKee
from patron.snrmod.snrevo import evocox as evocox	#analytic approximations for Sedov solutions by Cox
from patron.snrmod.snrevo import evotel as evotel	#semi-analytic solutions for (non-uniform) Sedov and transition stage Telezhinsky
from patron.snrmod.snrevo import evorob as evorob	#Toy-model Hydro-data
from patron.snrmod.snrevo import evovik as evovik	#wrap around Vikram's SNR HD data
from patron.snrmod.snrevo import evoplu as evoplu	#Python version of Pluto

from patron.auxlib import tecoef as tecoef		#transport equations' coefficients' functions

from patron.mfield import mftran as mftran		#MF transport equation module
from patron.mfield import mttran as mttran		#MT transport equation module

from patron.crmods import crtran as crtran		#CR transport equation module
from patron.crmods import crspe1 as crspe1
from patron.crmods import crspe2 as crspe2
from patron.crmods import crspe3 as crspe3
from patron.crmods import crprof as crprof

from patron.reader import mfread as mfread
from patron.reader import psread as psread
from patron.reader import mhdread as mhdread

from patron.emproc import thermx as thermx
from patron.emproc import synchr as synchr
from patron.emproc import incomp130 as incomp
from patron.emproc import pdecay as pdecay
from patron.emproc import neutrinodecay as neutrinodecay
from patron.emproc import bremss as bremss

from patron.snrmod import snrrad as snrrad
from patron.snrmod import snrmap as snrmap

from patron import solver as solver

from patron import setup as setup 

from patron.auxlib.constants import *

pc=3.08e18
yr=3.157e7

class SimParams:
	def __init__(self):
#file storing parameters of simulation:
		self.PARAMFILE = ""
#main parameter to define patron task:
		self.CALCULATE = ""    #
		
#input/output parameters:
		self.HDDATAINP = ""    # deprecated (DATAREP	--datarep)	introduced  --hddatainp
		self.HDFILEINP = ""    # 					introduced  --hdfileinp
		self.HDDATAOUT = ""    # 					introduced  --hddataout
		self.HDFILEOUT = ""    #
		
		self.MFDATAINP = ""    # deprecated (MFDAT	--magnfdata)	introduced  --mfdatainp
		self.MFFILEINP = ""    # deprecated (BFNAME)			introduced  --mffileinp
		self.MFDATAOUT = ""    # 					introduced  --mfdataout
		self.MFFILEOUT = ""    # 					introduced  --mffileout

		self.MHDDATAOUT = ""   
		self.MHDFILEOUT = ""   # 					introduced  --mhdfileout
		
		self.CRDATAINP = ""    #					introduced  --crdatainp
		self.CRFILEINP = ""    # deprecated (inFileName --read)		introduced  --crfileinp
		self.CRDATAOUT = ""    # deprecated (OUTSDIR	--outsdir)	introduced  --crdataout
		self.CRFILEOUT = ""    # deprecated (NFNAME)			introduced  --crfileout
		
		self.MTDATAINP = ""    #					introduced  --mtdatainp
		self.MTFILEINP = ""    #					introduced  --mtfileinp
		self.MTDATAOUT = ""    #					introduced  --mtdataout
		self.MTFILEOUT = ""    # deprecated (TFNAME)			introduced  --mtfileinp
		
		self.TIMESLIST = ""    # deprecated (TLST	 --tlst)	introduced  --timeslist
		self.timeslist = 0     #
		self.TIMEINOUT = ""    # deprecated (pret	 --pret)	introduced  --timeinout
		self.timeinout = 0     #
		self.timecont  = ""

		self.regrid_flag = "NO"
		self.regrid_time = 0.
		self.regrid_fact = 0.

		self.shock_finder = "default"

#magnetic field parameters:
		self.mfinitime = 0     #					introduced  --mfinitime
		self.mfofismna = 0     #					introduced  --mfofismna
                self.mfstarsurf = 0    #                                        introduced  --mfstarsurf
                self.starrad   = 0     #                                        introduced  --starrad
                self.mfatshock = 0     # deprecated (BSH	--mfstrength)	introduced  --mfatshock
		self.mfampfact = 0     # deprecated (AMP)			using  old  --mfampfact
		#self.MFAMPMODE = ""    # deprecated (AMODE)			using  old  --mfampmode
		self.MFPROFILE = ""    # deprecated (MFPRO	--magnfprof)	introduced  --mfprofile
		self.MFINTPROF = ""    #					introduced  --mfintprof
		self.mfinitcon = 0     #					introduced  --mfinitcon
		self.ALFVDRIFT = ""    # deprecated (ALFVV	--alfven)	introduced  --alfvdrift
		self.mfdampsca = 0     # 					introduced  --mfdampsca
		self.mfscabins = 0     # 					introduced  --mfscabins
		
#supernova remnant parameters:
		self.EXPLNTYPE = ""    # deprecated (SNTYPE	--sntype)	introduced  --explntype 
		self.SNSUBTYPE = ""    # deprecated (DATADIR	--datadir)	introduced  --snsubtype
		self.SHOCKTYPE = ""    # deprecated (SHOCK)			using  old  --shocktype 		
		self.WINDBNCSM = ""    #					introduced  --windbncsm
		self.windbubrad = 0    #                                        introduced  --windbubrad
                self.nhdensity = 0     #					introduced  --nhdensity
		self.expenergy = 0     #					introduced  --expenergy
		self.usesedsol = 0     # 					introduced  --usesedsol
		self.rshellpc1 = 0     # deprecated (RPC1	--rpc1)		introduced  --rshellpc1    
		self.rshellpc2 = 0     # deprecated (RPC2	--rpc2)		introduced  --rshellpc2
		self.shdensity = 0     #					introduced  --shdensity
		

		self.PLUTOFLAG = ""
		self.PLUTO_DLL  = ""	

#cosmic ray simulation parameters:
		self.CRSPECIES   = ""    # deprecated (particle	--particle)	introduced  --crspecies
		self.speciespr = ""
                self.speciesel = ""
		self.specieshe = ""
		self.speciesc = ""
		self.speciesox = ""
		self.speciesfe = ""
		self.injectpar   = 0     # 					introduced  --injectpar
		self.CR_feedback = ""
		self.downstreamfeedback = ""
		self.injsclpar   = 0     # 					introduced  --injsclpar
		self.injsclindex = 0
		self.ramptime 	 = 0	
		self.SHOCKGEOM   = ""    # deprecated (GEOMS)			using  old  --shockgeom 
		self.CRINITCON   = ""    # deprecated (CRBKG      --crbkg)	introduced  --crinitcon

#cosmic ray plotting parameters:
		self.CRSENERGY = ""    #					introduced  --crsenergy
				
#cosmic ray simulation grid parameters:
		self.rstepsnum = 0     # deprecated (nrsteps    --nrsteps)	introduced  --rstepsnum
		self.pstepsnum = 0     # deprecated (npsteps    --npsteps)	introduced  --pstepsnum
		self.rcoordmax = 0     # deprecated (rmax       --rmax)		introduced  --rcoordmax
		self.pcoordmax = 0     # deprecated (pmax       --pmax)		introduced  --pcoordmax
		
		self.rstepsnumrs=0     #
		self.rstepsnumfs=0     #
		self.rcoordmaxrs=0     #
		self.rcoordmaxfs=0     #
		
#empiric diffusion parameters:
		self.lmaxbdiff = 0     #
		self.lmingdiff = 0     #
		self.DIFFINTER = ""    #
		self.etaofbohm = 0     #					introduced  --etaofbohm
		
#empiric momentum diffusion parameters:
		self.momdifpow = 0     # 					introduced  --momdifpow
		self.momdiftau = 0     # 					introduced  --momdiftau
		self.momdiffr1 = 0     #
		self.momdiffr2 = 0     #
		self.momdifsclel = 0     #					introduced  --momdifsclel
 		self.momdifsclpr = 0     #					introduced  --momdifsclpr
		self.momdifsclhe = 0
		self.momdifsclc = 0
		self.momdifsclox = 0
		self.momdifsclfe = 0	

#magnetic turbulence parameters:
		self.MTAPPLIED = ""    #					introduced  --mtapplied
		self.MTSPECTRA = ""    #					introduced  --mtspectra
		
#magnetic turbulence simulation parameters:
		self.MTINITCON = ""    # 					introduced  --mtinitcon
		self.ENSDSTURB = ""    # 					introduced  --ensdsturb
		self.LESDSTURB = ""    # 					introduced  --lesdsturb
		self.TURBFIELD = ""    # 					introduced  --turbfield
		self.TURBAMPFACT = ""    # 					introduced  --turbampfact		
		
#magnetic turbulence simulation grid parameters:
		self.kstepsnum = 0     # deprecated (nksteps    --nksteps)	introduced  --kstepsnum
		
#radiation spectra parameters:
		self.RADIATION	= ""   # deprecated (spetyp     --spetyp)	introduced  --radiation
		self.RADOBJECT	= ""   #					introduced  --radobject
		self.RADORIGIN	= ""   #					introduced  --radorigin	so far is not used (CR file is specified in wrapper shell script) 
		self.SYNEMFUNC	= ""   #					introduced  --synemfunc
		self.STERADIAN	= ""   #					introduced  --steradian
		self.snrdistpc	= 0    # deprecated (DIST       --distance)	introduced  --snrdistpc
		self.radintres	= 0    #					introduced  --radintres
		self.rspenorm1	= 0    # deprecated (RMIN       --rmin)		introduced  --rspenorm1
		self.rspenorm2	= 0    # deprecated (RMAX       --rmax)		introduced  --rspenorm2
		self.radnormax	= 0    #					introduced  --radnormax
		self.ucmb	= 0
		self.udust	= 0
		self.ustarlight= 0		
		self.Tcmb	= 0
		self.Tdust	= 0
		self.Tstar	= 0		
		
#radiation maps parameters:
		self.CREATEMAP  = ""   #					introduced  --createmap
		self.MAPENERGY  = ""   #					introduced  --mapenergy
		self.HEMISPHER  = ""   #					introduced  --hemispher
		self.ROTMAPXYZ  = ""   #					introduced  --rotmapxyz
		self.scaleinpc  = 0    #					introduced  --scaleinpc
		self.MFCOMPDIM  = ""   #					introduced  --mfcompdim
		
		self.RPDATAOUT  = ""   # deprecated (OUTSDIR    --outsdir)	introduced  --rpdataout
		self.RPFILEOUT  = ""   # deprecated (sname      --sname)	introduced  --rpfileout

		self.Rundir     = ""

  #Abundance (mass fraction) of different components:
                self.AbundanceH  = 0
                self.AbundanceHe = 0
                self.AbundanceC  = 0
                self.AbundanceO  = 0
                self.AbundanceFe = 0


#reserved (not yet in use) parameters		
#		self.LSCMFGEOM  = ""	#orientation of the large scale magnetic field with respect to the shock normal, possible values: PAR -- parallel, OBL -- oblique, PER -- perpendicular

def SetupSimParams(simpar,inputParams):
	if parallel.procID == 0:
#		print "\n\n"
		print "-----------------------------------------------------------------------------------------"
		print "------:   Particle Acceleration Transport Radiation Object-orieNted PYthon Code   :------"
		print "-----------------------------------------------------------------------------------------"
		print "setpar: initializing parameters to run RATPaC..."
	keywords = \
	   ['paramfile=', \
	    'calculate=', \
	    'hddatainp=', 'hdfileinp=', 'hddataout=', 'hdfileout=', \
	    'mfdatainp=', 'mffileinp=', 'mfdataout=', 'mffileout=', \
	    'crdatainp=', 'crfileinp=', 'crdataout=', 'crfileout=', \
	    'mtdatainp=', 'mtfileinp=', 'mtdataout=', 'mtfileout=', \
	    'mhdfileout=', \
	    'timeslist=', 'timeinout='\
	    'explntype=', 'snsubtype=', 'shocktype=', 'windbncsm=', 'windbubrad=', 'nhdensity=', 'expenergy=', 'usesedsol=', \
	    'rshellpc1=', 'rshellpc2=', 'shdensity=', \
            'mfinitime=', 'mfofismna=', 'mfstarsurf=', 'starrad=', 'mfatshock=', 'mfampfact=', 'mfprofile=', 'mfintprof=', 'mfinitcon=', 'alfvdrift=', \
            'speciespr=', 'speciesel=', 'specieshe=', 'speciesc=', 'speciesox=', 'speciesfe=', 'injectpar=', 'injsclpar=', 'shockgeom=', 'crinitcon=', \
	    'crsenergy=', \
	    'rstepsnum=', 'pstepsnum=', 'rcoordmax=', 'pcoordmax=', 'rstepsnumrs=', 'rstepsnumfs=', 'rcoordmaxrs=', 'rcoordmaxfs=', \
	    'lmaxbdiff=', 'lmingdiff=', 'diffinter=', 'momdifpow=', 'momdiftau=', 'momdiffr1=', 'momdiffr2=',\
	    'etaofbohm=', 'mtapplied=', 'mtspectra=', 'mtinitcon=', 'kstepsnum=', \
	    'radiation=', 'radobject=', 'radorigin=', 'synemfunc=', 'steradian=', 'snrdistpc=', 'radintres=', 'rspenorm1=', 'rspenorm2=', 'radnormax=', \
	    'createmap=', 'mapenergy=', 'hemispher=', 'rotmapxyz=', 'scaleinpc=', 'mfcompdim=', \
	    'rpdataout=', 'rpfileout=', 'momdifsclel=', 'momdifsclpr=', 'momdifsclhe=', 'momdifsclc=', 'momdifsclox=', 'momdifsclfe=', 'mfdampsca=', 'mfscabins='\
            'AbundanceH=', 'AbundanceHe=','AbundanceC=','AbundanceO=','AbundanceFe='
	    ]
	    
	try: opt_arg, extrapar = getopt.getopt(inputParams,"",keywords)
	except:
		if parallel.procID == 0: print "setpar: wrong patron command line option provided!"
		sys.exit(0)
	
	for opt,arg in opt_arg:
		if   opt == "--paramfile": simpar.PARAMFILE=arg
#		elif opt == "--crspecies": simpar.CRSPECIES=arg
		elif opt == "--shocktype": simpar.SHOCKTYPE=arg
		elif opt == "--radiation": simpar.RADIATION=arg

	simpar.Rundir=simpar.PARAMFILE[0:-14]


	simpar.CALCULATE=setup.ReadXMLPar("calculate",simpar.PARAMFILE)
        simpar.speciespr=bool(int(setup.ReadXMLPar("speciespr",simpar.PARAMFILE)))
        simpar.speciesel=bool(int(setup.ReadXMLPar("speciesel",simpar.PARAMFILE)))
	simpar.specieshe=bool(int(setup.ReadXMLPar("specieshe",simpar.PARAMFILE)))
	simpar.speciesc=bool(int(setup.ReadXMLPar("speciesc",simpar.PARAMFILE)))
	simpar.speciesox=bool(int(setup.ReadXMLPar("speciesox",simpar.PARAMFILE)))
	simpar.speciesfe=bool(int(setup.ReadXMLPar("speciesfe",simpar.PARAMFILE)))
        simpar.CRSPECIES = []
        if simpar.speciespr == True: simpar.CRSPECIES.append("PR")
        if simpar.speciesel == True: simpar.CRSPECIES.append("EL")
	if simpar.specieshe == True: simpar.CRSPECIES.append("HE")
	if simpar.speciesc == True: simpar.CRSPECIES.append("C")
	if simpar.speciesox == True: simpar.CRSPECIES.append("OX")
	if simpar.speciesfe == True: simpar.CRSPECIES.append("FE")

	simpar.injectpar=float(setup.ReadXMLPar("injectpar",simpar.PARAMFILE))
	simpar.CR_feedback=bool(int(setup.ReadXMLPar("crfeedback",simpar.PARAMFILE)))
	simpar.downstreamfeedback=int(setup.ReadXMLPar("crfeedbackregion",simpar.PARAMFILE))
	simpar.injsclparpr=float(setup.ReadXMLPar("injsclparpr",simpar.PARAMFILE))
	simpar.injsclparel=float(setup.ReadXMLPar("injsclparel",simpar.PARAMFILE))
	simpar.injsclparhe=float(setup.ReadXMLPar("injsclparhe",simpar.PARAMFILE))
	simpar.injsclparc=float(setup.ReadXMLPar("injsclparc",simpar.PARAMFILE))
	simpar.injsclparox=float(setup.ReadXMLPar("injsclparox",simpar.PARAMFILE))
	simpar.injsclparfe=float(setup.ReadXMLPar("injsclparfe",simpar.PARAMFILE))
	simpar.injsclindex=float(setup.ReadXMLPar("injsclindex",simpar.PARAMFILE))
	simpar.ramptime=float(setup.ReadXMLPar("ramptime",simpar.PARAMFILE))	
	#if simpar.CRSPECIES == "PR": simpar.injsclpar=simpar.injsclparpr
	#elif simpar.CRSPECIES == "EL": simpar.injsclpar=simpar.injsclparel
	simpar.SHOCKGEOM=setup.ReadXMLPar("shockgeom",simpar.PARAMFILE)
	simpar.CRINITCON=setup.ReadXMLPar("crinitcon",simpar.PARAMFILE)
	simpar.etaofbohm=float(setup.ReadXMLPar("etaofbohm",simpar.PARAMFILE))

	simpar.TIMESLIST=simpar.Rundir+"/timeslist"
##########################sd
	simpar.TIMEINOUT=setup.ReadXMLPar("timeinout",simpar.PARAMFILE)
	if simpar.TIMEINOUT==None: simpar.TIMEINOUT=""
	simpar.timecont=setup.ReadXMLPar("timecont",simpar.PARAMFILE)

	simpar.regrid_flag = str(setup.ReadXMLPar("regrid_flag",simpar.PARAMFILE))
	simpar.regrid_time = float(setup.ReadXMLPar("regrid_time",simpar.PARAMFILE))
	simpar.regrid_fact = float(setup.ReadXMLPar("regrid_fact",simpar.PARAMFILE))

	simpar.shock_finder= str(setup.ReadXMLPar("shock_finder",simpar.PARAMFILE))

	#simpar.HDDATAINP=os.environ["PATRONDIR"]+"/data/snrmhd/hd/"+setup.ReadXMLPar("hdsimname",simpar.PARAMFILE) #Rundir+"/HDPROFILES"#
	simpar.HDFILEINP=setup.ReadXMLPar("hdfileinp",simpar.PARAMFILE)
	simpar.HDDATAOUT=simpar.Rundir+"/HDPROFILES"
	simpar.HDFILEOUT=setup.ReadXMLPar("hdfileout",simpar.PARAMFILE)
	simpar.HDSIMUINP=os.environ["PATRONDIR"]+"/data/snrmhd/hd/"+setup.ReadXMLPar("hdsimname",simpar.PARAMFILE)

	if simpar.CALCULATE == "RADSPE" or simpar.CALCULATE == "RADSPEALL"or\
	   simpar.CALCULATE == "RADMAP" or simpar.CALCULATE == "RADM3D"   or\
	   simpar.CALCULATE == "MAPINT" or simpar.CALCULATE == "MAPSPE" :# or simpar.CALCULATE == "CRSPE0": 
		simpar.HDDATAINP=simpar.HDDATAOUT
		simpar.HDFILEINP=simpar.HDFILEOUT
	else:	
		simpar.HDDATAINP=os.environ["PATRONDIR"]+"/data/snrmhd/hd/"+setup.ReadXMLPar("hdsimname",simpar.PARAMFILE) #Rundir+"/HDPROFILES"#		
		simpar.HDFILEINP=setup.ReadXMLPar("hdfileinp",simpar.PARAMFILE)

	#simpar.MFDATAINP=os.environ["PATRONDIR"]+"/data/snrmhd/mf/"+setup.ReadXMLPar("hdsimname",simpar.PARAMFILE)+"/"+setup.ReadXMLPar("mfmodel",simpar.PARAMFILE)
	simpar.MFDATAOUT=simpar.Rundir+"/MFPROFILES"
	simpar.MFFILEOUT=setup.ReadXMLPar("mffileout",simpar.PARAMFILE)
	if simpar.CALCULATE == "RADSPE" or simpar.CALCULATE == "RADSPEALL"or\
	   simpar.CALCULATE == "RADMAP" or simpar.CALCULATE == "RADM3D"   or\
	   simpar.CALCULATE == "MAPINT" or simpar.CALCULATE == "MAPSPE" :# or simpar.CALCULATE == "CRSPE0": 
		simpar.MFDATAINP=simpar.MFDATAOUT=simpar.Rundir+"/MFPROFILES"
		simpar.MFFILEINP=simpar.MFFILEOUT
	else:
		simpar.MFDATAINP=os.environ["PATRONDIR"]+"/data/snrmhd/mf/"+setup.ReadXMLPar("hdsimname",simpar.PARAMFILE)+"/"+setup.ReadXMLPar("mfmodel",simpar.PARAMFILE)		
		simpar.MFFILEINP=setup.ReadXMLPar("mffileinp",simpar.PARAMFILE)

	simpar.MHDDATAOUT=simpar.Rundir+"/RADIATIONS/MHDDATA/" #locaction for MHD data used by radiation module	
	simpar.MHDFILEOUT=setup.ReadXMLPar("mhdfileout",simpar.PARAMFILE)	
				
	simpar.CRDATAINP=simpar.Rundir+"/COSMICRAYS/" #Location of CRDATAFILES
	simpar.CRFILEINP=setup.ReadXMLPar("crfileinp",simpar.PARAMFILE) #Continuing of simulation, set as Parameter in setup
	simpar.CRFILEINP1="NRAW" #Input for CRSPE1/2-stage, hard coded
	#simpar.CRDATAOUT=simpar.Rundir+"/COSMICRAYS/"+simpar.CRSPECIES
	simpar.CRDATAOUT=[]
        simpar.MTDATAINP=simpar.Rundir+"TURBULENCE/"+simpar.SHOCKTYPE
        simpar.MTDATAOUT=simpar.Rundir+"TURBULENCE/"+simpar.SHOCKTYPE
        for crspecies in simpar.CRSPECIES:
                simpar.CRDATAOUT.append(simpar.Rundir+"/COSMICRAYS/"+crspecies)
                # simpar.MTDATAINP.append(simpar.Rundir+"TURBULENCE/"+crspecies+"/"+simpar.SHOCKTYPE)
                # simpar.MTDATAOUT.append(simpar.Rundir+"TURBULENCE/"+crspecies+"/"+simpar.SHOCKTYPE)
        simpar.CRFILEOUT=setup.ReadXMLPar("crfileout",simpar.PARAMFILE)
		
	#simpar.MTDATAINP=simpar.Rundir+"TURBULENCE/"+simpar.CRSPECIES+"/"+simpar.SHOCKTYPE
	simpar.MTFILEINP=setup.ReadXMLPar("mtfileinp",simpar.PARAMFILE)
	#simpar.MTDATAOUT=simpar.Rundir+"TURBULENCE/"+simpar.CRSPECIES+"/"+simpar.SHOCKTYPE
	simpar.MTFILEOUT=setup.ReadXMLPar("mtfileout",simpar.PARAMFILE)

	simpar.usesedsol=  int(setup.ReadXMLPar("usesedsol",simpar.PARAMFILE))

	simpar.PLUTOFLAG= setup.ReadXMLPar("plutoflag",simpar.PARAMFILE)
	simpar.PLUTO_DLL= os.getenv("PATRONDIR")+"/lib/"+setup.ReadXMLPar("plutodll",simpar.PARAMFILE)

	simpar.mfinitime=float(setup.ReadXMLPar("mfinitime",simpar.PARAMFILE))
	simpar.mfofismna=float(setup.ReadXMLPar("mfofismna",simpar.PARAMFILE))
        simpar.mfstarsurf=float(setup.ReadXMLPar("mfstarsurf",simpar.PARAMFILE))
        simpar.starrad=float(setup.ReadXMLPar("starrad",simpar.PARAMFILE))
	simpar.mfatshock=float(setup.ReadXMLPar("mfatshock",simpar.PARAMFILE))
	simpar.mfampfact=float(setup.ReadXMLPar("mfampfact",simpar.PARAMFILE))
	#simpar.MFAMPMODE=setup.ReadXMLPar("mfampmode",simpar.PARAMFILE)
	simpar.MFPROFILE=setup.ReadXMLPar("mfprofile",simpar.PARAMFILE)
	simpar.MFINTPROF=setup.ReadXMLPar("mfintprof",simpar.PARAMFILE)
	simpar.mfinitcon=float(setup.ReadXMLPar("mfinitcon",simpar.PARAMFILE))
	simpar.ALFVDRIFT=setup.ReadXMLPar("alfvdrift",simpar.PARAMFILE)
	simpar.mfdampsca=float(setup.ReadXMLPar("mfdampsca",simpar.PARAMFILE))
        simpar.mfscabins=float(setup.ReadXMLPar("mfscabins",simpar.PARAMFILE))
		
	simpar.EXPLNTYPE=setup.ReadXMLPar("explntype",simpar.PARAMFILE)
	simpar.SNSUBTYPE=setup.ReadXMLPar("snsubtype",simpar.PARAMFILE)
	simpar.WINDBNCSM=setup.ReadXMLPar("windbncsm",simpar.PARAMFILE)
        simpar.windbubrad=float(setup.ReadXMLPar("windbubrad",simpar.PARAMFILE))
	simpar.nhdensity=float(setup.ReadXMLPar("nhdensity",simpar.PARAMFILE))
	simpar.expenergy=float(setup.ReadXMLPar("expenergy",simpar.PARAMFILE))
	simpar.rshellpc1=float(setup.ReadXMLPar("rshellpc1",simpar.PARAMFILE))
	simpar.rshellpc2=float(setup.ReadXMLPar("rshellpc2",simpar.PARAMFILE))
	simpar.shdensity=float(setup.ReadXMLPar("shdensity",simpar.PARAMFILE))
		
	#simpar.CRSENERGY=setup.ReadXMLPar("crsenergy",simpar.PARAMFILE)

	simpar.rstepsnum=  int(setup.ReadXMLPar("rstepsnum",simpar.PARAMFILE))
	simpar.pstepsnum=  int(setup.ReadXMLPar("pstepsnum",simpar.PARAMFILE))
	simpar.rcoordmax=float(setup.ReadXMLPar("rcoordmax",simpar.PARAMFILE))
	simpar.pcoordmax=float(setup.ReadXMLPar("pcoordmax",simpar.PARAMFILE))
		
	simpar.lmaxbdiff=float(setup.ReadXMLPar("lmaxbdiff",simpar.PARAMFILE))
	simpar.lmingdiff=float(setup.ReadXMLPar("lmingdiff",simpar.PARAMFILE))
	simpar.DIFFINTER=setup.ReadXMLPar("diffinter",simpar.PARAMFILE)

	simpar.momdifpow=float(setup.ReadXMLPar("momdifpow",simpar.PARAMFILE))
	simpar.momdiftau=float(setup.ReadXMLPar("momdiftau",simpar.PARAMFILE))
	simpar.momdiffr1=float(setup.ReadXMLPar("momdiffr1",simpar.PARAMFILE))
	simpar.momdiffr2=float(setup.ReadXMLPar("momdiffr2",simpar.PARAMFILE))
	simpar.momdifsclel=float(setup.ReadXMLPar("momdifsclel",simpar.PARAMFILE))
	simpar.momdifsclpr=float(setup.ReadXMLPar("momdifsclpr",simpar.PARAMFILE))
	simpar.momdifsclhe=float(setup.ReadXMLPar("momdifsclhe",simpar.PARAMFILE))
	simpar.momdifsclc=float(setup.ReadXMLPar("momdifsclc",simpar.PARAMFILE))
	simpar.momdifsclox=float(setup.ReadXMLPar("momdifsclox",simpar.PARAMFILE))
	simpar.momdifsclfe=float(setup.ReadXMLPar("momdifsclfe",simpar.PARAMFILE))
               
	simpar.MTAPPLIED=setup.ReadXMLPar("mtapplied",simpar.PARAMFILE)
	simpar.MTSPECTRA=setup.ReadXMLPar("mtspectra",simpar.PARAMFILE)
	simpar.MTINITCON=setup.ReadXMLPar("mtinitcon",simpar.PARAMFILE)
	simpar.ENSDSTURB=float(setup.ReadXMLPar("ensdsturb",simpar.PARAMFILE))
	simpar.LESDSTURB=float(setup.ReadXMLPar("lesdsturb",simpar.PARAMFILE))
	simpar.TURBFIELD=int(setup.ReadXMLPar("turbfield",simpar.PARAMFILE))
	simpar.TURBAMPFACT=float(setup.ReadXMLPar("turbampfact",simpar.PARAMFILE))	

	simpar.kstepsnum=int(setup.ReadXMLPar("kstepsnum",simpar.PARAMFILE))

	simpar.rstepsnumrs=int(setup.ReadXMLPar("rstepsnumrs",simpar.PARAMFILE))
	simpar.rstepsnumfs=int(setup.ReadXMLPar("rstepsnumfs",simpar.PARAMFILE))
	simpar.rcoordmaxrs=float(setup.ReadXMLPar("rcoordmaxrs",simpar.PARAMFILE))
	simpar.rcoordmaxfs=float(setup.ReadXMLPar("rcoordmaxfs",simpar.PARAMFILE))

	simpar.RADORIGIN=setup.ReadXMLPar("radorigin",simpar.PARAMFILE)
	simpar.CRSENERGY=setup.ReadXMLPar("crsenergy",simpar.PARAMFILE)

	simpar.RADOBJECT=setup.ReadXMLPar("radobject",simpar.PARAMFILE)
	simpar.SYNEMFUNC=setup.ReadXMLPar("synemfunc",simpar.PARAMFILE)
	simpar.STERADIAN=setup.ReadXMLPar("steradian",simpar.PARAMFILE)
	simpar.snrdistpc=float(setup.ReadXMLPar("snrdistpc",simpar.PARAMFILE))
	simpar.radintres=float(setup.ReadXMLPar("radintres",simpar.PARAMFILE))
	simpar.rspenorm1=0.0	#No Value give in old code
	simpar.rspenorm2=0.0	#No Value give in old code
	simpar.radnormax=float(setup.ReadXMLPar("radnormax",simpar.PARAMFILE))
	simpar.ucmb		= float(setup.ReadXMLPar("ucmb",simpar.PARAMFILE))
	simpar.udust		= float(setup.ReadXMLPar("udust",simpar.PARAMFILE))
	simpar.ustarlight	= float(setup.ReadXMLPar("ustarlight",simpar.PARAMFILE))
	simpar.Tcmb		= float(setup.ReadXMLPar("Tcmb",simpar.PARAMFILE))
	simpar.Tdust		= float(setup.ReadXMLPar("Tdust",simpar.PARAMFILE))
	simpar.Tstar		= float(setup.ReadXMLPar("Tstar",simpar.PARAMFILE))

	simpar.CREATEMAP=setup.ReadXMLPar("createmap",simpar.PARAMFILE)
	simpar.MAPENERGY=setup.ReadXMLPar("mapenergy",simpar.PARAMFILE)
	simpar.HEMISPHER=setup.ReadXMLPar("hemispher",simpar.PARAMFILE)
	if simpar.HEMISPHER==None: simpar.HEMISPHER=""	
	simpar.ROTMAPXYZ=setup.ReadXMLPar("rotmapxyz",simpar.PARAMFILE)
	simpar.scaleinpc=float(setup.ReadXMLPar("scaleinpc",simpar.PARAMFILE))
	simpar.MFCOMPDIM=setup.ReadXMLPar("mfcompdim",simpar.PARAMFILE)
				
	simpar.RPDATAOUT=simpar.Rundir+"/RADIATIONS"
	simpar.RPFILEOUT=""

        simpar.AbundanceH  =float(setup.ReadXMLPar("abundanceh",simpar.PARAMFILE))
        simpar.AbundanceHe =float(setup.ReadXMLPar("abundancehe",simpar.PARAMFILE))
        simpar.AbundanceC  =float(setup.ReadXMLPar("abundancec",simpar.PARAMFILE))
        simpar.AbundanceO  =float(setup.ReadXMLPar("abundanceo",simpar.PARAMFILE))
        simpar.AbundanceFe =float(setup.ReadXMLPar("abundancefe",simpar.PARAMFILE))




def InitSimulation(simpar):	
	if   simpar.CALCULATE == "CRSPE0":
		if    simpar.MFFILEINP == simpar.MFFILEOUT:
			simpar.MFINPFN = simpar.MFDATAOUT + "/" + simpar.MFFILEINP + simpar.timecont
		else: simpar.MFINPFN = ""

                simpar.CRINPFN=[]
		
		if    simpar.CRFILEOUT == simpar.CRFILEINP:
                        #simpar.CRINPFN = simpar.CRDATAINP + "/" + simpar.CRSPECIES + "/" + simpar.SHOCKTYPE + "/" +simpar.CRFILEINP + simpar.timecont
                        for crspecies in simpar.CRSPECIES:
                                simpar.CRINPFN.append(simpar.CRDATAINP + "/" + crspecies + "/" + simpar.SHOCKTYPE + "/" +simpar.CRFILEINP + simpar.timecont)
                #else: simpar.CRINPFN = ""
                else: 
                        for crspecies in simpar.CRSPECIES: simpar.CRINPFN.append("")
		
		if    simpar.MTFILEOUT == simpar.MTFILEINP:
			simpar.MTINPFN = simpar.MTDATAINP + "/" + simpar.MTFILEINP + simpar.timecont
		else: simpar.MTINPFN = ""

		if    simpar.HDFILEOUT == simpar.HDFILEINP:
			simpar.HDINPFN = simpar.HDDATAOUT + "/" +simpar.HDFILEINP + simpar.timecont
		else: simpar.HDINPFN = ""
		
		simpar.HDOUTFN = simpar.HDDATAOUT + "/" + simpar.HDFILEOUT
		simpar.MFOUTFN = simpar.MFDATAOUT + "/" + simpar.MFFILEOUT
		#simpar.CROUTFN = simpar.CRDATAOUT + "/" + simpar.SHOCKTYPE + "/" + simpar.CRFILEOUT
		#simpar.MTOUTFN = simpar.MTDATAOUT + "/" + simpar.MTFILEOUT
                simpar.CROUTFN = []
                simpar.MTOUTFN = simpar.MTDATAOUT + "/" + simpar.MTFILEOUT
                for crdataout in simpar.CRDATAOUT:
                        simpar.CROUTFN.append(crdataout + "/" + simpar.SHOCKTYPE + "/" + simpar.CRFILEOUT)
                # for mtdataout in simpar.MTDATAOUT:
                #         simpar.MTOUTFN.append(mtdataout + "/" + simpar.MTFILEOUT)
		simpar.MHDOUTFN=simpar.MHDDATAOUT+simpar.MHDFILEOUT

	
	elif simpar.CALCULATE == "CRSPE1":
		#simpar.CRINPFN = simpar.CRDATAINP + "/" + simpar.CRSPECIES + "/" + simpar.SHOCKTYPE + "/" + simpar.CRFILEINP1 + simpar.TIMEINOUT
                simpar.CRINPFN = []
		for crspecies in simpar.CRSPECIES:
                        simpar.CRINPFN.append(simpar.CRDATAINP + "/" + crspecies + "/" + simpar.SHOCKTYPE + "/" + simpar.CRFILEINP1 + simpar.TIMEINOUT)

	
	elif simpar.CALCULATE == "CRSPE2":
#		simpar.CRINPFNRS = simpar.CRDATAINP + "/" + simpar.CRSPECIES + "/RSH/" + simpar.CRFILEINP1 + simpar.TIMEINOUT
#		simpar.CRINPFNFS = simpar.CRDATAINP + "/" + simpar.CRSPECIES + "/FSH/" + simpar.CRFILEINP1 + simpar.TIMEINOUT
		simpar.CRINPFNRS = []
                simpar.CRINPFNFS = []
                for crspecies in simpar.CRSPECIES:
                        simpar.CRINPFNRS.append(simpar.CRDATAINP + "/" + crspecies + "/RSH/" + simpar.CRFILEINP1 + simpar.TIMEINOUT)
                        simpar.CRINPFNFS.append(simpar.CRDATAINP + "/" + crspecies + "/FSH/" + simpar.CRFILEINP1 + simpar.TIMEINOUT)

        elif simpar.CALCULATE == "CRSPE3":
		#simpar.CRINPFN = simpar.CRDATAINP + "/" + simpar.CRSPECIES + "/" + simpar.SHOCKTYPE + "/" + simpar.CRFILEINP1 + simpar.TIMEINOUT
                simpar.CRINPFN = []
		for crspecies in simpar.CRSPECIES:
                        simpar.CRINPFN.append(simpar.CRDATAINP + "/" + crspecies + "/" + simpar.SHOCKTYPE + "/" + simpar.CRFILEINP1)

	elif simpar.CALCULATE == "CRPROF":
#		simpar.CRINPFN = simpar.CRDATAINP + "/" + simpar.CRSPECIES + "/" + simpar.RADORIGIN + "/NER" + simpar.TIMEINOUT  #Hard coded for CRPROF stage
                simpar.CRINPFN = []
                for crspecies in simpar.CRSPECIES:
                        simpar.CRINPFN.append(simpar.CRDATAINP + "/" + crspecies + "/" + simpar.RADORIGIN + "/NER" + simpar.TIMEINOUT)  #Hard coded for CRPROF stage
 
	elif simpar.CALCULATE == "RADSPE":
		simpar.RPFILEOUT=simpar.RADIATION
		simpar.RPDATAOUT=simpar.RPDATAOUT+"/SPE"
		if simpar.RADIATION == "PDV" or simpar.RADIATION == "PDR" or simpar.RADIATION == "NR" or simpar.RADIATION == "NRTHEO":
			del simpar.CRSPECIES[:]				
			if simpar.speciespr == True: simpar.CRSPECIES.append("PR")
			if simpar.specieshe == True: simpar.CRSPECIES.append("HE")
			if simpar.speciesc  == True: simpar.CRSPECIES.append("C")
			if simpar.speciesox == True: simpar.CRSPECIES.append("OX")
			if simpar.speciesfe == True: simpar.CRSPECIES.append("FE")			
							
		else:
			simpar.CRSPECIES=["EL"]
		if simpar.RADIATION == "SYR" or simpar.RADIATION == "ICR" or simpar.RADIATION == "PDR":
			simpar.CRFILEINP="NER"
		else:
			simpar.CRFILEINP="NED"	

		simpar.HDINPFN = simpar.HDDATAINP + "/" + simpar.HDFILEINP + simpar.TIMEINOUT		
		simpar.CRINPFN = []
		simpar.RPOUTFN = []
		simpar.MHDINPFN=simpar.MHDDATAOUT+simpar.MHDFILEOUT+simpar.TIMEINOUT


		for crspecies in simpar.CRSPECIES:
			simpar.CRINPFN.append(simpar.CRDATAINP + "/" + crspecies + "/" + simpar.RADORIGIN + "/" + simpar.CRFILEINP + simpar.TIMEINOUT)
		
			simpar.RPOUTFN.append(simpar.RPDATAOUT + "/" + simpar.RADOBJECT + simpar.RPFILEOUT + simpar.RADORIGIN.translate(None,'/') + crspecies + simpar.TIMEINOUT)
		
		if simpar.ROTMAPXYZ == "":
			simpar.rotmapxyz = (0.0, 0.0, 0.0)
		else:
			X,Y,Z=simpar.ROTMAPXYZ.split(',')
			simpar.rotmapxyz = (float(X),float(Y),float(Z))
	######################RADSPEALL##########################################
	elif simpar.CALCULATE == "RADSPEALL":
		simpar.RPFILEOUT=simpar.RADIATION
		simpar.RPDATAOUT=simpar.RPDATAOUT+"/SPE"
		if simpar.RADIATION == "PDV" or simpar.RADIATION == "PDR" or simpar.RADIATION == "NR" or simpar.RADIATION == "NRTHEO":
			del simpar.CRSPECIES[:]				
			if simpar.speciespr == True: simpar.CRSPECIES.append("PR")
			if simpar.specieshe == True: simpar.CRSPECIES.append("HE")
			if simpar.speciesfe == True: simpar.CRSPECIES.append("FE")
		else:
			simpar.CRSPECIES=["EL"]
		if simpar.RADIATION == "SYR" or simpar.RADIATION == "ICR" or simpar.RADIATION == "PDR":
			simpar.CRFILEINP="NER"
		else:
			simpar.CRFILEINP="NED"	

		simpar.HDINPFN = simpar.HDDATAINP + "/" + simpar.HDFILEINP
		simpar.MHDINPFN = simpar.MHDDATAOUT + "/" + simpar.MHDFILEOUT

		simpar.CRINPFN = []
		simpar.RPOUTFN = []

 		for crspecies in simpar.CRSPECIES:
			simpar.CRINPFN.append(simpar.CRDATAINP + "/" + crspecies + "/" + simpar.RADORIGIN + "/" + simpar.CRFILEINP)
			simpar.RPOUTFN.append(simpar.RPDATAOUT + "/" + simpar.RADOBJECT + simpar.RPFILEOUT + simpar.RADORIGIN.translate(None,'/') + crspecies)
		
		if simpar.ROTMAPXYZ == "":
			simpar.rotmapxyz = (0.0, 0.0, 0.0)
		else:
			X,Y,Z=simpar.ROTMAPXYZ.split(',')
			simpar.rotmapxyz = (float(X),float(Y),float(Z))

	elif simpar.CALCULATE == "RADMAP" or simpar.CALCULATE == "RADM3D" or simpar.CALCULATE == "MAPINT":
		simpar.RPFILEOUT=simpar.RADIATION
		simpar.RPDATAOUT=simpar.RPDATAOUT+"/MAP"
		if  simpar.RADIATION == "PDR":
			simpar.CRSPECIES="PR"
		else:
			simpar.CRSPECIES="EL"

		simpar.CRFILEINP="NER"
		simpar.MFINPFN = simpar.MFDATAINP + "/" + simpar.MFFILEINP + simpar.TIMEINOUT
		
		simpar.CRINPFN = simpar.CRDATAINP + "/" + simpar.CRSPECIES + "/" + simpar.RADORIGIN + "/" + simpar.CRFILEINP + simpar.TIMEINOUT
		
		simpar.RPOUTFN = simpar.RPDATAOUT + "/" + simpar.RADOBJECT + simpar.RPFILEOUT + simpar.TIMEINOUT
		
		if simpar.ROTMAPXYZ == "":
			simpar.rotmapxyz = (0.0, 0.0, 0.0)
		else:
			X,Y,Z=simpar.ROTMAPXYZ.split(',')
			simpar.rotmapxyz = (float(X),float(Y),float(Z))


	elif simpar.CALCULATE == "MAPSPE" or simpar.CALCULATE == "MAPSPE_PARALLEL":
		simpar.RPFILEOUT=simpar.RADIATION
		simpar.RPDATAOUT=simpar.RPDATAOUT+"/MSP"
		simpar.HDOUTFN = simpar.HDDATAOUT + "/" + simpar.HDFILEOUT
		simpar.HDINPFN = simpar.HDDATAINP + "/" + simpar.HDFILEINP + simpar.TIMEINOUT
		simpar.MHDINPFN=simpar.MHDDATAOUT+simpar.MHDFILEOUT+simpar.TIMEINOUT
		if  simpar.RADIATION == "PDR":
			simpar.CRSPECIES="PR"
		else:
			simpar.CRSPECIES="EL"

		simpar.CRFILEINP="NER"
		simpar.MFINPFN = simpar.MFDATAINP + "/" + simpar.MFFILEINP + simpar.TIMEINOUT
		simpar.CRINPFN = simpar.CRDATAINP + "/" + simpar.CRSPECIES + "/" + simpar.SHOCKTYPE + "/" + simpar.CRFILEINP + simpar.TIMEINOUT
		
		simpar.RPOUTFN = simpar.RPDATAOUT + "/" + simpar.RADOBJECT + simpar.RPFILEOUT + simpar.TIMEINOUT
		
		if simpar.ROTMAPXYZ == "":
			simpar.rotmapxyz = (0.0, 0.0, 0.0)
		else:
			X,Y,Z=simpar.ROTMAPXYZ.split(',')
			simpar.rotmapxyz = (float(X),float(Y),float(Z))
	


	tecoef.l         = simpar.lmaxbdiff
	tecoef.L         = simpar.lmingdiff
	tecoef.DINT      = simpar.DIFFINTER
	tecoef.MTSPE     = simpar.MTSPECTRA
	tecoef.eta       = simpar.etaofbohm
	tecoef.mdp       = simpar.momdifpow
	tecoef.tau       = simpar.momdiftau
	tecoef.r1        = simpar.momdiffr1
	tecoef.r2        = simpar.momdiffr2
	tecoef.P_0_el    = simpar.momdifsclel
	tecoef.P_0_pr    = simpar.momdifsclpr
	tecoef.P_0_he    = simpar.momdifsclhe
	tecoef.P_0_c     = simpar.momdifsclc
	tecoef.P_0_ox    = simpar.momdifsclox
	tecoef.P_0_fe    = simpar.momdifsclfe

	
	###INITIALIZING FUNCTIONS AND SNTYPE-DEPENDENT VARIABLES#########
        snrmhd.ld       = simpar.mfdampsca
        snrmhd.SCBIN 	= simpar.mfscabins
	######################
#################### changed SD
      
##############################################################################################################################


        if simpar.WINDBNCSM == "TRUE":
			evotru.S = 2					#power-law profile in the wind-zone
        else:
			evotru.S = 0
        evotru.N       = 7					#power-law profile in the ejecta
	#evotru.SetupParameters()
	evotru.M_ej    = 5.45*evotru.M_sun
	evotru.Mdot    = 6.0e21 #3.0e21 #6.0e21			#mass-loss rate in g/s
	evotru.V_Z1    = 4.5e06 #2.25e6 #4.5e06			#wind speed in cm/s
	evotru.R_Z2    = simpar.rshellpc1*pc
	evotru.RWSH    = simpar.rshellpc2*pc
	evotru.RHO_SHL = simpar.shdensity*2.339e-24


	if   simpar.EXPLNTYPE == "T1":
		evovik.tinit = 1.37e-3*yr
		evovik.M_e=1.4*evovik.M_sun
		evovik.RHO_ISM=simpar.nhdensity*2.339e-24	#n=1.0 -> rho = 2.339e-24
		evovik.V_ism = 0.1e7
		evovik.rho_ism=evovik.rho_ism_T1
		evovik.rho_in=evovik.rho_in_T1
		evovik.v_ed_fs_u=evovik.v_ed_fs_u_T1
		mftran.v_plato=2.0*4.515e8*yr
	elif simpar.EXPLNTYPE == "T2":
		if   simpar.SNSUBTYPE == "type1c":
			evovik.Mdot = 6.35e20
			evovik.tinit = 4.11e-2*yr
			evovik.M_e=5.45*evovik.M_sun
			evovik.V_Z1 = 1.5e8
			evovik.V_Z2 = 0.3e8
			evovik.R_Z1 = 7.0*pc
			evovik.DJZ1Z2 = 4.0
		elif simpar.SNSUBTYPE == "type2p":
			evovik.Mdot = 6.35e21
			evovik.tinit = 4.11e-2*yr
			evovik.M_e=5.45*evovik.M_sun
			evovik.V_Z1 = 1.0e6
			evovik.V_Z2 = 5.0e6
			evovik.R_Z1 = 2.0*pc
			evovik.DJZ1Z2 = 0.000175716852
		evovik.R_Z2      = simpar.rshellpc1*pc
		evovik.RWSH      = simpar.rshellpc2*pc
		evovik.RHO_SHL   = simpar.shdensity*2.339e-24	#n=1.0 -> rho = 2.339e-24
		evovik.RHO_ISM   = simpar.nhdensity*2.339e-24 
		evovik.rho_ism   = evovik.rho_ism_T2
		evovik.rho_in    = evovik.rho_in_T2
		evovik.v_ed_fs_u = evovik.v_ed_fs_u_T2
		mftran.v_plato   = 1.0*4.515e8*yr
	else:
		evocox.V_Z1    = 1.0e6
		evocox.R_Z2    = simpar.rshellpc1*pc
		evocox.RWSH    = simpar.rshellpc2*pc
		evocox.RHO_SHL = simpar.shdensity*2.339e-24

		evotel.V_Z1    = 1.0e6
		evotel.R_Z2    = simpar.rshellpc1*pc
		evotel.RWSH    = simpar.rshellpc2*pc
		evotel.RHO_SHL = simpar.shdensity*2.339e-24

		evorob.V_Z1    = 1.0e6
		evorob.R_Z2    = simpar.rshellpc1*pc
		evorob.RWSH    = simpar.rshellpc2*pc
		evorob.RHO_SHL = simpar.shdensity*2.339e-24
		evorob.Rundir  = simpar.Rundir		

		if simpar.WINDBNCSM == "TRUE":
			evotru.S = 2					#power-law profile in the wind-zone
		else:
			evotru.S = 0
		evotru.N       = 7					#power-law profile in the ejecta
		#evotru.SetupParameters()
		evotru.M_ej    = 5.45*evotru.M_sun
		evotru.Mdot    = 6.0e21 #3.0e21 #6.0e21			#mass-loss rate in g/s
		evotru.V_Z1    = 4.5e06 #2.25e6 #4.5e06			#wind speed in cm/s
		evotru.R_Z2    = simpar.rshellpc1*pc
		evotru.RWSH    = simpar.rshellpc2*pc
		evotru.RHO_SHL = simpar.shdensity*2.339e-24
		
		evovik.tinit   = 0.001*yr
		mftran.v_plato = 5.0e8*yr
		if simpar.CALCULATE == "CRSPE0" or simpar.CALCULATE == "RADSPE"  or simpar.CALCULATE == "RADSPEALL" or simpar.CALCULATE == "RADMAP" or simpar.CALCULATE == "RADM3D" or simpar.CALCULATE == "MAPSPE" or simpar.CALCULATE == "MAPSPE_PARALLEL" or simpar.CALCULATE == "MAPINT":
			if parallel.procID == 0: print "setpar: no explosion type set! some evo and mftran parameters will not be set up!"
			if parallel.procID == 0: print "setpar: choose explosion type: T1 -- thermonuclear, T2 -- core-collapse." 
	
        snrmhd.BISM  = simpar.mfofismna
        snrmhd.AMP   = simpar.mfampfact

	if simpar.mfampfact == 0.0:
                if parallel.procID == 0: print "setpar: Magnetic field amplification factor is zero. I don't know what to do with it and just quit!"
		sys.exit(0)

        	
###END OF INITIALIZATION OF evovik, mftran, snrmhd ###################################

###reading times file to define timeStop and intermediate outputs#########################
	if simpar.TIMESLIST != "":
		try:
			f=open(simpar.TIMESLIST,"r")
			TIMES=f.readlines()
			f.close()
			if size(TIMES) == 0:
				if parallel.procID == 0: print "setpar: times list file is empty:",simpar.TIMESLIST
				if parallel.procID == 0: print "setpar: execution aborted!"
				sys.exit(0)
		except IOError:
			if parallel.procID == 0: print "setpar: no file found:",simpar.TIMESLIST
		LT=len(TIMES)
		timeslist=arange(LT,dtype=float)
		for i in range(LT):
			timeslist[i]=round(float(TIMES[i]),5)
		simpar.timeslist=timeslist
	
		simpar.timestart = timeslist[0]
		simpar.timefinal = timeslist[-1]

	else: 
		#No timefile provided use unclear...:-/
		if simpar.CALCULATE == "CRSPE0":
			if parallel.procID == 0:
				print "setpar: please, provide non-empty times list otherwise"
				print "setpar: start time will be set to", simpar.timeinout
				print "setpar: final time will be set to", simpar.timeinout
		simpar.timestart=simpar.timeinout
		simpar.timefinal=simpar.timeinout
	
	if simpar.TIMEINOUT != "":
		simpar.timeinout = float(simpar.TIMEINOUT)

	if simpar.timecont != None:		
		simpar.timestart = float(simpar.timecont)
		simpar.mfinitime = float(simpar.timecont)
		if parallel.procID == 0:
			print "setpar: Calculation will be continued from time", simpar.timecont

	synchr.SYNEMFUNC=simpar.SYNEMFUNC
	simpar.crinittime= timeslist[0]

def PrintSimParams(simpar):
	if parallel.procID == 0:
		print "setpar: cosmic-ray calculations are started with following parameters..."
		print "setpar: r-space N steps -", simpar.rstepsnum
		print "setpar: p-space N steps -", simpar.pstepsnum 
		print "setpar: start time (yrs)-", simpar.timestart
		print "setpar: final time (yrs)-", simpar.timefinal
		print "setpar: intermediate outputs will be made at times (yrs)"
		print "setpar: ",                  simpar.timeslist
#		print "setpar: init.inj.param. -", tecoef.smhd.InP

def PrintAllParams(simpar):
	return 0

def WriteSimParams(simpar):
	output = open(simpar.PARAMFILE,"wb")
	pickle.dump(simpar,output)
	output.close()

def ReadSimParams(parfile):
	pfile=open(parfile,"rb")
	return pickle.load(pfile)

def Rpc2Rnorm(CFFS,rShellpc1,rShellpc2,hdDataOut,timeslist,TIMESLIST):
	#RSHOCK=CFFS.Rsh(timeslist)
	#RNORM1=rShellpc1*pc/RSHOCK
	#RNORM2=rShellpc2*pc/RSHOCK
	if os.path.isfile(hdDataOut+"/rpc2rnorm") == False:
		f=open(hdDataOut+"/rpc2rnorm","w")
		L=len(timeslist)
		for i in range(L):
			#f.write(str(RSHOCK[i])+" "+str(RNORM1[i])+" "+str(RNORM2[i])+" "+str(int(timeslist[i])).zfill(5)+"\n")
			RSHOCK=CFFS.Rsh(timeslist[i])
			#print "!!!!!!!! RSHOCK=",RSHOCK,"!!!!!!!!!!"
			RNORM1=rShellpc1*pc/RSHOCK
			RNORM2=rShellpc2*pc/RSHOCK
			f.write(str(RSHOCK)+" "+str(RNORM1)+" "+str(RNORM2)+" "+str(float(timeslist[i]))+"\n")
		f.close()

def Rrsh2Rfsh(CFFS,hdDataOut,timeslist,TIMESLIST):
	#RRS=CFFS.RRS(timeslist)
	if os.path.isfile(hdDataOut+"/rrsh2rfsh") == False:
		f=open(hdDataOut+"/rrsh2rfsh","w")
		L=len(timeslist)
		for i in range(L):
			#f.write(str(RRS[i])+" "+str(int(timeslist[i])).zfill(5)+"\n")
			f.write(str(CFFS.RRS(timeslist[i]))+" "+str(float(timeslist[i]))+"\n")
		f.close()

def FindRrs(hdDataInp,timeInOut):
	fname=hdDataInp+"/rrsh2rfsh"
	try:
		f=open(fname,"r")
		alllines=f.readlines()
		f.close()
	except IOError:
		if parallel.procID == 0: print "setpar: no file found:",fname
	
	for row in alllines:
		(RRS,T)=row.split()
		if timeInOut == T:
			return float(RRS)

def FindR12(hdDataInp,timeInOut):
	fname=hdDataInp+"/rpc2rnorm"
	try:
		f=open(fname,"r")
		alllines=f.readlines()
		f.close()
	except IOError:
		if parallel.procID == 0: print "setpar: no file found:",fname
	
	for row in alllines:
		(RS,R1,R2,T)=row.split()
		if timeInOut == T:
			return float(R1),float(R2)

def FindRfs(hdDataInp,timeInOut):
	fname=hdDataInp+"/rpc2rnorm"
	try:
		f=open(fname,"r")
		alllines=f.readlines()
		f.close()
	except IOError:
		if parallel.procID == 0: print "setpar: no file found:",fname
	
	for row in alllines:
		(RS,R1,R2,T)=row.split()
		if timeInOut == T:
			return float(RS)
