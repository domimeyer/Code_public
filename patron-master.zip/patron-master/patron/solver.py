######################################################################################
### RATPaC - Radiation Acceleration Transport PArallel Code                        ###
#=====================================================================================
# File:	  solver.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2010 - 2015
# 	  Robert Brose <robert.brose@mail.de>, 2014 - present
#         Iurii Sushch <iurii.sushch@desy.de>, 2018 - present
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v1.0.0: module introduced
#v1.0.1: re-locating WriteVariable function
#v1.0.2: added WriteMHD
#v2.0.0: added new solvers for mttran.
#v2.0.1: some modification for RXJ1713 and IC443 modeling
#v2.1.0: version control added
#v2.1.1: now all solvers implemented, MT-solvers updated
#v2.1.2: preparation for hd-solvers
#v2.2.0: Added logging functions; All solvers implemented; Changed injection scaling
#v2.3.0: Merging all solvers into one universal; for PLUTO alone there is still a separate solver

__version__='2.3.0'

import sys
from numpy import exp
from numpy import log
from numpy import sqrt
from numpy import insert as insertnp
from numpy import savetxt
from numpy import array

from fipy.tools import parallel
from fipy.tools.numerix import zeros

from os.path import isfile
from os import remove

started = 0

def GetLogValue(TEs,t):
	log_description = []
	log_value       = []	
	for TE in TEs:
		if TE != 0:
                        #print TE
			logs, values = TE.GetLogValue(t)
			for i in range(len(logs)):
				log_description.append(logs[i])
				log_value.append(values[i])
	return log_description, log_value

def PrintLogValues(descriptions, values,t,sp,cr):
	logFileDir = str(sp.Rundir)+"ALLSUBDIR/CRSPE0/logs/log_file"+cr

  	if parallel.procID == 0: 
		print "\nsolver: Logged values:"
		for i in range(len(descriptions)):
			print "\t", descriptions[i],"\t", values[i]
		print "\n"
                if t == sp.timestart and sp.timecont == None:
			if isfile(logFileDir):
				print "solver: Removing old log-file..." 
				remove(logFileDir)
			#started=started+1
			f=open(logFileDir,'a')
			f.write("time\t"+''.join(str(x+"\t") for x in descriptions)+"\n")
			f.close()	

		print "solver: Writing log-file..."
		f=open(logFileDir,'a')
		f.write(str(t)+"\t"+''.join(str(str(x)+"\t") for x in values)+"\n")
		f.close()
		print "solver: Log-file written"
	return





def SolveEquationHD(SP,CRTE,MFTE,MTTE,HDTE):
	timesout=SP.timeslist

	#Do intervall for HD without CR-calculation
	if SP.timecont != None:
		time = float(SP.timecont)
		#read shock speed
		HDTE.ReadRpc2Rnorm()
	else:
		time = 0.0
	if time < min(timesout):
		timesout=insertnp(timesout,0,0)

	mhtran = HDTE
	mhtran.WriteMhd(mhtran.Mhd_full,mhtran.ConvTime(mhtran.g_time()),timesout,SP.HDOUTFN)
	if parallel.procID == 0:
		mhtran.WriteMhd(mhtran.Mhd_full_output,mhtran.ConvTime(mhtran.g_time()),timesout,SP.HDOUTFN+"_pp")

	i = 0
	while i < len(timesout)-1:
	 	mhtran.DoTimeIntervall(timesout[i],timesout[i+1])
		mhtran.WriteMhd(mhtran.Mhd_full,mhtran.ConvTime(mhtran.g_time()),timesout,SP.HDOUTFN)
		if parallel.procID == 0:
			mhtran.WriteMhd(mhtran.Mhd_full_output,mhtran.ConvTime(mhtran.g_time()),timesout,SP.HDOUTFN+"_pp")

		i += 1	
		if parallel.procID == 0: print "\n"

	mhtran.EndSimulation()



def SolveEquationCRandHDandMTandMF(SP,CRTE,MFTE,MTTE,HDTE):
	timesout=SP.timeslist

	# for i, crte in enumerate(CRTE):
	# 	HDTE.UpdateMhd(CRTE[i])
	# HDTE.UpdateMhd(MTTE)
	# HDTE.UpdateMhd(MFTE)
	
	timeInitCR = SP.timestart
	timeStop   = SP.timefinal

	#Do intervall for HD without CR-calculation
	if SP.timecont != None:
		time = float(SP.timecont)
		MTTE.SetupEquation(time,CRTE[0].N)
	#	for i, crte in enumerate(CRTE):		
	#		MTTE.EvalDiffCoeff(time, crte)		#self consistent case
	#		CRTE[i].SetupEquation(time,MTTE.D)	#self consistent case
	#		#CRTE.EvalDiffCoeff(time)		#Bohm case
	#		#CRTE.SetupEquation(time,CRTE.D)	#Bohm case
	
	#	#read shock speed
	#	HDTE.ReadRpc2Rnorm()
	else:
		time = 0.0
	#Insert 0.0 in timeslist: starting time for HD-calculation
	if time < min(timesout):
		timesout=insertnp(timesout,0,0)
	
	#Write MHD-initial conditions
	
        HDTE.WriteMhd(HDTE.Mhd_full,HDTE.ConvTime(HDTE.g_time()),[0],SP.HDOUTFN)

	#Values for MFTE
        timeInitMF = MFTE.timestart

	#Propagate till MFTE-starting time
	HDTE.DoTimeIntervall(time,timeInitMF)
	time 	 = timeInitMF
	timeStep = MFTE.AdaptTimeStep(time,SP.timeslist)

	#Setting up MFTE
	MFTE.SetupVariable(timeInitMF,MFTE.mfIntProf,MFTE.mfInitCon,MFTE.inFileName)
	MFTE.StartBoundCon(timeInitMF)
	MFTE.SetupEquation(timeInitMF)

	#Loop till starting time of CRs
	while time < timeInitCR:
		MFTE.WriteVariable(time,timesOut=SP.timeslist,outFileName=SP.MFOUTFN)
		MFTE.DoOneTimeStep(time,timeStep)
		HDTE.DoTimeIntervall(time,round(time+timeStep,5))
		#Updating MFTE-equations
		MFTE.Br.updateOld()
		MFTE.Bt.updateOld()
		MFTE.SetupBoundCon(round(time+timeStep,5))
		MFTE.SetupEquation(round(time+timeStep,5))

		time = time + timeStep

	if time == timeInitCR:
		if parallel.procID == 0: 
			print "\nsolver: Great, HDTE and MFTE arrived at the starting time of CRTE...lets go\n"

	else:
		if parallel.procID == 0:
			print "\nsolver: Oops, HDTE and MFTE arrived at different times...runs will be terminated here, but don't get desperate - maybe you will be lucky next time\n\t time=", time, " ,timeInitCR=",timeInitCR
		sys.exit(0)	
		

	for crte in CRTE:
		crte.EvalDiffCoeff(time)		#evaluates Bohm diff.coeff.using internal formulae
		crte.SetupEquation(time,crte.D)

	#Fix initial conditions for MTTE
	MTTE.tecf.MFB=MFTE.B.globalValue
	MTTE.SetupVariable(time,MTTE.inFileName)
	MTTE.SetupBoundCon(time)
	MTTE.SetupEquation(time,CRTE[0].N)
	if SP.timecont == None:
			MTTE.Ew_int   = MTTE.Ew_u.globalValue.reshape((MTTE.nksteps,MTTE.nrsteps))

	#Calculation with CR-spectra
	timeStep = min(	MTTE.AdaptTimeStep(time,SP.timeslist),\
			CRTE[0].AdaptTimeStep(time,SP.timeslist),\
			MFTE.AdaptTimeStep(time,SP.timeslist) )


	#Directory names for Intermediate turbulence outputs(growth rate, CFL-condition, etc.)
	MTDIR="/".join(SP.MTOUTFN.split("/")[:-1])
	GRATEFNAME= MTDIR+"/GRRAW"
	CFLRFNAME = MTDIR+"/CFLRRAW"
	CFLKFNAME = MTDIR+"/CFLKRAW"
	DNDXFNAME = MTDIR+"/DNDXRAW"
	InPNAME   = MTDIR+"/InP_hist"
	MTTE.WriteVariableInit(time,outFileName=SP.MTOUTFN)

	#Set scaling parameter to apropiate value
#	CRTE.tecf.SetSrcSclPar(1.0)

	#Setup equations
	MTTE.tecf.MFB=MFTE.B.globalValue		
	for i, crte in enumerate(CRTE):	
		CRTE[i].tecf.MFB=MFTE.B.globalValue
		CRTE[i].tecf.SetSrcSclPar(CRTE[i].ScP(time,SP.injsclindex))
	#MTTE.EvalDiffCoeff(time)
	#for i, crte in enumerate(CRTE):
		MTTE.EvalDiffCoeff(time, crte)		
		CRTE[i].SetupEquation(time,MTTE.D)
		#CRTE.SetupEquation(time,CRTE.D) #to comment

	#Write initial values
	MFTE.WriteVariable(time,timesOut=SP.timeslist,outFileName=SP.MFOUTFN+"_raw")
	for i, crte in enumerate(CRTE):	
		crte.WriteVariable(time,timesOut=SP.timeslist,outFileName=SP.CROUTFN[i])
	MTTE.WriteVariable(time,timesOut=SP.timeslist,outFileName=SP.MTOUTFN)
	MTTE.WriteMfField(time,timesOut=SP.timeslist,outFileName=SP.MFOUTFN+"_MT")
	HDTE.WriteMhd(HDTE.Mhd_full,HDTE.ConvTime(HDTE.g_time()),SP.timeslist,SP.HDOUTFN)
	#CRTE[0].tecf.WriteMHDData((CRTE[0].tecf.B,),"TRUE",MTTE.nrsteps,MTTE.rmax,time,timesOut=SP.timeslist,outFileName=SP.MFOUTFN)
	CRTE[0].tecf.WriteMHDData(tuple((CRTE[0].tecf.B, CRTE[0].tecf.nh, CRTE[0].tecf.nhe, CRTE[0].tecf.nc, CRTE[0].tecf.nox, CRTE[0].tecf.nfe, CRTE[0].tecf.ne, CRTE[0].tecf.Tg)), MTTE.nrsteps,MTTE.rmax,time,timesOut=SP.timeslist,outFileName=SP.MFOUTFN,MHDOutFile=SP.MHDOUTFN)
	
	#CR feedback
	if HDTE.CR_feedback:	
		HDTE.SetCrSourceTerms(CRTE[0].N,CRTE[0].mesh_rp,CRTE[0].npsteps,CRTE[0].nrsteps)

	while time < timeStop:
		#Printing logged informations
		for i, crte in enumerate(CRTE):		
			log_description,log_values = GetLogValue([CRTE[i],MTTE,HDTE],time)
			if parallel.procID == 0:
				print "\nsolver: Print values for ", crte.tecf.crSpecies
                                print "\n"
                        PrintLogValues(log_description,log_values,time,SP,crte.tecf.crSpecies)
		
		#Test for self-consistent magnetic field
		for i, crte in enumerate(CRTE):
			CRTE[i].tecf.B_TURB = MTTE.dB_A

		timeNext=round(time+timeStep,5)

		MTTE.DoOneTimeStep(time,timeStep)
		for i, crte in enumerate(CRTE):
			CRTE[i].DoOneTimeStep(time,timeStep)
		MFTE.DoOneTimeStep(time,timeStep)


		for i, crte in enumerate(CRTE):
			CRTE[i].N.updateOld()
		MTTE.Ew_u.updateOld()
		MFTE.Br.updateOld()
		MFTE.Bt.updateOld()

		if HDTE.CR_feedback:	
			HDTE.SetCrSourceTerms(CRTE[0].N,CRTE[0].mesh_rp,CRTE[0].npsteps,CRTE[0].nrsteps)
                        if parallel.procID == 0:
				print "\nsolver: feedback is on!!! are you crazy? \n"

		HDTE.DoTimeIntervall(time,timeNext)
		
		time=round(time+timeStep,5)

		#Write Variables
		MFTE.WriteVariable(time,timesOut=SP.timeslist,outFileName=SP.MFOUTFN+"_raw")
		for i, crte in enumerate(CRTE):		
			CRTE[i].WriteVariable(time,timesOut=SP.timeslist,outFileName=SP.CROUTFN[i])
		MTTE.WriteVariable(time,timesOut=SP.timeslist,outFileName=SP.MTOUTFN)
		MTTE.WriteMfField(time,timesOut=SP.timeslist,outFileName=SP.MFOUTFN+"_MT")
		HDTE.WriteMhd(HDTE.Mhd_full,HDTE.ConvTime(HDTE.g_time()),SP.timeslist,SP.HDOUTFN)
		#CRTE[0].tecf.WriteMHDData((CRTE[0].tecf.B,),"TRUE",MTTE.nrsteps,MTTE.rmax,time,timesOut=SP.timeslist,outFileName=SP.MFOUTFN)
		CRTE[0].tecf.WriteMHDData(tuple((CRTE[0].tecf.B, CRTE[0].tecf.nh, CRTE[0].tecf.nhe, CRTE[0].tecf.nc, CRTE[0].tecf.nox, CRTE[0].tecf.nfe, CRTE[0].tecf.ne, CRTE[0].tecf.Tg)), MTTE.nrsteps,MTTE.rmax,time,timesOut=SP.timeslist,outFileName=SP.MFOUTFN,MHDOutFile=SP.MHDOUTFN)

		for i, crte in enumerate(CRTE):
				CRTE[i].tecf.SetSrcSclPar(CRTE[i].ScP(time,SP.injsclindex))

		#At each time step just diffusion and growth terms are updated
		MFTE.SetupBoundCon(time)
		MFTE.SetupEquation(time)
		MTTE.tecf.MFB=MFTE.B.globalValue
		for i, crte in enumerate(CRTE):		
			CRTE[i].tecf.MFB=MFTE.B.globalValue
			MTTE.EvalDiffCoeff(time,crte)		#self consistent case
			CRTE[i].SetupDiffTerm(time,MTTE.D)	#self consistent case
			#CRTE.EvalDiffCoeff(time)		#Bohm case
			#CRTE.SetupDiffTerm(time,CRTE.D)	#Bohm case
		MTTE.EvalGrowthCoeff(time,CRTE[0].N)
		#p_r  = MTTE.P_ratio(time)
		#dB   = MTTE.dB(time)
		if parallel.procID == 0: print "\n"

		#Update Full equations for steps of full-years
		if True: #round(time, 3) % 1.0 == 0.00:	#Not working properly for early evolution
			for i, crte in enumerate(CRTE):
				CRTE[i].tecf.SetSrcSclPar(CRTE[i].ScP(time,SP.injsclindex))
			MTTE.SetupEquation(time,CRTE[0].N)
			for i, crte in enumerate(CRTE):		
				MTTE.EvalDiffCoeff(time, crte)		#self consistent case
				CRTE[i].SetupEquation(time,MTTE.D)	#self consistent case
				#CRTE.EvalDiffCoeff(time)		#Bohm case
				#CRTE.SetupEquation(time,CRTE.D)	#Bohm case
	
			#Adapt time-step
			if HDTE.CR_feedback:
				timeStep=0.1
			else:
				timeStep=min(	MTTE.AdaptTimeStep(time,SP.timeslist),\
						CRTE[0].AdaptTimeStep(time,SP.timeslist),\
						MFTE.AdaptTimeStep(time,SP.timeslist))

		if parallel.procID == 0: print "\n"
			
	HDTE.EndSimulation()

