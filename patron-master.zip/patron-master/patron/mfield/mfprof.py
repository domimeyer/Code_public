######################################################################################
### RATPaC - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  mfprof.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2010 - 2015
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v2.0.0: adjusted to be used in patron as a module.
#v2.1.0: added Sedov profiles for MF
#v2.1.1: adding small MF value to Sedov internal region to avoid BKG CRs accumulation (probably not worthy -> commented in following version)
#v2.2.0: adding damped profiles for MF
#v2.3.0: version control added
#v2.3.1: damping-length parameter added, 

__vesion__='2.3.1'

from patron.snrmod.snrevo import evovik as evovik
from patron.snrmod.snrevo import evocox as evocox
from patron.snrmod.snrevo import evotru as evotru

from scipy import interpolate

from numpy import *

c    = 3.0e10
pi   = 3.1415926
pc   = 3.08e18
E51  = 1.0

BCR  = sqrt(11.0)       #compression of magnetic field 
SCF  = 0.05		#MF decay scale in front of FS
SCR  = 0.05		#MF decay scale in front of RS

ksi  = 0.04		#CR acceleration efficiency take approx.4%

Bins = 1.0e-7		#MF inside ejecta
ld   = 0.01		#damping length
SCBIN= 4.0


R_sun = 6.957e+10       #Solar radius in cm

B0 = 1e-6 #DUMMY

#C=0.03
#AMP=0
#R_Z1=7.0*pc
#R_Z2=15.5*pc
#RWSH=16.0*pc
#BISM=0.000005		#MF in the ISM
#BSHL=0.000005		#MF in the wind-blown shell
#B_ST=100.0		#MF at the star surface in G
#R_ST=5.6e11		#Radius of the star
#BJZ1Z2=sqrt(11.0)	#Jump in MF at the transition from ZONE1 to ZONE2



### SNTYPE-DEPENDANT PARAMETERS as they were set in setpar for mfprof. ###
# T2, type1c:
# mfprof.B_ST= 100.0
# mfprof.R_ST= 5.6e11
# mfprof.BJZ1Z2 = 11.0**0.5
# T2, type2p:
# mfprof.B_ST= 1.0
# mfprof.R_ST= 4.2e13	
# mfprof.BJZ1Z2 = 11.0**(-0.5)
#
#mfprof.BSHL      = simpar.mfofismna
#mfprof.R_Z1      = evovik.R_Z1
#mfprof.R_Z2      = evovik.R_Z2
#mfprof.RWSH      = evovik.RWSH
#mfprof.Bism      = mfprof.Bism_T2
#




def Bism_T1(r,t,snr):							#type I
	return BISM

# def Bism_T2(r,t,snr):							#type II
# 	R=r*evovik.R_ED(t,snr)
# 	B_Z1=B_ST*R_ST/R
# 	B_Z2=BJZ1Z2*B_ST*R_ST/R_Z1
# 	B_CSM=where(R<=R_Z1,B_Z1,B_Z2)
# 	B_SHL=where(R<=R_Z2,B_CSM,BSHL)
# 	return where(R<=RWSH,B_SHL,BISM)

def Bism_T2(r,t,snr):							#magnetic field in the core-collapse scenario (wind_blown bubble + ISM). We ignore the shell. Transition from the wind-zone to ISM is immediate

        R_star = starrad * R_sun #radius of the progenitor star in cm. 
        B_star = mfstarsurf #magnetic field at the surface of the star in G.
        RWSH = windbubrad * pc #radius of the wind bubble in cm
        
 	#R=r*evovik.R_ED(t,snr)
        #R=r*evocox.R(t)
        R=r*evotru.R(t)
        B_wind = B_star * R_star/R

        #print "BLAAAAAAAH: ", RWSH, R, R_star, B_wind
 	return where(R<=RWSH,B_wind,BISM)

# def Bism_T2(r,t,snr):							#B-field as 
# 	Rsh = evovik.R_ED(3320,snr)
#         R=r*evovik.R_ED(t,snr)
# 	return where(R<=Rsh,BISM*Rsh/R,BISM)

def B0_HAND_HD(t,snr):	
	return BSH/BCR

def B0_HAND_AN(t,XXX=0):		
	return BSH/BCR

def B0_AMPF(t,snr):							#B0 HAND-SET VIA AMPLIFICATION FACTOR, HYDRO
 	return AMP*Bism(1,t,snr)


### THESE TWO BELOW RETURN THE SAME THING - REPLACED BY ONE

# def B0_AMPF_HD(t,snr):							#B0 HAND-SET VIA AMPLIFICATION FACTOR, HYDRO
# 	return AMP*Bism(1,t,snr)

# def B0_AMPF_AN(t,snr):						#B0 HAND-SET VIA AMPLIFICATION FACTOR, ANALYTIC
# 	#return AMP*BISM
#         return AMP*Bism(1,t,snr)

#####################################
# ALL THESE RESONANT OR NON-RESONANT AMPLIFICATION ARE REDUNDANT?
##################################
        
def B0_NAMP_HD(t,snr):							#NON-RESONANT AMPLIFICATION SATURATED VALUE, HYDRO
	rho=evovik.rho_ism(1,t,snr)
	Vsh=evovik.D_ED(t,snr)
	Bamp=(2.0*pi*rho*(Vsh**3/c)*ksi)**(0.5)
	if Bamp > Bism(1,t,snr):
		return Bamp
	else:
		return Bism(1,t,snr)

def B0_NAMP_AN(t,XXX=0):						#NON-RESONANT AMPLIFICATION SATURATED VALUE, ANALYTIC
	rho=evocox.rho0()
	Vsh=evocox.D(t)
	Bamp=(2.0*pi*rho*(Vsh**3/c)*ksi)**(0.5)
	if Bamp > BISM:
		return Bamp
	else:
		return BISM

def B0_RAMP_HD(t,snr):							#RESONANT AMPLIFICATION SATURATED VALUE, HYDRO
	rho=evovik.rho_ism(1,t,snr)
	Vsh=evovik.D_ED(t,snr)
	Bamp=(4.0*Vsh*Bism(1,t,snr)*ksi*(pi*rho)**0.5)**0.5
	if Bamp > Bism(1,t,snr):
		return Bamp
	else:
		return Bism(1,t,snr)

def B0_RAMP_AN(t,XXX=0):						#RESONANT AMPLIFICATION SATURATED VALUE, ANALYTIC
	rho=evocox.rho0()
	Vsh=evocox.D(t)
	Bamp=(4.0*Vsh*BISM*ksi*(pi*rho)**0.5)**0.5
	if Bamp > BISM:
		return Bamp
	else:
		return BISM

########################################################################


def B_con(t,snr):
	return BCR*B0(t,snr)

def B_fs_d_rho_FS(r,t,snr,RRS):
	ru=r-RRS
	rrs=array([RRS])
	B0rs=B0(t,snr)*(evovik.nh_fs(rrs,t,snr)[0]/evovik.nh_fs_sh(t,snr))
	B1=B0rs*exp((1./(SCR*RRS))*ru*log(B0rs/Bins))
	B2=BCR*B0(t,snr)*(evovik.nh_fs(r,t,snr)/evovik.nh_fs_sh(t,snr))
	Bd=where(r<RRS,B1,B2)		
	return where(Bd>Bins,Bd,Bins)

def B_fs_d_rho_RS(r,t,snr,RRS):
	ru=r-RRS
	rrs=array([RRS])
	B0rs=B0(t,snr)*(evovik.nh_rs(rrs,t,snr)[0]/evovik.nh_fs_sh(t,snr))
	B1=B0rs*exp((1./(SCR*RRS))*ru*log(B0rs/Bins))
	B2=BCR*B0(t,snr)*(evovik.nh_rs(r,t,snr)/evovik.nh_fs_sh(t,snr))
	Bd=where(r<RRS,B1,B2)		
	return where(Bd>Bins,Bd,Bins)
	
def B_fs_u_rho(r,t,snr,RFS):
	ru=r-RFS
	RSCF=RFS+SCF*RFS
	B0fs=B0(t,snr)
	Bup=B0fs*exp(-(1./(SCF*RFS))*ru*log(B0fs/Bism(RSCF,t,snr)))
	return where(r<=RSCF,Bup,Bism(r,t,snr))

def B_fs_d_pre(r,t,snr,RRS):
	B0rs=(1.0/BCR)*sqrt(C*8.0*pi*evovik.Pg_rs_sh(t,snr))
	ru=r-RRS
	B1=B0rs*exp((1./(SCR*RRS))*ru*log(B0rs/Bins))
	B2=sqrt(C*8.0*pi*evovik.Pg_fs(r,t,snr))
	Bd=where(r<RRS,B1,B2)			
	return where(Bd>Bins,Bd,Bins)

def B_fs_u_pre(r,t,snr,RFS):
	ru=r-RFS
	RSCF=RFS+SCF*RFS
	B0fs=(1.0/BCR)*sqrt(C*8.0*pi*evovik.Pg_fs_sh(t,snr))
	Bup=B0fs*exp(-(1./(SCF*RFS))*ru*log(B0fs/Bism(RSCF,t,snr)))
	return where(r<=RSCF,Bup,Bism(r,t,snr))

def B_fs_d_rho_AN(r,t):
	return BCR*B0(t)*(evocox.rho(r,t)/evocox.rho(1.0,t))

def B_fs_u_rho_AN(r,t):
	snr=0
	RFS=1.0
	ru=r-RFS
	B0fs=B0(t)
	Bup=B0fs*exp(-(1./(SCF*RFS))*ru*log(B0fs/BISM))
	return where(Bup>BISM,Bup,BISM)

def B_fs_d_pre_AN(r,t):
	return where(r<=1.0,sqrt(C*8.0*pi*evocox.P(r,t)),0.0)

def B_fs_u_pre_AN(r,t):
	snr=0
	RFS=1.0
	ru=r-RFS
	B0fs=(1.0/BCR)*sqrt(C*8.0*pi*evocox.P(1,t))
	Bup=B0fs*exp(-(1./(SCF*RFS))*ru*log(B0fs/BISM))
	return where(Bup>BISM,Bup,BISM)


def B_fs_d_sed(r,t):
	a   = evocox.a(r)
	Br0 = B0(t)/1.73205
	Bt0 = B0(t)/1.73205
	Br  =     Br0*(a/r)**2
	Bt  = 4.0*Bt0*(r/a)*evocox.rho_profile(r)
	return sqrt(Br**2 + 2.0*Bt**2)
	#B = sqrt(Br**2 + 2.0*Bt**2)
	#return where(B>=3e-6,B,3e-6)

def B_fs_u_sed(r,t):
	RFS=1.0
	ru=r-RFS
	B0fs=B0(t)
	Bup=B0fs*exp(-(1./(SCF*RFS))*ru*log(B0fs/BISM))
	return where(Bup>BISM,Bup,BISM)


def B_fs_d_dam_AN(r,t):
#	a   = evocox.a(r)
        snr = 0
	B0fs=B0(t,snr)
	return SCBIN*BISM + (BCR*B0fs - SCBIN*BISM)*exp(-(1.0-r)/ld)

def B_fs_u_dam_AN(r,t):
	RFS=1.0
	ru=r-RFS
        snr = 0
	B0fs=B0(t,snr)
	Bup=B0fs*exp(-(1./(SCF*RFS))*ru*log(B0fs/BISM))
	return where(Bup>BISM,Bup,BISM)


def B_fs_d_dam_FS(r,t,snr,RRS):
	B0fs=B0(t,snr)
	return SCBIN*BISM + (BCR*B0(t,snr) - SCBIN*BISM)*exp(-(1.0-r)/ld)

def B_fs_u_dam(r,t,snr,RFS):
	ru=r-RFS
	RSCF=RFS+SCF*RFS
	B0fs=B0(t,snr)
	Bup=B0fs*exp(-(1./(SCF*RFS))*ru*log(B0fs/Bism(RSCF,t,snr)))
	return where(r<=RSCF,Bup,Bism(r,t,snr))

mfevo=0

def B_fs_d_tra(r,t):
	TSTEPS=len(mfevo)
	RSTEPS=len(r)
	mfrt=arange(RSTEPS,dtype=float)
	ti=arange(TSTEPS,dtype=float)
	mfti=ndarray(shape=(TSTEPS,RSTEPS),dtype=float)
	for i in xrange(TSTEPS):
		mfti[i]=interpolate.interp1d(mfevo[i].R,mfevo[i].B, bounds_error=False, fill_value=mfevo[i].B[-1])(r)
		ti[i]=mfevo[i].t
	mftir=mfti.transpose()
	mfrt=interpolate.interp1d(ti,mftir)(t)
	return mfrt

def B_fs_u_tra(r,t,snr,RFS):
	ru=r-RFS
	RSCF=RFS+SCF*RFS
	B0fs=B0(t,snr)
	Bup=B0fs*exp(-(1./(SCF*RFS))*ru*log(B0fs/Bism(RSCF,t,snr)))
	return where(r<=RSCF,Bup,Bism(r,t,snr))

def B_fs_u_tra_AN(r,t):
	snr=0
	RFS=1.0
	ru=r-RFS
	B0fs=B0(t,snr)
	Bup=B0fs*exp(-(1./(SCF*RFS))*ru*log(B0fs/BISM))
	return where(Bup>BISM,Bup,BISM)

###analytical case:
def v_av_fs_u_mfcon_AN(r,t):
	return B0(t)/sqrt(4.0*pi*evocox.rho_ism(r,t))	

def v_av_fs_u_mfrho_AN(r,t):
	return B_fs_u_rho_AN(r,t)/sqrt(4.0*pi*evocox.rho_ism(r,t))

def v_av_fs_u_mfpre_AN(r,t):
	return B_fs_u_pre_AN(r,t)/sqrt(4.0*pi*evocox.rho_ism(r,t))

def v_av_fs_u_mftra_AN(r,t):
	return B_fs_u_tra_AN(r,t)/sqrt(4.0*pi*evocox.rho_ism(r,t))

	
###Alfven velocity upstream of the FS of the SNR###########
def v_av_fs_u_mfcon(r,t,snr,XXX):
	return B0(t,snr)/sqrt(4.0*pi*evovik.rho_ism(r,t,snr))

def v_av_fs_u_mfrho(r,t,snr,RFS):
	return B_fs_u_rho(r,t,snr,RFS)/sqrt(4.0*pi*evovik.rho_ism(r,t,snr))

def v_av_fs_u_mfpre(r,t,snr,RFS):
	return B_fs_u_pre(r,t,snr,RFS)/sqrt(4.0*pi*evovik.rho_ism(r,t,snr))

def v_av_fs_u_mftra(r,t,snr,RFS):
	return B_fs_u_tra(r,t,snr,RFS)/sqrt(4.0*pi*evovik.rho_ism(r,t,snr))


###Alfven velocity upstream of the RS of the SNR###########
def v_av_rs_u_mfcon_FS(r,t,snr,XXX):
	return B0(t,snr)/sqrt(4.0*pi*evovik.rho_fs(r,t,snr))

def v_av_rs_u_mfcon_RS(r,t,snr,XXX):
	return B0(t,snr)/sqrt(4.0*pi*evovik.rho_rs(r,t,snr))

def v_av_rs_u_mfrho_FS(r,t,snr,RRS):
	return B_fs_d_rho_FS(r,t,snr,RRS)/sqrt(4.0*pi*evovik.rho_fs(r,t,snr))

def v_av_rs_u_mfrho_RS(r,t,snr,RRS):
	return B_fs_d_rho_RS(r,t,snr,RRS)/sqrt(4.0*pi*evovik.rho_rs(r,t,snr))

def v_av_rs_u_mfpre_FS(r,t,snr,RRS):
	return B_fs_d_pre(r,t,snr,RRS)/sqrt(4.0*pi*evovik.rho_fs(r,t,snr))

def v_av_rs_u_mfpre_RS(r,t,snr,RRS):
	return B_fs_d_pre(r,t,snr,RRS)/sqrt(4.0*pi*evovik.rho_rs(r,t,snr))

def v_av_rs_u_mftra_FS(r,t,snr,XXX):
	return B_fs_d_tra(r,t)/sqrt(4.0*pi*evovik.rho_fs(r,t,snr))

def v_av_rs_u_mftra_RS(r,t,snr,XXX):
	return B_fs_d_tra(r,t)/sqrt(4.0*pi*evovik.rho_rs(r,t,snr))
#############################################



#def B0_NAMP_RS(t,snr):		#NON-RESONANT AMPLIFICATION, HYDRO AT REVERSE SHOCK? doesn't work properly, not used now
#	rho=evovik.rho_rs_sh(t,snr)
#	Vsh=evovik.D_RS(t,snr)
#	Bamp=(2.0*pi*rho*(Vsh**3/c)*ksi)**(0.5)
#	if Bamp > Bins:
#		return Bamp
#	else:
#		return Bins
#	return Bamp


