######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  mttran.py
# Author: Robert Brose <robert.brose@desy.de>, 2013 - 2018								
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2013 - 2015
# 
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#new version tracking start with 2.0.0; the last version of pspec2d is 19.2
#v2.0.0: transport equation object for turbulence is implemented
#v2.0.1: some changes from Igor to improve performance and readability
#v2.0.2: corrections of some introduced errors
#v2.0.3: changes required for coupling of turbulence TE and cosmic-ray TE
#v-----:
#v2.2.0: compliant with patron_v2.2.0 and later; renamed to mttran [(m)agnetic (t)urbulence (tran)sport]
#v2.2.2: optional limitting of growth rate, error of Bells paper corrected
#v2.3.0: version control added
#v2.4.0: merging changes: now all magnetic field profiles supported, correctet Inital conditions and output, ELectrons supported by reading Turbulence files(right now just for given times),some solver functions added, new ScP scaling: TB level dependent, minor opimisations,switching to one equation without alfven speed
#v2.4.1: Adaptive time step improved
#v2.4.2: Added GetLogValues and helper functions therefore

__vesion__='2.4.2'

import sys
import time as modtime

import fipy as fipy
from fipy.tools.numerix import *
from fipy.tools import parallel
from scipy import interpolate
from scipy import integrate
from numpy import arange
from numpy import savetxt
from numpy import size
from numpy import round
from numpy import sqrt
from numpy import cbrt
from numpy import amax
from numpy import amin
from numpy import nan

from inspect import currentframe, getframeinfo

#constants
yr  	= 3.156e+7						#time step (in years) in seconds
c 	= 2.998e10						#speed of light in cm/s
m_e 	= 9.109e-28						#electron mass in grams
p_e 	= m_e*c							#electron momentum
m_p 	= 1.673e-24						#proton mass in grams
p_p 	= m_p*c	 						#proton momentum
q 	= 4.8e-10						#electron charge in statcoulons
Bmax 	= 10#400e-6						#maximum B-field(REPLACE later with aktual field Value!)
kB	= 1.3807e-16						#Boltzmann constant
h      	= 6.6260755e-27						#Planck constant
eV     	= 1.6021772e-12						#electron Volt 	
parsec 	= 3.08567758e18						#parsec in cgs 
mu      = 13./21.


#steering parameter
c_comp = 1.0							#compression pre-factor

class Buffer:
	def __init__(self, TIME, FIELD):
		self.TIME = TIME
		self.FIELD = FIELD	

class TransportEquation:
#	def __init__(self,nrsteps,npsteps,nksteps,rmax,pmax,timeInit,shGeometry,HDDAT,N,InitTurb):
	def __init__(self,rStepsNum,pStepsNum,kStepsNum,rCoordMax,pCoordMax,timeInit,shockGeom,mtInitCon,inFileName,teCoeffFuncs,crNumDensity,setpar):
		if parallel.procID == 0: print "mttran: initializing transport equations object..."
		self.setpar	= setpar	
		self.inFileName = inFileName

		self.pm	     = 0		
		
		self.rshw    = 1.0
		
#		self.timeInit = timeInit
		#initial time has to agree with Plutos initial time: check if simulation is continued, otherwise Pluto is at time=0
		if setpar.timecont != None:
			self.timeInit = float(setpar.timecont)
			self.timeInit_old = setpar.timeslist[0]
		elif setpar.usesedsol == 5:
			self.timeInit = 0
		else:
			self.timeInit = timeInit
	
		self.tecf     = teCoeffFuncs
		self.N        = crNumDensity

		#self.tecf.B = self.B								#TEST CASE - REMOVE LATER!
		#if parallel.procID == 0: print "mttran: magnetic field: ", self.tecf.B([0.5],self.timeInit), self.tecf.B([1.5],self.timeInit)
		if parallel.procID == 0: print "mttran: shock geometry spherically-symmetric"
		if shockGeom != "SS":
			if parallel.procID == 0:			
				print "mttran: geometry not suported!"
			sys.exit(0)

                if self.setpar.MTAPPLIED == "ANALYTIC" or self.setpar.MTAPPLIED == "WHITE":
                        
                        self.AdaptTimeStep 	= self.AdaptTimeStepDummy
                        self.WriteVariableInit 	= self.WriteVariableInitDummy
                        self.EvalDiffCoeff 	= self.EvalDiffCoeffAnalytic
                        self.WriteVariable 	= self.WriteVariableDummy
                        self.WriteMfField 	= self.WriteMfFieldDummy
                        self.DoOneTimeStep 	= self.DoOneTimeStepDummy
                        self.EvalGrowthCoeff 	= self.EvalGrowthCoeffDummy
                        self.SetupEquation 	= self.SetupEquationDummy
                        self.dB_A 		= self.dB_ADummy
                        self.PrepareTurbData 	= self.PrepareTurbDataDummy
			self.SetupBoundCon 	= self.SetupBoundConDummy
			self.SetupVariable	= self.SetupVariableDummy
                        
                elif self.setpar.MTAPPLIED == "NUMERIC":
                        
                        if   self.tecf.crSpecies == "PR":
                                self.pm=p_p
                                self.DoOneTimeStep = self.DoOneTimeStep_PR
                                self.SetupEquation = self.SetupEquation_PR
                                self.EvalGrowthCoeff = self.EvalGrowthCoeff_PR
                                self.PrepareTurbData = self.PrepareTurbData_PR
                        elif self.tecf.crSpecies == "EL":
                                self.pm=p_e
                                self.DoOneTimeStep = self.DoOneTimeStep_EL
                                self.SetupEquation = self.SetupEquation_EL
                                self.EvalGrowthCoeff = self.EvalGrowthCoeff_EL
                                self.PrepareTurbData = self.PrepareTurbData_EL
                        else:
                                if parallel.procID == 0:
                                        print "mttran: unsuported particle type!"
                                sys.exit(0)		


				
		self.nrsteps = rStepsNum
		self.npsteps = pStepsNum
		self.nksteps = kStepsNum
		self.rmax    = rCoordMax
		self.pmax    = pCoordMax
		self.dr      = self.rmax/float(self.nrsteps)
		self.dp      = self.pmax/float(self.npsteps)
		
		self.kmax = log(q*Bmax/(exp(-self.pmax/4.)*p_p*c)) #always proton mass
		self.kmin = log(1/(25*parsec)) # log(q*3e-6/(exp(self.pmax)*self.pm*c)) #/4 # 
		self.dk = (self.kmax-self.kmin) / float(self.nksteps)
		
		if parallel.procID == 0: print "mttran: kmax: ", self.kmax, " kmin: ", self.kmin, " dk: ",self.dk
		
		self.mesh_rk = fipy.Grid2D(dx = self.dr, dy = self.dk, nx = self.nrsteps, ny = self.nksteps) + ((self.dr/2.,),(+self.kmin,))
		self.mesh_rp = self.N.mesh
		
		self.rc,self.pc = self.N.mesh.cellCenters
		self.rf,self.pf = self.N.mesh.faceCenters

		self.rc1,self.kc = self.mesh_rk.cellCenters
		self.rf1,self.kf = self.mesh_rk.faceCenters
		self.expkc = exp(self.kc)
		self.expkf = exp(self.kf)		
		
		cc_rk = self.mesh_rk.cellCenters
		self.cc_rk_1_l = cc_rk[1]
		cc_rp = self.mesh_rp.cellCenters
		self.cc_rp_1_l = cc_rp[1]
		self.cc_rk_0 = cc_rk.globalValue[0]
		self.cc_rk_1 = cc_rk.globalValue[1]
		self.cc_rp_0 = cc_rp.globalValue[0]
		self.cc_rp_1 = cc_rp.globalValue[1]

		
		self.Rc      = self.R(self.rc1)
		self.Rf      = self.R(self.rf1)
		self.Jc      = self.J(self.rc1,self.dr)
		self.Jf      = self.J(self.rf1,self.dr)
		
		self.Left    = self.mesh_rk.facesLeft
		self.Right   = self.mesh_rk.facesRight
		self.Bottom  = self.mesh_rk.facesBottom
		self.Top     = self.mesh_rk.facesTop
		
		self.EwBOHM  = self.EwBohmlnrs(self.rc1,self.kc,self.timeInit)
		self.Dc      = fipy.CellVariable(mesh=self.mesh_rp, value=0.0)
		self.D       = fipy.FaceVariable(mesh=self.mesh_rp, value=0.0) #Incompatible to older version
		self.N_init  = fipy.CellVariable(mesh=self.mesh_rp, value=0.0)
		self.N_init.setValue(self.N)
		
		if   (mtInitCon == "EXP05"):
			self.NORM  = 1.0e28
			self.delta = 1./2.
		elif (mtInitCon == "KOLM"):
			self.NORM  = 1.0e29
			self.delta = 1./3.
		else:
			if parallel.procID == 0:
				print "mttran: unkonwon initial condition! Run aborted!"
			sys.exit(0)

		self.NORM = 1e27 #Enhanced for stability purposes, kolm only

		#Cascading switch
		self.s_cas  = 1.0 #setpar.CASSWITCH #1e-6

		#Buffer variables for magnetic field values
		self.Buffer_B	   = Buffer(0,self.rc)
		
		if setpar.timecont != None and self.setpar.MTFILEOUT == self.setpar.MTFILEINP:
			File = str(self.setpar.Rundir)+"/TURBULENCE/"+str(self.setpar.SHOCKTYPE)+"/"+str(self.setpar.MTFILEOUT)+"_U_"+str(self.timeInit_old) 
			try:
				f=open(File,"r")
				RPN=f.readlines()
				f.close()
			except IOError:
				if parallel.procID == 0: 
					frameinfo = getframeinfo(currentframe())
					print "mttran(",frameinfo.lineno,"): no file found:",File
				sys.exit(0)
			if parallel.procID == 0: print "mttran: reading...", File
			LEN=len(RPN)-2
			NN=arange(LEN,dtype=float)
			rr1=arange(LEN,dtype=float)
			for i in range(0,LEN):
				(rrr,ppp,NNN)=RPN[i+2].split()
				NN[i]=float(NNN)
				rr1[i]=float(rrr)
			try:
				File = str(self.setpar.Rundir)+"/MFPROFILES/"+str(self.setpar.MFFILEOUT)+str(self.timeInit_old)
				f=open(File,"r")
				RPN=f.readlines()
				f.close()
			except IOError:
				if parallel.procID == 0:
					frameinfo = getframeinfo(currentframe()) 
					print "mttran(",frameinfo.lineno,"): no file found:",File
				sys.exit(0)
			if parallel.procID == 0: print "mttran: reading...", File
			LEN=len(RPN)-1
			UB=arange(LEN,dtype=float)
			rr=arange(LEN,dtype=float)
			for i in range(0,LEN):
				(rrr,br,bt,bb)=RPN[i+1].split()
				UB[i]=float(bb)
				rr[i]=float(rrr)
			if parallel.procID == 0: print "mttran: reading is done"

			UB2 = interpolate.interp1d(rr,UB,bounds_error=False, fill_value=UB[-1])((rr1-1)**3.+1.)

			Ew_dummy = fipy.CellVariable(mesh=self.mesh_rk, name = "Ew_int", value=NN*UB2**2./(8*pi), hasOld=1)
			self.Ew_int   = Ew_dummy.globalValue.reshape((self.nksteps,self.nrsteps))	

	
		self.SetupVariable(self.timeInit,inFileName)
		self.SetupBoundCon(self.timeInit)
		self.PrepareTurbData()		
		
		self.Solver1 = fipy.DefaultAsymmetricSolver(tolerance=1e-20) 			# test afterwards if still needed

		##################################################################################
		#finding forked grid boundaries
		#fipy.getGlobalValue is easyest way to share information between different nodes
		self.CPU_p = range(parallel.Nproc)	#array will contain length of grid segment, p-grid
		self.CPU_k = range(parallel.Nproc)	#array will contain length of grid segment, k-grid
		for i in range(parallel.Nproc):		#filling in lengths
			self.CPU_p[i]=0
			self.CPU_k[i]=0
			if i==parallel.procID:		#contains zeros everywhere except at node position. there length of grid segment. information is "local" for each node
				self.CPU_p[i]=len(self.pc)
				self.CPU_k[i]=len(self.kc)
		mesh_node=fipy.Grid1D(dx=1, nx=parallel.Nproc, overlap=1)+(-0.5)	#mesh for cellvariables
		x=mesh_node.cellCenters
		CPU1_p=fipy.CellVariable(mesh=mesh_node, value=0.)	#creating variable
		CPU1_p.setValue(CPU1_p+self.CPU_p-4*self.nrsteps)	#filling with lengths. for CPU_p is "local" one needs to add CPU1_p. result contains length at each node. "-4*self.nrsteps" is compensation for overlap
		CPU1_k=fipy.CellVariable(mesh=mesh_node, value=0.)
		CPU1_k.setValue(CPU1_k+self.CPU_k-4*self.nrsteps)
		for i in range(parallel.Nproc):	#for grid positions are starting indexes needed-therefore summation of lengths of previous nodes
			self.CPU_p[i]=int(sum((CPU1_p.globalValue)[0:i]))
			self.CPU_k[i]=int(sum((CPU1_k.globalValue)[0:i]))	
		self.CPU_k[0]=0	#first node starts at 0
		self.CPU_p[0]=0
#		print "mttran: node- ", parallel.procID, self.CPU_p, CPU1_p, len(self.pc), self.CPU_k, CPU1_k, len(self.kc) 

		###################################################################################
		
		self.SetupEquation(self.timeInit,self.N)		
		
		if parallel.procID == 0:
			print "mttran: transport equations object is initialized."

		self.n_smooth = 30

		#Initial turbulence level - needed for magnetic field calculation
		if self.setpar.timecont == None:
			self.Ew_int   = self.Ew_u.globalValue.reshape((self.nksteps,self.nrsteps))


		self.dB_0     = 0
		self.dB_0     = self.dB(self.timeInit)	#Normalisation factor for getting generated field right
		self.sig_u_max= 0

		if parallel.procID == 0: 
			print "mttran: Turbulence seed field dB_0=", self.dB_0
		
	#coordinate transformations
	#########################################################
	def R(self,rstar):					#
		return (rstar-1.0)**3+1.0			#
								#
	#descrete jacobian; otherwise 0 at rstar = 1		#
	def J(self,rstar,dr):					#
		return 3.0*(rstar-1.0)**2+0.25*dr**2		#
	#########################################################
	#def B(self,r,t):
	#	return where(r>1.0, 5.0e-6, sqrt(11)*5.0e-6)
	def a(self,t):
		return self.tecf.Rsh(t)

#####################################################################################################################
	#Damping mechanisms												
	#Damping due to neutral-charged collisions							
	def Damp_nc(self,r,t):
		T = self.tecf.Tg(r,t)
		lnT = log10(T)										
		a = 1/self.tecf.nh(r,t)*(2*pi*kB*T*m_e/h**2.)**(3/2.)*exp(-13.6*eV/(kB*T))	#saha equation
		Ion = sqrt(a**2./4+a)-a/2.+(a>1e16) 						#ionisation fraction, a>1e16 catches nummerical error when Ion becomes 0 because of numerics
		return (1.675*lnT**2 - 6.615*lnT + 8.06)*1e-9*(self.tecf.nh(r,t)*(1-Ion))*yr	
	
	def Damp_ncrs(self,rstar,t):
		r=self.R(rstar)
		return self.Damp_nc(r,t)

	#Ion-cyclotron damping		
	def Damp_IC(self,r,k,t):				
		omega_p = q*sqrt(4.*pi*self.tecf.nh(r,t)/m_p)					
		C_eff = 1.0				
		return 0.5*self.tecf.Valf(r,t)*k**2.0*c/omega_p*C_eff #year in Valf included				
		#return where(r>self.rshw+self.dr/3.0, 1/2.0*self.tecf.Valf(r,t)*k**2.0*c/omega_p*yr*C_eff,0)		
	
	def Damp_IClnrs(self,rstar,lnk,t):
		r=self.R(rstar)
		k=exp(lnk)
		return self.Damp_IC(r,k,t)											
	########################################################################################################################
	#Shock ram pressure	
	def P_shock(self,t):
		P = 0.25*self.tecf.rho(array([1.0]),t)*self.tecf.Vsh(t)**2./yr**2.
		return P

	#cosmic ray pressure
	def P_cr(self):
		lnp = arange(0,self.pmax,self.dp)-self.pmax/4.
		p   = exp(lnp)
		zero= array([0.0])
		dp  = concatenate((diff(p),zero))
		Nsh = self.N.globalValue[where(self.cc_rp_0==1.0)]
		f   = Nsh*c*p/(p**2+1.0)**0.5
		crp = self.pm*(f*dp).sum()/3.
		return crp
	
	#pressure ratio
	def P_ratio(self,t):
		return self.P_cr()/self.P_shock(t)


	#Minimum k, until wich the turbulencespectrum is amplified
	def min_k(self,r,t):
		Ew_t  = self.Ew_u.globalValue.reshape((self.nksteps,self.nrsteps))
		k_t   = self.cc_rk_1.reshape((self.nksteps,self.nrsteps))	
		kmin  = zeros(self.nrsteps)
		rc    = arange(self.dr/2.,(self.nrsteps)*self.dr,self.dr)	
		for i in range(self.nrsteps):
			Ew = Ew_t[:,i]
			k  = k_t[:,i]
			try:
				index = where((gradient(Ew)[3:-1] > 0.)*(Ew[3:-1] > 1.01*self.Ew_int[3:-1,i]))[0][0]
			except:
				index = len(Ew)-1

			kmin[i] = k[index]
		#print kmin
		
		kmin2 = interpolate.interp1d(rc,kmin,bounds_error=False, fill_value=0)(r) #fill_value=0?
		
		return kmin2
		

	#generated magnetic field in muG(imideate downstream)
	def dB(self, time):
		Ew    = self.Ew_u.globalValue[where(self.cc_rk_0 == (1.0))]
		try:
			#index = where((gradient(Ew)[3:-1] > 0.)*(Ew[3:-1] > 1.01*self.Ew_int[3:-1,80]))[0][0]
			#index = where((gradient(Ew)[3:-1] > 0.))[0][0] #changed due to bug in center
			index = where((gradient(Ew)[20:-1] > 0.))[0][0] #Testing
		except:
			index = len(Ew)-1

		dB    = (sqrt(4*pi*(Ew[index:-1]*self.dk).sum()))
		return dB

	#generated magnetic field in G
	def dB_A(self,r, time):
		#Using buffered interpolation object
		if time == self.Buffer_B.TIME:
			Bfield = self.Buffer_B.FIELD(r)
			if any(isnan(Bfield)):
				if parallel.procID == 0:
					print "mttran(", parallel.procID, "): nan in buffered Bfield"
			return 	Bfield				
		else:
			if parallel.procID == 0:
				print "mttran: Unbuffered call of B_TURB. Length of array=", size(r), " time=", time

		#if not already buffered, calculate
		Ew_t  = self.Ew_u.globalValue.reshape((self.nksteps,self.nrsteps))
		if parallel.procID == 0:
			if any(isnan(Ew_t)):
				if parallel.procID == 0:
					print "mttran: nan in Ew_t"
		dB    = zeros(self.nrsteps)
		rc    = arange(self.dr/2.,(self.nrsteps)*self.dr,self.dr)	
		for i in range(self.nrsteps):
			Ew = Ew_t[:,i]
			try:
				#index = where((gradient(Ew)[3:-1] > 0.)*(Ew[3:-1] > 1.01*self.Ew_int[3:-1,i]))[0][0]
				#index = where((gradient(Ew)[3:-1] > 0.))[0][0] #changed due to bug in center
				index = where((gradient(Ew)[20:-1] > 0.))[0][0] #Testing
			except Exception as e: 
				index = len(Ew)

			dB[i]    = (sqrt(4*pi*(Ew[index:-1]*self.dk).sum()))
			if isnan(dB[i]):
				if parallel.procID == 0:				
					print "mttran: nan while integrating - index=", i, dB[i], index
					print "mttran: nan while integrating - Ew=", Ew[index:-1]

#		if any(isnan(dB)):
#			if parallel.procID == 0:
#				print "mttran: nan in dB - replacing with 0"
#				print "mttran: nan in dB at rc=", rc[where(isnan(dB))]
#				print "mttran: nan in dB at index=", where(isnan(dB))
#				print "mttran: nan in dB at index=", where(isnan(dB))[0][0]
#				print "mttran: nan in dB at dB=", dB[where(isnan(dB))[0][0]:where(isnan(dB))[0][-1]]
#			sys.exit(0)

#		dB = where(isnan(dB),0.0, dB) 	#Catch nan due to weird integration				
#		if any(isnan(dB)):
#			if parallel.procID == 0:
#				print "mttran(", parallel.procID, "): nan in dB (fixed)"

		#Update Buffer
		if self.Buffer_B.TIME != time:
			self.Buffer_B.TIME      = time
			self.Buffer_B.FIELD     = interpolate.interp1d(rc,dB,bounds_error=False, fill_value=0)

		#Calculate return value
		Bfield = interpolate.interp1d(rc,dB,bounds_error=False, fill_value=0)(r)
		if any(isnan(Bfield)):
			if parallel.procID == 0:
				print "mttran(", parallel.procID, "): nan in Bfield"
		return Bfield

        def dB_ADummy(self,r, time):
                return 0

	#Total energy in magnetic turbulence
	def TurbEnergy(self,time):
#		Ew  = self.Ew_u.globalValue
#		rs  =self.cc_rk_0
#		r_l = ((rs-self.dr-1)**3.+1)*self.tecf.Rsh(time)
#		r_r = ((rs+self.dr-1)**3.+1)*self.tecf.Rsh(time)
#		V   = 4/3.*pi*(r_r**3.-r_l**3.)
#		Etot= (Ew*V*self.dk).sum()
#		EwBk= self.EwINIT((rs-1)**3.+1,exp(self.cc_rk_1),time) #Need different background subtraction
#		EBK = (EwBk*V*self.dk).sum()
#		return Etot#-EBK
		rs = arange(0,self.rmax,self.dr)+self.dr/2.
		dB = self.dB_A(rs,time)
		EB = dB**2./(8*pi)
		V  = 4/3.*pi*((rs-self.dr-1)**3.+1)*self.tecf.Rsh(time)
		return (EB*V).sum()
 

	########################################################################################################################
	#resonant growth rate
	def Source_Ew_2(self,t,N0):
		r  = self.cc_rk_0
		k  = self.cc_rk_1
		r2 = self.cc_rp_0
		p2 = self.cc_rp_1
		B=self.tecf.B(self.R(r),t)

		N1 = N0.globalValue.reshape((self.npsteps,self.nrsteps))
		N2 = ndarray(shape=(self.npsteps,self.nrsteps),dtype=float)
		
		for i in range(int(self.npsteps)):
			N2[i] = N1[(i,range(int(self.nrsteps)))]
		
		N3 = fliplr(N2.transpose())
		N1 = ndarray(shape=(self.nrsteps,self.nksteps),dtype=float)
		
		p3 = fliplr(((q*self.tecf.B(self.R(r2),t)/(exp(p2)*self.pm*c)).reshape((self.npsteps,self.nrsteps))).transpose())
		k3 = (k.reshape((self.nksteps,self.nrsteps))).transpose()
		
		for i in range(int(self.nrsteps)):
			defrange = (exp(k3[i])>p3[i].min())*(exp(k3[i])<p3[i].max())
			N1[i]=interpolate.interp1d(p3[i],N3[i],bounds_error=False, fill_value=0)(exp(k3[i])*defrange+(1-defrange)*(p3[i,0]))*defrange
		#Changed because of indexing problems after SL7 update
		N1=(N1.transpose()).reshape(self.nksteps*self.nrsteps)
			
		f2 = abs(N1) 
		
		C_fix=self.setpar.TURBAMPFACT #1.0e0 #5*10**1
		f3=where((r >= 0.05) & ( r < self.rmax), 2/3.0*self.tecf.Valfrs(r,t)*(q*B/(exp(k)*c))*c*f2*yr*C_fix, 0) #changed from 1.0 to 0.25
		
		##################################extracting slice
		if (all(round_(k[self.CPU_k[parallel.procID]:len(self.cc_rk_1_l)+self.CPU_k[parallel.procID]],12) == round_(self.cc_rk_1_l,12))):
			#print "node:", parallel.procID, ", slice found, starting point: ", self.CPU_k[parallel.procID]
			return (f3[self.CPU_k[parallel.procID]:len(self.cc_rk_1_l)+self.CPU_k[parallel.procID]])
			
		print "mttran: node(p1):", parallel.procID, " !Error, slice not found! ", self.CPU_k[parallel.procID], self.cc_rk_1_l#, k[CPU[parallel.procID]:len(cc1[1])+CPU[parallel.procID]]
		sys.exit(0)
	######################################################################################################################################
	

	######################################################################################################################################
	#diffusion coefficient in rp-space global value
	def Drp(self,r,p,t):
		B  = self.tecf.B(self.R(r),t)
		if any(isnan(B)):
			print "mttran: nan in Drp"
		Bn = 3e-6
		E  = c*p*self.pm 
		D  = self.NORM*(E*62.4)**self.delta*(B/Bn)**(-self.delta)
		return D

	#conversion of Ew_ from rk- to rp-space
	def conEW(self,E,t,pmom):
		r1full = self.cc_rp_0
		r2full = self.cc_rk_0
		kfull  = self.cc_rk_1
		pfull  = self.cc_rp_1

		kmin = log(1/(15*parsec))	#limit by remnant size
		pmin = self.pm*c*1e-3		#limit by injection, always proton mass
		kmax = log(q*Bmax/(c*pmin))
	
		E1 = (E.globalValue).reshape((self.nksteps,self.nrsteps))
		E2 = ndarray(shape=(self.nksteps,self.nrsteps),dtype=float)
		for i in range(int(self.nksteps)):
			E2[i] = E1[(i,range(int(self.nrsteps)))]
		E3 = fliplr(E2.transpose())
		E1 = ndarray(shape=(self.nrsteps,self.npsteps),dtype=float)

		k2 = fliplr(((log(q*self.tecf.B(self.R(r2full),t)/(exp(kfull)*self.pm*c))).reshape((self.nksteps,self.nrsteps))).transpose())
		p2 = (pfull.reshape((self.npsteps,self.nrsteps))).transpose()

		#print "Resonanzen; k: ", k2.max(), k2.min()," p: ", p2.max(), p2.min()

		for i in range(int(self.nrsteps)):
			if (p2[i].min()<k2[i].min() or p2[i].max()>k2[i].max()):
				print "mttran: ERROR in conEW! Grid mismatch!", p2[i].min(), p2[i].max(), k2[i].min(), k2[i].max(), kmin, kmax
				sys.exit(0)
			E1[i]=interpolate.interp1d(k2[i],E3[i],bounds_error=False, fill_value=0.)(p2[i])
		E4=(E1.transpose()).reshape(self.nrsteps*self.npsteps)
		 
		##################################extracting slice
		if (all(round_(pfull[self.CPU_p[parallel.procID]:len(self.cc_rp_1_l)+self.CPU_p[parallel.procID]],12) == round_(array(self.cc_rp_1_l),12))):
			return E4[self.CPU_p[parallel.procID]:len(self.cc_rp_1_l)+self.CPU_p[parallel.procID]]
			
		print "mttran: node(p2):", parallel.procID, " !Error, slice not found! ", self.CPU_p[parallel.procID]
		sys.exit(0)


	#conversion of Ew_ from rk- to rp-space using
	def conEW_v2(self,E,t,pmom):
		r1full = self.cc_rp_0
		r2full = self.cc_rk_0
		kfull  = self.cc_rk_1
		pfull  = self.cc_rp_1
		
		#reshaping: x-Value for interpolation have to be increasing(fliplr), interpolation for every r-bin(reshape, loop over i)
		E1 = (E.globalValue).reshape((self.nksteps,self.nrsteps))
		E2 = ndarray(shape=(self.nksteps,self.nrsteps),dtype=float)
		for i in range(int(self.nksteps)):
			E2[i] = E1[(i,range(int(self.nrsteps)))]
		E3 = fliplr(E2.transpose())
		E1 = ndarray(shape=(self.nrsteps,self.npsteps),dtype=float)

		#k2 = fliplr(((log(q*self.tecf.B(self.R(r2full),t)/(exp(kfull)*self.pm*c))).reshape((self.nksteps,self.nrsteps))).transpose())	#k-grid turned into p
		k2 = fliplr(((log(q*self.tecf.B(self.R(r2full),t)/(exp(kfull)*pmom*c))).reshape((self.nksteps,self.nrsteps))).transpose())	#k-grid turned into p	
		p2 = (pfull.reshape((self.npsteps,self.nrsteps))).transpose() #reshaped p grid
		r2 = (r1full.reshape((self.npsteps,self.nrsteps))).transpose() #reshaped p grid


		for i in range(int(self.nrsteps)):
			E1[i]=interpolate.interp1d(k2[i],E3[i],bounds_error=False, fill_value=nan)(p2[i]) #fill_value=float('nan')
			E1[i]=where(isnan(E1[i]),self.Drp(r2[i],exp(p2[i]),t),E1[i])	#catch bound error and replace with inital conditions
			if any(isnan(E1[i])):
				if parallel.procID == 0: print "mttran: E1: nan left", i, sum(isnan(E1[i]))

		E4=(E1.transpose()).reshape(self.nrsteps*self.npsteps) #backtransformation
		#if parallel.procID == 0: print "mttran: Nan-check", any(isnan(E4)) #check for removal of all 'nan'-entrys
		 
		##################################extracting slice
		if (all(round_(pfull[self.CPU_p[parallel.procID]:len(self.cc_rp_1_l)+self.CPU_p[parallel.procID]],12) == round_(array(self.cc_rp_1_l),12))):
			return E4[self.CPU_p[parallel.procID]:len(self.cc_rp_1_l)+self.CPU_p[parallel.procID]]
			
		print "mttran: node(p2):", parallel.procID, " !Error, slice not found! ", self.CPU_p[parallel.procID]
		sys.exit(0)
	#################################################################################################################################################
	def EwBohm(self,r,k,t):
		B    = self.tecf.B(r,t)
		UB   = (B**2.)/(8*pi)	
		return 4.0/pi*UB
	
	def EwBohmlnrs(self,rstar,lnk,t):
		k=exp(lnk)
		r=self.R(rstar)	
		return self.EwBohm(r,k,t)
	
	#inital conditions	
	def EwINIT(self,r,k,t):
		B  = self.tecf.B(r,t)
		UB = B**2./(8*pi)
		Bn = 3e-6
		p  = q*B/(k*c)
		v  = c
		E  = p*c
		D  = self.NORM*(E*62.4)**self.delta*(B/Bn)**(-self.delta)		#62.4 [1/erg] = 10 [1/GeV] to keep NORM
		Ew = 4.0*v/(3.0*pi*k*D)*UB
		return where(Ew>self.EwBohm(r,k,t),self.EwBohm(r,k,t),Ew)
	
	def EwINITlnrs(self,rstar,lnk,t):
		k=exp(lnk)
		r=self.R(rstar)	
		return self.EwINIT(r,k,t)

	#conversion of energy density Ew to diffusion coefficient in r-k space
	def Ew2Dk(self,r,k,t,Ew):
		B  = self.tecf.B(r,t)
   		UB = (B**2.)/(8*pi)
		p  = q*B/(k*c)
		v  = p*c/(self.pm**2 + p**2)**0.5
		D  = 4.0*v/(3.0*pi*k*Ew)*UB
		return D
	
	def Ew2Dklnrs(self,rstar,lnk,t,Ew):
		k=exp(lnk)
		r=self.R(rstar)
		return self.Ew2Dk(r,k,t,Ew)
	
	#sets up grid variables and inital conditions
	def SetupVariableDummy(self,t,inFileName):
		self.Ew_u = fipy.CellVariable(mesh=self.mesh_rk, name = "Ew_u", value=0, hasOld=1)
		return

	def SetupVariable(self,t,inFileName):	
		if inFileName == "":
			self.Ew_u = fipy.CellVariable(mesh=self.mesh_rk, name = "Ew_u", value=1.0*self.EwINITlnrs(self.rc1,self.kc,t), hasOld=1)
			self.Ew_u.updateOld
		else:
			inFileName = inFileName.replace("TRAW","TRAW_U_")
			try:
				f=open(inFileName,"r")
				RPN=f.readlines()
				f.close()
			except IOError:
				if parallel.procID == 0: 
					frameinfo = getframeinfo(currentframe())
					print "mttran(",frameinfo.lineno,"): no file found:",inFileName
				sys.exit(0)
			if parallel.procID == 0: print "mttran(627): reading...", inFileName
			LEN=len(RPN)-2
			NN=arange(LEN,dtype=float)
			rr1=arange(LEN,dtype=float)
			for i in range(0,LEN):
				(rrr,ppp,NNN)=RPN[i+2].split()
				NN[i]=float(NNN)
				rr1[i]=float(rrr)
			try:
				File = str(self.setpar.Rundir)+"/MFPROFILES/"+str(self.setpar.MFFILEOUT)+str(self.setpar.timecont)
				f=open(File,"r")
				RPN=f.readlines()
				f.close()
			except IOError:
				if parallel.procID == 0: 
					frameinfo = getframeinfo(currentframe())
					print "mttran(",frameinfo.lineno,"): no file found:",File
				sys.exit(0)
			if parallel.procID == 0: print "mttran: reading...", File
			LEN=len(RPN)-1
			UB=arange(LEN,dtype=float)
			rr=arange(LEN,dtype=float)
			for i in range(0,LEN):
				(rrr,Bt,br,bt)=RPN[i+1].split()
				UB[i]=float(Bt)
				rr[i]=float(rrr)
			if parallel.procID == 0: print "mttran: reading is done"

			r = (self.cc_rk_0-1)**3.+1
			UB = self.tecf.B(r,t)**2./(8*pi)

#			UB2 = interpolate.interp1d(rr,UB)(rr1)

#			self.Ew_u = fipy.CellVariable(mesh=self.mesh_rk, name = "Ew_u", value=NN*UB2**2./(8*pi), hasOld=1)
			self.Ew_u = fipy.CellVariable(mesh=self.mesh_rk, name = "Ew_u", value=NN*UB, hasOld=1)
			self.Ew_u.updateOld 

		if parallel.procID == 0:
			print "mttran: variable is set"
	
	#method setups boundary conditions for the solution variable
	def SetupBoundConDummy(self,t):
		return

	def SetupBoundCon(self,t):
		self.Ew_u.constrain(self.Ew_u.faceValue(),              	self.Left)
		self.Ew_u.constrain(1.0*self.EwINITlnrs(self.rf1,self.kf,t), 	self.Right)
		#self.Ew_u.constrain(self.Ew_u.faceValue(),              	self.Bottom)
		self.Ew_u.constrain(0,				              	self.Bottom) #Changed due to damping
		self.Ew_u.constrain(1.0*self.EwINITlnrs(self.rf1,self.kf,t),    self.Top)

		if parallel.procID == 0: print "mttran: setting up BCs is done"

	#method writes the solution variable to file
	def WriteVariable(self,t,timesOut,outFileName):
		r = (self.rc1-1)**3.+1
		UB = self.tecf.B(r,t)**2./(8*pi) 
		#UB = self.tecf.B(r,t)**2./(8*pi) 
		self.viewerEw_u = fipy.TSVViewer(vars=(self.Ew_u/UB))
		for time in timesOut:
			if round(time - t,5)==0:
				TIME=str(time)
				fnameU=outFileName+"_U_"+TIME
				fnameD=outFileName+"_D_"+TIME
				self.viewerEw_u.plot(filename=fnameU)
				if parallel.procID == 0:
					print "mttran: writing file", fnameU

        def WriteVariableDummy(self,t,timesOut,outFileName):
		return

	#method writes the effektive magnetic field
	def WriteMfField(self,t,timesOut,outFileName):
		r = self.rc1
		rs = arange(0,self.rmax,self.dr)+self.dr/2.
		for time in timesOut:
			if round(time - t,5)==0:
				TIME=str(time)
				fnameU=outFileName+TIME
				#print "TEST: ", len(r), len(self.dB_A(t))
				savetxt(outFileName+TIME, array([((arange(self.dr/2.,self.rmax, self.dr)-1)**3.+1),self.dB_A(rs,t)]).transpose(), fmt='%.18e', delimiter=' ', newline='\n', header='', footer='', comments='# ')
				if parallel.procID == 0:
					print "mttran: writing file", fnameU

        def WriteMfFieldDummy(self,t,timesOut,outFileName):
                return

	#method writes inital conditions for the solution variable to file
	def WriteVariableInit(self,t,outFileName):
		r  = (self.rc1-1)**3.+1
		UB = (self.tecf.B(r,t)**2.)/(8*pi) 
		Ew = fipy.CellVariable(mesh=self.mesh_rk, name = "Ew", value=1.0*self.EwINITlnrs(self.rc1,self.kc,t), hasOld=1)
		viewerEw = fipy.TSVViewer(vars=(Ew/UB))
		fname=outFileName+str(int(t))
		fname1=outFileName+str(int(t))+"_Bohm"
		viewerEw.plot(filename=fname)
		Ew.setValue(self.EwBOHM)
		viewerEw.plot(filename=fname1)
		if parallel.procID == 0:
			print "mttran: time=",t, fname,"+\n       ",fname1, "has been written"

        def WriteVariableInitDummy(self,t,outFileName):
                return			

	#method writes any variable to file
	def WriteVariableAny(self,t,timesOut,var,outFileName):
		viewerAny = fipy.TSVViewer(vars=(var))
		for time in timesOut:
			if round(time - t,5)==0:
				TIME=str(int(round(time,1))).zfill(5)
				fname=outFileName+TIME
				viewerAny.plot(filename=fname)
				if parallel.procID == 0: print "mttran: writing file", fname



	def SetupEquation_PR(self,t,N):
#		if parallel.procID == 0: print "mttran: ", self.tecf.Vsh(t), self.tecf.Rsh(t)

		#variables and coefficents for Turbulence spektrum
		start = modtime.time()
#		print "mttran: SetupEquation: time0: 0"
		convCoeff_Rv        = fipy.FaceVariable(mesh=self.mesh_rk, rank=1)	#Nabla(\dot{a}/a*R*Ew)
		convCoeff_Rr_u      = fipy.FaceVariable(mesh=self.mesh_rk, rank=1) #Nabla(v/a*Ew)
		convCoeff_Rr_u1= fipy.CellVariable(mesh=self.mesh_rk)		#Ew*Nabla(v/a)
		
		imsCoeff1      = fipy.CellVariable(mesh=self.mesh_rk)		#J*dot{a}/a*Ew
		imsCoeff3_u    = fipy.CellVariable(mesh=self.mesh_rk)		#2*J*v/(a*R)*Ew
		self.growthCoeff_u  = fipy.CellVariable(mesh=self.mesh_rk)		#Growth Rate
		self.growthCoeff    = fipy.CellVariable(mesh=self.mesh_rk)		#Growth Rate
		dampCoeff           = fipy.CellVariable(mesh=self.mesh_rk)		#generell Damping Rate
		dampCoeff_nc   = fipy.CellVariable(mesh=self.mesh_rk)		#neutral-charged damping
		dampCoeff_Landau_Pl = fipy.CellVariable(mesh=self.mesh_rk)		#reserved for landau damping
		dampCoeff_IC   		= fipy.CellVariable(mesh=self.mesh_rk)		#Ion-Cyclotron damping
		trt_Coeff1          = fipy.CellVariable(mesh=self.mesh_rk)		#transient coefficient

		v                   = fipy.FaceVariable(mesh=self.mesh_rk, rank=1)	#Plasma speed(vPl)	
		v1                  = fipy.CellVariable(mesh=self.mesh_rk)		#Plasma speed
			
		v_alfven_u          = fipy.FaceVariable(mesh=self.mesh_rk, value=0.0, rank=1)	#vPl+vAlf 
		v_alfven1_u         = fipy.CellVariable(mesh=self.mesh_rk)			#vPl+vAlf

		self.CoeffSource_u    = fipy.CellVariable(mesh=self.mesh_rk)			#Source term
		
		diffCoeff_ku        = fipy.FaceVariable(mesh=self.mesh_rk, rank=2)		#Cascading: diffusion
		convCoeff_ku        = fipy.FaceVariable(mesh=self.mesh_rk, rank=1)		#Cascading: convection
		convCoeff_ku2       = fipy.FaceVariable(mesh=self.mesh_rk, rank=1)		#wavenumber shifting at shock
		self.SourceCoeff_u  = fipy.CellVariable(mesh=self.mesh_rk)	#collects all ImplicitSourceTerm coefficients except growth rate
		
		self.dNdx                = fipy.CellVariable(mesh=self.mesh_rp,rank=1)		#Gradient of N
		
		#####################################################################################
		# turbulence coefficents update!!! spherical only
#		print "mttran: SetupEquation: time1: ",time.time()-start
		Bd_max     = 100.0			
		UB	   = self.tecf.B(self.R(self.rf1),t)**2./(8*pi) #B at faces
		UB1	   = self.tecf.B(self.R(self.rc1),t)**2./(8*pi) #B at centers
#		print "mttran: SetupEquation: time2: ",time.time()-start
		adot  = self.tecf.Vsh(t)						#adot		
		ainv  = self.tecf.Rsh(t)**(-1)						#1/a
		Valfc = self.tecf.Valfrs(self.rc1,t)					#vAlf at centers
#		ValfcCV = fipy.CellVariable(mesh=self.mesh_rk,value=Valfc) 		# faster way to get facevalues 
		Valff = self.tecf.Valfrs(self.rf1,t) #ValfcCV.faceValue()		# vAlf at faces

#		print "mttran: SetupEquation: time2.1: ",time.time()-start
		
		#setting plasma speeds(upstream/downstream/faces/centers)
		v1.setValue(self.tecf.Vlhsrs(self.rc1,t), where=(self.rc1 <=self.rshw+self.dr/3.))
		v1.setValue(self.tecf.Vrhsrs(self.rc1,t), where=(self.rc1 > self.rshw+self.dr/3.))
#		v.setValue(self.tecf.Vlhsrs(self.rf1,t), where=(self.rf1 <=self.rshw+self.dr/3.))
		v.setValue(v1.faceValue())#self.tecf.Vrhsrs(self.rf1,t), where=(self.rf1 > self.rshw+self.dr/3.))
		v[1] = 0
#		print "mttran: SetupEquation: time2.2: ",time.time()-start		
		#setting speeds for equation(upstream/downstream-moving/faces/centers)
		v_alfven_u.setValue(v)
		v_alfven_u[1] = 0
		v_alfven1_u.setValue(v1)
#		print "mttran: SetupEquation: time2.3: ",time.time()-start		
		
		convCoeff_Rv.setValue(adot*ainv*self.Rf)
		convCoeff_Rv[1]=0.0

		convCoeff_Rr_u.setValue(v_alfven_u*ainv)
		convCoeff_Rr_u[1]=0.0

		convCoeff_Rr_u1.setValue(v_alfven_u.divergence*ainv)

		imsCoeff1.setValue(self.Jc*adot*ainv)	
		
		imsCoeff3_u.setValue(c_comp*self.Jc*2.0*v_alfven1_u*ainv/self.Rc)
		
		self.dNdx.setValue(N.grad)
		self.dNdx[1]=0.
		GSRC = self.Source_Ew_2(t,self.dNdx[0])/(yr*self.Jc)*ainv #*self.Jc

		#Adding additional Magnetic field in the region around the shock
		MFSRC = self.AddDownstreamTurbulence(t,True)*self.Jc#*ainv
		
		self.CoeffSource_u.setValue(GSRC*self.Jc+MFSRC)#*self.Jc)
		
		self.growthCoeff.setValue(GSRC*self.Jc**2/ainv)
		
		dampCoeff.setValue(0.0)
		dampCoeff_IC.setValue(self.Damp_IClnrs(self.rc1,self.kc,t)*self.Jc, where=(self.rc1 > self.rshw+self.dr/3.))
		
		trt_Coeff1.setValue(self.Jc)

		#Cascading coefficients:
		#Modification for Alfven velocities
		kmin_cc  = self.min_k(self.rc1,t)
		kmin_fc  = self.min_k(self.rf1,t)
		#c_cas_cc = sqrt(1. - self.dB_A(self.rc1,t)**2./self.tecf.B(self.R(self.rc1),t)**2.*(1-(exp(kmin_cc)/exp(self.kc))**(2/3.)) )
		#c_cas_fc = sqrt(1. - self.dB_A(self.rf1,t)**2./self.tecf.B(self.R(self.rf1),t)**2.*(1-(exp(kmin_fc)/exp(self.kf))**(2/3.)) )
		#c_cas_cc = where(exp(kmin_cc) > exp(self.kc), sqrt(1.0-self.dB_A(self.rc1,t)**2./self.tecf.B(self.R(self.rc1),t)**2.), c_cas_cc)
		#c_cas_fc = where(exp(kmin_fc) > exp(self.kf), sqrt(1.0-self.dB_A(self.rf1,t)**2./self.tecf.B(self.R(self.rf1),t)**2.), c_cas_fc)
		#if parallel.procID == 0: 
		#	fdir="/lustre/fs17/group/that/rb/G1.9+0.3/E-W/FINAL/Runs_ModCas/FINAL/Model2_TEST/TURBULENCE/kmin"
		#	savetxt(fdir+str(t), array([self.rc1,kmin_cc]).transpose(), fmt='%.18e', delimiter=' ', newline='\n', header='', footer='', comments='# ')

		c_cas_cc = 1.0 #where( exp(self.kc) > (exp(-38.)+exp(-16.0956703793885))/2.,1.0, sqrt(1 - self.dB_A(self.rc1,t)**2./self.tecf.B(self.R(self.rc1),t)**2.) )
 		c_cas_fc = 1.0 #where( exp(self.kf) > (exp(-38.)+exp(-16.0956703793885))/2.,1.0, sqrt(1 - self.dB_A(self.rf1,t)**2./self.tecf.B(self.R(self.rf1),t)**2.) )

		#c_cas_cc = where( (self.kc) > 1.0e-13,1.0, 0.1) 
 		#c_cas_fc = where( (self.kf) > 1.0e-13,1.0, 0.1) 

		CC = self.Jf*self.expkf*Valff*sqrt(0.5/UB)*c_cas_fc #*abs(self.Ew_u.faceValue)
		CC1= self.Jc*self.expkc*Valfc*sqrt(0.5/UB1)*c_cas_cc #*abs(self.Ew_u.faceValue)
#		diffCoeff_ku.setValue(CC)#,where=(self.rf1 > self.rshw+self.dr/3.))
		diffCoeff_ku.setValue(where(self.rf1 > self.rshw+self.dr/3.,CC,self.s_cas*CC))
		diffCoeff_ku[0,0] = 0.0
		diffCoeff_ku[0,1] = 0.0
		diffCoeff_ku[1,0] = 0.0
#		convCoeff_ku.setValue(3.0*CC)#, where=(self.rf1 > self.rshw+self.dr/3.))
		convCoeff_ku.setValue(where(self.rf1 > self.rshw+self.dr/3.,3.0*CC,self.s_cas*3.0*CC))
		convCoeff_ku[0]  = 0.0
		convCoeff_ku2.setValue(v_alfven1_u.grad.faceValue*self.Jf)
		convCoeff_ku2[0]  = 0.0
		
		self.SourceCoeff_u.setValue((-1.0)*imsCoeff1 - 1.0*imsCoeff3_u - 0.0*dampCoeff_nc - 0.0*dampCoeff_IC - 0.0*(c_comp-1.0)*convCoeff_Rr_u1)
		self.TranTerm  = fipy.TransientTerm(trt_Coeff1)
		self.DiffTerm_u = fipy.ImplicitDiffusionTerm(diffCoeff_ku*sqrt(abs(self.Ew_u.faceValue)))
		self.ConvTerm_u = fipy.PowerLawConvectionTerm(1.0*convCoeff_Rv - convCoeff_ku*sqrt(abs(self.Ew_u.faceValue)) - 1.0*convCoeff_Rr_u + 0.0*convCoeff_ku2)
		self.SourTerm_u = fipy.ImplicitSourceTerm(self.SourceCoeff_u)
		self.eqB1 = self.TranTerm \
			 == self.DiffTerm_u \
			  + self.SourTerm_u \
			  + self.ConvTerm_u \
			  + self.CoeffSource_u	
	
		# printing the biggest/smalest growth rates
		self.sig_u_max = max(GSRC*self.Jc)
		sig_u_min = min(self.CoeffSource_u.globalValue)
		damp_u_max = max(dampCoeff.globalValue)
		damp_u_min = min(dampCoeff.globalValue)
		damp_u_nc_min = min(dampCoeff_nc.globalValue)
		damp_u_nc_max = max(dampCoeff_nc.globalValue)
		damp_u_Lan_Pl_max = max(dampCoeff_Landau_Pl.globalValue)
		damp_u_Lan_Pl_min = min(dampCoeff_Landau_Pl.globalValue)
		damp_u_IC_max = max(dampCoeff_IC.globalValue)
		damp_u_IC_min = min(dampCoeff_IC.globalValue)
		gamma_1_max = max(self.CoeffSource_u.globalValue-dampCoeff.globalValue) 
		self.gamma_1_min = min(self.CoeffSource_u.globalValue-dampCoeff.globalValue)
		self.gamma_max = max(self.CoeffSource_u.globalValue-dampCoeff.globalValue-dampCoeff_nc.globalValue-dampCoeff_Landau_Pl.globalValue-dampCoeff_IC.globalValue) 
		gamma_min = min(self.CoeffSource_u.globalValue-dampCoeff.globalValue-dampCoeff_nc.globalValue-dampCoeff_Landau_Pl.globalValue-dampCoeff_IC.globalValue)
		N_max = max(N.globalValue)
		N_min = min(N.globalValue)
		Ew_max = max(self.Ew_u.faceValue.globalValue)
		Ew_min = min(self.Ew_u.faceValue.globalValue)
		con_k_max = max(convCoeff_ku.globalValue[1])
		diff_k_max = max(diffCoeff_ku.globalValue[1,1])
		N_grad_max = max(N.grad.globalValue[0])
		N_grad_min = min(N.grad.globalValue[0])
		Ew_grad_x_max = max(self.Ew_u.grad.globalValue[0])
		Ew_grad_x_min = min(self.Ew_u.grad.globalValue[0])
		Ew_grad_k_max = max(self.Ew_u.grad.globalValue[1])
		Ew_grad_k_min = min(self.Ew_u.grad.globalValue[1])
		p_cr = self.P_cr()
#		if parallel.procID == 0:
#			print "----------------------------------------------------"
#			print "mttran: "
#			print '\t',"sigmna(up): ", self.sig_u_max, sig_u_min
#			print '\t',"damp(up): ", damp_u_max, damp_u_min
#			print '\t',"nc-damping: ", damp_u_nc_max, damp_u_nc_min
#			print '\t',"Landau damping: ", damp_u_Lan_Pl_max, damp_u_Lan_Pl_min
#			print '\t',"IC-damping: ", damp_u_IC_max, damp_u_IC_min 
#			print '\t',"sigma-damp: ", gamma_1_max, self.gamma_1_min
#			print '\t',"Gamma(up): ", self.gamma_max, gamma_min
#			print '\t',"N: ", N_max, N_min
#			print '\t',"Ew_u: ", Ew_max, Ew_min
#			print '\t',"convection k-space: ", con_k_max, "diffusion k-space: ", diff_k_max
#			print '\t',"dN/dx: ", N_grad_max, N_grad_min
#			print '\t',"dEw_u/dx: ", Ew_grad_x_max, Ew_grad_x_min
#			print '\t',"dEw_u/dk: ", Ew_grad_k_max, Ew_grad_k_min
#			print '\t',"P_cr/P_sh: ",p_cr, self.P_shock(t), p_cr/self.P_shock(t)
#			print "----------------------------------------------------" 
		#calculating CFL Numbers:
		dt = 1.0
		#self.CFL_D_r = fipy.FaceVariable(mesh=self.mesh_rp, value=0.0)
 		#self.CFL_U_k = fipy.FaceVariable(mesh=self.mesh_rk, value=0.0)
 		#self.CFL_D_k = fipy.FaceVariable(mesh=self.mesh_rk, value=0.0)
		N_map = (abs(N-self.N_init)*self.pc**2. > 10**(-10.)) & (self.pc > -3.) & (self.rc > 0.3)
		K_map = (exp(self.kc) < (q*sqrt(UB1*8*pi*ainv/self.Jc))/(c*0.01*self.pm)) & (self.rc1 > 1.0) & (self.rc1 < 3.5)
		self.CFL_D_r   = dt/self.dr**2.*(self.Dc/self.J(self.rc,self.dr)*ainv**2.*yr) 	#Diffusion of particles in r-p-grid
		self.CFL_D_r_g = (self.CFL_D_r*N_map).globalValue
		self.CFL_U_k   = dt/self.dr*(CC1*sqrt(abs(self.Ew_u))) 	 		#convection in wavenumberspace
		self.CFL_U_k_g = (self.CFL_U_k*K_map).globalValue
		self.CFL_D_k   = dt/self.dr**2.*(3*CC1*sqrt(abs(self.Ew_u))) 	 	#diffusion in wavenumberspace
		self.CFL_D_k_g = (self.CFL_D_k*K_map).globalValue
#		if parallel.procID == 0:
#			print '\t',"CFL-Numbers: ", max(self.CFL_D_r_g), max(self.CFL_U_k_g), max(self.CFL_D_k_g)  
#			print "----------------------------------------------------" 


	def SetupEquation_EL(self,t,N):
		#variables and coefficents for Turbulence spektrum
		self.growthCoeff_u  = fipy.CellVariable(mesh=self.mesh_rk)		#Growth Rate
		self.growthCoeff    = fipy.CellVariable(mesh=self.mesh_rk)		#Growth Rate
		self.CoeffSource_u    = fipy.CellVariable(mesh=self.mesh_rk)			#Source term
		self.SourceCoeff_u  = fipy.CellVariable(mesh=self.mesh_rk)	#collects all ImplicitSourceTerm coefficients except growth rate
		self.dNdx                = fipy.CellVariable(mesh=self.mesh_rp,rank=1)		#Gradient of N
		dt=1.0
		ainv=1.0
		N_map=1.0
		K_map=1.0
		self.CFL_D_r   = dt/self.dr**2.*(self.Dc/self.J(self.rc,self.dr)*ainv**2.*yr) 	#Diffusion of particles in r-p-grid
		self.CFL_D_r_g = (self.CFL_D_r*N_map).globalValue
		self.CFL_U_k   = dt/self.dr*(1.0*sqrt(abs(self.Ew_u))) 	 		#convection in wavenumberspace
		self.CFL_U_k_g = (self.CFL_U_k*K_map).globalValue
		self.CFL_D_k   = dt/self.dr**2.*(3*1.0*sqrt(abs(self.Ew_u))) 	 	#diffusion in wavenumberspace
		self.CFL_D_k_g = (self.CFL_D_k*K_map).globalValue
		return

        def SetupEquationDummy(self,t,N):
                return

	#method makes one time step with dt=timeStep
	def DoOneTimeStep_PR(self,t,timeStep):
		if parallel.procID == 0: sys.stdout.write('mttran: making step from time {0:6.4f} to time {1:6.4f}, '.format(t,t+timeStep))
		lim1 = 5e-3
		lim2 = 5e-3
		nsw1 = 1
		nsw2 = 1
		res1 = 1e4
		res2 = 1e4

		while res1 > lim1 and nsw1<10:
			res1 = self.eqB1.sweep(solver=self.Solver1,var=self.Ew_u,dt=timeStep)
			if parallel.procID == 0: sys.stdout.write('swept {0:d} time(s), res={1:e}\n'.format(nsw1,float(res1)))
			nsw1=nsw1+1 #,boundaryConditions=self.EwBcs_u
			if nsw1 == 10:
				if parallel.procID == 0:
					print "mttran: WARNING - residuals above defined limits!"
			if nsw1 >= 1e3:
				sys.exit(0)
		
		if len(where(self.Ew_u<0)[0])>0:
			print "mttran(", parallel.procID,"): negative value in Ew detected - fixing it"#, where(self.Ew_u<0)
			self.Ew_u.setValue(abs(self.Ew_u))		


	def DoOneTimeStep_EL(self,t,timeStep):
		if parallel.procID == 0: sys.stdout.write('mttran: making step from time {0:6.2f} to time {1:6.2f}, '.format(t,t+timeStep))
		B  = self.tecf.B(self.R(self.rc),t)
		UB = B**2./(8*pi)
		#print "mttran: TEST: ", parallel.procID, self.CPU_k[parallel.procID], len(self.Ew_u)
		#Finding slices:
		
		Test = zeros(len(self.Ew_u.globalValue))
		for i in range(self.CPU_k[parallel.procID],len(self.cc_rk_1_l)+self.CPU_k[parallel.procID]):
			Test[i]=(self.Ew_u_raw[i](t))


		##################################extracting slice
		if (all(round_(self.cc_rk_1[self.CPU_k[parallel.procID]:len(self.cc_rk_1_l)+self.CPU_k[parallel.procID]],12) == round_(self.cc_rk_1_l,12))):
			#print "node:", parallel.procID, ", slice found, starting point: ", self.CPU_k[parallel.procID]
			self.Ew_u.setValue(Test[self.CPU_k[parallel.procID]:len(self.cc_rk_1_l)+self.CPU_k[parallel.procID]])
			
		else:
			print "mttran: node(p1):", parallel.procID, " !Error, slice not found! ", self.CPU_k[parallel.procID], self.cc_rk_1_l#, k[CPU[parallel.procID]:len(cc1[1])+CPU[parallel.procID]]
			sys.exit(0)


#		for i in range(0,len(self.Ew_u.globalValue)):
#			if parallel.procID == 0: print i 
#			self.Ew_u.globalValue[i] = self.Ew_u_raw[i](t)

		self.Ew_u.setValue(self.Ew_u*UB)
		#print "mttran: debugging: ", max(self.Ew_u), min(self.Ew_u)
        
        def DoOneTimeStepDummy(self,t,timeStep):
                return


	def PrepareTurbData_PR(self):
		return

	def PrepareTurbData_EL(self):
	#	RUN = "RUN_turbulence"
	#	timeslist = "/lustre/fs17/group/that/rb/G1.9+0.3/E-W/RUN_turbulence/timeslist"
	#	inFileName1 ="/lustre/fs17/group/that/rb/G1.9+0.3/E-W/RUN_turbulence/TURBULENCE/PR/FSH/TRAW_U_" #Find way to make dynamic
		inFileName1 =self.setpar.Rundir+"TURBULENCE/PR/"+self.setpar.SHOCKTYPE+"/TRAW_U_"
		print "mttran: Reading turbulence files...", inFileName1
		self.Ew_u_raw = [0]*(len(self.Ew_u.globalValue))
	#	try:
	#		f=open(timeslist,"r")
	#		RPN=f.readlines()
	#		f.close()
	#	except IOError:
	#		if parallel.procID == 0: print "mttran: no file found:",timeslist
	#		sys.exit(0)
	#	LEN=len(RPN)

	#	times=arange(LEN,dtype=float)
	#	for i in range(0,LEN):
	#		times[i]=float(RPN[i])
	
		times = self.setpar.timeslist
		EWU = list(arange(len(times)))		
		j=0
           	for time in times:
			try:
				f=open(inFileName1+str(float(time)),"r")
				RPN=f.readlines()
				f.close()
			except IOError:
				if parallel.procID == 0: 
					frameinfo = getframeinfo(currentframe())
					print "mttran(",frameinfo.lineno,"): no file found:",(inFileName1+str(int(round(time,1))).zfill(5))
				sys.exit(0)

			LEN=len(RPN)-2
			NN=arange(LEN,dtype=float)
			for i in range(0,LEN):
				(rrr,ppp,NNN)=RPN[i+2].split()
				NN[i]=float(NNN)
			EWU[j]=NN
			j=j+1
		EWU=array(EWU)
	
		for i in range(0,LEN):
			self.Ew_u_raw[i] = interpolate.interp1d(array(times),EWU[:,i])
	

		if parallel.procID == 0: print "mttran: Turbulence data read and prepared"

        def PrepareTurbDataDummy(self):
		return

	def DoOneSweep(self,t,timeStep):
		res1 = self.eqB1.sweep(solver=self.Solver1,var=self.Ew_u,dt=timeStep,boundaryConditions=self.EwBcs_u)
		return res1
	
		
	#method solves transport equation and writes solution variable at predefined steps
	def SolveEquation(self,timeInit,timeStop,timeStepInit,timesOut,outFileName):
		time = timeInit
		timeStep = timeStepInit
		while time <= timeStop:
			self.DoOneTimeStep(time,timeStep)
			self.Ew_u.updateOld()
			self.WriteVariable(time,timesOut,outFileName)
			time=time+timeStep
			self.SetupEquation(time,self.N)
	
	#future adaptive time step
	def AdaptTimeStep(self,t,timelist):
		timestep = 0.001
		timenext = min(where(timelist-t>0,timelist,1e7))
		if t < 0.02:
			timestep = 0.0002#0.0002
		elif t < 0.1:
			timestep = 0.0002#0.0002
		elif t >= 0.1 and t < 1.0:
			timestep = 0.001
		elif t >= 1.0 and t < 10.0:
			timestep = 0.005 #0.25
		elif t >= 10.0 and t < 20.0:
			timestep = 0.025		
		elif t >= 20.0 and t < 50.0:
			timestep = 0.1
		elif t >= 50.0 and t < 100.0:
			timestep = 0.34
		elif t >= 100.0 and t < 499.0:
			timestep = 1.0
		elif t >= 499.0 and t < 998.0:
			timestep = 2.0
		elif t >= 998.0 and t< 2000.0:
			timestep = 5.0
		elif t >= 2000.0:
			timestep = 25.0
		#timestep=timestep/10. # Activate for consistency/CFL-checks
		if (t+timestep)>timenext:
			timestep = timenext-t
		return timestep

        def AdaptTimeStepDummy(self, t, timelist):
                return 1000.

	
	#Diffusion coefficent in r-p-space
	def EvalDiffCoeff(self,t,crte):
		#print "mttran: Evolving diffusion coefficient"
		#self.Dc.setValue(self.conEW_v2(self.Ew2Dklnrs(self.rc1,self.kc,t,self.Ew_u+1e-6*(5e-6/(8*pi)**2.)),t,crte.tecf.pmom)) #buffer for e- +1e-6*(5e-6/(8*pi)**2.) ##old

		#new block
		B  = 5e-6
		UB = B**2./(8*pi)
		Bn = 3e-6
		k  = exp(self.kc)
		p  = q*B/(k*c)
		v  = c
		E  = p*c
		D  = self.NORM*(E*62.4)**self.delta*(B/Bn)**(-self.delta)		#62.4 [1/erg] = 10 [1/GeV] to keep NORM
		Ew = 4.0*v/(3.0*pi*k*D)*UB
		self.Dc.setValue(self.conEW_v2(self.Ew2Dklnrs(self.rc1,self.kc,t,self.Ew_u+1e-4*Ew),t,crte.tecf.pmom))
		if len(where(self.Dc<0)[0])>0:
			print "mttran(", parallel.procID, "): negative diffusion coefficient! ", where(self.Dc<0)[0]
		#end new block	

		self.D.setValue(self.Dc.faceValue*yr)
		#print "EvalDiffCoeff executed"

        def EvalDiffCoeffAnalytic(self,t,crte):
#		print "mttran: Evolving diffusion coefficient (analytic)"
#                self.D.setValue(self.tecf.Dln(self.rf,self.pf,t))
		crte.EvalDiffCoeff(t)
                self.D.setValue(crte.D)
	
	def EvalGrowthCoeff_PR(self,t,N):
		self.dNdx.setValue(N.grad)
		self.dNdx[1] = 0.
		ainv  = self.tecf.Rsh(t)**(-1)
		GSRC = self.Source_Ew_2(t,self.dNdx[0])/(yr*self.Jc)*ainv
		#GSRC = 0.0
		MFSRC = self.AddDownstreamTurbulence(t,True)*self.Jc#*ainv
		self.CoeffSource_u.setValue(GSRC*self.Jc+MFSRC)#*self.Jc)
		self.sig_u_max = max(GSRC*self.Jc)
			

		sig_max = max(self.CoeffSource_u.globalValue)
		#if parallel.procID == 0:
			#print "mttran: Growth-rate updated to: ", sig_max

		self.eqB1 = self.TranTerm \
			 == self.DiffTerm_u \
			  + self.SourTerm_u \
			  + self.ConvTerm_u \
			  + self.CoeffSource_u
	

	def EvalGrowthCoeff_EL(self,t,N):
		return
        
        def EvalGrowthCoeffDummy(self,t,N):
		return

	def writeInP(self,t,fileName,CRTE,p_r,timesOut):
		InP_hist = open(fileName,'a')
		value = str(t)+"\t"+str(self.tecf.InP)+"\t"+str(self.tecf.ScP)+"\t"+str(p_r)+"\n"
		#for time in timesOut:
		#	if round(time - t,5)==0:
		InP_hist.write(value)
		InP_hist.close()

	
	def ScP(self,t,p_r,pr_old):
		self.n_smooth = 30
	#	return 1.0
		gew=(array(range(self.n_smooth))+1)**2.
		ScP_new   = 1.0 #/5.
		p_r_bound = 0.05 #/5. 	#desired stable CR-pressure
		p_r_scale = 0.1 #/5.		#/p_r_bound	#Value where to have f_scale divided by p_r_bound
	 	f_scale	  = 0.001 #/5.	#value at p_r_scale
	#	b         = log(f_scale)/(1-p_r_scale)
	#	a         = 1/exp(-b)
		a  	  = -log(f_scale)/(p_r_scale-p_r_bound)**2.0
		p_r_1     = sum(gew*pr_old)/sum(gew)
	#	if parallel.procID == 0: print "solver: ratios: ", p_r, p_r_1 #, pr_old 
	#	if parallel.procID == 0: print "solver: a=", a, " b=", b	
		if float(p_r_1) >= p_r_bound:
	#		ScP_new = a*exp(-p_r_1/p_r_bound*b)
			ScP_new = exp(-(p_r_1-p_r_bound)**2.0*a)
		#if t>=7800: ScP_new = 0
	#	return (t-20.+1.)**(-0.5)
		return ScP_new #/5.

	def ScP2(self,eta,time,dB_old,dB):
		# turbulence and angle dependent injection 
		# eta=0.01, dB=integral(Ew)
		# theta = 0.0
		#return 1.0
		sigma	= 4.0
		scale 	= 5.	#potentuial scaling because of high sensitivity to changes in dB

		self.n_smooth = 30
		gew=(array(range(self.n_smooth))+1)**2.
		dB_1     = sum(gew*dB_old)/sum(gew)/scale

#		Ew = self.Ew_u.globalValue[where(self.cc_rk_0==1.0)]
#		dB = (sqrt(4*pi*(Ew*self.dk).sum())-dB_0)/(self.tecf.B(1.0,time))			#0-Value dynamical
#		if parallel.procID == 0: print "\t \t mttran: eta=", eta
#		if parallel.procID == 0: print "\t \t mttran: dB=", dB/scale, dB_1
		result 	= integrate.quad(lambda x: eta**(1-sigma**2.)*0.5*eta**(sigma**2.*(1.+dB_1**2.-2*dB_1*cos(pi-x))/(dB_1*cos(x)+1.)**2.)*sin(x), 0, pi)
#		if parallel.procID == 0: print "\t \t mttran: eta_new=", result[0]
 #		if parallel.procID == 0: print "\t \t mttran: ScP_new=", result[0]/eta
		return result[0]/eta

	def N(self,t,k,r):
		yr  = 3.156e+7
		pc  = 3.08e18
		u   = 1e4*1e5		 
		a   = 0.4*pc+u*yr*t #(adot*t+0.4*pc)
		B   = 5e-6 
		q   = 4.8e-10
		m_p = 1.673e-24
		c   = 2.998e10
		s   = 2
		m   = 0 #2/3.
		delta = 1/3.

		p_0 = c*m_p
		p   = q*B/(k*c)/(c*m_p)
		N_d = 1e3*(4.0*pi/c)*2.2*p**(-s+1) #4*1e-6*(p/p_0)**(-2.0)

		Ew  = 4.0*c/(3.0*pi*k)/(1e26*(62.4*q*B/k)**delta*(B/3e-6)**(-delta)) #1.0 #   
	#	D   = 4.0*c/(3.0*pi*k)/Ew	
		D   = 1e26*(62.4*q*B/k)**delta*(B/3e-6)**(-delta)
	
		N_u = 1e3*(4.0*pi/c)*2.2*p**(-s+1)*exp(-u/D*(r-1)*a) #1e-6*(p/p_0)**(-2.0)*exp(-u/D*(r-1)*a)
		return where(r > 1.0,N_u,N_d)
	
	def Nln(self,t):
		m_p = 1.673e-24
		c   = 2.998e10	
		B   = 5e-6 
		q   = 4.8e-10
		k   = q*B/(exp(self.pc)*m_p*c**2.0)
		r   = (self.rc-1)**3.0+1
		return N(t,k,r)

	def D_mod(self,t):
		c 	= 2.998e10
		m_p 	= 1.673e-24
		yr  	= 3.156e+7						
		B	= self.tecf.B(self.R(self.rf),t)
	 	Bn	= 3e-6
		delta	= 1/3.
		if (t<120):
			NORM = 1e25	
		elif (t>=120): # and (t<5120):
			NORM = 1e25*((t-120)*yr+1)**(1/5.)
	#		NORM = 10**(25+(t-120)*(29-25)/(5120-120))
	#	elif (t>=5120):
	#		NORM = 1e29
		#NORM 	= 1e29
		v 	= c
		p 	= m_p*c*exp(MTTE.pf)
		E  	= p*c
	#	if parallel.procID == 0: print "NORM: ", NORM
		return yr*NORM*(E*62.4)**delta*(B/Bn)**(-delta)

		
	def AddDownstreamTurbulence(self,t,local):
		k0    = -38.1019294891798 #-40.138371807169 ##Set by hand, open to changes, not working if B_0 is changed
		#k0    = -38.199212480584784 #for modified pstepnumber
		#for i in range(len(self.kc)):
		#	print "mttran: self.kc, i:", i, self.kc[i]
		#sys.exit(0)
		dr    = self.setpar.LESDSTURB	#0.005 			#Thickness of region i r'
		kappa = self.setpar.ENSDSTURB	#0.002			#amount of energy transfered into magnetic field from flow energy behind the shock 


################Old version for G1.9+0.3
#	#	E0    = kappa*self.tecf.rho(array([1.0]),t)*(3/4.*self.tecf.Vsh(t))**2./(yr**2.*2*self.dk)  #Energy density transformed into turbulence
#		E0    = kappa*(1.05e9)**2.0/2.0*(2.6e-25)/self.dk
	
#		dt    = dr*self.tecf.Rsh(t)/(3./4.*(self.tecf.Vsh(t)+1))	#Crossing time; +1 to avoid crash for t=0
		
		Rrs   = cbrt(self.tecf.RRS(t)-1.)+1
		Vrs1  = self.tecf.Vlhsrs(array([Rrs+2*self.dr]),t)/yr
		Vrs2  = self.tecf.Vlhsrs(array([Rrs-2*self.dr]),t)/yr
		Vrs   = abs((Vrs1-Vrs2)*4/3.)						 #reverse shock velocity in the shock rest frame
##		E2    = kappa*self.tecf.rho(array([Rrs+self.dr]),t)*Vrs**2./(2*self.dk)  #Energy density transformed into turbulence
#		E2    = kappa*(4.1e8)**2.0/2.0*(7.7e-25)/self.dk

#		dt2   = dr*self.tecf.RRS(t)*self.tecf.Rsh(t)/(3./4.*(Vrs+1))/yr	         #Crossing time; +1 to avoid crash for t=0

		#print  "mttran: node=",parallel.procID, Rrs, Vrs, E2, dt2, E0, dt  

################Coupling to thermal energy
		#Forward shock
		dt    	 = dr*self.tecf.Rsh(t)/(1./4.*(self.tecf.Vsh(t)+1))	#Crossing time; +1 to avoid crash for t=0
		
		#rhofs105 = 2.646682797654538664e-25
		#Tfs105	 = 2.728977688229498386e+09
		rhofs105 = self.tecf.rho(array([1.0+self.dr]),t)
		Tfs105	 = self.tecf.Tg_sh(t)
		if parallel.procID == 0: 
			print "mttran: density and temperature: ", rhofs105, Tfs105
		
		E0    	 = kappa/self.dk*3/2.*kB*rhofs105/(mu*m_p)*Tfs105


		#Reverse shock
		dt2   	 = dr*self.tecf.Rsh(t)*self.tecf.RRS(t)/(1/4.*(Vrs+1))/yr	         #Crossing time; +1 to avoid crash for t=0
		rhors105 = 7.725097562492019924e-25
		Trs105	 = 4.333193078481711745e+08
		E2    	 = kappa/self.dk*3/2.*kB*rhors105/(mu*m_p)*Trs105

		if local:
			r      = (self.rc1-1)**3.+1
			Gamma  = where((round(self.kc,5) == round(k0,5))*(self.rc1 <= 1.0), E0*exp((r-1.0)/dr)/dt, 0)
			Gamma2 = 0#where((round(self.kc,5) == round(k0,5))*(self.rc1 >= Rrs), E2*exp(-(r-self.tecf.RRS(t))/dr)/dt2, 0)
			Gamma  = Gamma+Gamma2
		else:
			r      = (self.cc_rk_0-1)**3.+1
			Gamma  = where((round(self.cc_rk_1,5) == round(k0,5))*(self.cc_rk_0 <= 1.0), E0*exp((r-1.0)/dr)/dt, 0)
			Gamma2 = 0#where((round(self.cc_rk_1,5) == round(k0,5))*(self.cc_rk_0 >= Rrs), E2*exp(-(r-self.tecf.RRS(t))/dr)/dt2, 0)
			Gamma  = Gamma+Gamma2


		if parallel.procID == 0: 
			print "mttran: crossing times - dt_FS=", dt, "VFS=", self.tecf.Vsh(t)/yr/1e5, "km/s max(Gamma)=", max(Gamma)
		return Gamma

	def GetLogValue(self,t):
		log_description = ["Energy in turbulence","Downstream field","Growth rate(Alvfenic)","Growth rate(downstream field)"]
		log_values	= zeros(len(log_description))

		#Assign values		
		#Energy in turbulence
		log_values[0]	= self.TurbEnergy(t)
		#Upstream field
		log_values[1]	= self.dB(t) 
		#Growth rate(total)	
		log_values[2]	= self.sig_u_max
		#Growth rate(downstream field)
		log_values[3]	= max(self.AddDownstreamTurbulence(t,False))

		return log_description,log_values

