######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  mftran.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2012 - 2015
# 	  Robert Brose <robert.brose@desy.de>, 2016
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v1.0.0: original version written for Telezhinsky et al 2013
#v2.0.0: corrected to comply with fipy v.3.0.0 standard
#v2.1.0: re-written to comply with new patron code
#v2.2.0: parameters renamed and reordered to comply with patron v2.2.0 and higher
#v2.3.0: version control added
#v2.4.0: DoTimeIntervall introduced
#v2.4.1: changed self.flow --> self.tecf for compability with UpdateMhd

__vesion__='2.4.0'

import sys
import getopt
import fipy as fipy
from fipy.tools import parallel
from fipy.tools.numerix import sqrt
from fipy.tools.numerix import where
from fipy.tools.numerix import arange
from fipy.tools.numerix import shape
from scipy.interpolate import interp1d

yr=3.156E+7
pc=3.08e18

v_plato=0.0

class TransportEquation:
	def __init__(self,rStepsNum,rCoordMax,timeInit,mfIntProf,mfInitCon,inFileName,teCoeffFuncs,SP):
		if parallel.procID == 0: print "mftran: initializing transport equations object for time ", timeInit," ...mfInitCon =",mfInitCon
		
		self.timestart = timeInit		#Not used, why is it here?
	
		self.tecf    = teCoeffFuncs

		if not self.tecf.mfProfile in (["TR2","TRA"]):
			self.AdaptTimeStep = self.AdaptTimeStepDummy
			self.SetupEquation = self.SetupEquationDummy
			self.StartBoundCon = self.StartBoundConDummy
			self.SetupBoundCon = self.SetupBoundConDummy
			self.WriteVariable = self.WriteVariableDummy
			self.DoOneTimeStep = self.DoOneTimeStepDummy
			self.SetupVariable = self.SetupVariableDummy
			if parallel.procID == 0: print "mftran: Using dummy functions"
			

		self.rshw    = 1.0
		
		self.nrsteps = rStepsNum

		self.rmax    = rCoordMax
#		print "mftran: DEBUG: rcoordmax = ", self.rmax
		self.dr      = rCoordMax/float(rStepsNum)
		
		self.mesh    = fipy.Grid1D(dx=self.dr,nx=self.nrsteps)+(self.dr/2.,)
#		if parallel.procID == 0:
#			print "mftran: DEBUG: nrsteps = ", self.nrsteps
#			print "mftran: DEBUG: mesh = ", self.mesh
#			print "mftran: DEBUG: shape = ", shape(self.mesh)


		self.rc      = self.mesh.cellCenters[0]
		self.rf      = self.mesh.faceCenters[0]
		
		self.Left    = self.mesh.facesLeft
		self.Right   = self.mesh.facesRight
		
		#initial time has to agree with Plutos initial time: check if simulation is continued, otherwise Pluto is at time=0
		if SP.timecont != None:
			timeStart = float(SP.timecont)
		elif SP.usesedsol == 5:
			timeStart = 0
		else:
			timeStart = timeInit

		self.SetupVariable(timeStart,mfIntProf,mfInitCon,inFileName)
		self.mfIntProf  = mfIntProf
		self.mfInitCon  = mfInitCon
		self.mfInitCon  = mfInitCon
		self.inFileName = inFileName


		self.StartBoundCon(timeStart)
		self.SetupEquation(timeStart)
		
		self.solver  = fipy.DefaultAsymmetricSolver(tolerance=1e-16)
		#self.viewerW = fipy.TSVViewer(vars=(self.Br,self.Bt,self.B))

	#	self.viewerP = fipy.Matplotlib1DViewer(vars=(self.Br,self.Bt,self.B),ylog=1, datamin=1e-12, datamax=1e-1, title="Bfield", legend='upper left')
	#	self.pidBr   = fipy.steppers.pidStepper.PIDStepper(vardata=(self.Br))
	#	self.pidBt   = fipy.steppers.pidStepper.PIDStepper(vardata=(self.Bt))
		
		if parallel.procID == 0: print "\tmftran: transport equations object is initialized."
	
	
	def Br0(self,t):
		return self.tecf.B0(t)/1.73205
		
	def Bt0(self,t):
		return self.tecf.B0(t)/1.73205
		
	def BrInit(self,r,t,inProfile,Bnorm):
		if inProfile   == "FLAT":
			return (Bnorm)*((1e15)**2/(self.tecf.Rsh(t)+0)**2)
		elif inProfile == "PWLAW":
			return (Bnorm/r**2)*((1e15)**2/(self.tecf.Rsh(t)+0)**2)
		elif inProfile == "PWLPL":
			B=(Bnorm/r.globalValue**2)*((1e15)**2/(self.tecf.Rsh(t)+0)**2)
			i_plato = where(self.Vlhs(r.globalValue,t)<=v_plato)[-1][-1]
			return    where(self.Vlhs(r.globalValue,t)<=v_plato,B[i_plato],B)
			#return self.Br0(t)
	
	def BtInit(self,r,t,inProfile,Bnorm):
		if inProfile   == "FLAT":
			return (Bnorm)*((1e15)**2/(self.tecf.Rsh(t)+0)**2)
		elif inProfile == "PWLAW":
			return (Bnorm/r**2)*((1e15)**2/(self.tecf.Rsh(t)+0)**2)
		elif inProfile == "PWLPL":
			B=(Bnorm/r.globalValue**2)*((1e15)**2/(self.tecf.Rsh(t)+0)**2)
			i_plato = where(self.Vlhs(r.globalValue,t)<=v_plato)[-1][-1]
			return    where(self.Vlhs(r.globalValue,t)<=v_plato,B[i_plato],B)
			#return 4.0*self.Bt0(t)
	
	def Vlhs(self,r,t):
		return self.tecf.VLHS(r,t)
	
	def Vrhs(self,r,t):
		return self.tecf.VRHS(r,t)

	def SetupVariableDummy(self,timeInit,inProfile,Bnorm,inFileName):
		self.Br = fipy.CellVariable(mesh=self.mesh, name = "Br", value=0.0, hasOld=1)
		self.Bt = fipy.CellVariable(mesh=self.mesh, name = "Bt", value=0.0, hasOld=1)
		self.B = fipy.CellVariable(mesh=self.mesh, name = "B", value=0.0)
		return
	
       	               
	def SetupVariable(self,timeInit,inProfile,Bnorm,inFileName):
		if inFileName == "":
			self.Br = fipy.CellVariable(mesh=self.mesh, name = "Br", value=0.0, hasOld=1)
			self.Br.setValue(self.BrInit(self.rc,timeInit,inProfile,Bnorm))
			self.Br.updateOld()
			self.Bt = fipy.CellVariable(mesh=self.mesh, name = "Bt", value=0.0, hasOld=1)
			self.Bt.setValue(self.BtInit(self.rc,timeInit,inProfile,Bnorm))
			self.Bt.updateOld()
		else:
			try:
				f=open(inFileName,"r")
				RBrBtB=f.readlines()
				f.close()
			except IOError:
				print "mftran: No file found:",inFileName
			if parallel.procID == 0: print "mftran: Reading...", inFileName
			LEN = len(RBrBtB)-1
			BBr = arange(LEN,dtype=float)
			BBt = arange(LEN,dtype=float)
			RR  = arange(LEN,dtype=float)
			for i in range(0,LEN):
				(rr,br,bt,bb)=RBrBtB[i+1].split()
				RR[i]=float(rr)				
				BBr[i]=float(br)
				BBt[i]=float(bt)
			if parallel.procID == 0: print "mftran: Reading is done."
			#self.Br = fipy.CellVariable(mesh=self.mesh, name = "Br", value=0.0, hasOld=1).globalValue
			#self.Bt = fipy.CellVariable(mesh=self.mesh, name = "Bt", value=0.0, hasOld=1).globalValue
			self.Br = fipy.CellVariable(mesh=self.mesh, name = "Br", value=0.0, hasOld=1)
			self.Bt = fipy.CellVariable(mesh=self.mesh, name = "Bt", value=0.0, hasOld=1)
			
			#if parallel.procID == 0: print "mftran: ", shape(self.Br), shape(self.Bt), shape(BBr), shape(BBt), shape(self.mesh)
			#if parallel.procID == 0: print "mftran: reading of magnetic field is currently not working"
			#sys.exit(0)

			#if parallel.procID == 0: print "mftran: DEBUG: ", shape(rr), shape(BBr)

			self.Br.setValue(interp1d(RR,BBr,bounds_error=False, fill_value=0)(self.rc))
			self.Bt.setValue(interp1d(RR,BBt,bounds_error=False, fill_value=0)(self.rc))

			#self.Br.setValue(BBr)
			#self.Bt.setValue(BBt)

		self.B = fipy.CellVariable(mesh=self.mesh, name = "B")
		self.B.setValue(sqrt((self.Br**2+2.0*self.Bt**2)))
		if parallel.procID == 0: print "mftran: Variable is set up"
	
	def WriteVariable(self,t,timesOut,outFileName):
		self.viewerW = fipy.TSVViewer(vars=(self.Br,self.Bt,self.B))
		for time in timesOut:
			#if (time == t):
			if round(time - t,5) == 0:
				#TIME=str(int(time)).zfill(5)
				TIME=str(time)
				fname=outFileName+TIME
				if parallel.procID == 0: print "\tmftran: writing file", fname
				self.viewerW.plot(filename=fname)

	def WriteVariableDummy(self,t,timesOut,outFileName):	
		return

	def StartBoundCon(self,t):
		if parallel.procID == 0: print "\tmftran: initializing BCs for time",t
		#old	
		#self.Br.faceGrad.constrain([0.],self.Left)
		#self.Bt.faceGrad.constrain([0.],self.Left)
		#self.Br.constrain(self.Br0(t),self.Right)
		#self.Bt.constrain(self.Bt0(t),self.Right)
		#new
		self.Br.faceGrad.constrain(self.Br.faceValue(),self.Left)
		self.Bt.faceGrad.constrain(self.Br.faceValue(),self.Left)
		self.Br.constrain(self.Br0(t),self.Right)
		self.Bt.constrain(self.Bt0(t),self.Right)

	def StartBoundConDummy(self,t):
		return	

	def SetupBoundCon(self,t):
		if parallel.procID == 0: print "\tmftran: setting up BCs for time",t
		#old
		#del self.Br.faceConstraints
		#del self.Bt.faceConstraints
		#self.Br.constrain(self.Br0(t),self.Right)
		#self.Bt.constrain(self.Bt0(t),self.Right)
		#new
		del self.Br.faceConstraints
		del self.Bt.faceConstraints
		self.Br.constrain(self.Br0(t),self.Right)
		self.Bt.constrain(self.Bt0(t),self.Right)
		
	def SetupBoundConDummy(self,t):
		return	
		
	def SetupEquation(self,t):
		if parallel.procID == 0: print "\tmftran: setting up equations for time",t
		
		v                = fipy.FaceVariable(mesh=self.mesh, rank=1)
		convCoeff_r      = fipy.FaceVariable(mesh=self.mesh, rank=1)
		convCoeff_v      = fipy.FaceVariable(mesh=self.mesh, rank=1)
		Source_r         = fipy.CellVariable(mesh=self.mesh)
		Source_t         = fipy.CellVariable(mesh=self.mesh)
		implCoeff_adota  = fipy.CellVariable(mesh=self.mesh)
		implCoeff_v_a_r2 = fipy.CellVariable(mesh=self.mesh)
		implCoeff_v_a_r1 = fipy.CellVariable(mesh=self.mesh)
		implCoeff_divva  = fipy.CellVariable(mesh=self.mesh)
		
		ainv             = self.tecf.Rsh(t)**(-1)
		adot             = self.tecf.Vsh(t)
		
		v.setValue(self.Vlhs(self.rf,t), where=(self.rf<=self.rshw+self.dr/3.))
		v.setValue(self.Vrhs(self.rf,t), where=(self.rf> self.rshw+self.dr/3.))
	
		convCoeff_r.setValue(self.rf*adot*ainv)
		convCoeff_v.setValue(v*ainv)
	
		implCoeff_adota.setValue(adot*ainv)
		implCoeff_v_a_r2.setValue(2.0*self.Vlhs(self.rc,t)*ainv/self.rc)
		implCoeff_v_a_r1.setValue(1.0*self.Vlhs(self.rc,t)*ainv/self.rc)
		implCoeff_divva.setValue(v.divergence*ainv)
		
		self.EqBr = fipy.TransientTerm() \
			 == fipy.PowerLawConvectionTerm(convCoeff_r - convCoeff_v) \
			  - fipy.ImplicitSourceTerm(implCoeff_adota + implCoeff_v_a_r2 - implCoeff_divva)
		
		self.EqBt = fipy.TransientTerm() \
			 == fipy.PowerLawConvectionTerm(convCoeff_r - convCoeff_v) \
			  - fipy.ImplicitSourceTerm(implCoeff_adota + implCoeff_v_a_r1)
	
	def SetupEquationDummy(self,t):
		return	

	def DoOneTimeStep(self,t,timeStep):
		if parallel.procID == 0: print "\tmftran: making step from time",t,"to",t+timeStep
		lim = 0.01
		nsw1 = 1
		nsw2 = 1
		res1 = 1.0e4
		res2 = 1.0e4
		while res1 > lim:
			res1 = self.EqBr.sweep(solver=self.solver, var=self.Br, dt=timeStep)
			if parallel.procID == 0:
				print "\tmftran: Br swept",nsw1,"time(s) at time",t,"res =",res1#,"B0=",self.Br0(t),"Br=",self.Br[-1],"cr=",self.Br[-1]/self.Br0(t)
			nsw1=nsw1+1
#		self.Br.updateOld()
		
		while res2 > lim:
			res2 = self.EqBt.sweep(solver=self.solver, var=self.Bt, dt=timeStep)
			if parallel.procID == 0:
				print "\tmftran: Bt swept",nsw2,"time(s) at time",t,"res =",res2#,"B0=",self.Bt0(t),"Bt=",self.Bt[-1],"cr=",self.Bt[-1]/self.Bt0(t)
			nsw2=nsw2+1
#		self.Bt.updateOld()
		self.Br.setValue(where(self.Br<1e-12, 1e-12, self.Br))
		self.Bt.setValue(where(self.Bt<1e-12, 1e-12, self.Bt))
		
		self.B.setValue(sqrt((self.Br**2+2.0*self.Bt**2)))
			
	def DoOneTimeStepDummy(self,t,timeStep):
		return	

	def DoTimeIntervall(self,time,timeEnd,timelist):
		if parallel.procID == 0: print "mftran: Doing time-intervall from ",time, " to ", timeEnd
		time_1 = time		
		while time_1 < timeEnd:
			step = min(1.0,timeEnd-time_1) #MF-transport has a fixed time-step of 1 yr
			self.DoOneTimeStep(time_1,step)
			self.Br.updateOld()
			self.Bt.updateOld()
			time_1 += step
			self.SetupBoundCon(time_1)
			self.SetupEquation(time_1) 
		if parallel.procID == 0: print "mftran: Reached final Intervall-time: ", time_1

	def SolveEquation(self,timeInit,timeStop,timeStepInit,timesOut,outFileName):
		time = timeInit
		print "\tmftran: time = ", time
		timeStep = timeStepInit
		while time <= timeStop:
			self.WriteVariable(time,timesOut,outFileName)
			self.DoOneTimeStep(time,timeStep)
			self.Br.updateOld()
			self.Bt.updateOld()
#			self.viewerP.plot()
			time=time+timeStep
			self.SetupBoundCon(time)
			self.SetupEquation(time)
			
#			timeStep=self.AdaptTimeStep(time)
	
#	def AdaptTimeStep(self,time,timelist):
##		print self.pidBt.step(timeStep)
#		return 1.0

	def AdaptTimeStep(self,t,timelist):
		timestep = 1.0
		timenext = min(where(timelist-t>0,timelist,1e7))

		if t < 50.0:
			timestep = 1.0
		elif t >= 50.0  and t < 100.0:
			timestep = 5.0
		elif t >= 100.0 and t < 1000.0:
			timestep = 25.0
		elif t >= 1000.0:
			timestep = 50.0
		if (t+timestep)>timenext:
			timestep = timenext-t
		return timestep


	def AdaptTimeStepDummy(self,time,timelist):
		timestep = 1e3
		timenext = min(where(timelist-time>0,timelist,1e7))
		if (time+timestep)>timenext:
			timestep = timenext-time
		return timestep

#	def AdaptTimeStepDummy(self,time,timelist):
#		return 1000	
