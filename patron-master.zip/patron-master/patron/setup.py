#\cond
######################################################################################
### RATPaC - Radiation Acceleration Transport PArallel Code                        ###
#=====================================================================================
# File:	  setup.py									
# Author: Robert Brose <robert.brose@mail.de>, 2015 - present
#         Iurii Sushch <iurii.sushch@desy.de>, 2017 - present
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################
#\endcond

##@package patron.setup
#This routine sets up alls files for running a RATPaC simulation in a runfolder.
#
#It has to be called from the desired RUNFOLDER using <em>python PATRONDIR/patron/setup.py\em .
#An interactive menu will appear and provide the setup-options.

#v0.0.1 start of devolpment for replacing startup script. Creating XML-parameter file
#v0.1.0 Compatible and working for all modes exept MAPSPE_PARALLEL and GETMSP, commited for further testing
#v0.1.1 Added PyPluto-switch
#v0.1.1 Added CR-feedback and injection-index switch
#v0.1.4 Added reggriding flags
#v0.1.5 Changed to SLURM-submission scripts
#v0.1.6 Adding CR-species parameters

__version__='0.1.6'

#from xml.dom.minidom import parse
import xml.dom.minidom as minidom
import sys
import xml.etree.cElementTree as ET
import os
import shutil
import numpy
import stat
from numpy import ceil

##Main function of the setup-routine.
#
#Provides the menu and processes the userinput.
def main(argv=None):
	print "Patron setup started..."
	print "Current directory: ", os.getcwd(),
	cwd=os.getcwd()

	menu = {}
	menu['1']="Full setup"
	menu['2']="Create/Check Parameter file"
	menu['3']="Create Directory structure"
	menu['4']="Create Timelist"
	menu['5']="Create Shocklist"
	menu['6']="Create Radiationlisst"
	menu['7']="Create Executables"
	menu['8']="Exit"	
	while True:
		print "\n"
		options=menu.keys()
		options.sort()
		for entry in options:
			print entry, menu[entry]
		selection=raw_input("Please Select: ")
		if selection=='1':
			if os.path.isfile('Parameters.xml'):
				print "\nParameter-file found..."
				CheckXML('Parameters.xml')
			else: 
				CreateXML()
				raw_input("Parameter-file created. Default values are set for analytic solutions of the SNR evolution. Edit Parameters.xml if needed, otherwise press Enter to continue\n")
			CreateDIRs()
			CreateTimesList()
			CreateShockList()
			CreateRadiationList()
			CreateScripts(cwd)
		
		elif selection == '2':
			if os.path.isfile('Parameters.xml'):
				print "\nParameter-file found..."
				CheckXML('Parameters.xml')
			else: 
                                CreateXML()
                                print "\nParameter-file created. Default values are set for analytic solutions of the SNR evolution."

		elif selection == '3':
			CreateDIRs()
		elif selection == '4':
			CreateTimesList()
		elif selection == '5':
			CreateShockList()
		elif selection == '6':
			CreateRadiationList()
		elif selection == '7':
			CreateScripts(cwd)
		elif selection == '8':
			print "Exit..."
			break 
		else: print "Uknown Option selected!"

##Function for the creation of the run-related scripts
#
#Creates - depending on the runmode defined in the parameter-file - the executable patron.sh in the rundirectory, the Job*.sh script for a execution over the batch-system and the Executable*.sh with the run-command.
#
#input: cwd=current working directory path \n 
#The structure is somewhat outdated and has historic reasons as the passing of environment-variables to the cluster was not possibile in the past. \n
def CreateScripts(cwd):
	mode		= ReadXMLPar("mode","Parameters.xml")
	NNUM		= ReadXMLPar("nnum","Parameters.xml") #change depending on mode...
	calculate	= ReadXMLPar("calculate","Parameters.xml")


	patrondir	= os.environ["PATRONDIR"]

	if calculate=="CRSPE0" or calculate=="CRSPE1" or calculate=="CRSPE2" or calculate=="CRSPE3" or calculate=="CRPROF":
		#parlist   = [line.rstrip('\n') for line in open('parlist')]
		shocklist = [line.rstrip('\n') for line in open('shocklist')]
		radlist   = [""]	
	else:
		#parlist   = [""]
		shocklist = [line.rstrip('\n') for line in open('shocklist')]
		radlist = [line.rstrip('\n') for line in open('radlist')]
		for shock in shocklist:
			if shock == "RSH":
				shocklist.remove("RSH")
				print "\nRSH was removed from the shocklist to avoid the radiation calculated twice for both shocks runs. Adjust accordingly in case you want to run only reverse shock"

	print "\nCreating scripts..."

	for shock in shocklist:
		for rad in radlist:

		#creating executable
			bashname="Executable_"+shock+rad+".sh"
			bash=open(str('ALLSUBDIR/'+calculate+'/BASH/'+bashname),'w')
			bash.write("#!/bin/bash\n")
			#Needed for serial CLUSTER
			if mode=="CLUSTER" and calculate!="CRSPE0" and calculate!="RADSPEALL" and calculate!="CRSPE3":	
				bash.write(str("export LD_LIBRARY_PATH=${_LD_LIBRARY_PATH}\n"))
			bash.write(str("python "+os.environ["PATRONDIR"]+"/main.py --paramfile="+cwd+"/Parameters.xml --shocktype="+shock+" --radiation="+rad+"\n"))
			bash.close()
			st = os.stat(str('ALLSUBDIR/'+calculate+'/BASH/'+bashname))
			os.chmod(str('ALLSUBDIR/'+calculate+'/BASH/'+bashname),st.st_mode | stat.S_IEXEC)

		#creating jobfile
			jobname="Job_"+shock+rad+".sh"
			job=open(str('ALLSUBDIR/'+calculate+'/JOBS/'+jobname),'w')
			job.write("#!/bin/bash\n")
			
			#Uses SLURM
                        if calculate=="CRSPE0" or calculate=="RADSPEALL" or calculate=="CRSPE3" :
                        	#Get cluster infrastructure
                        	cluster = ReadXMLPar("institute","Parameters.xml")

				#DESY-template
                        	if cluster == "DESY":
		              		# Default entrys
					job.write(str("#SBATCH -J "+calculate+shock+rad+"\n"))
					job.write(str("#SBATCH --get-user-env\n"))
					job.write(str("#SBATCH -c 2\n"))

					# log and error-file output
					job.write(str("#SBATCH --output="+cwd+"/ALLSUBDIR/"+calculate+"/logs/log_%A.out\n")) 		#log file
					job.write(str("#SBATCH --error="+cwd+"/ALLSUBDIR/"+calculate+"/errs/error_%A.out\n")) 	#error file
					job.write("#\n")

					#Mail on jobs begin/end abort
					job.write("#(send mail on job's begin, end and abort)\n")
					job.write("#SBATCH --mail-type=ALL\n")
				
					#Memory consumption and cluster setup(number of cores)
					job.write("#SBATCH -N "+str(int(ceil(float(NNUM)/16.)))+"\n")
					job.write("#SBATCH -p haswell \n")
					#Exclude pax10[28-31]
					job.write("#SBATCH -x pax10-[28-31] \n")

					#Job Runtime definition
					job.write("#SBATCH --time=48:00:00\n")
					
					#execution commands
					job.write(str('mpirun -np '+NNUM+' --bind-to core '+cwd+'/ALLSUBDIR/'+calculate+'/BASH/'+bashname+'\n'))
                        	if cluster == "KAY":
		              		# Default entrys
					job.write(str("#SBATCH -J "+calculate+shock+rad+"\n"))
					job.write(str("#SBATCH --get-user-env\n"))

					# log and error-file output
					job.write(str("#SBATCH --output="+cwd+"/ALLSUBDIR/"+calculate+"/logs/log_%A.out\n")) 		#log file
					job.write(str("#SBATCH --error="+cwd+"/ALLSUBDIR/"+calculate+"/errs/error_%A.out\n")) 	#error file
					job.write("#\n")

					#Memory consumption and cluster setup(number of cores)
					job.write("#SBATCH -N "+str(int(ceil(float(NNUM)/16.)))+"\n")
					job.write("#SBATCH -p ProdQ \n")
					job.write("#SBATCH -A dsast026c\n")

					#Job Runtime definition
					job.write("#SBATCH --time=36:00:00\n")
					
					#execution commands
					job.write(str('mpirun -np '+NNUM+' --bind-to core '+cwd+'/ALLSUBDIR/'+calculate+'/BASH/'+bashname+'\n'))
                                if cluster == "CSRNWU":
			                #Uses qsub
                                        #run through bash
                                        job.write("#$ -S /bin/bash\n")
                                        job.write("#\n")

                                        #Set name
                                        job.write("#set name\n")
				        job.write("#$ -N "+calculate+shock+rad+"\n")
                                        job.write("#\n")

                                      
                                        job.write("set log/err outputs\n")
                                        job.write("#$ -j n\n")	#logs and error seperated joined
                                        job.write("#\n")
				        # log and error-file output
				        job.write(str("#$ -o "+cwd+"/ALLSUBDIR/"+calculate+"/logs\n")) 		#log file
                                        job.write(str("#$ -e "+cwd+"/ALLSUBDIR/"+calculate+"/errs\n")) 		#log file
				        job.write("#\n")

				        #Reserving slots
				        job.write("#reserve slots\n")
				        job.write("#$ -R y\n")
				        job.write("#\n") 

                                        #Mail
                                        job.write("#send mail on job's begin, end and abort\n")
                                        job.write("#$ -m bae\n")
				        job.write("#\n") 

                                        
				        #Memory consumption and cluster setup(number of cores)
                                        job.write("#memory consumption\n")
				        job.write("#$ -l h_vmem=5G\n")
				        job.write("#\n") 
                                      
				        #Job Runtime definition
                                        job.write("#max runtime\n")
				        job.write("#$ -l h_rt=48:00:00\n") #runtime limit
				        job.write("#\n") 

                                        
                                        #use parallel queue
                                        job.write("#parallel queue\n")
                                        job.write("#$-q parallel.q\n")
				        job.write("#\n") 
                                        
                                        #allocate cores
                                        job.write("#allocate cores\n")
                                        job.write(str('#$-pe mpi-ib-0 '+NNUM+'\n'))
				        job.write("#\n") 
                                        
				        #source commands
                                        job.write("source " + patrondir +"/../RATPaC_software/login_RATPaC.sh\n")
				        job.write("source " + patrondir + "/login-patron_CLUSTER.sh --developer --"+patrondir+"\n") #make dynamic
				        job.write("#\n") 
				                                                
				        #execution commands
				        job.write(str('mpirun -np '+NNUM+' --bind-to core '+cwd+'/ALLSUBDIR/'+calculate+'/BASH/'+bashname+'\n'))
				        job.write("#\n") 

                                                                        
                                        
			#Uses qsub
			if calculate!="CRSPE0" and calculate!="RADSPEALL" and calculate!="CRSPE3":
				job.write("#$ -j y\n")	#logs and error seperated joined

				job.write("#\n")
				# log and error-file output
				job.write(str("#$ -o "+cwd+"/ALLSUBDIR/"+calculate+"/logs\n")) 		#log file
				job.write("#\n")

				#Reserving slots
				job.write("#reserve slots\n")
				job.write("#$ -R y\n")
				job.write("#\n") 

				#Memory consumption and cluster setup(number of cores)
				job.write("#$ -l h_rss=5G\n")

				#Job Runtime definition
				job.write("#$ -l h_rt=00:29:59\n")
				job.write(str("#SBATCH --output="+cwd+"/ALLSUBDIR/"+calculate+"/logs/log_%A.out\n")) 		#log file
				job.write(str("#SBATCH --error="+cwd+"/ALLSUBDIR/"+calculate+"/errs/error_%A.out\n"))

				#login-file definition
				job.write("source " + patrondir + "/login-patron_CLUSTER.sh --developer --" + patrondir+"\n") 
				job.write("export _LD_LIBRARY_PATH=$LD_LIBRARY_PATH\n")

				#execution commands
				job.write(str(cwd+"/ALLSUBDIR/"+calculate+"/BASH/"+bashname+"\n"))


			job.close()
			st = os.stat(str('ALLSUBDIR/'+calculate+'/JOBS/'+jobname))
			os.chmod(str('ALLSUBDIR/'+calculate+'/JOBS/'+jobname),st.st_mode | stat.S_IEXEC)


	#creating executable
	executable=open('patron.sh','w')
	executable.write("#!/bin/bash\n")
	if mode=="LOCAL":

		for shock in shocklist:
			for rad in radlist:
				bashname="Executable_"+shock+rad+".sh"
				executable.write(str("time -p mpirun -np "+str(NNUM)+" ALLSUBDIR/"+calculate+"/BASH/"+bashname+"| tee ./ALLSUBDIR/"+calculate+"/logs/log_LOCAL_"+shock+rad+"\n")) #test of tee|
	elif mode=="CLUSTER":
		if calculate=="CRSPE1" or calculate=="CRSPE2" or calculate=="CRSPE3" or calculate=="CRPROF" or calculate=="RADSPE" or calculate=="RADSPEALL" or calculate=="RADMAP" or calculate=="RADM3D" or calculate=="MAPSPE" or calculate=="MAPINT":
			executable.write("source /usr/gridengine/default/common/settings.sh\n")

		for shock in shocklist:
			for rad in radlist:
				jobname="Job_"+shock+rad+".sh"
				if calculate=="CRSPE0":
                                        if cluster == "CSRNWU":
					        executable.write(str("qsub "+cwd+"/ALLSUBDIR/"+calculate+"/JOBS/"+jobname+"\n"))
					else:
                                                executable.write(str("sbatch "+cwd+"/ALLSUBDIR/"+calculate+"/JOBS/"+jobname+"\n"))
				else:
					#serial cluster still with SL6?
                                        if cluster == "CSRNWU":
                                                executable.write(str("qsub "+cwd+"/ALLSUBDIR/"+calculate+"/JOBS/"+jobname+"\n"))
					else:
                                                executable.write(str("sbatch "+cwd+"/ALLSUBDIR/"+calculate+"/JOBS/"+jobname+"\n"))


	else:
		print "Runmode invalid!"
		sys.exit(0)
	executable.close()
	st = os.stat('patron.sh')
	os.chmod('patron.sh',st.st_mode | stat.S_IEXEC)

##Ensures that there is a valid file with output-times for the RATPaC aclculation
#
#Checks if there is a file named timeslist in the runfolder and creates a file if none is found. The automatic timelist-creation depends on the parameters "timestart", "timefinish" and "timeinterval" in the parameters-file. 
def CreateTimesList():
	print "\nChecking for Timeslist..."
	if ReadXMLPar("timeslist","Parameters.xml")==None:
		if os.path.isfile('timeslist'):
			print "Using standard timelist-file found in work directory..."
			return	
		print "\tNo timelist-file given, creting standard one..."
		timestart	= int(ReadXMLPar("timestart","Parameters.xml"))
		timeintervall	= int(ReadXMLPar("timeintervall","Parameters.xml"))
		timefinish	= int(ReadXMLPar("timefinish","Parameters.xml"))
		
		timeslist	=[]
		timeslist.append(timestart)
		while timestart+timeintervall < timefinish:
			timeslist.append(timestart+timeintervall)
			timestart = timestart+timeintervall
		timeslist.append(timefinish)
		#print timeslist.zfill(5), len(timeslist)
		timeslistfile=open('timeslist','w')
		for time in timeslist:
			print>>timeslistfile, str(time).zfill(5)
		timeslistfile.close()
	else :
		print "\tUsing given Timeslist: ", ReadXMLPar("timeslist","Parameters.xml")
		timeslistfile=ReadXMLPar("timeslist","Parameters.xml")
		if os.path.isfile(timeslistfile):
			shutil.copy(timeslistfile,'timeslist')
		else:
			print "\nERROR: No file found!"
			sys.exit(0)
##Creates a list with the shocks for which the simulation has to be run
#
#FSA=Forward shock analytic; FSH=Forward shock hydro; RSH=reverse shock hydro.
#
#Potentially outdated. 
def CreateShockList():
	print "\nChecking for Shoklist..."
	if os.path.isfile('shocklist'):
			print "Using shocklist-file found in work directory..."
			return
	shocklist = []
	in_value = "FSA"	
	while in_value != "":
		in_value = raw_input("Enter shock(s) for calculation(FSA, FSH, RSH, Enter to continue)\n")
		if in_value == "FSA" or in_value == "FSH" or in_value == "RSH":
			shocklist.append(in_value)
		elif in_value == "":
			break
		else:
			print "Invalid input, press enter to exit"
	if shocklist != []:	
		shocklistfile=open('shocklist','w')
		for shock in shocklist:
			print>>shocklistfile, str(shock)
		shocklistfile.close()
		print "Shocklist created..."
	else:
		print "No shocks given..."

##Contains the radiation types that are calculated for post-processing
#
#Radiation types that are supported right now are divided in two groups. A fast routine (ends always with "V") calculates the emission based on volume averages of all involved quantities. A more precise routine calculates the emission at every grid-point (ends on R).
#
#PD - Gamma-ray emission from neutral Pion-deay: PDR, PDV; see also pdecay.py \n 
#IC - Inverse Compton emission; by default only due to interaction with the CMB: ICR, ICV; see also incomp.py \n 
#SY - Synchrotron emission of electrons: SYR, SYV; see also synchr.py \n 
#NU - Neutrinos produced by hadronic interactions: NUV, NUTHEO; see also neutrinodecay.py \n 
#TH - Thermal (X-ray) emission: THR, THX; see also thermx.py \n
#BR - non-thermal Bremststrahlung; see also bremss.py 
def CreateRadiationList():
	print "\nChecking for radiationlist..."
	if os.path.isfile('radlist'):
			print "Using radlist-file found in work directory..."
			return
	radlist = []
	radtypes = ["ICR","ICV","PDR","PDV","SYR","SYV","THR","BRV","NUV", "NUVTHEO"]
	in_value = "PR"	
	while in_value != "":
		in_value = raw_input("Enter Radiation-type that shall be calculated (ICR,ICV,PDR,PDV,SYR,SYV,THR,BRV,NUV,NUVTHEO)\nPress enter to continue)\n")
		if in_value in radtypes:
			radlist.append(in_value)
		elif in_value == "":
			break
		else:
			print "Invalid input...try again"

	if radlist != []:	
		radlistfile=open('radlist','w')
		for rad in radlist:
			print>>radlistfile, str(rad)
		radlistfile.close()
		print "Radiationlist created..."
	else:
		print "No radiation-type(s) given..."
##Creates the directory structure of the rundirectory
#
#Creates all subfolders to store the simulation output.
def CreateDIRs():
	print "\nCreating Directory structure..."
	calculate = ReadXMLPar("calculate","Parameters.xml")
	allsubdir = os.getcwd()+"/ALLSUBDIR/"+calculate #make in advance
	createdir(os.getcwd()+"/ALLSUBDIR/"+calculate)
	createdir(allsubdir+"/JOBS")
	createdir(allsubdir+"/PARS")
	shutil.rmtree(allsubdir+"/JOBS")
	shutil.rmtree(allsubdir+"/PARS")
	createdir(allsubdir+"/JOBS")
	createdir(allsubdir+"/PARS")
	createdir(allsubdir+"/BASH")
	createdir(allsubdir+"/logs")
	createdir(allsubdir+"/errs")
	createdir(allsubdir+"/host")

	print "Creating HDPROFILES directory..."
	createdir("HDPROFILES")
	HDDIR=os.getcwd()+"/HDPROFILES"
	
	print "Creating MFPROFILES directory..."
	createdir("MFPROFILES")
	MFDIR=os.getcwd()+"/MFPROFILES"

	print "Creating COSMICRAYS directory..."
	createdir("COSMICRAYS")
	CRDIR=os.getcwd()+"/COSMICRAYS"
	
	print "Creating TURBULENCE directory..."
	createdir("TURBULENCE")
	MTDIR=os.getcwd()+"/TURBULENCE"
	
	print "Creating RADIATIONS directory..."
	createdir("RADIATIONS")
	createdir("RADIATIONS/SPE")
	createdir("RADIATIONS/MAP")
	createdir("RADIATIONS/MSP")
	createdir("RADIATIONS/MHDDATA")
	RPDIR=os.getcwd()+"/RADIATIONS"

	for crspecies in ["PR", "EL", "HE","C", "OX", "FE"]:
 		print "Creating COSMICRAYS/"+crspecies+" directory ..."
		createdir(CRDIR+"/"+crspecies)

		#print "Creating TURBULENCE/"+crspecies+" directory ..."
		#createdir(MTDIR+"/"+crspecies)

		print "Creating cosmic rays SUM directories..."
		createdir(CRDIR+"/"+crspecies+"/SUM")
		createdir(CRDIR+"/"+crspecies+"/SUM/R")
		createdir(CRDIR+"/"+crspecies+"/SUM/F")
		createdir(CRDIR+"/"+crspecies+"/SUM/S")

		print "Creating cosmic rays ESC directories..."
		createdir(CRDIR+"/"+crspecies+"/ESC")
		createdir(CRDIR+"/"+crspecies+"/ESC/R")
		createdir(CRDIR+"/"+crspecies+"/ESC/F")
		createdir(CRDIR+"/"+crspecies+"/ESC/S")
		createdir(CRDIR+"/"+crspecies+"/ESC")

		for shocktype in ["FSA", "FSH", "RSH"]:
			createdir(CRDIR+"/"+crspecies+"/"+shocktype)
			
        for shocktype in ["FSA", "FSH", "RSH"]:
                createdir(MTDIR+"/"+shocktype)

##Creates and saves a new Parameters.xml file
#
#Loades the current parameters-configuration from CreateTree() and saves it in human-readable form. 
def CreateXML():
	print "\nCreating new Parameter-File..."
	
	tree=CreateTree()
	tree.write("Parameters.xml")

	#Formating XML to make it human readable	
	xml = minidom.parse("Parameters.xml")
	pretty = xml.toprettyxml()
	xml_file = open("Parameters.xml", "w")
	xml_file.write(pretty)
	xml_file.close()

	print "New Parameter-File created"

##Creates a ElementTree object with all the run-relevant parameters
#
#Contains the definitions of all parameters that are stored in the parameter-file. It uses the CreateSubElement()-function to create the entries "Description", "Allowed Value" and "Value" for each parameter. The entries of "Value" are the ones extracted for the configuration of the simulation.\n 
def CreateTree():
	Pars = ET.Element("PARAMETERS")

	#Generell Parameters
	CreateSubElement(Pars, "mode","Runmode","LOCAL, CLUSTER","LOCAL")
	CreateSubElement(Pars, "nnum","Number of cores","int","8")

	CreateSubElement(Pars, "calculate","Defienes the simulation-stage to be calculated","CRSPE0, CRSPE1, CRSPE2, CRSPE3, CRPROF, RADSPE, RADMAP, RADM3D, MAPSPE, MAPSPE_PARALLEL, MAPINT", "CRSPE0")
	CreateSubElement(Pars, "shockgeom","Schock geometry, plane-parallel or spherically-symmetric","PP, SS", "SS")

	CreateSubElement(Pars, "rstepsnum","number of bins in r-space for calculations","int","400")
	CreateSubElement(Pars, "pstepsnum","number of bins in p-space for calculations","int","560")
	CreateSubElement(Pars, "kstepsnum","number of bins in k-space for turbulence calculations","int","560")
	CreateSubElement(Pars, "rcoordmax","maximum in r-space (real maximum is (RCOORDMAX-1)**3+1) for calculations","float","5.0")
	CreateSubElement(Pars, "pcoordmax","maximum in p-space is 0.75*PCOORDMAX", "float", "28.0")

	CreateSubElement(Pars, "timeslist","File name and location of timeslist","File-path","")
	CreateSubElement(Pars, "timestart","Start time for automatic time-generation","int","20")
	CreateSubElement(Pars, "timeintervall",	"Time-intervall for automatic time-generation","int","100")

	##########################################################
	CreateSubElement(Pars, "timefinish","Stop time for automatic time-generation","int","1000")
	CreateSubElement(Pars, "timecont","Starting time for continuing simulation for CRSPE0","int","")
	CreateSubElement(Pars, "timeinout","Output time for any post-processing step","int","01000")

	CreateSubElement(Pars, "regrid_flag","Enables dynamic regriding in pluto","NO, RC","NO")
	CreateSubElement(Pars, "regrid_time","Time from which regriding is applied","float","0.5")
	CreateSubElement(Pars, "regrid_fact","Sets the factor by which the boundary is moved","double","10")

	CreateSubElement(Pars, "shock_finder","Sets the shock-finding algorithm","str","default")
  
############################################################################################################

	##########################################################

	##CLUSTER Parameters subsection
	#CLUSTER   = ET.SubElement(Pars,"CLUSTER_VARIABLES")

	CreateSubElement(Pars,"institute","Instititute/Cluster infrastructure","DESY, KAY, CSRNWU","DESY")

	##########################################################	
	
	##SNR Parameters subsection
	SNR   = ET.SubElement(Pars,"SUPERNOVA_REMNANT")

	CreateSubElement(SNR,"usesedsol","Hydrodynamics: 0 - free expansion analytic solutions, 1 - Sedov analytic solutions, 2 - semi-analytic Sedov and transition stage solutions, 3 - simple fake constant profiles, 4 - simulated hydro in Vikram's files format, 5 - solving hydro with Pluto on the fly","0, 1, 2, 3, 4, 5","1")
	CreateSubElement(SNR,"snsubtype","SN subtype","type1a, type1c, type2p","type1a")
	CreateSubElement(SNR,"explntype","SN explosion type","T1,T2","T1")
	CreateSubElement(SNR,"windbncsm","if TRUE density profile will be calculated from mass-loss rate and wind velocity, else from setup density","TRUE,FALSE","FALSE")
        CreateSubElement(SNR,"windbubrad","Radius of the wind blown bubble", "float","10.0")
	CreateSubElement(SNR,"nhdensity","density of the ISM in the explosion region", "float","0.1")
	CreateSubElement(SNR,"expenergy","SN explosion energy (valid for analytical solutions) in erg","float","1e51")
	CreateSubElement(SNR,"rshellpc1","near boundary of the dense shell/mc in parsec","float","50.0")
	CreateSubElement(SNR,"rshellpc2","far  boundary of the dense shell/mc in parsec","float","51.0")
	CreateSubElement(SNR,"shdensity","shell/mc density","float","0.1")

	CreateSubElement(SNR,"plutoflag","Parameter to steer Pluto","on,off,pure","off")
	CreateSubElement(SNR,"plutodll","Define wich precompiled Pluto-library to use","str","pluto_vik.so")

	##########################################################

	##MF Parameters subsection
	MF   = ET.SubElement(Pars,"MAGNETIC_FIELD")

        CreateSubElement(MF,"mfinitime","Initial time for magnetic field profiles calculation. Has to be not lower than the hydro start time", "float", "20.0")
	CreateSubElement(MF,"mfofismna","Magnetic field of the ISM far upstream of the shock in microGauss", "float", "5e-6")
        CreateSubElement(MF,"mfstarsurf","Magnetic field at the surface of the progenitor star in Gauss", "float", "10.0")
        CreateSubElement(MF,"starrad","Radius of the progenitor star in solar radii", "float", "100.0")
	CreateSubElement(MF,"mfintprof","the profile of the MF inside the stellar ejecta","FLAT, PWLAW, PWLPL","FLAT")
	CreateSubElement(MF,"mfinitcon","initial value of the MF inside the stellar ejecta at the age of 5 days in Gauss","float","12.0")
	CreateSubElement(MF,"mfdampsca","Damping length for damped magnetic field profile", "float", "0.01")
	CreateSubElement(MF,"mfscabins","Scaling factor in front of BISM(B0=BISM*MFSCABINS) for damped magnetic field profile","float","1.0")
	CreateSubElement(MF,"mfatshock","Magnetic field at front-shock, 0.0 means, amplification factor is used","float","0.0")
	CreateSubElement(MF,"mfampfact","Amplification factor for magnetic field at the shock","float","1.0")
	#CreateSubElement(MF,"mfampmode","Amplification Mode resonant or non-resonant.","NAMP, RAMP","")
	CreateSubElement(MF,"mfprofile","Profile of Background magnetic field","CON,COM,SED,DAM,RHO,PRE,TR1,TRA","COM")
	CreateSubElement(MF,"alfvdrift","Switch for using alfvenic drift (I=off)","I,A","I")

	##########################################################

	##CR Parameters subsection
	CRs  = ET.SubElement(Pars,"COSMIC_RAYS")

        CreateSubElement(CRs, "speciespr", "Switch for protons: 1 - on, 0 - off", "1,0", "1") 
        CreateSubElement(CRs, "speciesel", "Switch for electrons: 1 - on, 0 - off", "1,0", "1") 
	CreateSubElement(CRs, "specieshe", "Switch for helium: 1 - on, 0 - off", "1,0", "0")
	CreateSubElement(CRs, "speciesc", "Switch for carbon: 1 - on, 0 - off", "1,0", "0")
	CreateSubElement(CRs, "speciesox", "Switch for oxygen: 1 - on, 0 - off", "1,0", "0")
	CreateSubElement(CRs, "speciesfe", "Switch for iron: 1 - on, 0 - off", "1,0", "0")

        CreateSubElement(Pars, "abundanceh","mass fraction of hydrogen","float","0.71")
        CreateSubElement(Pars, "abundancehe","mass fraction of helium","float","0.28")
        CreateSubElement(Pars, "abundancec","mass fraction of carbon","float","2e-3")
        CreateSubElement(Pars, "abundanceo","mass fraction of oxygen","float","2.06e-3")
        CreateSubElement(Pars, "abundancefe","mass fraction of iron","float","4e-4")

	CreateSubElement(CRs, "crinitcon","CR-background switch, CRBKG: CR background on, NOBKG: CR background off","CRBKG,NOBKG ","NOBKG")

	CreateSubElement(CRs, "crfeedback","Decides weather CR-feedback is applied: 1 - yes, 0 - no","1, 0","0")
	CreateSubElement(CRs, "crfeedbackregion","Decides where CR-feedback is applied: no downstream feedback(0),full downstream feedback(1),constant CR-density downstream(2)","0,1,2","1")

	CreateSubElement(CRs,"injectpar","Injection Parameter, multiple of thermal momentum at wich particles are injected as CRs","float","4.2")
	CreateSubElement(CRs,"injsclparpr","Linear scaling-parameter for CR injection, protons" ,"float","1.0")
	CreateSubElement(CRs,"injsclparel","Linear scaling-parameter for CR injection, electrons" ,"float","1.0")
	CreateSubElement(CRs,"injsclparhe","Linear scaling-parameter for CR injection, helium" ,"float","1.0")
	CreateSubElement(CRs,"injsclparc","Linear scaling-parameter for CR injection, carbon" ,"float","1.0")
	CreateSubElement(CRs,"injsclparox","Linear scaling-parameter for CR injection, oxygen" ,"float","1.0")
	CreateSubElement(CRs,"injsclparfe","Linear scaling-parameter for CR injection, iron" ,"float","1.0")
	CreateSubElement(CRs,"injsclindex","Index for power-law time-dependance of injection" ,"float","0.0")
	CreateSubElement(CRs,"ramptime","Time-window over which injection is ramped up from 10-3 to 1.0 times the injection value" ,"float","0.0")

	CreateSubElement(CRs,"lmaxbdiff","distance limit (maximum) in SNR radii units where Bohm diffusion applies","float","1.0")
	CreateSubElement(CRs,"lmingdiff","distance limit (minimum) in SNR radii units where Galactic diffusion applies","float","2.0")
	CreateSubElement(CRs,"diffinter","transition type in intermedium region between two limits above", "LIN, EXP","EXP")
	CreateSubElement(CRs,"etaofbohm","if MTSPECTRA==BOHM, possible to specify Bohm eta parameter (default is 1.0)","float","1.0")

	CreateSubElement(CRs,"momdifpow","momentum diffusion power parameter", "float","0.2")
	CreateSubElement(CRs,"momdiftau","momentum diffusion time scale","float","2.7")
	CreateSubElement(CRs,"momdiffr1","Rmin of SOFA activity (normally assumed downstream)","float","1.0")
	CreateSubElement(CRs,"momdiffr2","Rmax of SOFA activity","float","1.0")
	CreateSubElement(CRs,"momdifsclel","max kinetic energy for isotrop particle distribution, provides p_0_el, in GeV","float","0.0005")     
	CreateSubElement(CRs,"momdifsclpr","max kinetic energy for isotrop particle distribution, provides p_0_pr, in GeV","float","0.0005")
	CreateSubElement(CRs,"momdifsclhe","max kinetic energy for isotrop particle distribution, provides p_0_he, in GeV","float","0.0005") 
	CreateSubElement(CRs,"momdifsclc","max kinetic energy for isotrop particle distribution, provides p_0_c, in GeV","float","0.0005") 
    	CreateSubElement(CRs,"momdifsclox","max kinetic energy for isotrop particle distribution, provides p_0_ox, in GeV","float","0.0005") 
	CreateSubElement(CRs,"momdifsclfe","max kinetic energy for isotrop particle distribution, provides p_0_fe, in GeV","float","0.0005")  
	##########################################################
	
	##Turbulence Parameters subsection
	TURB = ET.SubElement(Pars,"MAGNETIC_TURBULENCE")

	CreateSubElement(TURB, "mtapplied", "Switch for using self-consistent turbulence modul", "ANALYTIC, NUMERIC", "ANALYTIC")
	CreateSubElement(TURB, "mtspectra", "Used if MTAPPLIED==ANALYTIC, defienes shape of diffusion coefficient", "BOHM, KOLM, KRAI, HAND","BOHM")
	CreateSubElement(TURB, "mtinitcon", "Initial Condition of magnetic turbulence-spektrum", "KOLM, EXP05", "KOLM")
	CreateSubElement(TURB, "ensdsturb", "Fraction of the downstream fluid energy density that is transfered to postshock turbulence", "float", "0.002")
	CreateSubElement(TURB, "lesdsturb", "Thickness of the postshock turbulence region", "float", "0.0075")
	CreateSubElement(TURB, "turbfield", "Switch for self-consistent magnetic field", "0,1", "0")
	CreateSubElement(TURB, "turbampfact", "Factor by which the resonant growth-rate gest boosted", "float", "1.0")

	###########################################################

	##Radiation subsection
	RAD = ET.SubElement(Pars,"RADIATION_PARAMETERS")

	CreateSubElement(RAD, "rstepsnumrs","Reverse-shock: number of bins in r-space for calculations","int","400")
	CreateSubElement(RAD, "rstepsnumfs","Forward-shock: number of bins in r-space for calculations","int","400")
	CreateSubElement(RAD, "rcoordmaxrs","Reverse-shock: maximum in r-space","float","5.0")
	CreateSubElement(RAD, "rcoordmaxfs","Forward-shock: maximum in r-space","float","5.0")

	CreateSubElement(RAD, "radorigin","SUM/S: radiation from particles originated at both shocks, SUM/F: at forward shock only, SUM/R: at reverse shock only, FSA, FSH", "SUM/S, SUM/F, SUM/R, FSA", "FSA")
	CreateSubElement(RAD, "crsenergy","Energy in GeV for production of cosmic rays profile","int","1000")
	CreateSubElement(RAD, "radobject","SNR: radiation from snr, MCL: from molecular cloud, SHL: from shell","SNR, MCL, SHL","SNR")
	CreateSubElement(RAD, "synemfunc", "synchrotron emissivity function","STANDARD, GAUSSIAN","STANDARD")
	CreateSubElement(RAD, "steradian", "SR: flux per cm^2 per steradian, NO - per cm^2","SR,NO","NO")
	CreateSubElement(RAD, "snrdistpc", "SNR distance in parsecs","float","1000")
	CreateSubElement(RAD, "radintres", "Number of steps for radiation integration over r","int","200")
	CreateSubElement(RAD, "radnormax", "Position of the shock in normalised coordinates","1.0","1.0")
 	
	CreateSubElement(RAD, "createmap", "TRUE: creates surface map, FALSE: creates intensity profile scaled to max","TRUE, FALSE","TRUE")
	CreateSubElement(RAD, "mapenergy", "Energyfor which map is created in eV, give range for MAPINT mode", "float", "1e0")
	CreateSubElement(RAD, "hemispher", "LHS: left hemisphere, RHS: right hemisphere, "": total", "LHS, RHS, ", "")
	CreateSubElement(RAD, "rotmapxyz", "Rotation of map", "float, float, float", "0.,0.,0.")
	CreateSubElement(RAD, "scaleinpc", "Map scale in pc. if 0.0 no scaling applied", "float", "0.0")
	CreateSubElement(RAD, "mfcompdim", "?", "1D, 2D", "1D")

	CreateSubElement(RAD, "ucmb", "Energy density of the CMB in Gev/cm^3", "2.6e-10", "2.6e-10")
	CreateSubElement(RAD, "udust", "Energy density of IR-background photon field in Gev/cm^3", "1e-9", "0.0")
	CreateSubElement(RAD, "ustarlight", "Energy density of the strlight photon field in Gev/cm^3", "1e-9", "0.0")
	CreateSubElement(RAD, "Tcmb", "Temperature of the CMB photon-field in K", "2.7", "2.7")
	CreateSubElement(RAD, "Tdust", "Temperature of IR-background photon field K", "1.4e2", "1.4e2")
	CreateSubElement(RAD, "Tstar", "Temperature of the strlight photon field in K", "2e5", "2e5")
	###############################################
   

	
	##Directories subsection
	DIRS = ET.SubElement(Pars,"DIRECTRORIES")

	CreateSubElement(DIRS,"hdfileout","File name for hydrodynamic files","string","hraw")
	CreateSubElement(DIRS,"mffileout","File name for magnetic-field files","string","BRAW")
	CreateSubElement(DIRS,"crfileout","File name for cosmic ray files","string","NRAW")
	CreateSubElement(DIRS,"mtfileout","File name for turbulence files","string","TRAW")

	CreateSubElement(DIRS,"mhdfileout","File name for MHD output which is then used as input for all radiation stages","string","MHD")

	CreateSubElement(DIRS,"hdsimname","Folder containing Vikrams hd-data","subdirectory of: data/snrmhd/hd","type1a")
	CreateSubElement(DIRS,"mfmodel","Folder containing MF-data for Vikrams hd-data","subdirectory of: data/snrmhd/mf/'hdsimname'","B00500")

	CreateSubElement(DIRS,"hdfileinp","Name of vikrams hd-files e.g. tycho, type1a, HRAW, etc.","str","tycho")
	CreateSubElement(DIRS,"mffileinp","","","")
	CreateSubElement(DIRS,"crfileinp","","","")
	CreateSubElement(DIRS,"mtfileinp","","","")
	###########################################################
	return 	ET.ElementTree(Pars)

##This function checks the validity of a Parameter file.
#
#The function opens the parameter-file and cross checks the elements with a reference tree created by CreateTree(). \n 
#A list of all missing elements is created and the user is given the option to interactively update the incomplete parameter file. Entries can be entered by keyboard or the default values can be used.\n 
#There is no consitency check enabled if the entered values are in accordance with the allowed values.
#
#input: xml_file=name of the parameter-file in the the rundirectory \n 
def CheckXML(xml_file):
	print "Checking Parameter-file..."	
	tree_ref   = CreateTree()
	tree_new   = ET.parse(xml_file)
	root       = tree_new.getroot()
	root_old   = tree_ref.getroot()
	errorcount = 0
	errorlist  = []	

	for Elem in tree_ref.iter():
		if Elem.tag != "Value" and Elem.tag != "Allowed_value" and Elem.tag != "Description":
			i=0			
			for elem in root.iter(Elem.tag):
				i=1
			if i==0:
				errorcount = errorcount+1
				if errorcount ==1: print "ERROR: Invalid Parameter-file!"
				print "\t Parameter ", Elem.tag," not defined in ", xml_file
				errorlist.append(Elem.tag)

	if errorcount == 0:
		print "Parameter file checked...seems fine"
	else:
		print "Do you want to interactively update your Parameter-file?"
		selection=raw_input("Please Select: y/n\n")
		if selection == "n":
			return
		elif selection != "y":
			print "I'll get a cofee..."
			return
		else:
			#Replace values in reference tree with values from read in Parameter file
			for Elem in tree_ref.iter():
				for elem in root.iter(Elem.tag):
					if elem.tag != "Value" and Elem.tag != "Allowed_value" and Elem.tag != "Description" and elem.find("Value")!=None:
						Elem.find("Value").text = elem.find("Value").text

			#Upade undefined values
			for i in range(errorcount):
				for missing in tree_ref.iter(errorlist[i]):
					print '\nParamterer "', errorlist[i], '" was missing\nDescription: ', missing.find("Description").text, "\nAllowed value(s): ", missing.find("Allowed_value").text, "\nDefault value: ", missing.find("Value").text
					selection=raw_input("Use default value? (y/n)\n")
  					if selection == "y":
						missing.find("Value").text = missing.find("Value").text
					elif selection != "n":
						print "Yes or no? This question wasn't that hard, was it? Humans...\n"
						sys.exit(0)	
					else:
						selection=raw_input("Please enter value:\n")
						missing.find("Value").text = selection

			selection =  raw_input("I am not checking if your inputs made sense... Do you want to write the file to disk? (y/n)\n")
			if selection == "y":
				print "Writing file to disk..."	
				tree_ref.write("Parameters.xml")
				#Formating XML to make it human readable	
				xml = minidom.parse("Parameters.xml")
				pretty = xml.toprettyxml()
				xml_file = open("Parameters.xml", "w")
				xml_file.write(pretty)
				xml_file.close()
				print "Done."	

##Extracts a specific parameter from the parameter file.
#
#Recursively searches the parsed xml-file and returns the value-field of the desired parameter
#
#input: \n
#Par=Parameter name as defined in CreateTree() \n 
#xml_file=Name of the parameter-file that is going to be read
def ReadXMLPar(Par,xml_file):
	tree = ET.parse(xml_file)
	root = tree.getroot()
	i=0
	for elem in root.iter(Par):
		i=1
	if i==0:
		print "ERROR: Parameter ",Par,"\t\t not found in ", xml_file
		sys.exit(0)

	for elem in root.iter(Par):
		return elem.find("Value").text

##Provides the data-structure for the parameters in the parameter-files
#
#Creates subelements for a parameter that are: Description, Aloowed_value and Value
#
#input: \n 
#Parent=Category the parameter belongs to, e.g. PARAMETERS (general parameter), SUPERNOVA_REMNANTS (for object-related parameter), etc... \n
#Name=Name of the parameter as it will be stored in the Parameter file \n 
#Description=Brief description of the parameter as text \n 
#AValue="Allowed value"; Value(s) that the parameter can take and that will be understood when the parameter is read \n 
#Value=Value of the corresponding parameter  
def CreateSubElement(Parent,Name,Description,AValue,Value):
	elem = ET.SubElement(Parent,Name)
	ET.SubElement(elem,"Description").text = Description
	ET.SubElement(elem,"Allowed_value").text = AValue
	ET.SubElement(elem,"Value").text = Value

##Helper routine for directory creation
#
#Checks if a directory exsits and creates it if not 
def createdir(directory):
	if not os.path.exists(directory):
		os.makedirs(directory)


if __name__ == "__main__":sys.exit(main())

