######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  snrrad.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2007 - 2015
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v2.0.0: parameters module setpar v.1.0.0 introduced;!!!NOT TESTED!!! WILL NOT RUN WITHOUT MODIFICATIONS
#v2.1.0: skipped. running with old data structure and parameters module will not be supported
#v2.2.0: introducing main function to allow import as a module alone with independent run, parameters changed to work with global setpar module compliant with patron 2.2.x and higher
#v2.3.0: version control added, sp changed to patron.setpar
#v2.4.0: reads mhd data from the output file. main deleted as it is not needed anymore.

__version__='2.4.0'

import patron.setpar

from numpy import *
from scipy import interpolate
from scipy.integrate import quad
from os import getenv
from fipy.tools import parallel
global Bf,N,R1,R2,V,A,I,RCR,ECR,NCR


def B(r,MFR,MFB):
	B=interpolate.interp1d(MFR,MFB, bounds_error=False, fill_value=0.0)(r)
	return B

def ni(r,HDR,HDN):
	n=interpolate.interp1d(HDR,HDN, bounds_error=False, fill_value=0.0)(r)
	return n

def Tg(r,HDR,HDT):
	Tg=interpolate.interp1d(HDR,HDT, bounds_error=False, fill_value=0.0)(r)
	return Tg


def SS_TH(r,dr,E,t,HDR,HDN,HDT):
	T_g = Tg(r,HDR,HDT)
	ne = ni(r,HDR,HDN)*1.2
	LEN=len(r)
	FatER=arange(LEN,dtype=float)
	for i in range(0,LEN):
		FatER[i]=patron.setpar.thermx.F_atE_atR_TH(E,ne=ne[i],T=T_g[i])
	return FatER

def SS_SY(r,dr,E,t,MFR,MFB):
	MF = B(r,MFR,MFB)*Bf
	LEN=len(r)
	FatER=arange(LEN,dtype=float)
	for i in range(0,LEN):
		patron.setpar.synchr.spe=patron.setpar.psread.spe_dif(r[i],dr,(RCR,ECR,NCR))
		FatER[i]=patron.setpar.synchr.F_atE_atR_SY(E,B=MF[i])
	return FatER
		
def SS_IC(r,dr,E,t):
	LEN=len(r)
	FatER=arange(LEN,dtype=float)
	for i in range(0,LEN):
		patron.setpar.incomp.spe=patron.setpar.psread.spe_dif(r[i],dr,(RCR,ECR,NCR))
		FatER[i]=patron.setpar.incomp.F_atE_atR_IC(E)
	return FatER

def SS_PD(r,dr,E,t,cr,HDR,HDN):
        n = []
        for i,hdn in enumerate(HDN):
                n.append(ni(r,HDR,hdn))
        n = asarray(n)
	LEN=len(r)
	FatER=arange(LEN,dtype=float)
	for i in range(0,LEN):
		patron.setpar.pdecay.spe=patron.setpar.psread.spe_dif(r[i],dr,(RCR,ECR,NCR))
		FatER[i]=patron.setpar.pdecay.F_atE_atR_PD(E,cr,n=n[:,i])
	return FatER

def S_TH(E,t,HDR,HDN,HDT):
	dr=1.0/N
	r=arange(R1,R2,dr)+0.5*dr
	S=dr*r**2*SS_TH(r,dr,E,t,HDR,HDN,HDT)
	return I*S.sum()

def S_SY(E,t,MFR,MFB):
	dr=1.0/N
	r=arange(R1,R2,dr)+0.5*dr
	S=dr*r**2*SS_SY(r,dr,E,t,MFR,MFB)
	return I*S.sum()

def S_IC(E,t):
	dr=1.0/N
	r=arange(R1,R2,dr)+0.5*dr
	S=dr*r**2*SS_IC(r,dr,E,t)
	return I*S.sum()

def S_PD(E,t,cr,HDR,HDN):
	if E < 1e7:
		return 0.0
	dr=1.0/N
	r=arange(R1,R2,dr)+0.5*dr
	S=dr*r**2*SS_PD(r,dr,E,t,cr,HDR,HDN)
	return I*S.sum()

def S_vol_int_TH(t,fname,HDR,HDN,HDT):
	f=open(fname,"w")							#file object (opens/creates file)
	i=-1.0									#start of log for photon energies
	for step in range(51):							#number of bins; i is increased slightly with new bin
		E=10**i								#in eV for therm;will be changed to GeV
		F=S_TH(E,t,HDR,HDN,HDT)							#therm flux in 1/GeV cm^2 s (sr)
		f.write(str(E/1.0e9)+"\t"+str(F)+"\n") 				#writing to file: X energie, therm flux
		print "snrrad: #####POINT:",(i+1.0)/0.1,"ENERGY:",round(E,2),"[eV] IN THR IS DONE!#####"
		i=i+0.1 #0.02							#bin size in log scale
	f.close()


def S_vol_int_SY(MFR,MFB,t,fname):
	f=open(fname,"w")							#file object (opens/creates file)
	i=-8.0									#start of log for photon energies
	for step in range(141):							#number of bins; i is increased slightly with new bin
		E=10**i								#in eV for sync; will be changed to GeV
		F=S_SY(E,t,MFR,MFB)							#sync flux in 1/GeV cm^2 s (sr)
		f.write(str(E/1.0e9)+"\t"+str(F)+"\n") 				#writing to file: X energie, sync flux
		print "snrrad: #####POINT ",(i+8.0)/0.1,"ENERGY",round(E,2),"[eV] IN SYR IS DONE!#####"
		i=i+0.1 #0.02							#bin size in log scale
	f.close()

def S_vol_int_IC(t,fname):
	f=open(fname,"w")							#file object (opens/creates file)
	i=5.0									#start of log for photon energies
	for step in range(101):							#number of bins; i is increased slightly with new bin
		E=10**i								#in eV for ic; will be changed to GeV
		F=S_IC(E,t)							#ic flux in 1/GeV cm^2 s (sr)
		f.write(str(E/1.0e9)+"\t"+str(F)+"\n")				#writing to file: X energie, ic flux
		print "snrrad: #####POINT ",(i-5.0)/0.1,"ENERGY",round(E/1e9,2),"[GeV] IN ICR IS DONE!#####"
		i=i+0.1 #0.02							#bin size in log scale
	f.close()

def S_vol_int_PD(t,fname,cr,HDR,HDN):
	f=open(fname,"w")							#file object (opens/creates file)
	i=5.0									#start of log for photon energies
	for step in range(101):							#number of bins; i is increased slightly with new bin
		E=10**i								#in eV for ic; will be changed to GeV
		F=S_PD(E,t,cr,HDR,HDN)							#pd flux in 1/GeV cm^2 s (sr)
		f.write(str(E/1.0e9)+"\t"+str(F)+"\n") 				#writing to file: X energie, ic flux
		print "snrrad: #####POINT ",(i-5.0)/0.1,"ENERGY",round(E/1e9,2),"[GeV] IN PDR IS DONE!#####"
		i=i+0.1 #0.02							#bin size in log scale
	f.close()

def n_mean(HDR,HDN):
	N=1000.0
	dr=1.0/N
	r=arange(0,1.0,dr)+0.5*dr
	n_of_rl = dr*r**2*ni(r,HDR,HDN)			#n of the r layer
	return 3.0*n_of_rl.sum()			#3.0=4piR^3/(4/3.piR^3)



def ProduceRadSpectrum(radType,mhdInpFn,crInpFn,rsOutFn,crSpecies,rStepsNum,pStepsNum,timeInOut,SP):
	print "snrrad: Producing radiation spectrum ..."
	print "snrrad: R1 and R2 are",R1,R2 #,SNR.nh(1.75,timeInOut)
	global RCR,ECR,NCR
	if   radType == "THV":
		print "snrrad: add THV function to thermx"
	elif radType == "SYV":
		MHYDRO=patron.setpar.mhdread.fill_mhydro(mhdInpFn,timeInOut)
		MFR=MHYDRO.r
		MFB=MHYDRO.B
		BB = Bf*B(1.0,MFR,MFB)
		print "snrrad: effective magnetic field is",BB,"V =",V,"A =",A
		patron.setpar.synchr.spe=patron.setpar.psread.spe_vol(crInpFn)
		patron.setpar.synchr.F_spe_vol_int(BB,V,A,rsOutFn)
	elif radType == "ICV":
		patron.setpar.incomp.Uc=SP.ucmb		
		patron.setpar.incomp.Ud=SP.udust	
		patron.setpar.incomp.Us=SP.ustarlight
		patron.setpar.incomp.Tc=SP.Tcmb		
		patron.setpar.incomp.Td=SP.Tdust	
		patron.setpar.incomp.Ts=SP.Tstar
		patron.setpar.incomp.spe=patron.setpar.psread.spe_vol(crInpFn)
		print "snrrad: V =",V,"A =",A
		patron.setpar.incomp.F_spe_vol_int(V,A,rsOutFn)
	elif radType == "PDV":
		patron.setpar.pdecay.SP = SP
		patron.setpar.pdecay.target = ["H", "He", "C", "Ox"]
			
		del patron.setpar.pdecay.gmatr[:]
		del patron.setpar.pdecay.cmatr[:]			
			
		for i,tar in enumerate(patron.setpar.pdecay.target):
			gdata = getenv("PATRONDIR")+"/data/piondecay/"+crSpecies+"/gdata_"+tar+".dat"
			try:
				print "Matrix filled with data from file opened: ", gdata
				patron.setpar.pdecay.gmatr.append(fromfile(gdata, sep=' ', count=-1, dtype=float).reshape(201,374))
			except IOError:
				print "No file found:",gdata
			
			cdata = getenv("PATRONDIR")+"/data/piondecay/"+crSpecies+"/cdata_"+tar+".dat"
			try:	
				print "Matrix filled with data from file opened: ", cdata
				patron.setpar.pdecay.cmatr.append(1.0e-27*fromfile(cdata, sep=' ', count=-1, dtype=float))	#.reshape(201,374)
			except IOError:
				print "No file found:",cdata
		
		MHYDRO = patron.setpar.mhdread.fill_mhydro(mhdInpFn,timeInOut)
		HDR = MHYDRO.r
		HDN = [MHYDRO.nh, MHYDRO.nhe, MHYDRO.nc, MHYDRO.nox]
                n = []
                for i, hdn in enumerate(HDN):
                        ni_mean = n_mean(HDR,hdn)
                        n.append(ni_mean)
                        print "snrrad: average effective n for element ", patron.setpar.pdecay.target[i], " = ",ni_mean,"V =",V,"A =",A
		patron.setpar.pdecay.spe=patron.setpar.psread.spe_vol(crInpFn)
		patron.setpar.pdecay.F_spe_vol_int(n,V,A,rsOutFn,crSpecies)
    #Introduction of charged pion decay radiation into neutrinos (Neutrino Radiation = NR)
	elif radType == "NUV":
		MHYDRO = patron.setpar.mhdread.fill_mhydro(mhdInpFn,timeInOut)
		HDR = MHYDRO.r
		HDN = MHYDRO.nh
		n  = n_mean(HDR,HDN)
        	print "snrrad: average effective n is",n,"V =",V,"A =",A
        	patron.setpar.neutrinodecay.spe=patron.setpar.psread.spe_vol(crInpFn)
        	patron.setpar.neutrinodecay.F_spe_vol_int_neutrino(n,V,A,rsOutFn)

    #Introduction of charged pion decay radiation into neutrinos THEORICAL (Neutrino Radiation = NRTHEO)
    	elif radType == "NUVTHEO":
		MHYDRO = patron.setpar.mhdread.fill_mhydro(mhdInpFn,timeInOut)
		HDR = MHYDRO.r
		HDN = MHYDRO.nh
		n  = n_mean(HDR,HDN)
        	print "snrrad: average effective n is",n,"V =",V,"A =",A
        	patron.setpar.neutrinodecay.spe=patron.setpar.psread.spe_vol(crInpFn)
        	patron.setpar.neutrinodecay.F_spe_vol_int_neutrino_theo(n,V,A,rsOutFn)
	elif radType == "BRV":
		MHYDRO=patron.setpar.mhdread.fill_mhydro(mhdInpFn,timeInOut)
		HDR = MHYDRO.r
		HDN = MHYDRO.nh
		n  = n_mean(HDR,HDN)
		print "snrrad: average effective n is",n,"V =",V,"A =",A
		patron.setpar.bremss.spe=patron.setpar.psread.spe_vol(crInpFn)
		patron.setpar.bremss.F_spe_vol_int(n,V,A,rsOutFn)
	elif radType == "THR":
		MHYDRO = patron.setpar.mhdread.fill_mhydro(mhdInpFn,timeInOut)
		HDR = MHYDRO.r
		HDN = MHYDRO.nh
		HDT = MHYDRO.T
		S_vol_int_TH(timeInOut,rsOutFn,HDR,HDN,HDT)
	elif radType == "SYR":
		MHYDRO=patron.setpar.mhdread.fill_mhydro(mhdInpFn,timeInOut)
		MFR=MHYDRO.r
		MFB=MHYDRO.B
		(RCR,ECR,NCR)=patron.setpar.psread.fill_ren(rStepsNum,pStepsNum,crInpFn)
		S_vol_int_SY(MFR,MFB,timeInOut,rsOutFn)
	elif radType == "ICR":
		patron.setpar.incomp.Uc=SP.ucmb		
		patron.setpar.incomp.Ud=SP.udust	
		patron.setpar.incomp.Us=SP.ustarlight
		patron.setpar.incomp.Tc=SP.Tcmb		
		patron.setpar.incomp.Td=SP.Tdust	
		patron.setpar.incomp.Ts=SP.Tstar
			
		(RCR,ECR,NCR)=patron.setpar.psread.fill_ren(rStepsNum,pStepsNum,crInpFn)
		S_vol_int_IC(timeInOut,rsOutFn)
	elif radType == "PDR":
		patron.setpar.pdecay.SP = SP
		patron.setpar.pdecay.target = ["H", "He", "C", "Ox"]
			
		del patron.setpar.pdecay.gmatr[:]
		del patron.setpar.pdecay.cmatr[:]			
			
		for i,tar in enumerate(patron.setpar.pdecay.target):
			gdata = getenv("PATRONDIR")+"/data/piondecay/"+crSpecies+"/gdata_"+tar+".dat"
#			gdata = getenv("PATRONDIR")+"/data/piondecay/gdata.dat"
#			gdata = getenv("PATRONDIR")+"/data/piondecay/HE_old/gdata.dat"
			try:
				print "Matrix filled with data from file opened: ", gdata
				patron.setpar.pdecay.gmatr.append(fromfile(gdata, sep=' ', count=-1, dtype=float).reshape(201,374))
			except IOError:
				print "No file found:",gdata
				

			cdata = getenv("PATRONDIR")+"/data/piondecay/"+crSpecies+"/cdata_"+tar+".dat"
#			cdata = getenv("PATRONDIR")+"/data/piondecay/cdata.dat"
#			cdata = getenv("PATRONDIR")+"/data/piondecay/HE_old/cdata.dat"
			try:	
				print "Matrix filled with data from file opened: ", cdata
				patron.setpar.pdecay.cmatr.append(1.0e-27*fromfile(cdata, sep=' ', count=-1, dtype=float))	#.reshape(201,374)
			except IOError:
				print "No file found:",cdata
		
		MHYDRO = patron.setpar.mhdread.fill_mhydro(mhdInpFn,timeInOut)
		HDR = MHYDRO.r
		HDN = [MHYDRO.nh, MHYDRO.nhe, MHYDRO.nc, MHYDRO.nox]

		(RCR,ECR,NCR)=patron.setpar.psread.fill_ren(rStepsNum,pStepsNum,crInpFn)
		S_vol_int_PD(timeInOut,rsOutFn,crSpecies,HDR,HDN)
	else:
		print "snrrad: No radiation process chosen!"
	print "snrrad: radiation spectrum was produced!"


