######################################################################################
### RATPaC - Radiation Acceleration Transport PArticle Code ###
#=====================================================================================
# File:	  snrmhd.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2010 - 2015
# 	  Robert Brose <robert.brose@mail.de>, 2016 - present
#         Iurii Sushch <iurii.sushch@desy.de>, 2017 - present
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#new version tracking start with 2.0.0; the last version of pspec2d is 19.2
#v2.0.0: functions describing flow and magnetic field are implemented here
#v2.0.1: getting rid of function aliases where possible
#v2.1.0: moving module to object
#v2.2.0: parameters renamed and reordered to comply with patron v2.2.0
#v2.3.0: adding evotru 
#v2.4.0: re-arranging some parameters to add support of mttran
#v2.5.0: adding Sedov profiles for magnetic field
#v2.6.0: adding evotel
#v2.7.0: adding damped profile for magnetic field
#v2.8.0: version control added
#v2.8.1: adding evorob
#v2.9.0: any type of evolution (analytic or numeric) is introduced by useSedSol parameter
 
__version__='2.9.0'

import sys

from patron.snrmod.snrevo import evotru as evotru
from patron.snrmod.snrevo import evocox as evocox
from patron.snrmod.snrevo import evotel as evotel
from patron.snrmod.snrevo import evovik as evovik
from patron.snrmod.snrevo import evorob as evorob
from patron.snrmod.snrevo import evoplu as evoplu

from patron.snrmod import hddummy as hddummy

from patron.reader import mfread as mfread

from patron.auxlib.constants import *

from scipy import interpolate

from numpy import *

from fipy.tools import parallel
from fipy.tools.numerix import pi
from fipy.tools.numerix import exp
from fipy.tools.numerix import sqrt
from fipy.tools.numerix import array
from fipy.tools.numerix import where
from fipy.tools.numerix import cbrt


#InP = 4.45									#injection efficiency parameter in Blasi 2005 model -> InP x p_th (thermal momentum)


BCR  = sqrt(11.0)                                                               #compression of magnetic field 
SCF  = 0.05		                                                        #MF decay scale in front of FS
#SCF  = 0.1 #FOR TESTING!!! SET IT BACK TO 0.05!!!
SCR  = 0.05

Bins = 1.0e-7		                                                        #MF inside ejecta
ld   = 0.01		                                                        #damping length
SCBIN = 4.

     
#schould be later replaced with __init__ args
nhBkgDens = 1e-3  #10.0 							#background number density
densScale = 1e6  #0.5								#density gradient scale in pc. large value means nearly uniform medium
densAngle = pi/2.								#prefered direction wrt density gradient

       
                 

class PlasmaMHDProfiles: #(object):
        def __init__(self,shockType,nhDensity,expEnergy,useSedSol,mfProfile,alfvDrift,hdDataInp,hdFileInp,mfDataInp,mfFileInp,SP):		
###initialiasing self functions#####################################
		self.useSedSol = useSedSol
		self.HDTE = 0
		self.mfevo = 0
                

               

		if   shockType == "FSH" or shockType == "FSA":
			if   useSedSol == 0:
				if parallel.procID == 0: print "snrmhd: using free expansion analytic solutions"
				self.evoans=evotru
			elif useSedSol == 1:
				if parallel.procID == 0: print "snrmhd: using Sedov analytic solutions"
				self.evoans=evocox
			elif useSedSol == 2:
				if parallel.procID == 0: print "snrmhd: using semi-analytic solutions including transition stage"
				self.evoans=evotel
			elif useSedSol == 3:
				if parallel.procID == 0: print "snrmhd: using fake profiles"
				self.evoans=evorob
                        elif useSedSol == 4:
				if parallel.procID == 0: print "snrmhd: forward shock, hydro data"
				self.evoans=evovik
                        elif useSedSol == 5:
				if parallel.procID == 0: print "snrmhd: using pluto"
				self.evoans=evoplu
			else:
				print "snrmhd: invalid option"
				sys.exit(0)

# Magnetic field profiles limitations:
# SED would work only for useSedSol == 1
# RHO and PRE would work only for useSedSol == 4



                        if useSedSol in [0,1,2,3]:
				self.evoans.n     = nhDensity						#initial number density
				self.evoans.E     = expEnergy						#expolosion energy
				self.evoans.nb    = nhBkgDens						#background number density
				self.evoans.H     = densScale						#density gradient scale in pc. large value means nearly uniform medium 
				self.evoans.theta = densAngle						#prefered direction wrt density gradient

				self.evoans.SetupParameters()

	                        if parallel.procID == 0:
                                       print "snrmhd: forward shock, analytic solutions"
                                       print "snrmhd: evo(cox/tru/tel) E and n are ", self.evoans.E, self.evoans.n
                                       print "snrmhd: shell/mc density is",self.evoans.RHO_SHL/2.34e-24 #,self.evoans.R_Z2,self.evoans.RWSH
                                self.snr=0
                                if   mfProfile == "CON": self.B = self.B_CON
                        	elif mfProfile == "COM": self.B = self.B_COM
		                elif mfProfile == "COM2":self.B = self.B_COM2
		                elif mfProfile == "SED": self.B = self.B_SED
				elif mfProfile == "DAM": self.B = self.B_DAM_AN
				elif mfProfile == "RHO": self.B = self.B_RHO_AN
				elif mfProfile == "PRE": self.B = self.B_PRE_AN
				elif mfProfile == "TR1": self.B = self.B_TR1_AN; self.mfevo = mfread.fillMFevo(mfDataInp,mfFileInp,"history1","TOT",shockType,self.snr)
				elif mfProfile == "TR2" or mfProfile == "TRA": self.B = self.B_TR2_AN
				self.ttr   = self.ttr_AN
				self.tsf   = self.tsf_AN
				self.RFS   = self.RFS_AN
				self.RRS   = self.RRS_AN
				self.Rsh   = self.Rsh_AN
				self.Vsh   = self.Vsh_AN
				self.Vinj  = self.Vinj_AN
				self.Vlhs  = self.Vlhs_AN
				self.VLHS  = self.Vlhs_AN				#always without Alfvenic velocity
				self.VRHS  = self.Vrhs_AN_I				#always without Alfvenic velocity
				if   alfvDrift == "I": self.Vrhs = self.Vrhs_AN_I
				elif alfvDrift == "A": self.Vrhs = self.Vrhs_AN_A
				self.nh    = self.nh_AN
				self.nh_u  = self.nh_AN_u
				self.nh_sh = self.nh_AN_sh
				self.rho   = self.rho_AN
				self.rho_u = self.rho_AN_u
				self.rho_sh= self.rho_AN_sh
				self.Pg    = self.Pg_AN
				self.Pg_sh = self.Pg_AN_sh
				self.Tg    = self.Tg_AN
				self.Tg_sh = self.Tg_AN_sh
				self.eta_i = self.eta_i_AN
                                self.muh   = self.muh_FS
                                self.muhe  = self.muhe_FS
                                self.muc   = self.muc_FS
                                self.muox  = self.muox_FS
                                self.mufe  = self.mufe_FS
                                self.mue   = self.mue_FS
                                self.mu    = self.mu_FS
                                self.dr    = 1e-7                  #used do determine the upstream region - '+' for FS and '-' for RS
                
				self.HDTE = hddummy.TransportEquation()		

			elif useSedSol == 4:
				
#				if parallel.procID == 0:	
#					print "DEBUG (snrmhd): hdDataInp", hdDataInp, "hdFileInp", hdFileInp				
				self.snr = evovik.fillsnrevo(hdDataInp,hdFileInp,"history","FS")		#reading VIKRAM's files
                                if   mfProfile == "CON": self.B = self.B_CON
                                elif mfProfile == "COM": self.B = self.B_COM
                                elif mfProfile == "COM2":self.B = self.B_COM2
                                elif mfProfile == "DAM": self.B = self.B_DAM_FS
				elif mfProfile == "RHO": self.B = self.B_RHO_FS
				elif mfProfile == "PRE": self.B = self.B_PRE_FS
				elif mfProfile == "TR1": self.B = self.B_TR1_FS; self.mfevo = mfread.fillMFevo(mfDataInp,mfFileInp,"history0","TOT",shockType,self.snr)
				elif mfProfile == "TR2" or mfProfile == "TRA": self.B = self.B_TR2_FS
				self.ttr   = self.ttr_FS
				self.tsf   = self.tsf_FS
				self.RFS   = self.RFS_FS
				self.RRS   = self.RRS_FS
				self.Rsh   = self.Rsh_FS
				self.Vsh   = self.Vsh_FS
				self.Vinj  = self.Vinj_FS
				self.VLHS  = self.Vlhs_FS_I				#always without Alfvenic velocity
				self.VRHS  = self.Vrhs_FS_I				#always without Alfvenic velocity
				if   alfvDrift == "I": self.Vlhs = self.Vlhs_FS_I; self.Vrhs = self.Vrhs_FS_I
				elif alfvDrift == "A": self.Vlhs = self.Vlhs_FS_A; self.Vrhs = self.Vrhs_FS_A
				self.nh    = self.nh_FS
				self.nh_u  = self.nh_FS_u
				self.nh_sh = self.nh_FS_sh
				self.rho   = self.rho_FS
				self.rho_u = self.rho_FS_u
				self.rho_sh= self.rho_FS_sh
				self.Pg    = self.Pg_FS
				self.Pg_sh = self.Pg_FS_sh
				self.Tg    = self.Tg_FS
				self.Tg_sh = self.Tg_FS_sh
				self.eta_i = self.eta_i_FS
                                self.muh   = self.muh_FS
                                self.muhe  = self.muhe_FS
                                self.muc   = self.muc_FS
                                self.muox  = self.muox_FS
                                self.mufe  = self.mufe_FS
                                self.mue   = self.mue_FS
                                self.mu    = self.mu_FS
                                self.dr    = 1e-7                 #used do determine the upstream region - '+' for FS and '-' for RS

				self.HDTE = hddummy.TransportEquation()	
				
			elif useSedSol == 5:
				self.snr=0
                                if   mfProfile == "CON": self.B = self.B_CON
                        	elif mfProfile == "COM": self.B = self.B_COM
		                elif mfProfile == "COM2":self.B = self.B_COM2
		                elif mfProfile == "SED": self.B = self.B_SED
				elif mfProfile == "DAM": self.B = self.B_DAM_AN
				elif mfProfile == "RHO": self.B = self.B_RHO_AN
				elif mfProfile == "PRE": self.B = self.B_PRE_AN
				elif mfProfile == "TR1": self.B = self.B_TR1_AN; self.mfevo = mfread.fillMFevo(mfDataInp,mfFileInp,"history1","TOT",shockType,self.snr)
				elif mfProfile == "TR2" or mfProfile == "TRA": self.B = self.B_TR2_AN
				self.HDTE  = self.evoans.TransportEquation(SP.PLUTO_DLL,SP.HDOUTFN,SP.timeslist,SP,inFileName=SP.HDINPFN)
				self.ttr   = self.HDTE.ttr
				self.tsf   = self.HDTE.tsf
				self.RFS   = self.HDTE.RFS
				self.RRS   = self.HDTE.RRS
				self.Rsh   = self.HDTE.Rsh
				self.Vsh   = self.HDTE.Vsh
				self.Vinj  = self.HDTE.Vinj
				self.VLHS  = self.HDTE.Vlhs_FS_I				#always without Alfvenic velocity
				self.VRHS  = self.HDTE.Vrhs_FS_I				#always without Alfvenic velocity
				if   alfvDrift == "I": self.Vlhs = self.HDTE.Vlhs_FS_I; self.Vrhs = self.HDTE.Vrhs_FS_I
				elif alfvDrift == "A": self.Vlhs = self.HDTE.Vlhs_FS_A; self.Vrhs = self.HDTE.Vrhs_FS_A
				self.nh    = self.HDTE.nh
				self.nh_u  = self.HDTE.nh_u
				self.nh_sh = self.HDTE.nh_sh
				self.rho   = self.HDTE.rho
				self.rho_u = self.HDTE.rho_u
				self.rho_sh= self.HDTE.rho_sh
				self.Pg    = self.HDTE.Pg
				self.Pg_sh = self.HDTE.Pg_sh
				self.Tg    = self.HDTE.Tg
				self.Tg_sh = self.HDTE.Tg_sh
				self.eta_i = self.eta_i_AN
                                self.muh   = self.muh_FS
                                self.muhe  = self.muhe_FS
                                self.muc   = self.muc_FS
                                self.muox  = self.muox_FS
                                self.mufe  = self.mufe_FS
                                self.mue   = self.mue_FS
                                self.mu    = self.mu_FS
                                self.dr    = 1e-7                 #used do determine the upstream region - '+' for FS and '-' for RS           

			else:
				if parallel.procID == 0: print "snrmhd: useSedSol=", useSedSol, " That's not a valid choice - try again with another input value"
				sys.exit(0) 


		elif  shockType == "RSH":
			if parallel.procID == 0: print "snrmhd: reverse shock, hydro data"
			self.snr = evovik.fillsnrevo(hdDataInp,hdFileInp,"history","RS")		#reading VIKRAM's files
			if   mfProfile == "CON": self.B = self.B_CON
			elif mfProfile == "COM": self.B = self.B_COM
			elif mfProfile == "COM2":self.B = self.B_COM2
			elif mfProfile == "DAM": self.B = self.B_DAM_RS
			elif mfProfile == "RHO": self.B = self.B_RHO_RS
			elif mfProfile == "PRE": self.B = self.B_PRE_RS
			elif mfProfile == "TR1": 
				print "snrmhd: ", mfDataInp,mfFileInp
				self.B = self.B_TR1_RS; self.mfevo = mfread.fillMFevo(mfDataInp,mfFileInp,"history0","TOT",shockType,self.snr)
			elif mfProfile == "TR2" or mfProfile == "TRA": self.B = self.B_TR2_RS
			self.ttr   = self.ttr_RS
			self.tsf   = self.tsf_RS
			self.RFS   = self.RFS_RS
			self.RRS   = self.RRS_RS
			self.Rsh   = self.Rsh_RS
			self.Vsh   = self.Vsh_RS
			self.Vinj  = self.Vinj_RS
			self.VLHS  = self.Vlhs_RS_I				#always without Alfvenic velocity
			self.VRHS  = self.Vrhs_RS_I				#always without Alfvenic velocity
			if   alfvDrift == "I": self.Vlhs = self.Vlhs_RS_I; self.Vrhs = self.Vrhs_RS_I
			elif alfvDrift == "A": self.Vlhs = self.Vlhs_RS_A; self.Vrhs = self.Vrhs_RS_A
			self.nh    = self.nh_RS
			self.nh_u  = self.nh_RS_u
			self.nh_sh = self.nh_RS_sh
			self.rho   = self.rho_RS
			self.rho_u = self.rho_RS_u
			self.rho_sh= self.rho_RS_sh
			self.Pg    = self.Pg_RS
			self.Pg_sh = self.Pg_RS_sh
			self.Tg    = self.Tg_RS
			self.Tg_sh = self.Tg_RS_sh
			self.eta_i = self.eta_i_RS
                        self.muh   = self.muh_RS
                        self.muhe  = self.muhe_RS
                        self.muc   = self.muc_RS
                        self.muox  = self.muox_RS
                        self.mufe  = self.mufe_RS
                        self.mue   = self.mue_RS
                        self.mu    = self.mu_RS
                        self.dr    = -1e-7                 #used do determine the upstream region - '+' for FS and '-' for RS
                   
                    
                       	self.HDTE = hddummy.TransportEquation()
	#conversion between r and r*
	def R2RS(self,r):
		return cbrt(r-1)+1
	
#######################################################################################
#changed SD
#Mean Molecular Weight

#For the forward shock:
        def muh_FS(self,r,t):
                RWSH = self.SP.windbubrad * pc 					#radius of the wind bubble in cm
                R=r*self.Rsh(t)							#coordinate in cm
                return where(R<=RWSH,Ah/self.SP.AbundanceH, muh_ISM)

        def muhe_FS(self,r,t):
                RWSH = self.SP.windbubrad * pc 					#radius of the wind bubble in cm
                R=r*self.Rsh(t)							#coordinate in cm
                return where(R<=RWSH,Ahe/self.SP.AbundanceHe, muhe_ISM)

        def muc_FS(self,r,t):
                RWSH = self.SP.windbubrad * pc 					#radius of the wind bubble in cm
                R=r*self.Rsh(t)							#coordinate in cm
                return where(R<=RWSH,Ac/self.SP.AbundanceC, muc_ISM)

        def muox_FS(self,r,t):
                RWSH = self.SP.windbubrad * pc 					#radius of the wind bubble in cm
                R=r*self.Rsh(t)							#coordinate in cm
                return where(R<=RWSH,Aox/self.SP.AbundanceO, muox_ISM)

        def mufe_FS(self,r,t):
                RWSH = self.SP.windbubrad * pc 					#radius of the wind bubble in cm
                R=r*self.Rsh(t)							#coordinate in cm
                return where(R<=RWSH,Afe/self.SP.AbundanceFe, mufe_ISM)

        def mue_FS(self,r,t):
                RWSH = self.SP.windbubrad * pc 					#radius of the wind bubble in cm
                R=r*self.Rsh(t)							#coordinate in cm
                return where(R<=RWSH,(2./(1.+self.SP.AbundanceH)), mue_ISM) 	#For this expression we set that A_H = Z_H and for all other elments Z_i = A_i/2 

        def mu_FS(self,r,t):
                return ((1/self.muh(r,t)+1/self.muhe(r,t)+1/self.muc(r,t)+1/self.muox(r,t)+1/self.mufe(r,t)+1/self.mue(r,t))**(-1))


#For the reverse shock:
        def muh_RS(self,r,t):
                RWSH = self.SP.windbubrad * pc 					#radius of the wind bubble in cm
                R=self.RRS(t)*r*self.Rsh(t)							#coordinate in cm
                return where(R<=RWSH,Ah/self.SP.AbundanceH, muh_ISM)

        def muhe_RS(self,r,t):
                RWSH = self.SP.windbubrad * pc 					#radius of the wind bubble in cm
                R=self.RRS(t)*r*self.Rsh(t)							#coordinate in cm
                return where(R<=RWSH,Ahe/self.SP.AbundanceHe, muhe_ISM)

        def muc_RS(self,r,t):
                RWSH = self.SP.windbubrad * pc 					#radius of the wind bubble in cm
                R=self.RRS(t)*r*self.Rsh(t)							#coordinate in cm
                return where(R<=RWSH,Ac/self.SP.AbundanceC, muc_ISM)

        def muox_RS(self,r,t):
                RWSH = self.SP.windbubrad * pc 					#radius of the wind bubble in cm
                R=self.RRS(t)*r*self.Rsh(t)							#coordinate in cm
                return where(R<=RWSH,Aox/self.SP.AbundanceO, muox_ISM)

        def mufe_RS(self,r,t):
                RWSH = self.SP.windbubrad * pc 					#radius of the wind bubble in cm
                R=self.RRS(t)*r*self.Rsh(t)							#coordinate in cm
                return where(R<=RWSH,Afe/self.SP.AbundanceFe, mufe_ISM)

        def mue_RS(self,r,t):
                RWSH = self.SP.windbubrad * pc 					#radius of the wind bubble in cm
                R=self.RRS(t)*r*self.Rsh(t)							#coordinate in cm
                return where(R<=RWSH,(2./(1.+self.SP.AbundanceH)), mue_ISM) 	#For this expression we set that A_H = Z_H and for all other elments Z_i = A_i/2 

        def mu_RS(self,r,t):
                return ((1/self.muh(r,t)+1/self.muhe(r,t)+1/self.muc(r,t)+1/self.muox(r,t)+1/self.mufe(r,t)+1/self.mue(r,t))**(-1))
        
        
        
##########################################################################################################################################
        
	
###auxiliary functions for finding positions of respective shocks
        def RRS_AN(self,t):							#no RS in analytical case
		return 0.0
	
	def RFS_FS(self,t):							#position of the forward shock (FS) when normalized by the FS radius
		return 1.0
	
	def RFS_RS(self,t):							#position of the FS when normalized by the reverse shock (RS) radius
	        return evovik.R_ED(t,self.snr)/evovik.R_RS(t,self.snr)
	
	def RFS_AN(self,t):							#position of the FS when normalized by the FS radius in analytical case
		return 1.0
	
	def RRS_FS(self,t):							#position of the RS when normalized by the FS radius
		return evovik.R_RS(t,self.snr)/evovik.R_ED(t,self.snr)
	
	def RRS_RS(self,t):							#position of the RS when normalized by the RS radius
		return 1.0
        
	
###Magnetic field profiles######################################
	def B_CON(self,r,t):
		return sqrt((self.B_con(t))**2.+(self.B_TURB(self.R2RS(r),t))**2.)
	
	def B_COM(self,r,t):
		return sqrt((where(r<=1.0,self.B_con(t),self.B_com_u(r,t)))**2.+(self.B_TURB(self.R2RS(r),t))**2.)

	def B_COM2(self,r,t):
		return sqrt((where(r<=1.0,self.B_con(t),self.Bism(r,t)))**2.+(self.B_TURB(self.R2RS(r),t))**2.)

	def B_SED(self,r,t):                                                    #works only with useSedSol == 1
		return sqrt((where(r<=1.0,self.B_fs_d_sed(r,t),self.B_fs_u_sed(r,t)))**2.+(self.B_TURB(self.R2RS(r),t))**2.)
	
	def B_DAM_AN(self,r,t):
		return sqrt((where(r<=1.0,self.B_fs_d_dam_AN(r,t),self.B_fs_u_dam_AN(r,t)))**2.+(self.B_TURB(self.R2RS(r),t))**2.)
	
	def B_DAM_FS(self,r,t):
		rfs=self.RFS_FS(t)
		rrs=self.RRS_FS(t)	
		B1=self.B_fs_d_dam_FS(r,t,rrs)
		B2=self.B_fs_u_dam(r,t,rfs)
		return sqrt((where(r<=rfs,B1,B2))**2.+(self.B_TURB(self.R2RS(r),t))**2.)
	
	def B_DAM_RS(self,r,t):
		rfs=self.RFS_FS(t)
		rrs=self.RRS_FS(t)	
		B1=self.B_fs_d_dam_FS(r,t,rrs)
		B2=self.B_fs_u_dam(r,t,rfs)
		return where(r<=rfs,B1,B2)
	
	def B_RHO_AN(self,r,t):
		B1=self.B_fs_d_rho_AN(r,t)
		B2=self.B_fs_u_rho_AN(r,t)
		return sqrt((where(r<=1.0,B1,B2))**2.+(self.B_TURB(self.R2RS(r),t))**2.)
	
	def B_RHO_FS(self,r,t):
		rfs=self.RFS_FS(t)
		rrs=self.RRS_FS(t)						#rrs is added to test the ejecta
		B1=self.B_fs_d_rho_FS(r,t,rrs)			#MF similar to P case RUN_15
		B2=self.B_fs_u_rho(r,t,rfs)
		return sqrt((where(r<=rfs,B1,B2))**2.+(self.B_TURB(self.R2RS(r),t))**2.)
	
	def B_RHO_RS(self,r,t):
		rfs=self.RFS_RS(t)
		rrs=self.RRS_RS(t)						#rrs is added to test the ejecta
		B1=self.B_fs_d_rho_RS(r,t,rrs)			#MF similar to P case RUN_15
		B2=self.B_fs_u_rho(r,t,rfs)
		return where(r<=rfs,B1,B2)
	
	def B_PRE_AN(self,r,t):
		B1=self.B_fs_d_pre_AN(r,t)
		B2=self.B_fs_u_pre_AN(r,t)
		return sqrt(( where(r<=1.0,B1,B2))**2.+(self.B_TURB(self.R2RS(r),t))**2.)
	
	def B_PRE_FS(self,r,t):
		rfs=self.RFS_FS(t)
		rrs=self.RRS_FS(t)
		B1=self.B_fs_d_pre(r,t,rrs)
		B2=self.B_fs_u_pre(r,t,rfs)
		return sqrt((where(r<=rfs,B1,B2))**2.+(self.B_TURB(self.R2RS(r),t))**2.)
	
	def B_PRE_RS(self,r,t):
		rfs=self.RFS_RS(t)
		rrs=self.RRS_RS(t)
		B1=self.B_fs_d_pre(r,t,rrs)
		B2=self.B_fs_u_pre(r,t,rfs)
		return where(r<=rfs,B1,B2)

	def B_TR1_AN(self,r,t):
		B1=self.B_fs_d_tra(r,t)
		B2=self.B_fs_u_tra_AN(r,t)
		return sqrt((where(r<=1.0,B1,B2))**2.+(self.B_TURB(self.R2RS(r),t))**2.)
	
	def B_TR1_FS(self,r,t):
		rfs=self.RFS_FS(t)
		B1=self.B_fs_d_tra(r,t)
		B2=self.B_fs_u_tra(r,t,rfs)
		return sqrt((where(r<=rfs,B1,B2))**2.+(self.B_TURB(self.R2RS(r),t))**2.)
	
	def B_TR1_RS(self,r,t):
		rfs=self.RFS_RS(t)
		B1=self.B_fs_d_tra(r,t)
		B2=self.B_fs_u_tra(r,t,rfs)
		return where(r<=rfs,B1,B2)
	
	def B_TR2_AN(self,r,t):
		B1=interpolate.interp1d(self.MFR,self.MFB, bounds_error=False, fill_value=0.0)(r)
		B2=self.B_fs_u_tra_AN(r,t)
		return sqrt((where(r<=1.0,B1,B2))**2.+(self.B_TURB(self.R2RS(r),t))**2.)
	
	def B_TR2_FS(self,r,t):
		rfs=self.RFS_FS(t)
		B1=interpolate.interp1d(self.MFR,self.MFB, bounds_error=False, fill_value=0.0)(r)
		B2=self.B_fs_u_tra(r,t,rfs)
		return sqrt((where(r<=rfs,B1,B2))**2.+(self.B_TURB(self.R2RS(r),t))**2.)

	def B_TR2_RS(self,r,t):
		rfs=self.RFS_RS(t)
		B1=interpolate.interp1d(self.MFR*rfs,self.MFB, bounds_error=False, fill_value=0.0)(r)
		B2=self.B_fs_u_tra(r,t,rfs)
		return where(r<=rfs,B1,B2)

	#Dummy turbulent field. Has to be overwritten from outside.
	def B_TURB(self,r,t):
		return 0.0


        ###### mfprof migrated here: #############################
        
        def Bism_T1(self,r,t):							#type I
                return BISM 							#BISM is the interstellar medium magnetic field set in setpar (simpar.mfofismna)


        def Bism_T2(self,r,t):							#magnetic field in the core-collapse scenario (wind_blown bubble + ISM). 
										#We ignore the shell. Transition from the wind-zone to ISM is immediate
                R_star = self.SP.starrad * R_sun 				#radius of the progenitor star in cm. 
                B_star = self.SP.mfstarsurf 					#magnetic field at the surface of the star in G.
                RWSH = self.SP.windbubrad * pc 					#radius of the wind bubble in cm
                
                R=r*self.Rsh(t)
                B_wind = B_star * R_star/R
                
                return where(R<=RWSH,B_wind,BISM)

        def Bism(self,r,t):
                if self.SP.EXPLNTYPE == "T1":
                        return self.Bism_T1(r,t)
                elif self.SP.EXPLNTYPE == "T2":
                        return self.Bism_T2(r,t)
                else:
                        return self.Bism_T1(r,t) 				#returns constant B-field in all cases except T2
        
        def B0(self,t):
                #B0 HAND-SET VIA AMPLIFICATION FACTOR, HYDRO
                if self.SP.mfatshock == 0.0: return AMP*self.Bism(1.,t) 					#AMP is an amplification factor set in setpar (simpar.mfampfact)
		else: return self.SP.mfatshock/BCR

        #########################################################
        

        def B_con(self,t):
                return BCR*self.B0(t)

	def B_com_u(self,r,t):
                RFS=1.0
                ru=r-RFS
		RSCF=RFS+SCF*RFS
                B0fs=self.B0(t)
                if self.SP.mfatshock == 0.0:
			Bup=B0fs*exp(-(1./(SCF*RFS))*ru*log(B0fs/self.Bism(RSCF,t)))
		else:
			Bup=B0fs
		return where(r<=RSCF,Bup,self.Bism(r,t))

        def B_fs_d_rho_FS(self,r,t,RRS):                  #works only for evoans == evovik
                ru=r-RRS
                rrs=array([RRS])
                B0rs=self.B0(t)*(self.evoans.nh_fs(rrs,t,self.snr)[0]/self.evoans.nh_fs_sh(t,self.snr))
                B1=B0rs*exp((1./(SCR*RRS))*ru*log(B0rs/Bins))
                B2=BCR*self.B0(t)*(self.evoans.nh_fs(r,t,self.snr)/self.evoans.nh_fs_sh(t,self.snr))
                Bd=where(r<RRS,B1,B2)		
                return where(Bd>Bins,Bd,Bins)

        def B_fs_d_rho_RS(self,r,t,RRS):                  #works only for evoans == evovik
                ru=r-RRS
                rrs=array([RRS])
                B0rs=self.B0(t)*(self.evoans.nh_rs(rrs,t,self.snr)[0]/self.evoans.nh_fs_sh(t,self.snr))
                B1=B0rs*exp((1./(SCR*RRS))*ru*log(B0rs/Bins))
                B2=BCR*self.B0(t)*(self.evoans.nh_rs(r,t,self.snr)/self.evoans.nh_fs_sh(t,self.snr))
                Bd=where(r<RRS,B1,B2)		
                return where(Bd>Bins,Bd,Bins)
	
        def B_fs_u_rho(self,r,t,RFS):
                ru=r-RFS
                RSCF=RFS+SCF*RFS
                B0fs=self.B0(t)	
                Bup=B0fs*exp(-(1./(SCF*RFS))*ru*log(B0fs/self.Bism(RSCF,t)))
                return where(r<=RSCF,Bup,self.Bism(r,t))

        def B_fs_d_pre(self,r,t,RRS):                    #works only for evoans == evovik
                B0rs=(1.0/BCR)*sqrt(C*8.0*pi*self.evoans.Pg_rs_sh(t,self.snr))
                ru=r-RRS
                B1=B0rs*exp((1./(SCR*RRS))*ru*log(B0rs/Bins))
                B2=sqrt(C*8.0*pi*self.evoans.Pg_fs(r,t,self.snr))
                Bd=where(r<RRS,B1,B2)			
                return where(Bd>Bins,Bd,Bins)

        def B_fs_u_pre(self,r,t,RFS):                   #works only for evoans == evovik
                ru=r-RFS
                RSCF=RFS+SCF*RFS
                B0fs=(1.0/BCR)*sqrt(C*8.0*pi*self.evoans.Pg_fs_sh(t,self.snr))
                Bup=B0fs*exp(-(1./(SCF*RFS))*ru*log(B0fs/self.Bism(RSCF,t)))
                return where(r<=RSCF,Bup,self.Bism(r,t))
                
        def B_fs_d_rho_AN(self,r,t):                        #works only for evoans == evocox
                return BCR*self.B0(t)*(self.evoans.rho(r,t)/self.evoans.rho(1.0,t))

        def B_fs_u_rho_AN(self,r,t):
                RFS=1.0
                ru=r-RFS
		RSCF=RFS+SCF*RFS
                B0fs=self.B0(t)
                Bup=B0fs*exp(-(1./(SCF*RFS))*ru*log(B0fs/self.Bism(RSCF,t)))
		return where(r<=RSCF,Bup,self.Bism(r,t))                

        def B_fs_d_pre_AN(self,r,t):                        #works only for evoans == evocox
                return where(r<=1.0,sqrt(C*8.0*pi*self.evoans.P(r,t)),0.0)

        def B_fs_u_pre_AN(self,r,t):                        #works only for evoans == evocox
                RFS=1.0
                ru=r-RFS
		RSCF=RFS+SCF*RFS
                B0fs=(1.0/BCR)*sqrt(C*8.0*pi*self.evoans.P(1,t))
		Bup=B0fs*exp(-(1./(SCF*RFS))*ru*log(B0fs/self.Bism(RSCF,t)))
		return where(r<=RSCF,Bup,self.Bism(r,t))                


        def B_fs_d_sed(self,r,t):
                a   = self.evoans.a(r)                      #won't work with anything but evocox
                Br0 = self.B0(t)/1.73205
                Bt0 = self.B0(t)/1.73205
                Br  = Br0*(a/r)**2
                Bt  = 4.0*Bt0*(r/a)*self.evoans.rho_profile(r)
                return sqrt(Br**2 + 2.0*Bt**2)

        def B_fs_u_sed(self,r,t):
                RFS=1.0
                ru=r-RFS
		RSCF=RFS+SCF*RFS
                B0fs=self.B0(t)
		Bup=B0fs*exp(-(1./(SCF*RFS))*ru*log(B0fs/self.Bism(RSCF,t)))
		return where(r<=RSCF,Bup,self.Bism(r,t))                

        def B_fs_d_dam_AN(self,r,t):
                B0fs=self.B0(t)
                return SCBIN*BISM + (BCR*B0fs - SCBIN*BISM)*exp(-(1.0-r)/ld)
                
        def B_fs_u_dam_AN(self,r,t):
                RFS=1.0
                RSCF=RFS+SCF*RFS
                ru=r-RFS
                B0fs=self.B0(t)
                Bup=B0fs*exp(-(1./(SCF*RFS))*ru*log(B0fs/self.Bism(RSCF,t)))
                return where(r<=RSCF,Bup,self.Bism(r,t))


        def B_fs_d_dam_FS(self,r,t,RRS):
                B0fs=self.B0(t)
                return SCBIN*BISM + (BCR*self.B0(t) - SCBIN*BISM)*exp(-(1.0-r)/ld)
                
        def B_fs_u_dam(self,r,t,RFS):
                ru=r-RFS
                RSCF=RFS+SCF*RFS
                B0fs=self.B0(t)
                Bup=B0fs*exp(-(1./(SCF*RFS))*ru*log(B0fs/self.Bism(RSCF,t)))
                return where(r<=RSCF,Bup,self.Bism(r,t))

        def B_fs_d_tra(self,r,t):
                TSTEPS=len(self.mfevo)
                RSTEPS=len(r)
                mfrt=arange(RSTEPS,dtype=float)
                ti=arange(TSTEPS,dtype=float)
                mfti=ndarray(shape=(TSTEPS,RSTEPS),dtype=float)
                for i in xrange(TSTEPS):
                        mfti[i]=interpolate.interp1d(self.mfevo[i].R,self.mfevo[i].B, bounds_error=False, fill_value=self.mfevo[i].B[-1])(r)
                        ti[i]=self.mfevo[i].t
                mftir=mfti.transpose()
                mfrt=interpolate.interp1d(ti,mftir)(t)
                return mfrt

        def B_fs_u_tra(self,r,t,RFS):
                ru=r-RFS
                RSCF=RFS+SCF*RFS
                B0fs=self.B0(t)
                Bup=B0fs*exp(-(1./(SCF*RFS))*ru*log(B0fs/self.Bism(RSCF,t)))
                return where(r<=RSCF,Bup,self.Bism(r,t))

        def B_fs_u_tra_AN(self,r,t):
                RFS=1.0
                RSCF=RFS+SCF*RFS
                ru=r-RFS
                B0fs=self.B0(t)
                Bup=B0fs*exp(-(1./(SCF*RFS))*ru*log(B0fs/self.Bism(RSCF,t)))
                return where(r<=RSCF,Bup,self.Bism(r,t))

        ##########################################################


	
###Hydrodynamical parameters:###############################################################################################
###start time of transition to radiative stage##################
#for evotru and cox returns 1e6 and 1e7 yr to force free expansion
#and Sedov solutions; for Vikrams files it is irrelevant therefore
#similar values
	def ttr_AN(self):
		return self.evoans.ttr()

	def ttr_FS(self):
		return 1e6
	
	def ttr_RS(self):
		return 1e7

###end time of transition or start of radiative stage###########
	def tsf_AN(self):
		return self.evoans.tsf()

	def tsf_FS(self):
		return 1e6
	
	def tsf_RS(self):
		return 1e7

###shock radius#################################################
	def Rsh_AN(self,t):							#scale in cm
		return self.evoans.R(t)
	
	def Rsh_FS(self,t):							#scale in cm
		return evovik.R_ED(t,self.snr)					#!!!VIKRAM profiles forward shock
	
	def Rsh_RS(self,t):							#scale in cm
		return evovik.R_RS(t,self.snr)					#!!!VIKRAM profiles reverse shock
	
	
###shock speed##################################################
	def Vsh_AN(self,t):	
		return self.evoans.D(t)*yr
	
	def Vsh_FS(self,t):							#shock speed in cm/tsyr
		return evovik.D_ED(t,self.snr)*yr				#!!!VIKRAM profiles, getting shock speed
	
	def Vsh_RS(self,t):
		return evovik.D_RS(t,self.snr)*yr				#!!!VIKRAM profiles, getting reverse shock speed
	
	
###velocity of injected particles###############################
	def Vinj_AN(self,t):
		return self.Vsh_AN(t) - self.evoans.v(1+1e-6,t)*yr
	
	def Vinj_FS(self,t):
		return self.Vsh_FS(t) - evovik.v_ed_fs_u(1.0,t,self.snr)*yr
	
	def Vinj_RS(self,t):
		return evovik.v_ed_rs_u(t,self.snr)*yr - self.Vsh_RS(t)
	
	
###Alfven velocity##############################################
	def Valf(self,r,t):
		return self.B(r,t)/sqrt(4.0*pi*self.rho(r,t))*yr
	
	
###velocity of plasma left hand side of the considered shock.   		!NB: for FS it is downstream, for RS it is upstream
	def Vlhs_AN(self,r,t):							#plasma speed in cm/tsyr
		return self.evoans.v(r,t)*yr						#FS downstream region
	
	def Vlhs_FS_I(self,r,t):						#plasma speed in cm/yr
		return evovik.v_ed(r,t,self.snr)*yr				#FS downstream region (includes RS upstream)
	
	def Vlhs_RS_I(self,r,t):						#plasma speed in cm/yr
		return evovik.v_ed(r,t,self.snr)*yr				#FS downstream region is used because it includes RS upstream region
	
	def Vlhs_FS_A(self,r,t):						#plasma speed in cm/yr
		rrs=self.RRS_FS(t)						#
		V2=evovik.v_ed(r,t,self.snr)*yr					#FS downstream region (includes RS upstream)
		VA=self.Valf(r,t)
		return where(r<rrs,V2-VA,V2)					#upstream of the RS velocity of scattering centers is lower by VA
	
	def Vlhs_RS_A(self,r,t):						#plasma speed in cm/yr
		rrs=self.RRS_RS(t)						#equals always 1.0 for RS
		V2=evovik.v_ed(r,t,self.snr)*yr					#FS downstream region is used because it includes RS upstream region
		VA=self.Valf(r,t)
		return where(r<rrs,V2-VA,V2)					#upstream of the RS, velocity of scattering centers is lower by VA
	
	
###velocity of plasma right hand side of the considered shock.  		!NB: for FS it is upstream, for RS it is downstream
	def Vrhs_AN_I(self,r,t):						#plasma speed in cm/yr
		if self.useSedSol != 3:						
			return self.evoans.V_Z1*yr				#modified for NDSA tests with Oleh
		if self.useSedSol == 3:					
			return self.evoans.v(r,t)*yr				
		else:
			if parallel.procID == 0: print "snrmhd:	Uups... useSedSol check failed in Vrhs_AN_I"
	
	def Vrhs_FS_I(self,r,t):						#plasma speed in cm/yr
		return evovik.v_ed_fs_u(r,t,self.snr)*yr			#ISM velocity
	
	def Vrhs_RS_I(self,r,t):						#plasma speed in cm/yr
		return evovik.v_ed_rs_d(r,t,self.snr)*yr			#RS downstream region (includes FS upstream)
	
	def Vrhs_AN_A(self,r,t):						#plasma speed in cm/yr
		return self.Valf(r,t)
	
	def Vrhs_FS_A(self,r,t):						#plasma speed in cm/yr
		VI=evovik.v_ed_fs_u(r,t,self.snr)*yr				#FS upstream region (ISM velocity)
		VA=self.Valf(r,t)
		return VI+VA							#upstream of the FS, velocity of incoming scattering centers is lower by VA 
	
	def Vrhs_RS_A(self,r,t):						#plasma speed in cm/yr right to the shock
		rfs=self.RFS_RS(t)						#
		V2=evovik.v_ed_rs_d(r,t,self.snr)*yr				#RS downstream region (includes FS upstream)
		VA=self.Valf(r,t)
		return where(r<=rfs,V2,V2+VA)					#upstream of the FS, velocity of incoming scattering centers is lower by VA 
	
		
###gas density##############################################
	def rho_AN(self,r,t):
		return where(r<=1.0,self.evoans.rho(r,t),self.evoans.rho_ism(r,t))
	
	def rho_FS(self,r,t):
		rfs=self.RFS_FS(t)			
		return where(r<=rfs,evovik.rho_fs2(r,t,self.snr),evovik.rho_ism(r,t,self.snr)) 		#using smoothed density. smoothing is done during reading Vikram's data
	
	def rho_RS(self,r,t):
		rfs=self.RFS_RS(t)
		return where(r<=rfs,evovik.rho_rs(r,t,self.snr),evovik.rho_ism(r,t,self.snr))

###gas density just upstream of the shock####################
	def rho_AN_u(self,t):					
		return 0.25*self.evoans.rho(1.0,t)
	
	def rho_FS_u(self,t):					
		return evovik.rho_fs_u(t,self.snr)		
	
	def rho_RS_u(self,t):					
		return evovik.rho_rs_u(t,self.snr)		
	
###gas density at the shock###################################
	def rho_AN_sh(self,t):					
		return self.evoans.rho(1.0,t)
	
	def rho_FS_sh(self,t):					
		return evovik.rho_fs_sh(t,self.snr)		
	
	def rho_RS_sh(self,t):					
		return evovik.rho_rs_sh(t,self.snr)		
	
		
###proton number density########################################
	def nh_AN(self,r,t):
                return self.rho_AN(r,t)/(self.muh(r,t)*m_p)
	
	def nh_FS(self,r,t):					
		return self.rho_FS(r,t)/(self.muh(r,t)*m_p)		
	
	def nh_RS(self,r,t):					
		return self.rho_RS(r,t)/(self.muh(r,t)*m_p)		
	

###number density just upstream of the shock###################
	def nh_AN_u(self,t):					
		return 0.25*self.nh_AN(1.0,t)
	
	def nh_FS_u(self,t):					
		#return evovik.nh_fs_u(t,self.snr)		
                return self.rho_FS_u(t)/(self.muh(1.+self.dr,t)*m_p)
	
	def nh_RS_u(self,t):					
		#return evovik.nh_rs_u(t,self.snr)		
                return self.rho_RS_u(t)/(self.muh(1.+self.dr,t)*m_p)	
	
###proton number density at the shock###########################
	def nh_AN_sh(self,t):					
		return nh_AN(1.0,t)
	
	def nh_FS_sh(self,t):					
		#return evovik.nh_fs_sh(t,self.snr)
                return self.rho_FS_sh(t)/(self.muh(1.,t)*m_p)		
	
	def nh_RS_sh(self,t):					
		#return evovik.nh_rs_sh(t,self.snr)
                return self.rho_RS_sh(t)/(self.muh(1.,t)*m_p)		
	

###electron number density######################################
	def ne(self,r,t):					
		return (self.muh(r,t)/self.mue(r,t))*self.nh(r,t)

###electron number density just upstream of the shock###########
	def ne_u(self,t):					
		return (self.muh(1.+self.dr,t)/self.mue(1.+self.dr,t))*self.nh_u(t)
	
###electron number density at the shock#########################
	def ne_sh(self,t):					
		return (self.muh(1.,t)/self.mue(1.,t))*self.nh_sh(t)

###helium number density######################################
	def nhe(self,r,t):					
		return (self.muh(r,t)/self.muhe(r,t))*self.nh(r,t)

###helium number density just upstream of the shock###########
	def nhe_u(self,t):					
		return (self.muh(1.+self.dr,t)/self.muhe(1.+self.dr,t))*self.nh_u(t)
	
###helium number density at the shock#########################
	def nhe_sh(self,t):					
		return (self.muh(1.,t)/self.muhe(1.,t))*self.nh_sh(t)
###carbon number density######################################
	def nc(self,r,t):					
		return (self.muh(r,t)/self.muc(r,t))*self.nh(r,t)

###carbon number density just upstream of the shock###########
	def nc_u(self,t):					
		return (self.muh(1.+self.dr,t)/self.muc(1.+self.dr,t))*self.nh_u(t)
	
###carbon number density at the shock#########################
	def nc_sh(self,t):					
		return (self.muh(1.,t)/self.muc(1.,t))*self.nh_sh(t)

###oxygen number density######################################
	def nox(self,r,t):					
		return (self.muh(r,t)/self.muox(r,t))*self.nh(r,t)

###oxygen number density just upstream of the shock###########
	def nox_u(self,t):					
		return (self.muh(1.+self.dr,t)/self.muox(1.+self.dr,t))*self.nh_u(t)
	
###oxygen number density at the shock#########################
	def nox_sh(self,t):					
		return (self.muh(1.,t)/self.muox(1.,t))*self.nh_sh(t)

###iron number density######################################
	def nfe(self,r,t):					
		return (self.muh(r,t)/self.mufe(r,t))*self.nh(r,t)

###iron number density just upstream of the shock###########
	def nfe_u(self,t):					
		return (self.muh(1.+self.dr,t)/self.mufe(1.+self.dr,t))*self.nh_u(t)
	
###iron number density at the shock#########################
	def nfe_sh(self,t):					
		return (self.muh(1.,t)/self.mufe(1.,t))*self.nh_sh(t)	

	def Pr(self,t):
		return self.rho_u(t)*self.Vsh(t)**2/yr**2

###gas pressure at the shock#####################################
	def Pg_AN_sh(self,t):
		return self.evoans.P(1.0,t)
	
	def Pg_FS_sh(self,t):
		return evovik.Pg_fs_sh(t,self.snr)
	
	def Pg_RS_sh(self,t):
		return evovik.Pg_rs_sh(t,self.snr)
	
	
###gas pressure#################################################
	def Pg_AN(self,r,t):
		return self.evoans.P(r,t)
	
	def Pg_FS(self,r,t):
		return evovik.Pg_fs(r,t,self.snr)
	
	def Pg_RS(self,r,t):
		return evovik.Pg_fs(r,t,self.snr)				#same function as for forward shock
	
	
###gas temperature at the shock################################
	def Tg_AN_sh(self,t):
		return self.evoans.T(1.0,t)/mu_ISM*self.mu(1.,t)
	
	def Tg_FS_sh(self,r,t):
		return evovik.Tg_fs_sh(t,self.snr)/mu_ISM*self.mu(1.,t)
	
	def Tg_RS_sh(self,r,t):
		return evovik.Tg_rs_sh(t,self.snr)/mu_ISM*self.mu(1.,t)
	
	
###gas temperature#############################################
	def Tg_AN(self,r,t):
		return where(r<=1.0,self.evoans.T(r,t)/mu_ISM*self.mu(r,t),10000.0)
	
	def Tg_FS(self,r,t):
		return evovik.Tg_fs(r,t,self.snr)/mu_ISM*self.mu(r,t)
	
	def Tg_RS(self,r,t):
		return evovik.Tg_fs(r,t,self.snr)/mu_ISM*self.mu(r,t)				#same function as for forward shock
	
	
###injection efficiency########################################
	def eta_i_AN(self,t,InP):
		rs=1.0
		Vs=self.Vsh(t)
		CR=abs((Vs-self.VRHS(rs+2e-6,t))/(Vs-self.VLHS(rs-2e-6,t))) #4.0
		#if parallel.procID == 0: print "snrmhd: CR = ", CR 
		return (4.0/(3.0*pi**0.5))*(CR-1.0)*InP**3*exp(-InP**2)
	
	def eta_i_FS(self,t,InP):
		Vs=self.Vsh(t)
		rs=array([1.0])
		CR=abs((Vs-self.VRHS(rs,t))/(Vs-self.VLHS(rs,t)))[0]
		return (4.0/(3.0*pi**0.5))*(CR-1.0)*InP**3*exp(-InP**2)
	
	def eta_i_RS(self,t,InP):
		Vs=self.Vsh(t)
		rs=array([1.0])
		CR=abs((Vs-self.VLHS(rs,t))/(Vs-self.VRHS(rs,t)))[0]
		return (4.0/(3.0*pi**0.5))*(CR-1.0)*InP**3*exp(-InP**2)

#######################################################
