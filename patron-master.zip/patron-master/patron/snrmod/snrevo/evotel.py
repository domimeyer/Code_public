######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  evotel.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2005 - 2015
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v1.0.0: original version based on library compiled from Telezhinsky's PhD thesis codes revised in 2010
#v2.0.0: adjusted to be used in patron as a module based on library compiled from Telezhinsky's PhD thesis codes revised in 2015
#v2.1.0: tried internal C (rho_v2) and weave (rho_v3) array filling but no gain in perfomance
#v2.1.1: ctypes imported as C
#v2.1.2: bug fix to check if a variable is a float instead of if it is ndarray
#v2.2.0: version control added

__version__='2.2.0'

from os import sys
from os import getenv
import ctypes as C
import weave
from numpy import *
from patron.auxlib.constants import *


snrdll = C.CDLL(getenv("PATRONDIR")+"/lib/snrtelphd.so")

# yr    = 3.156e7
# km    = 1e5
# pc    = 3.086e18
# m_p   = 1.6726e-24
# mu    = 0.609
# muh   = 1.4
# mue   = 1.17
# Rg    = 8.3143e7

mu = mu_ISM
muh = muh_ISM
mue = mue_ISM

dims   = 1			#allow for 2D solutions; this wrapper version is restricted to 1D; changing to dim = 2 and varying theta globally will return results for given direction

###TO BE SET in snrmhd!###
E     = 1.0e51
n     = 1000.0  #1e-6
nb    = 1e-3   #10.0		#background number density
H     = 1e6   #0.5 	   	#density gradient scale in pc. large value means nearly uniform medium 
theta = pi/2.			#solution perpendicular to density gradient is equivalent to Sedov in uniform medium. If 2D solution needed make it variable throughout and change dim = 2.
############################

###TO BE SET FROM setpar!###
V_Z1 = 1e6
RHO_SHL=n*2.34e-24
R_Z2 = 50*pc
RWSH = 51*pc
############################

DIMs  = C.c_int.in_dll(snrdll,"DIMENSIONS")
DIMs.value = dims

E0  = C.c_double.in_dll(snrdll,"E0")
E0.value = E

nh0 = C.c_double.in_dll(snrdll,"nh0")
nh0.value = n

nhb = C.c_double.in_dll(snrdll,"nhb")
nhb.value = nb

Hsc = C.c_double.in_dll(snrdll,"H")	
Hsc.value = H

def ResetMemoryVars():
	Reset = snrdll.ResetMemoryVars
	Reset()
	

def SetupParameters():
	DIMs.value = dims
	E0.value = E
	nh0.value = n
	nhb.value = nb
	Hsc.value = H


def ttr():
	tt = snrdll.ttr
	tt.argtypes = [C.c_double]
	tt.restype = C.c_double
	return tt(theta)

def tsf():
	ts = snrdll.tsf
	ts.argtypes = [C.c_double]
	ts.restype = C.c_double
	return ts(theta)

def R(t):
	Rsh = snrdll.Rtrph
	Rsh.argtypes = [C.c_double, C.c_double]
	Rsh.restype = C.c_double
	return Rsh(t,theta)*pc

def D(t):
	Vsh = snrdll.Dtrph
	Vsh.argtypes = [C.c_double, C.c_double]
	Vsh.restype = C.c_double
	return Vsh(t,theta)*km


def rho0(r,t):
	ro0 = snrdll.ro0
	ro0.argtypes = [C.c_double, C.c_double]
	ro0.restype = C.c_double
	
	if type(r) is float or type(r) is int:
		rho = ro0(r*R(t)/pc,theta)
	else:
		LEN=len(r)
		rho = arange(LEN,dtype=float)
		for i in range(LEN): rho[i] = ro0(r[i]*R(t)/pc,theta)
	return rho

def rho_ism(r,t):
	r1=R_Z2/R(t)
	r2=RWSH/R(t)
	return where((r>=r1)&(r<=r2),RHO_SHL,rho0(r,t))

def rho(r,t):
	ro = snrdll.rotrph
	ro.argtypes = [C.c_double, C.c_double, C.c_double]
	ro.restype = C.c_double
	aL=a(r,t)
	if type(r) is float or type(r) is int:
		rho = ro(aL,t,theta)
	else:
		LEN=len(aL)
		rho = arange(LEN,dtype=float)
		for i in range(LEN): rho[i] = ro(aL[i],t,theta)
	return rho

def rho_v2(r,t):
	if type(r) is float or type(r) is int:
		ro = snrdll.rotrph
		ro.argtypes = [C.c_double, C.c_double, C.c_double]
		ro.restype = C.c_double
		rho = ro(a(r,t),t,theta)
	else:
		LEN=len(r)
		ro = snrdll.rotrph_array
		ro.argtypes = [C.POINTER(C.c_double), C.c_int, C.c_double, C.c_double]
		ro.restype  = C.POINTER(C.c_double)
		RHO = ro(r.ctypes.data_as(C.POINTER(C.c_double)),C.c_int(LEN),t,theta)
		#no copy of instance
		rho = fromiter(RHO, dtype=dtype(float), count=LEN)
		#alternative version but copy of instance
		#ArrayType = C.c_double*LEN
		#addr = addressof(RHO.contents)
		#rho = frombuffer(ArrayType.from_address(addr))
	return rho

def rho_v3(r,t):
	ro = snrdll.rotrph
	ro.argtypes = [C.c_double, C.c_double, C.c_double]
	ro.restype = C.c_double
	aL=a(r,t)
	if type(r) is float or type(r) is int:
		rho = ro(aL,t,theta)
	else:
		LEN=len(aL)
		rho = arange(LEN,dtype=float)
		
		cpp_code = """
		py::tuple arg(3);
		
		for(int i=0;i<LEN;i++)
		{
			arg[0]=aL[i];
			arg[1]=t;
			arg[2]=theta;
			rho[i] = ro.call(arg);
		}
		"""
		weave.inline(cpp_code, ["LEN","rho","ro","aL","t","theta"])
	return rho

def nh(r,t):
	return rho(r,t)/(muh*m_p)

def ne(r,t):
	return (muh/mue)*nh(r,t)

def P(r,t):
	Pg = snrdll.Ptrph
	Pg.argtypes = [C.c_double, C.c_double, C.c_double]
	Pg.restype = C.c_double
	aL=a(r,t)
	if type(r) is float or type(r) is int:
		P = Pg(aL,t,theta)
	else:
		LEN=len(aL)
		P = arange(LEN,dtype=float)
		for i in range(LEN): P[i] = Pg(aL[i],t,theta)
	return P

def T(r,t):
	Tg = snrdll.Ttrph
	Tg.argtypes = [C.c_double, C.c_double, C.c_double]
	Tg.restype = C.c_double
	aL=a(r,t)
	if type(r) is float or type(r) is int:
		T = Tg(aL,t,theta)
	else:
		LEN=len(aL)
		T = arange(LEN,dtype=float)
		for i in range(LEN): T[i] = Tg(aL[i],t,theta)
	return T

def v(r,t):
	vg = snrdll.v
	vg.argtypes = [C.c_double, C.c_double, C.c_double]
	vg.restype = C.c_double
	aL=a(r,t)
	if type(r) is float or type(r) is int:
		v = vg(aL,t,theta)
	else:		
		LEN=len(aL)
		v = arange(LEN,dtype=float)
		for i in range(LEN): v[i] = vg(aL[i],t,theta)
	return v*km
	
def a(r,t):
	#astrph = snrdll.astrphx
	astrph = snrdll.astrphg
	#astrph = getattr(snrdll,"as")
	astrph.argtypes = [C.c_double, C.c_double, C.c_double]
	astrph.restype = C.c_double
	
	if type(r) is float or type(r) is int:
		ass = astrph(r,t,theta)
	else:
		LEN=len(r)
		ass = arange(LEN,dtype=float)
		for i in range(LEN): ass[i] = astrph(r[i],t,theta)
	return ass


###implemented for test purposes#########
def ro0(X):
	#ro0=2.3*n*mu*m_p
	#rob=2.3*nb*mu*m_p
	#return rob + ro0*exp((-X*cos(theta))/Hsc)
	return nb + n*exp((-X*cos(theta))/Hsc)

def aint(t,theta):
	ai = snrdll.aint
	ai.argtypes = [C.c_double, C.c_double]
	ai.restype = C.c_double
	return ai(t,theta)

def ain(t,theta):
	ai = snrdll.ain
	ai.argtypes = [C.c_double, C.c_double]
	ai.restype = C.c_double
	return ai(t,theta)

def tcool(x,theta):
	tcool = snrdll.tcool
	tcool.argtypes = [C.c_double, C.c_double]
	tcool.restype = C.c_double
	return tcool(x,theta)


def a2r(a,t,theta):
	rtr = snrdll.rtrphart
	rtr.argtypes = [C.c_double, C.c_double, C.c_double]
	rtr.restype = C.c_double

	if type(a) is float or type(a) is int:
		rrr = rtr(a,t,theta)
	else:
		LEN=len(a)
		rrr = arange(LEN,dtype=float)
		for i in range(LEN): rrr[i] = rtr(a[i],t,theta)
	return rrr

def Vtot(t):
	V = snrdll.Vtot
	V.argtypes = [C.c_double]
	V.restype = C.c_double
	return V(t)

def Vtots(t):
       V = snrdll.Vtots
       V.argtypes = [C.c_double]
       V.restype = C.c_double
       return V(t)

Vol = C.c_double.in_dll(snrdll,"Volume")
 
