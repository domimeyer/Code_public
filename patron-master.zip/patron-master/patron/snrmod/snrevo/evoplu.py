######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  evoplu.py									
# Author: Robert Brose <robert.brose@mail.com>, 2016
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################
#Implementation of the Pluto-code as source of Hydro-data

#v0.0.1: start of development
#v0.0.2: changed to modularized form
#v0.0.3: python based "time"-controll
#v0.0.4: Added dynamical reggriding; Changed Pluto-log file; Fixed shock tracing 

__version__='0.0.4'

from os import sys
from os import getenv
from os import remove
from os.path import isfile

import ctypes as C

from time import asctime
from time import localtime

from fipy.tools import parallel

import pyplut.classes as classes
import pyplut.prototypes as prototypes

from mpi4py import MPI

from numpy import where
from numpy import array
from numpy import argmin
from numpy import argmax
from numpy import amin
from numpy import exp
from numpy import log
from numpy import insert as insertnp
from numpy import zeros
from numpy import empty
from numpy import roll
from numpy import arange
from numpy import savetxt
from numpy import concatenate
from numpy import diff
from numpy import isnan
from numpy import NaN
from numpy import nansum
from numpy import polyfit
from numpy import trapz
from numpy import shape
from numpy import sort

from scipy.interpolate import interp1d
from scipy import optimize
from scipy.integrate import quad

#For filter:
import numpy as np
from math import factorial

from patron.auxlib.constants import * 

mu = mu_ISM
muh = muh_ISM


# m_p   = 1.673e-24						#proton mass in grams
# mu    = 0.6190
# muh   = 1.40							#hydrogen molar weight
# yr    = 3.156e+7
# pc    = 3.08567758e18
# pi    = 3.1415926
# c     = 2.998e10
# kb    = 1.38064852e-16						#Boltzman konstant, erg/K


class TransportEquation:
	def __init__(self,dll,outFileName,timesout,setpar,inFileName):
		if parallel.procID == 0: print "hdtran: Initializing transport equations object..."

		self.timesout		= timesout
		self.outFileName	= outFileName
		self.shock_outFileName	= outFileName+"SHOCK"

		if parallel.procID == 0:
			if isfile(self.shock_outFileName) and setpar.timecont == None:
				print "hdtran: Removing old HRAWSHOCK-file..."
				remove(self.shock_outFileName)

		self.setpar 		= setpar
		self.inFileName		= inFileName

		#Initalize ctypes dll
		self.plutodll = C.CDLL(dll)
		prototypes.plutodll = self.plutodll

		#Defines the time when the reverse shock is removed to sustain the stability of the code
		if dll.split("/")[-1] == "pluto_vik.so" or dll.split("/")[-1] == "pluto_vik2.so":
			self.time_RemoveReverseShock = 1e6 #3000 #depends on prameters!
		elif dll.split("/")[-1] == "pluto_CC.so":
			#Removeing reverse shock doesn't
			self.time_RemoveReverseShock = 1e6
		else:
			if parallel.procID == 0: print "hdtran: WARNING - Unkonwn Pluto library: ", dll
			self.time_RemoveReverseShock = 1e6
			#sys.exit(0)	

		#get code-dimensions
		self.UNIT_LENGTH  = C.c_double.in_dll(self.plutodll,"pyUNIT_LENGTH").value
		self.UNIT_VELOCITY= C.c_double.in_dll(self.plutodll,"pyUNIT_VELOCITY").value
		self.UNIT_TIME    = self.UNIT_LENGTH/self.UNIT_VELOCITY
		self.UNIT_DENSITY = C.c_double.in_dll(self.plutodll,"pyUNIT_DENSITY").value
		self.KELVIN 	  = C.c_double.in_dll(self.plutodll,"pyKELVIN").value
		self.UNIT_ENERGY  = self.UNIT_DENSITY/self.UNIT_TIME**2.0*self.UNIT_LENGTH**5.0
		self.UNIT_PRESSURE= self.UNIT_DENSITY*self.UNIT_VELOCITY**2.	

		#Statics defined before compiling, e.g. in pluto.h
		MAX_OUTPUT_TYPES = 11

		#preprocessor statements:
		self.PARABOLIC_FLUX	= C.c_int.in_dll(self.plutodll,"pyPARABOLIC_FLUX").value
		SUPER_TIME_STEPPING	= C.c_int.in_dll(self.plutodll,"pySUPER_TIME_STEPPING").value
		RK_CHEBYSHEV		= C.c_int.in_dll(self.plutodll,"pyRK_CHEBYSHEV").value
		self.USE_ASYNC_IO	= C.c_int.in_dll(self.plutodll,"pyUSE_ASYNC_IO").value
		self.PARALLEL		= C.c_int.in_dll(self.plutodll,"pyPARALLEL").value
		self.SHOW_TIME_STEPS	= C.c_int.in_dll(self.plutodll,"pySHOW_TIME_STEPS").value
		self.COOLING 		= C.c_int.in_dll(self.plutodll,"pyCOOLING").value
		self.DIMENSIONS 	= C.c_int.in_dll(self.plutodll,"pyDIMENSIONS").value
		DIMENSIONAL_SPLITTING 	= C.c_int.in_dll(self.plutodll,"pyDIMENSIONAL_SPLITTING").value
		if parallel.procID == 0:
			print "hdtran: Printing Pluto preprocessor statements..."
			print "\tPARABOLIC_FLUX:\t\t",self.PARABOLIC_FLUX		
			print "\tSUPER_TIME_STEPPING:\t", SUPER_TIME_STEPPING	
			print "\tRK_CHEBYSHEV:\t\t", RK_CHEBYSHEV		
			print "\tUSE_ASYNC_IO:\t\t", self.USE_ASYNC_IO		
			print "\tPARALLEL:\t\t", self.PARALLEL		
			print "\tSHOW_TIME_STEPS:\t", self.SHOW_TIME_STEPS		
			print "\tCOOLING:\t\t", self.COOLING 		
			print "\tDIMENSIONS:\t\t", self.DIMENSIONS 		
			print "\tDIMENSIONAL_SPLITTING:\t", DIMENSIONAL_SPLITTING 

		C.c_int.in_dll(self.plutodll,"py_regrid").value = 0

		self.SetupParameters()
		self.Initialize()
		self.PrintDataTypes()
		self.InitTimeSteps()
		self.InitPy()

		
		#/* --------------------------------------------------------
		#    Check if restart is necessary. 
		#    If not, write initial condition to disk.
		#   ------------------------------------------------------- */
	   
		if self.cmd_line.restart == 1:
			prototypes.Restart(C.byref(self.ini), self.cmd_line.nrestart, 1, self.grd)
		elif self.cmd_line.h5restart == 1:
			if parallel.procID==0:
				print "h5restart not supported...exit"
			sys.exit(0)
			#Restart(&self.ini, self.cmd_line.nrestart, 4, self.grd)
			
		if parallel.procID==0:
			print "hdtran: Seems like everything is initialized corectly..."
			print "> Starting computation... \n\n"

		#Constants for Hydro module, remove later
		self.Radius = 4*pc
		self.SSpeed = 5000*1e5
		self.WSpeed = 10*1e5

		#Regriding part
		self.regrid_flag = self.setpar.regrid_flag
		self.regrid_time = self.setpar.regrid_time
		self.regrid_fact = self.setpar.regrid_fact
		if parallel.procID == 0:
			print "hdtran: Regriding parameters: ", self.regrid_flag, self.regrid_time, self.regrid_fact

		#Additional stuff
		if self.setpar.timecont == None or float(self.setpar.timecont) < self.time_RemoveReverseShock:
			self.sedov_flag = False #Flag for sedov-transition: True if reverse-shock has been removed
		elif float(self.setpar.timecont) > self.time_RemoveReverseShock:
			self.sedov_flag = True
			if parallel.procID==0:
				print "hdtran: Assuming reverse-shock has already been removed"

		self.start_tracing  = 0.9*self.regrid_time*yr/self.UNIT_TIME #0.0001*yr/self.UNIT_TIME#10*yr/self.UNIT_TIME #Time from wich the forward and reverse-shock will be traced
		self.first_tracking = 0

		#CR-feedback variables
		self.start_feedback = 5*yr/self.UNIT_TIME #20*yr/self.UNIT_TIME #Time from wich CR-feedback will be included
		self.CR_feedback    = self.setpar.CR_feedback
		if parallel.procID==0: print "hdtran: Feedback switch", self.CR_feedback		
		self.CRP	    = interp1d([0,1],[0,0],bounds_error=False, fill_value = 0)#zeros(self.RRES)
		self.CRP_INT	    = interp1d([0,1],[0,0],bounds_error=False, fill_value = 0)
		self.DIFFE_INT	    = interp1d([0,1],[0,0],bounds_error=False, fill_value = 0)
		self.crpold	    = 0	

	def CheckTime(self,t):
		if round(t,5) != round(self.ConvTime(self.g_time()),5):
			if parallel.procID == 0:
				print "hdtran: Time missmatch: ",t, self.ConvTime(self.g_time())," aborting"
			raise ValueError('A very specific bad thing happened here')
			sys.exit(0)


	#/*!
	# * Start PLUTO, initialize functions, define data structures and 
	# * handle the main integration loop.
	# *
	# * \param [in] argc Argument counts. 
	# * \param [in] argv Array of pointers to the strings.
	# * \return This function return 0 on normal exit.
	# *
	# *********************************************************************** */	    
	def SetupParameters(self):
		if parallel.procID == 0: print "hdtran: Setting up Plutos data structures and variables..."



		#give pluto.ini in rundir
		self.argc = C.c_int(3)
   		
		LP_c_char = C.POINTER(C.c_char)
    		LP_LP_c_char = C.POINTER(LP_c_char)
		self.argv = (LP_c_char * ( 4 ))()
		self.argv[1] = C.create_string_buffer("-i")
		self.argv[2] = C.create_string_buffer(self.setpar.Rundir + "/pluto.ini")

	
		##########Set globals originaly defined in globals.h###############################
		#/**< The maximum fractional variation due to cooling from one step to the next. */
		C.c_double.in_dll(self.plutodll,"g_maxCoolingRate").value = 0.1

  		#/**< The minimum temperature (in K) below which cooling is suppressed. */
		C.c_double.in_dll(self.plutodll,"g_minCoolingTemp").value = 50.0 

		#/**< Small value for density fix. */
		C.c_double.in_dll(self.plutodll,"g_smallDensity").value  = 1.e-12 

		#/**< Small value for pressure fix. */
		C.c_double.in_dll(self.plutodll,"g_smallPressure").value = 1.e-12 
		##################################################################################

		#int    nv, idim, err;
		nv   = C.c_int()
		idim = C.c_int()
		self.err  = C.c_int()		
	  	#char
		self.first_step = C.c_char("1")
		self.last_step  = C.c_char("0")
		#double scrh 		#Maximal mach number(?)
		scrh = C.c_double()
		#Data   data 		#Data structue
		self.data = classes.Data()
		#time_t  tbeg, tend 	#time_t class
		time_t = C.c_uint64
		self.tbeg = time_t()
		self.tend = time_t()
		#Riemann_Solver *Solver #Pointer to solver
		self.Solver = C.POINTER(classes.Riemann_Solver)()
		#Grid      self.grd[3]	#Grid definition
		self.grd = (classes.Grid * 3)()   #To be figured out
		#Time_Step Dts
		self.Dts = classes.Time_Step()		
		#Cmd_Line cmd_line	#?
		self.cmd_line = classes.Cmd_Line()
		#Input  ini
		self.ini = classes.Input()
		#Output *output	
		output = C.POINTER(classes.Output)()

		self.prank = C.c_int()
		
	def Initialize(self):
		if parallel.procID == 0: print "hdtran: Initalizing pluto..."
		if self.PARALLEL:
	   		prototypes.AL_Init(self.argc, self.argv)
			prototypes.pyMPI_1(C.byref(self.prank))
			C.c_int.in_dll(self.plutodll, "prank").value = self.prank.value
		
	  	prototypes.Initialize(self.argc, self.argv, C.byref(self.data), C.byref(self.ini), self.grd, C.byref(self.cmd_line))


	def PrintDataTypes(self):
		#double *dbl_pnt;
		dbl_pnt = C.POINTER(C.c_double)(C.c_double(1.0))
		#int    *int_pnt;
		int_pnt = C.POINTER(C.c_int)(C.c_int(1))
		if parallel.procID == 0:
			print "> Basic data type:\n"
			print "  sizeof (char)     = ", sys.getsizeof(C.c_char("c"))
			print "  sizeof (uchar)    = ", sys.getsizeof(C.c_ubyte(0))
			print "  sizeof (int)      = ", sys.getsizeof(C.c_int(1))
			print "  sizeof (*int)     = ", sys.getsizeof(int_pnt)
			print "  sizeof (float)    = ", sys.getsizeof(C.c_float(1.0))
			print "  sizeof (double)   = ", sys.getsizeof(C.c_double(1.0))
			print "  sizeof (*double)  = ", sys.getsizeof(dbl_pnt)

	def InitTimeSteps(self):
		if parallel.procID == 0: print "hdtran: Creating timestep structure..."
	#/* -- initialize members of Time_Step structure -- */
		self.Dts.cmax     = prototypes.Array1D(self.NMAX_POINT(), sys.getsizeof(C.c_double(1.0)), C.c_double)
		self.Dts.inv_dta  = 0.0
		self.Dts.inv_dtp  = 0.0
		self.Dts.dt_cool  = 1.e38
		self.Dts.cfl      = self.ini.cfl
		self.Dts.cfl_par  = self.ini.cfl_par
		self.Dts.rmax_par = self.ini.rmax_par
		self.Dts.Nsts     = self.Dts.Nrkc = 0

		self.Solver = prototypes.SetSolver(self.ini.solv_type) #not sure whether type is correct...

	  	prototypes.time(C.byref(self.tbeg));
	  	C.c_int.in_dll(self.plutodll,"g_stepNumber").value = 0;

	def reInitPy(self):
		if parallel.procID == 0: print "hdtran: Re-Initalizing Python-related stuff..."

	#extracting run-relevant parameters
		self.RRES 	= C.c_int.in_dll(self.plutodll,"NX1_TOT").value #Includes Ghost-cells
		self.RRES_local = C.c_int.in_dll(self.plutodll,"NX1").value #Includes Ghost-cells

	#output to txt-file
		self.Mhd  = self.GetMhdArrays(self.data, self.grd, self.RRES)
		self.comm = MPI.COMM_WORLD
		self.comm.Barrier
		self.Mhd_full  = self.CombineMhdArrays(self.comm,self.Mhd,self.RRES)
		if parallel.procID == 0:
			self.Mhd_full_output = zeros((5,int(6e5)), dtype=float)#self.Mhd_full
		self.diffE1 = zeros(len(self.Mhd_full[0]))
		self.diffE2 = zeros(len(self.Mhd_full[0]))
		self.diffE3 = zeros(len(self.Mhd_full[0]))

	#Getting array dimensions
		self.dr		  = self.Mhd_full[0][1]-self.Mhd_full[0][0]
		self.r_min_global = self.Mhd_full[0][0]
		self.r_max_global = self.Mhd_full[0][-1]
		self.r_min_local  = self.Mhd[0][0]
		self.r_max_local  = self.Mhd[0][-1]

	#/* -- print additional information -- */
		if parallel.procID==0:
			print "\tInner and outer boundarys #",parallel.procID,": ", self.Mhd[0][0], self.Mhd[0][-1]


	def InitPy(self):
		if parallel.procID == 0: print "hdtran: Initalizing Python-related stuff..."

	#extracting run-relevant parameters
		self.RRES 	= C.c_int.in_dll(self.plutodll,"NX1_TOT").value #Includes Ghost-cells
		self.RRES_local = C.c_int.in_dll(self.plutodll,"NX1").value 	#Excludes Ghost-cells

	#output to txt-file
		self.Mhd  = self.GetMhdArrays(self.data, self.grd, self.RRES)
		self.comm = MPI.COMM_WORLD
		self.comm.Barrier
		self.Mhd_full  = self.CombineMhdArrays(self.comm,self.Mhd,self.RRES)
		if parallel.procID == 0:
			self.Mhd_full_output = zeros((5,int(6e5)), dtype=float)#self.Mhd_full
		self.diffE1 = zeros(len(self.Mhd_full[0]))
		self.diffE2 = zeros(len(self.Mhd_full[0]))
		self.diffE3 = zeros(len(self.Mhd_full[0]))

	#Getting array dimensions
		self.dr		  = self.Mhd_full[0][1]-self.Mhd_full[0][0]
		self.r_min_global = self.Mhd_full[0][0]
		self.r_max_global = self.Mhd_full[0][-1]
		self.r_min_local  = self.Mhd[0][0]
		self.r_max_local  = self.Mhd[0][-1]
						
	#Variable for shock positions
		if self.setpar.shock_finder == "default":
			self.shock=[]
			self.rfs=0.0010*pc
			self.rrs=0.0005*pc
			self.rfs_old=0
			self.rrs_old=0
			self.time_old=0
			self.vfs=0
			self.vfs_old=0
			self.vrs=0
		elif self.setpar.shock_finder == "shock_inside_bubble":
			self.shock=[]
			self.rfs=0.0010*pc
			self.rrs=0.0005*pc
			self.rfs_old=0
			self.rrs_old=0
			self.time_old=0
			self.vfs=0
			self.vfs_old=0
			self.vrs=0
                	self.structure_found= 0
			self.r_inflow_old = 0
			self.r_CD_old = 0
			self.r_dis_old = 0	
			self.r_outflow_old=0
			self.v_inflow_old = 0
			self.v_CD_old = 0
			self.v_dis_old = 0	
			self.v_outflow_old=0
			self.r_inflow = 0
			self.r_CD = 0
			self.r_dis = 0	
			self.r_outflow = 0
			self.v_inflow = 0
			self.v_CD = 0
			self.v_dis = 0	
			self.v_outflow = 0
		else:
			if parallel.procID==0: "\tThere is no valid shock-finder selected... Good bye..."
			sys.exit(0)

	#/* -- print additional information -- */
		if parallel.procID==0:
			print "\tInner and outer boundarys #",parallel.procID,": ", self.Mhd[0][0], self.Mhd[0][-1]

	#Remove old rpc2rnorm file if Pluto is the hydro-module. rpc2rnorm has to be written on the fly
		if parallel.procID == 0:
			if self.setpar.timecont == None:
				if isfile(self.setpar.HDDATAOUT+"/rpc2rnorm"):
					remove(self.setpar.HDDATAOUT+"/rpc2rnorm")


	#Read in Data if simulation is continued
		if self.inFileName != "":
			try:
				f=open(self.inFileName,"r")
				RPN=f.readlines()
				f.close()
			except IOError:
				if parallel.procID == 0: print "hdtran: no file found:",self.inFileName
				sys.exit(0)

			if parallel.procID == 0: print "hdtran: reading...", self.inFileName
			LEN=len(RPN)-1
			#print LEN, len(self.Mhd_full[0][:]) dimensions agree
			for i in range(0,LEN):
				(r,rho,v,prs,T)=RPN[i+1].split()
				self.Mhd_full[0][i] = float(r)
				self.Mhd_full[1][i] = float(rho)
				self.Mhd_full[2][i] = float(v)
				self.Mhd_full[3][i] = float(prs)
				self.Mhd_full[4][i] = float(T)
			prototypes.pyMPI_Barrier(0)
			if parallel.procID == 0: print "hdtran: reading is done"

			rho_ip = interp1d(self.Mhd_full[0][:],self.Mhd_full[1][:],bounds_error=False, fill_value = NaN)	
			v_ip   = interp1d(self.Mhd_full[0][:],self.Mhd_full[2][:],bounds_error=False, fill_value = NaN)	
			prs_ip = interp1d(self.Mhd_full[0][:],self.Mhd_full[3][:],bounds_error=False, fill_value = NaN)
			#Assign values to data-structure
			r_c   = array(self.grd[0].x[0:self.RRES])*self.UNIT_LENGTH
			for i in range(self.RRES):
				self.data.Vc[0][0][0][i] = C.c_double(rho_ip(r_c[i])/self.UNIT_DENSITY)
				self.data.Vc[1][0][0][i] = C.c_double(v_ip(r_c[i])/self.UNIT_VELOCITY)
				self.data.Vc[2][0][0][i] = C.c_double(prs_ip(r_c[i])/self.UNIT_PRESSURE)
			#inner and outer most ghost cells have to be filled
			#Ghost cells are out of the interpolation range --> NaN-values(should stack-4 in a row), replace with interpolation
			
			if isnan(self.data.Vc[0][0][0][0]):
				#print "NaNs(beginning) on node", parallel.procID
				fit1 = polyfit(r_c[4:8],self.data.Vc[0][0][0][4:8],1)
				fit2 = polyfit(r_c[4:8],self.data.Vc[1][0][0][4:8],1)
				fit3 = polyfit(r_c[4:8],self.data.Vc[2][0][0][4:8],1)

				for i in range(4):
					self.data.Vc[0][0][0][i] = C.c_double(fit1[0]*r_c[i]+fit1[1])	
					self.data.Vc[1][0][0][i] = C.c_double(fit2[0]*r_c[i]+fit2[1])
					self.data.Vc[2][0][0][i] = C.c_double(fit3[0]*r_c[i]+fit3[1])

			if isnan(self.data.Vc[0][0][0][self.RRES-1]):
				#print "NaNs(ending) on node", parallel.procID
				fit1= polyfit(r_c[self.RRES-8:self.RRES-4],self.data.Vc[0][0][0][self.RRES-8:self.RRES-4],1)
				fit2= polyfit(r_c[self.RRES-8:self.RRES-4],self.data.Vc[1][0][0][self.RRES-8:self.RRES-4],1)
				fit3= polyfit(r_c[self.RRES-8:self.RRES-4],self.data.Vc[2][0][0][self.RRES-8:self.RRES-4],1)

				for i in range(self.RRES-4,self.RRES):
					self.data.Vc[0][0][0][i] = C.c_double(fit1[0]*r_c[i]+fit1[1])
					self.data.Vc[1][0][0][i] = C.c_double(fit2[0]*r_c[i]+fit2[1])
					self.data.Vc[2][0][0][i] = C.c_double(fit3[0]*r_c[i]+fit3[1])

			for i in range(self.RRES):
				if isnan(self.data.Vc[0][0][0][i]):
					print parallel.procID,": ", i, self.RRES

			if parallel.procID == 0: print "hdtran: values have been assigned"

			C.c_double.in_dll(self.plutodll,"g_time").value = float(self.setpar.timecont)*yr/self.UNIT_TIME

			if parallel.procID == 0: print "hdtran: starting time assigned"

			#obtain shock-speed and position from log-files:
			try:
				#f=open(str(self.setpar.Rundir)+"/HDPROFILES/"+self.shock_outFileName,"r")
				f=open(self.shock_outFileName,"r")
				RPN=f.readlines()
				f.close()
			except IOError:
				#if parallel.procID == 0: print "hdtran: no file found:",str(self.setpar.Rundir)+"/HDPROFILES/"+self.shock_outFileName
				if parallel.procID == 0: print "hdtran: no file found:",self.shock_outFileName
				sys.exit(0)				

			LEN=len(RPN)-1
			#print LEN, len(self.Mhd_full[0][:]) dimensions agree
			for i in range(0,LEN):
				(TIME,RFS,RRS,VFS,VRS) = RPN[i+1].split()
				if round(float(TIME),2) == round(float(self.setpar.timecont)):
					if self.setpar.shock_finder == "default":
						self.rfs      = float(RFS)
						self.rrs      = float(RRS)
						self.vfs      = float(VFS)
						self.vrs      = float(VRS)
						self.time_old = self.g_time()*self.UNIT_TIME #float(self.setpar.timecont)
						self.rfs_old  = float(RFS)
						self.rrs_old  = float(RRS)
					else:
						if parallel.procID == 0:
							print "hdtran: treatment of old shock values not defined... Have agood time!"
						sys.exit(0)	 

			if parallel.procID == 0: print "hdtran: read shock properties from log-file...Rshock=",self.rfs, "Vshock=",self.vfs

			#self.first_tracking = 0
			#self.sedov_flag = True
			#self.Mhd = self.GetMhdArrays(self.data, self.grd, self.RRES)
			#self.rfs,self.rrs,self.vfs,self.vrs,i,j = self.getShockProperties(self.Mhd,\
			#								self.rfs_old,\
			#								self.rrs_old,\
			#								self.g_time()*self.UNIT_TIME,\
			#								self.time_old,\
			#								self.setpar)

			if parallel.procID == 0: print "hdtran: Shock properties have been searched"


	def DoTimeIntervall(self,time,timeEnd):
	#/* =====================================================================
	#          M A I N      L O O P      S T A R T S      H E R E
	#   ===================================================================== */
	#/* -- Standard loop, don't use Asynchrouns I/O -- */
	
	#Check if Patron and Pluto time agree
		if round(time,5) != round(self.ConvTime(self.g_time()),5):
				if parallel.procID == 0: 
					print "hdtran: Error, Pluto and Patron are at different times..."
					print time, self.ConvTime(self.g_time())
				sys.exit(0)
		if parallel.procID == 0: print "hdtran: Doing time-intervall from ",time, " to ", timeEnd
		#Set Step-number for time-intervall to zero	
		C.c_int.in_dll(self.plutodll,"g_stepNumber").value = 0
		self.ini.tstop = timeEnd
		self.last_step = 0
		#indexes for shock positions, remove later
		i = 0; j = 0

	#	if self.g_time()*self.UNIT_TIME/yr >= 4.9999:
	#			print "DEBUG: ", parallel.procID, "before while loop"

		while (round(self.ConvTime(self.g_time()),10) < round(timeEnd,10)):
	
	#  /* ------------------------------------------------------
	#                Dump log information
	#     ------------------------------------------------------ */
			#if self.g_time()*self.UNIT_TIME/yr >= 4.9999:
			#	print "DEBUG: ", parallel.procID, "after while loop"

			if (C.c_int.in_dll(self.plutodll,"g_stepNumber").value % self.ini.log_freq == 0):
				if parallel.procID==0:
					sys.stdout.write('\tstep:{0} ; t = {1:10.4e} ; dt = {2:10.4e} ; {3:d} % ; [{4:f}, {5:d}'.format(\
					C.c_int.in_dll(self.plutodll,"g_stepNumber").value,\
					self.g_time(),\
					self.g_dt(),\
					int(100.0*(self.ConvTime(self.g_time())-time)/(timeEnd-time)),\
					C.c_double.in_dll(self.plutodll,"g_maxMach").value,\
					C.c_int.in_dll(self.plutodll,"g_maxRiemannIter").value))
			#/*      if (g_maxRootIter > 0) print1 (", root it. # = %d",g_maxRootIter);  */
				if (self.PARABOLIC_FLUX and SUPER_TIME_STEPPING):
					if parallel.procID==0:			       
						sys.stdout.write(", Nsts = ",self.Dts.Nsts)
				if (self.PARABOLIC_FLUX and RK_CHEBYSHEV):
					if parallel.procID==0:
						sys.stdout.write(", Nrkc = ",self.Dts.Nrkc)
				if parallel.procID==0:
					print ("]")      

	#  /* ------------------------------------------------------
	#       check if it's time to write or perform analysis
	#     ----------------------------------------self.start_feedback <= self.g_time()-------------- */
			#log frequencie depends on feedback-switch
			
			if self.CR_feedback:
				if self.start_feedback <= self.g_time():
					log = 1.
				else:
					log = 1e2
			elif not self.CR_feedback:
				log = 1e3
			else:
				print "!Unknown value for CR_feedback : ", self.CR_feedback
				sys.exit(0)
		
 			#if self.g_time()*self.UNIT_TIME/yr >= 4.9999:
			#	print "DEBUG: ", parallel.procID, "before shock properties"

			#Get shock properties
			if C.c_int.in_dll(self.plutodll,"g_stepNumber").value%log == 0:
				if self.g_time() >= self.start_tracing:
					self.rfs,self.rrs,self.vfs,self.vrs,i,j = self.getShockProperties(self.Mhd,\
											self.rfs_old,\
											self.rrs_old,\
											self.g_time()*self.UNIT_TIME,\
											self.time_old,\
											self.setpar)

				#Give rfs to library				
				C.c_double.in_dll(self.plutodll,"g_front_shock_radius").value = self.rfs/self.UNIT_LENGTH
#				self.time_old=self.g_time()*self.UNIT_TIME
	#			self.rfs_old=self.rfs
	#			self.rrs_old=self.rrs
				if parallel.procID==0:
					shock_file = open(self.shock_outFileName,'a')
					shock_file.write(str(self.ConvTime(self.g_time()))+"\t"+str(self.rfs)+"\t"+str(self.rrs)+"\t"+str(self.vfs)+"\t"+str(self.vrs)+"\n")
					shock_file.close()
#					self.shock.append([self.ConvTime(self.g_time()),self.rfs,self.rrs, self.vfs, self.vrs,i,j])

	#  /* ------------------------------------------------------
	#      Update cosmic-ray source and sink terms
	#     ------------------------------------------------------ */
			#if self.g_time()*self.UNIT_TIME/yr >= 4.9999:
			#	print "DEBUG: ", parallel.procID, "before feedback"

			#Check if feedback has to be aplied
			if self.CR_feedback:
				#if self.g_time()*self.UNIT_TIME/yr >= 4.9999:
				#	print "DEBUG: ", parallel.procID, "Flag 0"
				#Reads the globals for the RHS from Pluto
				#Indexes 0:density, 1:momentum, 2:energy
				test = (C.POINTER(C.POINTER(C.POINTER(C.POINTER(C.c_double)))))\
					.in_dll(self.plutodll, "g_Rhs_pluto")	
				r_c   = array(self.grd[0].x[0:self.RRES])
				downstreamfeedback = self.setpar.downstreamfeedback #0-absolutely no downstream feedback; 1-full feedback; 2-uniform CR-density downstream; 3 - full feedbac with transition to zero feedback further downstream
				#if self.g_time()*self.UNIT_TIME/yr >= 4.9999:
				#	print "DEBUG: ", parallel.procID, "Flag 1"
				#Test CR-pressure
				def P_CR(r_c):
					#return where(r_c > 0, 1e-7, 1e-7)
					dr = r_c[1]-r_c[0]

					if downstreamfeedback == 1 or downstreamfeedback == 3:
						#Working basis:					
						return where(r_c*self.UNIT_LENGTH > 5e-17,self.CRP_INT(r_c*self.UNIT_LENGTH/self.rfs)/self.UNIT_PRESSURE,0)
					elif (downstreamfeedback == 0) or (downstreamfeedback == 2):
						return where((r_c)*self.UNIT_LENGTH/self.rfs >= 1e-0,self.CRP_INT(r_c*self.UNIT_LENGTH/self.rfs)/self.UNIT_PRESSURE,max(self.CRP_INT(r_c*self.UNIT_LENGTH/self.rfs)/self.UNIT_PRESSURE))
					else:
						print "hdtran: Wrong option provided"
						sys.exit(0)
					#Older 
				#	return self.CRP(r_c*self.UNIT_LENGTH/self.rfs)/self.UNIT_PRESSURE
				#	return where(r_c*self.UNIT_LENGTH > self.rfs,self.CRP(r_c*self.UNIT_LENGTH/self.rfs)/self.UNIT_PRESSURE,0)

				self.P_CR = P_CR
				#if self.g_time()*self.UNIT_TIME/yr >= 4.9999:
				#	print "DEBUG: ", parallel.procID, "Flag 2"
				def V_CR(r,r_shock):
					#V = 3/4.*15000e5/self.UNIT_VELOCITY
					#return where(r<r_shock,V,0) 
					V = interp1d(r_c,array(self.data.Vc[1][0][0][0:self.RRES]),bounds_error=False, fill_value = 0, kind=2)(r)
					return where(r > 5e-17/self.UNIT_LENGTH,V,0)
				
				#if self.g_time()*self.UNIT_TIME/yr >= 4.9999:
				#	print "DEBUG: ", parallel.procID, "Flag 3"
				#Apply feedback if starting time is reached
				if self.g_time() >= self.start_feedback:
					#Fill the source/sink array; Loop over full array;

					#Momentum-density; -d_r P_cr
					PCR1  = P_CR(r_c)
					dPCR1 = (PCR1-roll(PCR1,1))/(r_c[1]-r_c[0])
					dPCR1[0:2] = 0
					if downstreamfeedback == 0:
						dPCR1 = where(r_c*self.UNIT_LENGTH/self.rfs < 0.999, 0, dPCR1)
					elif downstreamfeedback == 3:
						dPCR1 = where(r_c*self.UNIT_LENGTH/self.rfs < 0.97, dPCR1*exp((r_c*self.UNIT_LENGTH/self.rfs-1.0)/0.025), dPCR1)

					#Energy; -1/r^2 d_r r^2 V_cr P_cr
					#r^2 V_cr P_cr:
				#	PCR = P_CR(r_c)*V_CR(r_c,self.rfs/self.UNIT_LENGTH)*r_c**2.0
				#	v_cr= V_CR(r_c,self.rfs/self.UNIT_LENGTH)
					#dr:
				#	dPCR = (PCR-roll(PCR,1))/(r_c[1]-r_c[0])
				#	dPCR[0:2] = 0; dPCR[-3:-1] = 0

				#	dv_cr = (v_cr-roll(v_cr,1))/(r_c[1]-r_c[0])
				#	dv_cr[0:2] = 0; dv_cr[-3:-1] = 0

				#	if downstreamfeedback == 0:
				#		dPCR = where(r_c*self.UNIT_LENGTH/self.rfs < 1., 0, dPCR)

					diffE = self.DIFFE_INT(r_c*self.UNIT_LENGTH/self.rfs)
					if downstreamfeedback == 0 or downstreamfeedback == 2:
						diffE = where(r_c*self.UNIT_LENGTH/self.rfs < 0.999, 0, diffE)
					elif downstreamfeedback == 3:
						diffE = where(r_c*self.UNIT_LENGTH/self.rfs < 0.97, diffE*exp((r_c*self.UNIT_LENGTH/self.rfs-1.0)/0.025), diffE)


					#working before
					#diffE = where(r_c*self.UNIT_LENGTH/self.rfs > 0.999,diffE,0.0)
					#diffE = where(r_c*self.UNIT_LENGTH/self.rfs < 1.001,diffE,0.0)

					#r_c_full = self.Mhd_full[0]/self.UNIT_LENGTH
					#self.diffE3 = self.DIFFE_INT(r_c_full*self.UNIT_LENGTH/self.rfs)*self.UNIT_PRESSURE


					#if self.g_time()*self.UNIT_TIME/yr >= 4.9999:
					#	print "DEBUG: ", parallel.procID, "Flag 4"
					for i in range(self.RRES):
			 		#Density; 0 -> neglect injection
						#if parallel.procID == 0:
						#	print "1, ", i
						test[0][0][0][i] = 0.
						#if parallel.procID == 0:
						#	print "2, ", i
						test[1][0][0][i] = -dPCR1[i]*self.g_dt() #
						#if parallel.procID == 0:
						#	print "3, ", i

						#according to deviation, possibly excluding internal energy
						#test[2][0][0][i] = -dPCR[i]*self.g_dt()*1/r_c[i]**2.#+diffE[i]*self.g_dt()
						#Working version: Version according to pfrommer
						#test[2][0][0][i] = -dPCR1[i]*v_cr[i]*self.g_dt()#+diffE[i]*self.g_dt()
						#Working version: modifyed Version according to pfrommer
						#test[2][0][0][i] = (-dPCR[i]*self.g_dt()*1/r_c[i]**2. + PCR1[i]*dv_cr[i])*self.g_dt()
						#Including internal energy
						#test[2][0][0][i] = (-4*dPCR[i]*self.g_dt()*1/r_c[i]**2.-diffE[i])*self.g_dt()
						#Energy loss calculated in CR-grid 
						test[2][0][0][i] = -diffE[i]*self.g_dt()


						#if parallel.procID == 0:
						#	print "4, ", i
#			if self.g_time()*self.UNIT_TIME/yr >= 4.9999:
#				print "DEBUG: ", parallel.procID, "after feedback"		
	#  /* ------------------------------------------------------
	#      Advance solution array by a single time step
	#      self.g_dt() = dt(n)
	#     ------------------------------------------------------ */
			if (self.cmd_line.jet != -1):
				SetJetDomain(C.byref(self.data), self.cmd_line.jet, self.ini.log_freq, self.grd) 
			self.err = prototypes.Integrate(C.byref(self.data), self.Solver, C.byref(self.Dts), self.grd)
			if (self.cmd_line.jet != -1):
				UnsetJetDomain(C.byref(self.data), self.cmd_line.jet, self.grd)
	#		if self.g_time()*self.UNIT_TIME/yr >= 4.9999:
	#			print "DEBUG: ", parallel.procID, "after advance solution"	
	#  /* ------------------------------------------------------
	#       Integration didn't go through. Step must
	#       be redone from previously saved solution.
	#     ------------------------------------------------------ */
	#/*
			if (self.err != 0):
				if parallel.procID==0:
					print "! Step failed. exit... "
				sys.exit(0)
	#			print  ("! Step failed. Re-trying\n")
	#			zones with problems must be tagged with MINMOD_FLAG and HLL_FLAG
	#			time step should be halved
	#			GET_SOL(&data);
			    #*/

	#  /* ------------------------------------------------------
	#      Increment time, t(n+1) = t(n) + dt(n)
	#     ------------------------------------------------------ */
			C.c_double.in_dll(self.plutodll,"g_time").value += self.g_dt()

	#  /* ------------------------------------------------------
	#      Show the time step ratios between the actual g_dt
	#      and the advection, diffusion and cooling time scales.
	#     ------------------------------------------------------ */

	    		if self.SHOW_TIME_STEPS == True:
				if (C.c_int.in_dll(self.plutodll,"g_stepNumber").value % self.ini.log_freq == 0):
					#double cg, dta, dtp, dtc;
					dta = 1.0/self.Dts.inv_dta
					if self.Dts.inv_dtp == 0:
						dtp = float('Inf')
					else:
						dtp = 0.5/self.Dts.inv_dtp
					dtc = self.Dts.dt_cool
					if self.PARALLEL:
						if parallel.procID==0:
							print "\tNot yet suported..."
						sys.exit(0)
						#complete later for mpi-support
						cg=0
						#MPI_Allreduce (&dta, &cg, 1, MPI_DOUBLE, MPI_MIN, MPI_COMM_WORLD);
						self.comm.allreduce(dta,cg,op=MPI.MIN)
						dta = cg;

						#MPI_Allreduce (&dtp, &cg, 1, MPI_DOUBLE, MPI_MIN, MPI_COMM_WORLD);
						self.comm.allreduce(dtp,cg,op=MPI.MIN)
						dtp = cg;

						#MPI_Allreduce (&dtc, &cg, 1, MPI_DOUBLE, MPI_MIN, MPI_COMM_WORLD);
						self.comm.allreduce(dtp,cg,op=MPI.MIN)
						dtc = cg;
	

	#   print1 ("[dt/dt(adv) = %10.4e, dt/dt(par) = %10.4e, dt/dt(cool) = %10.4e]\n",
	#                self.g_dt()/dta, self.g_dt()/dtp, self.g_dt()/dtc);
					if parallel.procID==0:
						sys.stdout.write('  dt(adv)  = cfl x {0:10.4e};\n'.format(dta))
						sys.stdout.write('  dt(par)  = cfl x {0:10.4e};\n'.format(dtp))
						sys.stdout.write('  dt(cool) =       {0:10.4e};\n'.format(dtc))

	#  /* ------------------------------------------------------
	#	  Get shock properties at last step
	#     ------------------------------------------------------ */ 
			if self.last_step == 1: 			
				self.Mhd = self.GetMhdArrays(self.data, self.grd, self.RRES)
				self.Mhd_full = self.CombineMhdArrays(self.comm, self.Mhd, self.RRES)
				self.rfs,self.rrs,self.vfs,self.vrs,i,j = self.getShockProperties(self.Mhd,\
											self.rfs_old,\
											self.rrs_old,\
											self.g_time()*self.UNIT_TIME,\
											self.time_old,\
											self.setpar)
				#processing the Mhd output
				if parallel.procID == 0:
					if isnan(self.rrs):					
						RRS = 1.0
					else:
						RRS = self.rrs 
					self.Mhd_full_output[0] = arange(RRS*0.9,self.rfs*1.1,((-RRS*0.9+self.rfs*1.1)/6e5))[0:int(6e5)]#self.Mhd_full[0]
					self.Mhd_full_output[1] = self.rho(self.Mhd_full_output[0]/self.rfs,self.g_time()*self.UNIT_TIME/yr)
	 				self.Mhd_full_output[2] = self.Pg(self.Mhd_full_output[0]/self.rfs,self.g_time()*self.UNIT_TIME/yr)
					self.Mhd_full_output[3] = self.Vrhs_FS_I(self.Mhd_full_output[0]/self.rfs,self.g_time()*self.UNIT_TIME/yr)/yr
					self.Mhd_full_output[4] = self.Tg(self.Mhd_full_output[0]/self.rfs,self.g_time()*self.UNIT_TIME/yr)
#				self.time_old=self.g_time()*self.UNIT_TIME
	#			self.rfs_old=self.rfs
	#			self.rrs_old=self.rrs
				if parallel.procID==0:
					shock_file = open(self.shock_outFileName,'a')
					shock_file.write(str(self.ConvTime(self.g_time()))+"\t"+str(self.rfs)+"\t"+str(self.rrs)+"\t"+str(self.vfs)+"\t"+str(self.vrs)+"\n")
					shock_file.close()
#					self.shock.append([self.ConvTime(self.g_time()),self.rfs,self.rrs, self.vfs, self.vrs,i,j])
					print "hdtran: shock positions updated\n \tstep = ",\
						 C.c_int.in_dll(self.plutodll,"g_stepNumber").value,\
						"\n\tschock radius = ",self.rfs, "\t",self.rfs/3.086e18,\
						"\n\tschock speed = ",self.vfs, "\t",self.vfs/1e5, "ratio: ",\
						 (self.rfs/self.vfs)/(13*3.086e18/(2900*1e5))

				#Write entry to Rpc2Rnorm-file
				#!double entries possible!
				if parallel.procID == 0:
					if any(self.setpar.timeslist == round(self.g_time()*self.UNIT_TIME/yr,8)):
						self.Rpc2Rnorm(self.rfs,self.setpar.rshellpc1,self.setpar.rshellpc2,self.setpar.HDDATAOUT,self.g_time()*self.UNIT_TIME/yr)


	#  /* ------------------------------------------------------
	#      Get next time step dt(n+1).
	#      Do it every two steps if cooling or dimensional
	#      splitting are used.
	#     ------------------------------------------------------ */

			if (self.COOLING == False) and ((self.DIMENSIONS == 1) or (DIMENSIONAL_SPLITTING == False)):
				C.c_double.in_dll(self.plutodll,"g_dt").value = prototypes.NextTimeStep(C.byref(self.Dts),\
												C.byref(self.ini), self.grd)
			else:
				if (C.c_int.in_dll(self.plutodll,"g_stepNumber").value%2 == 1):
					C.c_double.in_dll(self.plutodll,"g_dt").value = prototypes.NextTimeStep(C.byref(self.Dts),\
												C.byref(self.ini), self.grd)

	#check if time+timestep exceeds desired end-time
			if self.g_time() + self.g_dt() > timeEnd*yr/self.UNIT_TIME and self.last_step == 0:
				C.c_double.in_dll(self.plutodll,"g_dt").value = timeEnd*yr/self.UNIT_TIME-self.g_time()
				if parallel.procID==0:
					print "hdtran: Timestep changed..."
				#timestep has always to change for hitting end-time --> self.last_step
				self.last_step = 1
	

	#  /* ------------------------------------------------------
	#          Global MPI reduction operations
	#     ------------------------------------------------------ */
		  
			if self.PARALLEL == True:
				prototypes.pyMPI_2(0)
			
	    		C.c_int.in_dll(self.plutodll,"g_stepNumber").value = C.c_int.in_dll(self.plutodll,"g_stepNumber").value + 1
		    
			self.first_step = 0
		
	#  /* ------------------------------------------------------
	#          Fill MHD-array 
	#     ------------------------------------------------------ */ 	
			self.Mhd = self.GetMhdArrays(self.data, self.grd, self.RRES)


	#  /* ------------------------------------------------------
	#          Remove reverse shock and Oszilations
	#     ------------------------------------------------------ */ 	
			if self.g_time()*self.UNIT_TIME/yr > self.time_RemoveReverseShock: #Deactivated for CC-runs
				if self.sedov_flag == False:
					self.comm.Barrier
					self.Mhd_full = self.CombineMhdArrays(self.comm,\
										 self.Mhd,\
	  								    	 self.RRES)
#					self.sedov_flag = self.RemoveReverseShock(self.data,\
#										self.grd,\
#										self.plutodll,\
#										self.RRES,\
#										self.Mhd_full,\
#										self.rfs,self.rrs,
#										self.rho_sh(self.ConvTime(self.g_time())),\
#										self.Pg_sh(self.ConvTime(self.g_time())),\
#										self.Vlhs_FS_I(1.0-1e-7,self.ConvTime(self.g_time()))/yr)
					self.sedov_flag = True

					self.Mhd = self.GetMhdArrays(self.data, self.grd, self.RRES)
					self.comm.Barrier
					self.Mhd_full = self.CombineMhdArrays(self.comm,self.Mhd,self.RRES)
					if parallel.procID == 0: print "hdtran: SedovFlag switched to True" 

			if self.sedov_flag:
				self.SupressOszilations(self.data,self.RRES,self.grd)

			if self.last_step == 1 and False: # and any(round(self.g_time()*self.UNIT_TIME/yr,1) == array([5.0,12.0,14.0])): #True: # and self.RRES >9e4: # and self.CR_feedback:
				self.comm.Barrier
				self.Mhd_full = self.CombineMhdArrays(	self.comm,\
									self.Mhd,\
	  							    	self.RRES)
				self.SupressBoundaryErrors(	self.data,\
								self.grd,\
								self.plutodll,\
								self.RRES,\
								self.Mhd_full)


	#  /* ------------------------------------------------------
	#          Regriding part
	#     ------------------------------------------------------ */ 	

			if self.g_time()*self.UNIT_TIME/yr > self.regrid_time and\
			 self.regrid_flag != "NO":
				self.Regrid()
		



	#/* =====================================================================
	 #         M A I N       L O O P      E N D S       H E R E 
	 #  ===================================================================== */
		if parallel.procID == 0: print "hdtran: Reached final Intervall-time: ", self.ConvTime(self.g_time())
		#print "HDTE: ",parallel.procID, " DoTimeIntervall 4"


	def EndSimulation(self):
	#output to txt-file
		self.Mhd = self.GetMhdArrays(self.data, self.grd, self.RRES)
		self.comm.Barrier
		self.Mhd_full = self.CombineMhdArrays(self.comm,self.Mhd,self.RRES)


	#print final information from Pluto     
		if self.PARALLEL:
			prototypes.pyMPI_Barrier(0)
			if parallel.procID==0:
				sys.stdout.write('\n> Total allocated memory  {0:6.2f} Mb (proc #{1:d})\n'.format(float(C.c_int.in_dll(self.plutodll,"g_usedMemory").value/1.e6),self.prank.value));
			prototypes.pyMPI_Barrier(0)

		else:
			sys.stdout.write('\n> Total allocated memory  {0:6.2f} Mb\n'.format(float(C.c_int.in_dll(self.plutodll,"g_usedMemory").value/1.e6)))

		prototypes.time(C.byref(self.tend))
		C.c_double.in_dll(self.plutodll,"g_dt").value = self.tend.value - self.tbeg.value

		if parallel.procID==0:
			sys.stdout.write('> Elapsed time              {0}\n'.format(self.TotalExecutionTime(self.g_dt())))
			sys.stdout.write('> Average time/step       {0:10.2e}  (sec)  \n'.format((self.tend.value-self.tbeg.value)/float(C.c_int.in_dll(self.plutodll,"g_stepNumber").value)))
			sys.stdout.write('> Local time                {0}\n'.format(asctime(localtime(self.tend.value))));
			sys.stdout.write("> Done\n")

		prototypes.FreeArray4D(self.data.Vc)
		if self.PARALLEL:
			prototypes.pyMPI_Barrier(0)
			prototypes.AL_Finalize()

		return(0)



#####################################################################################
###		Functions to interface Pluto-results with Patron		  ###
###		  Interpolation and definiton of function names  		  ###
###										  ###
#####################################################################################



	def UpdateMhd(self,crte):
		crte.tecf.ttr   = self.ttr
		crte.tecf.tsf   = self.tsf
		crte.tecf.RFS   = self.RFS
		crte.tecf.RRS   = self.RRS
		crte.tecf.Rsh   = self.Rsh
		crte.tecf.Vsh   = self.Vsh
		crte.tecf.Vinj  = self.Vinj
		crte.tecf.VLHS  = self.Vlhs_FS_I				#always without Alfvenic velocity
		crte.tecf.VRHS  = self.Vrhs_FS_I				#always without Alfvenic velocity
		if   self.setpar.ALFVDRIFT == "I": crte.tecf.Vlhs = self.Vlhs_FS_I;  crte.tecf.Vrhs = self.Vrhs_FS_I
		elif self.setpar.ALFVDRIFT == "A": crte.tecf.Vlhs = self.Vlhs_FS_A;  crte.tecf.Vrhs = self.Vrhs_FS_A
		crte.tecf.nh    = self.nh
		crte.tecf.nh_u  = self.nh_u
		crte.tecf.nh_sh = self.nh_sh
		crte.tecf.rho   = self.rho
		crte.tecf.rho_u = self.rho_u
		crte.tecf.rho_sh= self.rho_sh
		crte.tecf.Pg    = self.Pg
		crte.tecf.Pg_sh = self.Pg_sh
		crte.tecf.Tg    = self.Tg
		crte.tecf.Tg_sh = self.Tg_sh
		#crte.tecf.eta_i = self.eta_i
		return

	#Functions to "submit" Mhd-data
	#Transition times for radiative stage, implement for compability purposes	
	def ttr(self): 
		self.CheckTime(t)
		return 1e6

	def tsf(self):
		self.CheckTime(t)
		return 1e7

	#Radius of forward-shock, normalized
	def RFS(self,t):
		self.CheckTime(t)
		return 1.0

	#Radius of reverse-shock, normalized
	def RRS(self,t):
		self.CheckTime(t)
		return self.rrs/self.rfs

	#Radius of shock in cm 
	def Rsh(self,t):
		self.CheckTime(t)
		return max(self.rfs,1.)

	#Shock-speed in cm/s
	def Vsh(self,t):
		self.CheckTime(t)
		return self.vfs*yr

	#velocity of injected particles
	def Vinj(self,t):
		self.CheckTime(t)
		return self.Vsh(t) - self.Vlhs_FS_I(1.0+1e-7,t)

	#velocity of plasma left hand side of the considered shock.
	#plasma speed in cm/yr
	def Vlhs_FS_I(self,r,t):
		self.CheckTime(t)
		x 	 = self.Mhd_full[0]/self.rfs
		y 	 = self.Mhd_full[2]
		#Add x-value at shock and sharpen shock-profile
		shock_index = argmax(where(x<=1,x,0))+1
		#Fail-safe if shock position is to close to boundary...may produce invalid results(needed for hydro-only runs with low resolutions)
		if shock_index+20 > len(self.Mhd_full[0]):
			shock_index = len(self.Mhd_full[0])-20

		x	 = insertnp(x,shock_index,1.0)
		y	 = insertnp(y,shock_index,y[shock_index-4])
		x	 = insertnp(x,shock_index+1,1.0+1e-8)
		y	 = insertnp(y,shock_index+1,y[shock_index+11])
		y[shock_index-3:shock_index] = y[shock_index-4]
	
		#interpolate the values near the shock
		fit = polyfit(x[shock_index+4:shock_index+7],y[shock_index+4:shock_index+7],1)
		y[shock_index+1:shock_index+6] = x[shock_index+1:shock_index+6]*fit[0]+fit[1]

		#Get steady-state upstream velocity:
#		if self.CR_feedback:		
#			y[shock_index+1:] = self.CRP(x[shock_index+1:])/(self.vfs*1.67e-24*0.3) #*2.5


#		fit = polyfit(x[shock_index+5:shock_index+10],y[shock_index+5:shock_index+10],2)
#		y[shock_index+1:shock_index+6] = x[shock_index+1:shock_index+6]*fit[1]+fit[2]+x[shock_index+1:shock_index+6]**2.*fit[0]

		vel 	 = interp1d(x, y, bounds_error=False, fill_value = -1)(r)
		vel_fill = where(r < 1.,self.Mhd_full[2][50],self.Mhd_full[2][-20])

		#Test for modified spectra
#		vel = where(r > 1, 3e8*exp(-(r-1)/0.1),vel)
#		vel = where(r > 1, vel,0.9*vel)
#		return where(r > 1., 1e9,1.2e9)*yr
		
		return where(vel == -1,vel_fill,vel)*yr

	def Vlhs_FS_A(self,r,t):
		#rrs=self.RRS_FS(t)						#
		#V2=evovik.v_ed(r,t,self.snr)*yr		#FS downstream region (includes RS upstream)
		#VA=self.Valf(r,t)
		#return where(r<rrs,V2-VA,V2)
		self.CheckTime(t)
		return 1

	def Vrhs_FS_I(self,r,t):
		self.CheckTime(t)
		x 	 = self.Mhd_full[0]/self.rfs
		y 	 = self.Mhd_full[2]
		#Add x-value at shock and sharpen shock-profile
		shock_index = argmax(where(x<=1,x,0))+1
		#Fail-safe if shock position is to close to boundary...may produce invalid results(needed for hydro-only runs with low resolutions)
		if shock_index+20 > len(self.Mhd_full[0]):
			shock_index = len(self.Mhd_full[0])-20

		x	 = insertnp(x,shock_index,1.0)
		y	 = insertnp(y,shock_index,y[shock_index-4])
		x	 = insertnp(x,shock_index+1,1.0+1e-8)
		y	 = insertnp(y,shock_index+1,y[shock_index+11])
		y[shock_index-3:shock_index]    = y[shock_index-4]

		#interpolate the values near the shock
		fit = polyfit(x[shock_index+4:shock_index+7],y[shock_index+4:shock_index+7],1)
		y[shock_index+1:shock_index+6] = x[shock_index+1:shock_index+6]*fit[0]+fit[1]

#		fit = polyfit(x[shock_index+5:shock_index+10],y[shock_index+5:shock_index+10],2)
#		y[shock_index+1:shock_index+6] = x[shock_index+1:shock_index+6]*fit[1]+fit[2]+x[shock_index+1:shock_index+6]**2.*fit[0]
		#Analytic upstream expression
#		if self.CR_feedback:		
#			y[shock_index+1:] = self.CRP(x[shock_index+1:])/(self.vfs*1.67e-24*0.3) #*2.5

		vel 	 = interp1d(x, y, bounds_error=False, fill_value = -1)(r)
		vel_fill = where(r < 1.,self.Mhd_full[2][50],self.Mhd_full[2][-20])

		#Test for modified spectra
#		vel = where(r > 1, 3e8*exp(-(r-1)/0.1),vel)
#		vel = where(r > 1, vel,0.9*vel)
#		return where(r > 1., 1e9,1.2e9)*yr

		return where(vel == -1,vel_fill,vel)*yr

	def Vrhs_FS_A(self,r,t):
		#rrs=self.RRS_RS(t)				#equals always 1.0 for RS
		#V2=evovik.v_ed(r,t,self.snr)*yr		#FS downstream region is used because it includes RS upstream region
		#VA=self.Valf(r,t)
		#return where(r<rrs,V2-VA,V2)
		self.CheckTime(t)
		return 1

	#proton number density
	def nh(self,r,t):
		self.CheckTime(t)
		return self.rho(r,t)/(muh*m_p)

	#number density just upstream of the shock
	def nh_u(self,t):
		self.CheckTime(t)
		return self.rho_u(t)/(muh*m_p)

	#proton number density at the shock
	def nh_sh(self,t):
		self.CheckTime(t)
		return self.rho_sh(t)/(muh*m_p)

	#gas density
	def rho(self,r,t):
		self.CheckTime(t)
		x 	 = self.Mhd_full[0]/self.rfs
		y 	 = self.Mhd_full[1]
		#Add x-value at shock and sharpen shock-profile
		shock_index = argmax(where(x<=1,x,0))+1
		#Fail-safe if shock position is to close to boundary...may produce invalid results(needed for hydro-only runs with low resolutions)
		if shock_index+20 > len(self.Mhd_full[0]):
			shock_index = len(self.Mhd_full[0])-20

		x	 = insertnp(x,shock_index,1.0)
		y	 = insertnp(y,shock_index,y[shock_index-4])
		x	 = insertnp(x,shock_index+1,1.0+1e-8)
		y	 = insertnp(y,shock_index+1,y[shock_index+5])
		y[shock_index-3:shock_index] = y[shock_index-4]
		y[shock_index+1:shock_index+4] = y[shock_index+5]

		rho 	 = interp1d(x, y, bounds_error=False, fill_value = -1)(r)
		rho_fill = where(r < 1.,self.Mhd_full[1][50],self.Mhd_full[1][-20])
		return where(rho == -1,rho_fill,rho)

	#gas density just upstream of the shock
	def rho_u(self,t):
		self.CheckTime(t)
		#x   = self.Mhd_full[0]/self.rfs
		#shock_index = argmax(where(x<=1,x,0)) 
		return self.rho(1+1e-7,t)
	
	#gas density at the shock
	def rho_sh(self,t):
		self.CheckTime(t)
		#x   = self.Mhd_full[0]/self.rfs
		#shock_index = argmax(where(x<=1,x,0))
		return self.rho(1.0,t)

	#gas pressure	
	def Pg(self,r,t):
		self.CheckTime(t)
		x 	 = self.Mhd_full[0]/self.rfs
		y 	 = self.Mhd_full[3]
		#Add x-value at shock and sharpen shock-profile
		shock_index = argmax(where(x<=1,x,0))+1
		#Fail-safe if shock position is to close to boundary...may produce invalid results(needed for hydro-only runs with low resolutions)
		if shock_index+20 > len(self.Mhd_full[0]):
			shock_index = len(self.Mhd_full[0])-20

		x	 = insertnp(x,shock_index,1.0)
		y	 = insertnp(y,shock_index,y[shock_index-4])
		x	 = insertnp(x,shock_index+1,1.0+1e-8)
		y	 = insertnp(y,shock_index+1,y[shock_index+5])
		y[shock_index-3:shock_index] = y[shock_index-4]
		y[shock_index+1:shock_index+4] = y[shock_index+5]

		pre 	 = interp1d(x, y, bounds_error=False, fill_value = -1)(r)
		pre_fill = where(r < 1.,self.Mhd_full[3][50],self.Mhd_full[3][-20])
		return where(pre == -1,pre_fill,pre)


	#gas pressure at the shock
	def Pg_sh(self,t):
		self.CheckTime(t)
#		x   = self.Mhd_full[0]/self.rfs
#		shock_index = argmax(where(x<=1,x,0)) 
#		return self.Mhd_full[3][shock_index]
		return self.Pg(1.0,t)

	#gas temperature
	def Tg(self,r,t):
		self.CheckTime(t)
		x 	 = self.Mhd_full[0]/self.rfs
		y 	 = self.Mhd_full[4]
		#Add x-value at shock and sharpen shock-profile
		shock_index = argmax(where(x<=1,x,0))+1
		#Fail-safe if shock position is to close to boundary...may produce invalid results(needed for hydro-only runs with low resolutions)
		if shock_index+20 > len(self.Mhd_full[0]):
			shock_index = len(self.Mhd_full[0])-20

		x	 = insertnp(x,shock_index,1.0)
		y	 = insertnp(y,shock_index,y[shock_index-4])
		x	 = insertnp(x,shock_index+1,1.0+1e-8)
		y	 = insertnp(y,shock_index+1,y[shock_index+5])
		y[shock_index-3:shock_index] = y[shock_index-4]
		y[shock_index+1:shock_index+4] = y[shock_index+5]

		tem 	 = interp1d(x, y, bounds_error=False, fill_value = -1)(r)
		tem_fill = where(r < 1.,self.Mhd_full[4][50],self.Mhd_full[4][-20])
		return where(tem == -1,tem_fill,tem)

	#gas temperature at the shock
	def Tg_sh(self,t):
		self.CheckTime(t)
#		x   = self.Mhd_full[0]/self.rfs
#		shock_index = argmax(where(x<=1,x,0)) 
#		return self.Mhd_full[4][shock_index]
		return self.Tg(1.0,t)

	#injection efficiency
	def eta_i(self,t,InP):
		self.CheckTime(t)
		Vs=self.Vsh(t)
		rs=array([1.0])
		CR=((Vs-self.Vrhs_FS_I(rs,t))/(Vs-self.Vlhs_FS_I(rs,t)))[0]
		#print "hdtran: InP...", (4.0/(3.0*pi**0.5))*(CR-1.0)*InP**3*exp(-InP**2)

		#figure out whether values are correct...so far analytic version
#		rs=1.0
#		CR=4.0
		return (4.0/(3.0*pi**0.5))*(CR-1.0)*InP**3*exp(-InP**2)

	def WriteVel(self,t):
		if parallel.procID == 0:
			x   = arange(0,2.0,1/80.)
			x2  = (x-1.0)**3.+1.0 
			vel = self.Vlhs_FS_I(x2,t)/yr
			savetxt(self.outFileName+"_vel_"+str(t), array([x2, vel]).transpose(), fmt='%.18e', delimiter=' ', newline='\n', header='', footer='', comments='# ')

	def WriteRho(self,t):
		if parallel.procID == 0:
			x   = arange(0,2.0,1/80.)
			x2  = (x-1.0)**3.+1.0 
			rho = self.rho(x2,t)
			savetxt(self.outFileName+"_rho_"+str(t), array([x2, rho]).transpose(), fmt='%.18e', delimiter=' ', newline='\n', header='', footer='', comments='# ')

#########################################################################################
#											#
#			Functions from former functions.py-file				#
#											#
#########################################################################################

	#Get globals as functions
	def NMAX_POINT(self):
	    return C.c_int.in_dll(self.plutodll, "NMAX_POINT").value

	def g_time(self):
		return C.c_double.in_dll(self.plutodll,"g_time").value

	def g_dt(self):
		return C.c_double.in_dll(self.plutodll,"g_dt").value

	#End of Globals

	#Functions defined in main.c
	def TotalExecutionTime(self,dt):
		days  = int(dt/86400.0)
	  	hours = int((dt - 86400.0*days)/3600.0)
	  	mins  = int((dt - 86400.0*days - 3600.0*hours)/60.)
	  	secs  = int(dt - 86400.0*days - 3600.0*hours - 60.0*mins)
		return str(days) + "d:" + str(hours) + "h:" + str(mins) + "m:" + str(secs) + "s"



	#End of function definitions

	#Additional Helper Functions
	def GetMhdArrays(self,data, grd, RRES):
		r_c   = array(grd[0].x[0:RRES])			#Contains the cell centers of the grid
		rho_c = array(data.Vc[0][0][0][0:RRES])		#Contains rho at the cell centers
		v_c   = array(data.Vc[1][0][0][0:RRES])		#Contains v at the cell centers
		prs_c =	array(data.Vc[2][0][0][0:RRES])		#Contains prs at the cell centers
		Mhd   = zeros((5,RRES))
		Mhd[0]= r_c*self.UNIT_LENGTH
		Mhd[1]= rho_c*self.UNIT_DENSITY #/m_p
		Mhd[2]= v_c*self.UNIT_VELOCITY
		Mhd[3]= prs_c*self.UNIT_DENSITY*self.UNIT_VELOCITY**2.0
		Mhd[4]= prs_c/(rho_c*mu)*self.KELVIN
		return Mhd


	def ConvTime(self,t):
		return t*self.UNIT_TIME/yr


	def CombineMhdArrays(self,comm,Mhd,RRES):
		size = comm.Get_size()
		rank = comm.Get_rank()

		sendbuf = Mhd 
		recvbuf = None
		if rank == 0:
		    recvbuf = empty([size, 5,RRES], dtype='d')
		comm.Gather(sendbuf, recvbuf, root=0)

		Mhd_full = zeros((5,size*RRES-size*8))
		RRES2=RRES-8
		if rank==0:
			for i in range(size):	
				Mhd_full[0][i*RRES2:i*RRES2+RRES2] = recvbuf[i][0][4:-4]
				Mhd_full[1][i*RRES2:i*RRES2+RRES2] = recvbuf[i][1][4:-4]
				Mhd_full[2][i*RRES2:i*RRES2+RRES2] = recvbuf[i][2][4:-4]
				Mhd_full[3][i*RRES2:i*RRES2+RRES2] = recvbuf[i][3][4:-4]
				Mhd_full[4][i*RRES2:i*RRES2+RRES2] = recvbuf[i][4][4:-4]

		Mhd_full = comm.bcast(Mhd_full, root=0)
		return Mhd_full
		


	def WriteMhd(self,Mhd,t,timesout2,outFileName):
			for time in timesout2:
				if round(time - t,5) == 0:
					TIME=str(time)
					fname=outFileName+TIME #+"_"+str(parallel.procID)
					if parallel.procID==0:
						print "evoplu: node(",parallel.procID,")writing file ", fname, "\n"
						savetxt(fname, Mhd.transpose(), fmt='%.18e', delimiter=' ', newline='\n', header='r rho v prs T', footer='', comments='# ')	

	#returns the next outputtime in Pluto-code units
	def NextOutputTime(self,g_t,timesout2):
		t=g_t*self.UNIT_TIME/yr
		timenext = min(where(timesout2-t>0,timesout2,1e7))
		return timenext*yr/self.UNIT_TIME





	#get shock positions and shock speed
	def getShockProperties(self,MHD,rfs_old,rrs_old,time,time_old,setpar):
		if (time-time_old) == 0:
			if parallel.procID == 0: print "HDTRAN: shock search - nothing to do..."
			return 	self.rfs, self.rrs, self.vfs, self.vrs, 0, 0

		#Function to fit the shock-position
		def logistic2(x,x0,k):
			return (1)/(1+exp(k*(1)*(x-x0)))

		#Calculates the index range where the shock should be found
		def indexSearch(old_position, new_position,forward_shock,local):
			del_r = 0.005	 #choose with care, too small value force more often a whole-grid search
	 		#Decide if local or global
			r_min = self.r_min_local*local + self.r_min_global*(not local)
			#Calculate positions
			if(old_position < (1-del_r)*new_position):
				index_min_f = int((((1-del_r)*new_position*forward_shock + (1-del_r)*new_position*(not forward_shock))-r_min)/self.dr)	
			else:
				index_min_f = int((old_position*forward_shock + (1-del_r)*new_position*(not forward_shock)-r_min)/self.dr)
			#index_min_f = int(((old_position*forward_shock + (1-del_r)*new_position*(not forward_shock))-r_min)/self.dr)
			
			index_max_f = int(((1+del_r)*new_position-r_min)/self.dr)
			if (index_min_f < index_max_f):
				if (index_max_f-index_min_f < 20):
					index_max_f = index_max_f+10
					index_min_f = index_min_f-10
			else:
				index_min_f,index_max_f = sort([index_min_f, index_max_f])
				if (index_max_f-index_min_f < 20):
					index_max_f = index_max_f+10
					index_min_f = index_min_f-10
			return [index_min_f,index_max_f]

		if self.setpar.shock_finder == "default":
			#Check if shock-search has to be performed

			def shockFitting(Mhd,forward_shock,local,compression_limit,index_min,index_max):
				#search for forward shock
				#print "!TEST! searching on node=", parallel.procID, index_min, index_max, self.vfs
				#defines the velocity-differences between cells
				dv_f = (Mhd[2][index_min:index_max])-(roll(Mhd[2][index_min:index_max],3))
				# defines the compression ratio
		                comp_f = (roll(Mhd[1][index_min:index_max],3))/(Mhd[1][index_min:index_max])
				#print "indices=", index_min,index_max
		      		compression_check = False
				while_count = 0
				# if max velocity difference (dv_max) is in certain range of compression ratio then that position is the right shock position else just to get rid of this dv_max 
				while not compression_check and while_count < 20:
					i = argmin(dv_f)+index_min
				#print "hdtran(1371): Compression ratio and dv around supposed shock: ", comp_f[i-index_min-4:i-index_min+4], parallel.procID,dv_f[i-index_min]
					#print "index vel min", i-index_min	
					
					compression_check = i-index_min in np.where((comp_f>=compression_limit[0])*(comp_f<=compression_limit[1]))[0]
					if not compression_check:
						dv_f[i-index_min-3:i-index_min+3] = 0
						while_count += 1

				#print "index", i, forward_shock
				#print "r", Mhd[0][i-15:i+4], Mhd[2][i-15:i+4]
				#Fit for forward shock
				if i < 15:
					i=15
				rmax1=max(Mhd[0][i-15:i+4])
				rmin1=min(Mhd[0][i-15:i+4])
				vmax1=max(Mhd[2][i-15:i+4])
				vmin1=min(Mhd[2][i-15:i+4])
				try:
					popt1,pcov = optimize.curve_fit(logistic2,(Mhd[0][i-15:i+4]-rmin1)/(rmax1-rmin1),(Mhd[2][i-15:i+4]-vmin1)/(vmax1-vmin1))
					rfs=popt1[0]*(rmax1-rmin1)+rmin1
				except:
					print "evoplu: Fit for shock failed...i=",i
					print "x: ",(Mhd[0][i-15:i+4]-rmin1)/(rmax1-rmin1)
					print "v: ",(Mhd[2][i-15:i+4]-vmin1)/(vmax1-vmin1)
					
					rfs = NaN #rfs_old
					#sys.exit(0)
				if compression_check:
					return rfs
				else:	
					return NaN

			#START OF SEARCH ALGORITHM###	
			forward_shock_found = False
			reverse_shock_found = False

		       #Estimating new shock position
			new_rfs     = rfs_old+self.vfs*(time-time_old)
			new_rrs     = rrs_old+self.vrs*(time-time_old)
		        
		        #print "DEBUG: evoplu: rfs_old = ", rfs_old, " new_rfs = ", new_rfs, " time = ", time, " time_old = ", time_old

			if new_rfs < rfs_old+10*self.dr and self.vfs > 0:
				if parallel.procID == 0: print "HDTRAN: skipping calculation at step", C.c_int.in_dll(self.plutodll,"g_stepNumber").value
				return new_rfs, new_rrs, self.vfs, self.vrs, 0, 0

			########SEARCH FOR FORWARD SHOCK#####
			#Search on part of the grid
			#Find index-range for local grid
			index_min_f, index_max_f = indexSearch(rfs_old, new_rfs, True, True)

		        #print "DEBUG: index_min_f = ", index_min_f, " index_max_f = ", index_max_f
	  		
			#CHeck if shock is not close to local grid-boundaries, calculate shock position
			if (index_min_f > 20) and (index_max_f < self.RRES_local-20):            
				rfs = shockFitting(MHD,True,True,[2.5,4.5],index_min_f,index_max_f)
			else:
				rfs = NaN

			#Distribute values between cores:
			size = self.comm.Get_size()
			rank = self.comm.Get_rank()
			sendbuf1 	 = rfs
			values_fs = self.comm.allgather(sendbuf1)
			#Count Number of NaNs
			nan_fs = sum(where(isnan(values_fs),1,0))		

			#Exactly one core should have found the shock
			if nan_fs == size-1:
				rfs = nansum(values_fs)
				vfs = (rfs-rfs_old)/(time-time_old)
				self.first_tracking += 1
				self.time_old=time
				self.rfs_old = rfs
				self.vfs_old = self.vfs
				vfs = (2*vfs+self.vfs)/3.
				forward_shock_found = True
				if parallel.procID == 0: print "hdtran: Forward shock found locally - Yeah :-)" 

			#Prepare search on whole grid
			if not forward_shock_found:
				#Combine arrays for full search
				self.comm.Barrier
				self.Mhd_full=self.CombineMhdArrays(self.comm,self.Mhd,self.RRES)


				#restrict range for forward shock
				index_min_f, index_max_f = indexSearch(rfs_old, new_rfs, True, False)

				if isnan(self.vfs) or\
				   self.first_tracking < 2 or\
				   index_max_f-index_min_f <= 4 or\
				   index_max_f > self.RRES*parallel.Nproc or\
				   index_min_f:
					#if parallel.procID == 0: print "hdtran: problems with reduced shock-search - searching on whole grid(",index_min_f,index_max_f,")"
					index_min_f = 5
					index_max_f = -1

				rfs = shockFitting(self.Mhd_full,True,False,[2.0,5.0],index_min_f,index_max_f)

				if not isnan(rfs):
					vfs = (rfs-rfs_old)/(time-time_old)
					self.first_tracking += 1
					self.time_old=time
					self.rfs_old = rfs
					self.vfs_old = self.vfs
					vfs = (2*vfs+self.vfs)/3.
					forward_shock_found = True
					if parallel.procID == 0: print "hdtran: Forward shock found globally - at least..."


			########SEARCH FOR REVERSE SHOCK#####
			#Search on part of the grid
			#Find index-range for local grid
			index_min_r, index_max_r = indexSearch(rrs_old, new_rrs, False, True)

		        #print "DEBUG: index_min_r = ", index_min_r, " index_max_r = ", index_max_r
	  		
			#CHeck if shock is not close to local grid-boundaries, calculate shock position
			if (index_min_r > 20) and (index_max_r < self.RRES_local-20):            
				rrs = shockFitting(MHD,False,True,[0, 0.9],index_min_r,index_max_r)
			else:
				rrs = NaN

			#Distribute values between cores:
			size = self.comm.Get_size()
			rank = self.comm.Get_rank()
			sendbuf2 	 = rrs
			values_rs = self.comm.allgather(sendbuf2)
			#Count Number of NaNs
			nan_rs = sum(where(isnan(values_rs),1,0))		

			#Exactly one core should have found the shock
			if nan_rs == size-1:
				rrs = nansum(values_rs)
				vrs = (rrs-rrs_old)/(time-time_old)
				#self.first_tracking += 1
				self.time_old=time
				self.rrs_old = rrs
				self.vrs_old = self.vrs
				vrs = (2*vrs+self.vrs)/3.
				reverse_shock_found = True
				if parallel.procID == 0: print "hdtran: Reverse shock found locally - Yeah :-)" 

			#Prepare search on whole grid
			if not reverse_shock_found:
				#Combine arrays for full search
				self.comm.Barrier
				self.Mhd_full=self.CombineMhdArrays(self.comm,self.Mhd,self.RRES)


				#restrict range for reverse shock
				index_min_r, index_max_r = sort(indexSearch(rrs_old, new_rrs, False, False))

				if isnan(self.vrs) or\
				   self.first_tracking < 2 or\
				   index_max_r-index_min_r <= 4 or\
				   index_max_r > self.RRES*parallel.Nproc or\
				   index_min_r < 0:
					#if parallel.procID == 0:print "hdtran: problems with reduced shock-search - searching on whole grid(",index_min_r,index_max_r,index_min_r,index_max_r,")"
					index_min_r = 0
					index_max_r = -1

		                #CHeck if shock is not close to local grid-boundaries, calculate shock position
				if (index_min_r > 20) and (index_max_r < self.RRES_local-20):            
		                	rrs = shockFitting(MHD,False,True,[0, 0.9],index_min_r,index_max_r, time)
				else:
		                	rrs = NaN
	#				rrs = shockFitting(self.Mhd_full,False,False,[0, 0.9],index_min_r,index_max_r)

				if not isnan(rrs):
					vrs = (rrs-rrs_old)/(time-time_old)
					#self.first_tracking += 1
					self.time_old=time
					self.rrs_old = rrs
					self.vrs_old = self.vrs
					vrs = (2*vrs+self.vrs)/3.
					reverse_shock_found = True
					if parallel.procID == 0: print "hdtran: Reverse shock found globally - at least..."
				if not reverse_shock_found:
					if parallel.procID == 0: print "reverse shock not found globally"
					vrs = 1e8

			if not forward_shock_found:
				if parallel.procID == 0: print "hdtran: forward shock not found, exiting code..."
				sys.exit(0)
			return rfs, rrs, vfs, vrs, 1, 0
			
		elif self.setpar.shock_finder == "shock_inside_bubble":
			
			#### Finds any outflowing shock in the vicinity of SNR forward shock along with SNR forward shock itself####	
			def shockFinder(Mhd,forward_shock,local,compression_limit_outflow,index_min,index_max, time):
				#defines the velocity-differences between cells
				dv_out = (Mhd[2][index_min:index_max])-(roll(Mhd[2][index_min:index_max],3))
				# defines the compression ratio
                        	comp_out = (roll(Mhd[1][index_min:index_max],3))/(Mhd[1][index_min:index_max])
			
                       		compression_check = False
				while_count = 0
				# if max velocity difference (dv_max) is in certain range of compression ratio then that position is the right shock position else just to get rid of this dv_max 
				while not compression_check and while_count < 20:
					i = argmin(dv_out)+index_min
					### difference in flow velocity	across the shock
					dv_outflow = min((Mhd[2][index_min:index_max])-(roll(Mhd[2][index_min:index_max],8)))
					# shock velocity calculation from mass flux	
					dm_out = (Mhd[2][i+4]*Mhd[1][i+4])-(Mhd[2][i-4]*Mhd[1][i-4])
				
					A = dm_out/Mhd[1][i+4]
					k =(Mhd[2][i+4]-A)/(Mhd[2][i-4])
					vfs = dm_out/((1-k)*Mhd[1][i+4])
      					compression_check = i-index_min in np.where((comp_out>=compression_limit_outflow[0])*(comp_out<=compression_limit_outflow[1]))[0]
					if not compression_check:
						dv_out[i-index_min-3:i-index_min+3] = 0
						while_count += 1
					else:
						while_count += 1
			
				#Fit for forward shock
				if i < 5:
					i=5
				rmax=max(Mhd[0][i-5:i+4])
				rmin=min(Mhd[0][i-5:i+4])
				vmax=max(Mhd[2][i-5:i+4])
				vmin=min(Mhd[2][i-5:i+4])
			
                     		try:
					popt1,pcov = optimize.curve_fit(logistic2,(Mhd[0][i-5:i+4]-rmin)/(rmax-rmin),(Mhd[2][i-5:i+4]-vmin)/(vmax-vmin))
					rfs=popt1[0]*(rmax-rmin)+rmin
				
				except:
					print "evoplu: Fit for shock failed...i=",i
					print "x: ",(Mhd[0][i-5:i+4]-rmin)/(rmax-rmin)
					print "v: ",(Mhd[2][i-5:i+4]-vmin)/(vmax-vmin)
					rfs = 0.5*(rmax+rmin)
				
				# Locating the shock position while the shock climbs CD with huge density jump, forget about fitting at that point

		       		rmax_nearCD=max(Mhd[0][i-5:i+2])
				rmin_nearCD=min(Mhd[0][i-5:i+2])	
				rfs_nearCD = 0.5*(rmax_nearCD+rmin_nearCD)
				# Locating any outflowing shock in the vicinity of SNR shock 
				rmax_outflow=max(Mhd[0][i-4:i+4])
				rmin_outflow=min(Mhd[0][i-4:i+4])
				r_outflow = 0.5*(rmax_outflow+rmin_outflow)
			
				if not compression_check:
					rfs= NaN
					vfs = NaN
					rfs_nearCD = NaN
					r_outflow = NaN
			
				return [rfs, vfs, rfs_nearCD, r_outflow, dv_outflow]
		
			            
			
			#### Locating the contact discontinuity (CD) and shock ahead of the supernova shock ####
			def HeadOnStructures(Mhd,compression_limit_inflow,compression_limit_CD,compression_limit_dis,index_min_d,index_max_d,time):
				#defines the velocity-differences between cells 
				dv_sh = (Mhd[2][index_min_d:index_max_d])-(roll(Mhd[2][index_min_d:index_max_d],5))
				#compression ratio around shock 
				comp_sh = (Mhd[1][index_min_d:index_max_d])/(roll(Mhd[1][index_min_d:index_max_d],5))

			
				#compression ratio around CD
                        	comp_CD = (Mhd[1][index_min_d:index_max_d])/(roll(Mhd[1][index_min_d:index_max_d],40))
			
				# For small density fluctuations 
                        	comp_dis = (Mhd[1][index_min_d:index_max_d])/(roll(Mhd[1][index_min_d:index_max_d],8))
			
			
				compression_check1 = False
				while_count1 = 0
				########### search for shock
				while not compression_check1 and while_count1 < 20:
					i = argmin(dv_sh)+index_min_d
					###### velocity flux through shock
					dv_inflow = min((Mhd[2][index_min_d:index_max_d])-(roll(Mhd[2][index_min_d:index_max_d],8)))
				
					compression_check1 = i-index_min_d in np.where((comp_sh>=compression_limit_inflow[0])*(comp_sh<=compression_limit_inflow[1]))[0]
					if not compression_check1:
						dv_sh[i-index_min_d-3:i-index_min_d+3] = 0
						while_count1 += 1
			
	      			compression_check2 = False
				while_count2 = 0
				######## search for CD
				while not compression_check2 and while_count2 < 20:
					j = argmax(comp_CD)+index_min_d
					###### velocity flux through CD
					dv_CD = min((Mhd[2][index_min_d:index_max_d])-(roll(Mhd[2][index_min_d:index_max_d],60)))
				
					compression_check2 = j-index_min_d in np.where((comp_CD>=compression_limit_CD[0])*(comp_CD<=compression_limit_CD[1]))[0]
					if not compression_check2:
						while_count2 += 1
			
				compression_check3 = False
				while_count3 = 0
				######## search for small fluctuations in density
				while not compression_check3 and while_count3 < 20:
					k = argmax(comp_dis)+index_min_d
				
				
					compression_check3 = k-index_min_d in np.where((comp_dis>=compression_limit_dis[0])*(comp_dis<=compression_limit_dis[1]))[0]
					if not compression_check3:
						while_count3 += 1
			
				###### radius of inflow
		     		rmax_inflow=max(Mhd[0][i-5:i+2])
				rmin_inflow=min(Mhd[0][i-5:i+2])
				r_inflow = 0.5*(rmax_inflow+ rmin_inflow)
			
				###### radius of CD      
				rmax_CD=max(Mhd[0][j-5:j+15])
				rmin_CD=min(Mhd[0][j-5:j+15])
				r_CD = 0.5*(rmax_CD + rmin_CD)
			
				###### radius of density fluctuations      
				rmax_dis=max(Mhd[0][k-5:k+2])
				rmin_dis=min(Mhd[0][k-5:k+2])
				r_dis = 0.5*(rmax_dis + rmin_dis)
			
				if not compression_check1:
					r_inflow = NaN
				if not compression_check2:
					r_CD = NaN
				if not compression_check3:
					r_dis = NaN
			
                      
			
				return [r_inflow, r_CD, r_dis, dv_inflow, dv_CD]


			#START OF SEARCH ALGORITHM###	
			forward_shock_found = False
			reverse_shock_found = False
			outflow_found = False
			inflow_found = False
			CD_found = False
			fluctuations_found = False
		
		
              	 	#Estimating new shock position
			new_rfs     = rfs_old+self.vfs*(time-time_old)
			new_rrs     = rrs_old+self.vrs*(time-time_old)
               
			if new_rfs < rfs_old + 3*self.dr and self.vfs > 0 and self.structure_found==0:
				if parallel.procID == 0: print "HDTRAN: skipping calculation at step", C.c_int.in_dll(self.plutodll,"g_stepNumber").value
				return new_rfs, new_rrs, self.vfs, self.vrs, 0, 0
			#### If structure is on the way of SNR shock, shock velocity changes sharply which points out to the need of calculating shock velocity frequently
	       	 	elif new_rfs < rfs_old + self.dr and self.vfs > 0 and self.structure_found==1 :
				if parallel.procID == 0: print "HDTRAN: skipping calculation at step", C.c_int.in_dll(self.plutodll,"g_stepNumber").value
				return new_rfs, new_rrs, self.vfs, self.vrs, 0, 0
			else:
				if parallel.procID == 0: print "HDTRAN: not skipping the calculation"
			
			########SEARCH FOR DIFFERENT STRUCTURES#####
			#Search on part of the grid
			#Find index-range for local grid
			index_min_f, index_max_f = indexSearch(rfs_old, new_rfs, True, True)
		
			#Check if shock is not close to local grid-boundaries, calculate shock position
			if (index_min_f > 20) and (index_max_f < self.RRES_local-20):  
				rfs = shockFinder(MHD,True,True,[1.0,8],index_min_f,index_max_f, time)[0]	
				vfs = shockFinder(MHD,True,True,[1.0,8],index_min_f,index_max_f, time)[1]
				rfs_nearCD = shockFinder(MHD,True,True,[1.0,8],index_min_f,index_max_f, time)[2]
			   

			else:
				rfs = NaN
				vfs = NaN
                        	rfs_nearCD = NaN


			#Distribute values between cores:
			size = self.comm.Get_size()
			rank = self.comm.Get_rank()
			sendbuf1 	 = rfs
			sendbuf2         = vfs
			sendbuf3 	 = rfs_nearCD
		
			values_fs1 = self.comm.allgather(sendbuf1)
			values_fs2 = self.comm.allgather(sendbuf2)
			values_fs3 = self.comm.allgather(sendbuf3)
		
			#Count Number of NaNst
			nan_fs1 = sum(where(isnan(values_fs1),1,0))		
			nan_fs2 = sum(where(isnan(values_fs2),1,0))		
			nan_fs3 = sum(where(isnan(values_fs3),1,0))

			#Exactly one core should have found the shock
			if nan_fs1 == size-1:
				rfs = nansum(values_fs1)
				if not isnan(rfs):
					forward_shock_found = True
					if parallel.procID == 0: print "hdtran: Forward shock found locally - Yeah :-)" 

					if parallel.procID == 0: print "shock radius and incoming shock", rfs, self.r_inflow, (rfs-self.r_inflow)/pc
					if parallel.procID == 0: print "shock radius and CD", rfs, self.r_CD, (rfs-self.r_CD)/pc
					if parallel.procID == 0: print "shock radius and density fluctuations", rfs, self.r_dis, (rfs-self.r_dis)/pc
					if parallel.procID == 0: print "shock radius and outgoing shock", rfs, self.r_outflow, (self.r_outflow-rfs)/pc
					if self.structure_found == 1:

						if (30*self.dr< rfs < 0.09*pc):
							####### supernova shock interacting with incoming shock 
							if (-10*self.dr< rfs-self.r_inflow < 30*self.dr):
								if parallel.procID == 0: print "in the range of incoming shock"
								vfs = (rfs-rfs_old)/(time-time_old)
				
							####### supernova shock interacting with CD
                        				elif (-10*self.dr< rfs-self.r_CD< 30*self.dr):
								if parallel.procID == 0: print "in the range of CD"
								rfs = nansum(values_fs3)
								vfs = (rfs-rfs_old)/(time-time_old)	
						
							####### supernova shock interacting with density fluctuations
							elif (-10*self.dr < rfs-self.r_dis < 30*self.dr):
								if parallel.procID == 0: print "in the range of smaller structures"
								vfs = (rfs-rfs_old)/(time-time_old)
			
							####### supernova shock interacting with outgoing shock		
							elif (-10*self.dr< self.r_outflow-rfs < 30*self.dr):
								if parallel.procID == 0: print "in the range of outgoing shock"
								vfs = nansum(values_fs2)		
				
							else:	
                                				####### You can use velocity from rdot or from mass flux anything you like.....
								#vfs = (rfs-rfs_old)/(time-time_old)	
								vfs = nansum(values_fs2)









						elif (rfs >= 0.09*pc):
							####### supernova shock interacting with incoming shock 
							if (-0.09*pc< rfs-self.r_inflow < 0.07*pc):
								if parallel.procID == 0: print "in the range of incoming shock"
								vfs = (rfs-rfs_old)/(time-time_old)
				
							####### supernova shock interacting with CD
                        				elif (-0.01*pc< rfs-self.r_CD< 0.8*pc):
								if parallel.procID == 0: print "in the range of CD"
								rfs = nansum(values_fs3)
								vfs = (rfs-rfs_old)/(time-time_old)	
						
							####### supernova shock interacting with density fluctuations
							elif (-0.008*pc< rfs-self.r_dis < 0.006*pc):
								if parallel.procID == 0: print "in the range of smaller structures"
								vfs = (rfs-rfs_old)/(time-time_old)
			
							####### supernova shock interacting with outgoing shock		
							elif (-0.09*pc< self.r_outflow-rfs < 0.07*pc):
								if parallel.procID == 0: print "in the range of outgoing shock"
								vfs = nansum(values_fs2)		
				
							else:	
                                				####### You can use velocity from rdot or from mass flux anything you like.....
								#vfs = (rfs-rfs_old)/(time-time_old)	
								vfs = nansum(values_fs2)
			

						else:
							print "Remanant is too small to classify the interaction"
								
							vfs = nansum(values_fs2)
			 		
					else:	
                                		####### You can use velocity from rdot or from mass flux anything you like.....
						#vfs = (rfs-rfs_old)/(time-time_old)	
						vfs = nansum(values_fs2)



					self.first_tracking += 1
					self.time_old=time
					self.rfs_old = rfs
					self.vfs_old = self.vfs
					if self.structure_found == 0:
						vfs = (2*vfs+self.vfs)/3.
					else:
						vfs = vfs
			#Prepare search on whole grid
			if not forward_shock_found:
				#Combine arrays for full search
				self.comm.Barrier
				self.Mhd_full=self.CombineMhdArrays(self.comm,self.Mhd,self.RRES)


				#restrict range for forward shock
				index_min_f, index_max_f = indexSearch(rfs_old, new_rfs, True, False)

				if isnan(self.vfs) or\
			   	   self.first_tracking < 2 or\
			   	   index_max_f-index_min_f <= 4 or\
			   	   index_max_f > self.RRES*parallel.Nproc or\
			   	   index_min_f:
					#if parallel.procID == 0: print "hdtran: problems with reduced shock-search - searching on whole grid(",index_min_f,index_max_f,")"
					index_min_f = 5
					index_max_f = -1

				#restrict the range of shock search in order to avoid confusion with different outgoing shocks
				if time < 20*3e7:
					index_max_f = int((1.0*pc-self.r_min_global)/self.dr)
				else:
				
					index_max_f = int((0.1*pc*(time-time_old)/yr + self.rfs_old)/self.dr)
			
			
				#Search for forward shock
				rfs = shockFinder(self.Mhd_full,True,False,[1.0,10],index_min_f,index_max_f, time)[0]
				if not isnan(rfs):
				
				
					forward_shock_found = True
					if parallel.procID == 0: print "hdtran: Forward shock found globally - Yeah :-)"
					if not forward_shock_found:
						rfs = rfs_old + self.vfs*(time-time_old)
						if parallel.procID == 0: print "hdtran: Something went wrong already regarding shock finding but fine if you do not see this frequently"
					
			
					if parallel.procID == 0: print "shock radius and incoming shock", rfs, self.r_inflow, (rfs-self.r_inflow)/pc
					if parallel.procID == 0: print "shock radius and CD", rfs, self.r_CD, (rfs-self.r_CD)/pc
					if parallel.procID == 0: print "shock radius and density fluctuations", rfs, self.r_dis, (rfs-self.r_dis)/pc
					if parallel.procID == 0: print "shock radius and outgoing shock", rfs, self.r_outflow, (self.r_outflow-rfs)/pc
					if self.structure_found == 1:
						if (30*self.dr< rfs < 0.09*pc):
							####### supernova shock interacting with incoming shock 
							if (-10*self.dr< rfs-self.r_inflow < 30*self.dr):
								if parallel.procID == 0: print "in the range of incoming shock"
								vfs = (rfs-rfs_old)/(time-time_old)
				
							####### supernova shock interacting with CD
                        				elif (-10*self.dr< rfs-self.r_CD < 30*self.dr):
								if parallel.procID == 0: print "in the range of CD"
								rfs = shockFinder(self.Mhd_full,True,False,[1.0,10],index_min_f,index_max_f, time)[2]
								vfs = (rfs-rfs_old)/(time-time_old)	
					
							####### supernova shock interacting with density fluctuations
							elif (-10*self.dr< rfs-self.r_dis < 30*self.dr):
								if parallel.procID == 0: print "in the range of smaller structures"
								vfs = (rfs-rfs_old)/(time-time_old)
			
							####### supernova shock interacting with outgoing shock		
							elif (-10*self.dr< self.r_outflow-rfs < 30*self.dr):
								if parallel.procID == 0: print "in the range of outgoing shock"
								vfs = shockFinder(self.Mhd_full,True,False,[1.0,10],index_min_f,index_max_f, time)[1]		
				
							else:	
                                			####### You can use velocity from rdot or from mass flux anything you like.....
							#vfs = (rfs-rfs_old)/(time-time_old)	
								vfs = shockFinder(self.Mhd_full,True,False,[1.0,10],index_min_f,index_max_f, time)[1]
							





						elif (rfs >= 0.09*pc):
							####### supernova shock interacting with incoming shock 
							if (-0.09*pc< rfs-self.r_inflow < 0.07*pc):
								if parallel.procID == 0: print "in the range of incoming shock"
								vfs = (rfs-rfs_old)/(time-time_old)
				
							####### supernova shock interacting with CD
                        				elif (-0.01*pc< rfs-self.r_CD < 0.8*pc):
								if parallel.procID == 0: print "in the range of CD"
								rfs = shockFinder(self.Mhd_full,True,False,[1.0,10],index_min_f,index_max_f, time)[2]
								vfs = (rfs-rfs_old)/(time-time_old)	
					
							####### supernova shock interacting with density fluctuations
							elif (-0.008*pc< rfs-self.r_dis < 0.006*pc):
								if parallel.procID == 0: print "in the range of smaller structures"
								vfs = (rfs-rfs_old)/(time-time_old)
			
							####### supernova shock interacting with outgoing shock		
							elif (-0.09*pc< self.r_outflow-rfs < 0.07*pc):
								if parallel.procID == 0: print "in the range of outgoing shock"
								vfs = shockFinder(self.Mhd_full,True,False,[1.0,10],index_min_f,index_max_f, time)[1]		
				
							else:	
                                			####### You can use velocity from rdot or from mass flux anything you like.....
							#vfs = (rfs-rfs_old)/(time-time_old)	
								vfs = shockFinder(self.Mhd_full,True,False,[1.0,10],index_min_f,index_max_f, time)[1]	
						else:
							print "Remanant is too small to classify the interaction"
								
							vfs = shockFinder(self.Mhd_full,True,False,[1.0,10],index_min_f,index_max_f, time)[1]
				
			 
					else:
						vfs = shockFinder(self.Mhd_full,True,False,[1.0,10],index_min_f,index_max_f, time)[1]		
				
					
					
					self.first_tracking += 1
			        	self.rfs_old = rfs
					self.vfs_old = self.vfs
					if self.structure_found == 0:
						vfs = (2*vfs+self.vfs)/3.
					else:
						vfs = vfs
				
			### Search for different structures can be started later according to the profile
			###if time > 500*3.156e7:
		
			self.comm.Barrier
			self.Mhd_full=self.CombineMhdArrays(self.comm,self.Mhd,self.RRES)
					
			if not isnan(rfs):
				### search for structures ahead of supernova shock
				index_min_d = int((rfs+10*self.dr)/self.dr)
				if (10*self.dr < 0.01*pc < 50*self.dr):
					index_max_d = int((rfs+0.01*pc)/self.dr)
				else:
					index_max_d = int((rfs+50*self.dr)/self.dr)
			
				### search for structures behind the supernova shock
				if (rfs <= 40*self.dr):
					index_max_out = int((rfs-0.999*rfs)/self.dr)
					index_min_out = int((rfs-0.95*rfs)/self.dr)
				else:
					if (10*self.dr > 1e-3*pc):
						index_max_out = int((rfs-10*self.dr)/self.dr)
					else:
						index_max_out = int((rfs-1e-3*pc)/self.dr)
					index_min_out = int((rfs-40*self.dr)/self.dr)
			
				
				r_outflow = shockFinder(self.Mhd_full,True,False,[1.3, 8], index_min_out,index_max_out, time)[3]
				dv_outflow = shockFinder(self.Mhd_full,True,False,[1.3, 8], index_min_out,index_max_out, time)[4]
			
				r_inflow, r_CD, r_dis, dv_inflow, dv_CD = HeadOnStructures(self.Mhd_full,[1.3,8],[8,10e3],[4,8],index_min_d,index_max_d, time)
			
			
				### Location of incoming shock
				if not isnan(r_inflow):
					v_inflow = (r_inflow-self.r_inflow_old)/(time-time_old)
				

					if(abs(dv_inflow) < 1e5):
						r_inflow =NaN
					else:
						r_inflow = r_inflow
					
					if not isnan(r_inflow):		
						self.r_inflow = r_inflow
						self.v_inflow = v_inflow
					else:
						self.v_inflow = NaN
				### Location of CD
				if not isnan(r_CD):
				
					v_CD = (r_CD-self.r_CD_old)/(time-time_old)
					
					if(abs(dv_CD) > 1e5):
						r_CD =NaN
					else:
						r_CD = r_CD
					
					if not isnan(r_CD):	
						self.r_CD = r_CD
					


				### Location of outgoing shock
				if not isnan(r_outflow):
					if ((rfs-r_outflow) < (self.rfs_old-self.r_outflow_old)):
						v_outflow = (r_outflow-self.r_outflow_old)/(time-time_old)
					
						if(abs(dv_outflow) < 1e5):
							r_outflow =NaN
						else:
							r_outflow = r_outflow
					
					else:
						r_outflow = NaN
				
					if not isnan(r_outflow):	
						self.r_outflow = r_outflow
						self.v_outflow = v_outflow
					else:
						self.v_outflow = NaN


				if not isnan(self.v_inflow) and (abs(self.v_outflow)>0):
					
					self.time_old=time
					self.r_inflow_old = self.r_inflow
					self.v_inflow_old = self.v_inflow
				
			
					inflow_found = True
					self.structure_found= 1
					if parallel.procID == 0: print "hdtran: incoming shock found"
					
				if not inflow_found:
					if parallel.procID == 0: print "hdtran: incoming shock not found"
					self.v_inflow = NaN
					
				if not isnan(self.r_CD)and(self.r_CD>0):
					
					self.time_old=time
					self.r_CD_old = self.r_CD
				
				
					CD_found = True
					if parallel.procID == 0: print "hdtran: discontinuity found"
					self.structure_found= 1	
				if not CD_found:
					if parallel.procID == 0: print "hdtran discontinuity not found"
				
				

				if not isnan(r_dis) and not inflow_found:
					
					self.time_old=time
					self.r_dis = r_dis
					self.r_dis_old = self.r_dis
				
					fluctuations_found = True
					if parallel.procID == 0: print "hdtran: small density fluctuations found"
					self.structure_found= 1	
				if not fluctuations_found:
					if parallel.procID == 0: print "hdtran: fluctuations not found"
					self.v_dis = NaN
						
				if not isnan(self.v_outflow) and (abs(self.v_outflow)>0):
					
					self.time_old=time
					self.r_outflow_old = self.r_outflow
					self.v_outflow_old = self.v_outflow
					outflow_found = True
					if parallel.procID == 0: print "hdtran: outgoing shock found"
					self.structure_found= 1	

				if not outflow_found:
					if parallel.procID == 0: print "hdtran: outgoing shock not found"
					self.v_outflow = NaN
				
					
		
				if not  CD_found and not outflow_found and not inflow_found and not fluctuations_found:
					self.structure_found = 0 
					if parallel.procID == 0: print "hdtran: structure found", self.structure_found
		
			########SEARCH FOR REVERSE SHOCK SAME AS BEFORE BUT AVOID THE ERROR DURING RESTART#####
			#Search on part of the grid
			#Find index-range for local grid

			#Search grid
			#Find index-range for local grid
			######## For the time being to get rid of problem regarding reverse shock during the restart the simulation at some point
			#index_min_r, index_max_r = indexSearch(rrs_old, new_rrs, False, True)
			index_min_r = 10
			index_max_r = 20
                	#print "DEBUG: index_min_r = ", index_min_r, " index_max_r = ", index_max_r
  		
			#CHeck if shock is not close to local grid-boundaries, calculate shock position
			if (index_min_r > 20) and (index_max_r < self.RRES_local-20):            
				rrs = shockFitting(MHD,False,True,[0, 1],index_min_r,index_max_r, time)[0]
				#vrs = shockvel(MHD,False,True,[0,1],index_min_r,index_max_r, time, time_int, comp_int)
			else:
				rrs = NaN
                       		vrs = 1e8
			#Distribute values between cores:
			size = self.comm.Get_size()
			rank = self.comm.Get_rank()
			sendbuf4 	 = rrs
			#sendbuf4 	 = vrs
			values_rs1 = self.comm.allgather(sendbuf4)
			#values_rs2 = self.comm.allgather(sendbuf4)
			#Count Number of NaNs
			nan_rs1 = sum(where(isnan(values_rs1),1,0))
			#nan_rs2 = sum(where(isnan(values_rs2),1,0))	
			
		
			#Exactly one core should have found the shock
			if nan_rs1 == size-1:
				rrs = nansum(values_rs1)
				#vrs = nansum(values_rs2)
				#vrs = shockvel(MHD,False,True,[0, 0.9],index_min_r,index_max_r, time)	
				vrs = (rrs-rrs_old)/(time-time_old)
				#vrs = vsr
				#vrs = shockFitting(MHD,False,True,[0, 0.9],index_min_r,index_max_r, time)[1]
				#self.first_tracking += 1
				self.time_old=time
				self.rrs_old = rrs
				self.vrs_old = self.vrs
				vrs = (2*vrs+self.vrs)/3.
				reverse_shock_found = True
				if parallel.procID == 0: print "hdtran: Reverse shock found locally - Yeah :-)" 

			#Prepare search on whole grid
			if not reverse_shock_found:
				#Combine arrays for full search
				self.comm.Barrier
				self.Mhd_full=self.CombineMhdArrays(self.comm,self.Mhd,self.RRES)


				#restrict range for reverse shock
				#index_min_r, index_max_r = sort(indexSearch(rrs_old, new_rrs, False, False))
				index_min_r = 10
				index_max_r = 20
				if isnan(self.vrs) or\
			   	self.first_tracking < 2 or\
			   	index_max_r-index_min_r <= 4 or\
			   	index_max_r > self.RRES*parallel.Nproc or\
			   	index_min_r < 0:
				     #if parallel.procID == 0:print "hdtran: problems with reduced shock-search - searching on whole grid(",index_min_r,index_max_r,index_min_r,index_max_r,")"
				     index_min_r = 0
				     index_max_r = -1

				#restrict the range of initial shock search in order to avoid confusion with wind-termination shock
				#40 years and 1pc as hardcoded restrictions - a good (a good what?!?)
				if time < 40*3e7:
					index_max_r = int((1.0*pc-self.r_min_global)/self.dr)
					#Search for forward shock
					if (index_min_r > 20) and (index_max_r < self.RRES-20):            
						rrs = shockFitting(MHD,False,False,[0, 1],index_min_r,index_max_r, time)[0]
						#vrs = shockvel(MHD,False,False,[0, 0.9],index_min_r,index_max_r, time)
					else:
						rrs = NaN
				        #vrs = NaN		
					if not isnan(rrs):
						vrs = (rrs-rrs_old)/(time-time_old)
						#vrs = shockvel(MHD,False,False,[0, 0.9],index_min_r,index_max_r, time)
						#vrs = shockFitting(MHD,False,False,[0, 0.9],index_min_r,index_max_r, time)[1]
		                       		#self.first_tracking += 1
						if not isnan(vrs):
							self.time_old= time
							self.rrs_old = rrs
							self.vrs_old = self.vrs
							vrs = (2*vrs+self.vrs)/3.
							reverse_shock_found = True
							if parallel.procID == 0: print "hdtran: Reverse shock found globally (initally) - Yeah :-)"
					if not reverse_shock_found:
						if parallel.procID == 0: print "reverse shock not found globally (initially)"
						vrs = 1e8


				else:
					if (index_min_r > 20) and (index_max_r < self.RRES-20):            
						rrs = shockFitting(MHD,False,False,[0, 1],index_min_r,index_max_r, time)[0]
						#vrs = shockvel(MHD,False,False,[0,0.9],index_min_r,index_max_r, time)
					else:
						rrs = NaN
						#vrs = NaN
					if not isnan(rrs):
						vrs = (rrs-rrs_old)/(time-time_old)
						#vrs = shockvel(MHD,False,False,[0,1],index_min_r,index_max_r, time, time_int, comp_int)
						#vrs = shockFitting(MHD,False,False,[0, 0.9],index_min_r,index_max_r, time)
						if not isnan(vrs):
		                        	#self.first_tracking += 1
							self.time_old=time
							self.rrs_old = rrs
							self.vrs_old = self.vrs
							vrs = (2*vrs+self.vrs)/3.
							reverse_shock_found = True
							if parallel.procID == 0: print "hdtran: Reverse shock found globally - at least..."
					if not reverse_shock_found:
						if parallel.procID == 0: print "reverse shock not found globally"
						vrs = 1e8

			if not forward_shock_found:
				if parallel.procID == 0:print "hdtran: forward shock not found, exiting code..."
				sys.exit(0)
			return rfs, rrs, vfs, vrs, 1, 0
			
			
		else:
			if parallel.procID == 0:print "hdtran: Shock finder invalid... See you later!"
			sys.exit(0)

	#write shock positions to file
	def Rpc2Rnorm(self,RFS,rShellpc1,rShellpc2,hdDataOut,time):
		f=open(hdDataOut+"/rpc2rnorm","a")
		RSHOCK=RFS
		RNORM1=rShellpc1*pc/RSHOCK
		RNORM2=rShellpc2*pc/RSHOCK
		f.write(str(RSHOCK)+" "+str(RNORM1)+" "+str(RNORM2)+" "+str(float(time))+"\n")
		f.close()

	#finds CD and sets velocity to 0 in the interior, set reverse shock flag to true after use
	def RemoveReverseShock(self,data,grd,dll,RRES,Mhd,rfs,rrs,rho_shock, pre_shock, v_shock):
		r_c   = array(grd[0].x[0:RRES])			#Contains the cell centers of the grid

		#Find the CD and its index
		r_CD_i = argmin(where((Mhd[0]<0.95*rfs)*(Mhd[0]>1.05*rrs),Mhd[1],1e40))	
		r_CD   = Mhd[0][r_CD_i]
		r_TR_i = argmin(where((Mhd[0]>0.7*rfs),Mhd[0],1e40))	
		r_TR   = Mhd[0][r_TR_i]
		r_TR_c = r_TR/self.UNIT_LENGTH

		if parallel.procID == 0:
			print "\tRemoving reverse-shock on node #",parallel.procID,\
			      "\tCD-radius=",r_CD

		#Making transition to Sedov-solution
		#profiles:
		def rho_profile(r):
			return (((3.*r**8)/8.)+(5./8.))*r**(9./2.)*exp((9./16.)*((r**8)-1.))

		def pre_profile(r):
			return (((3.*r**8)/8.)+(5./8.))**(5./3.)*exp((3./8.)*((r**8)-1.))

		def vel_profile(r):
			return 4.0*r*(1.+r**8)/(5.+3.*r**8)

		#values at shock needed
		if parallel.procID == 0:
			print "\tValues at shock: ", rho_shock, v_shock, pre_shock 
	

		RRES = C.c_int.in_dll(dll,"NX1_TOT").value

		for i in range(RRES):
			if r_c[i] < 0.7*rfs/self.UNIT_LENGTH:
				data.Vc[0][0][0][i]	= C.c_double(rho_profile(r_c[i]/(rfs/self.UNIT_LENGTH))*\
										(rho_shock/self.UNIT_DENSITY))
				if r_c[i] < 0.3*rfs/self.UNIT_LENGTH:
					data.Vc[0][0][0][i]	= C.c_double(rho_profile(0.3)*\
										(rho_shock/self.UNIT_DENSITY))
				data.Vc[1][0][0][i]	= C.c_double(Mhd[2][r_TR_i]*vel_profile(r_c[i]/(rfs/self.UNIT_LENGTH))/vel_profile(0.7)/self.UNIT_VELOCITY )

								#C.c_double(vel_profile(r_c[i]/(rfs/self.UNIT_LENGTH))*\
								#(v_shock/self.UNIT_VELOCITY)*(1-exp(10*(r_c[i]-r_TR_c)/r_TR_c))\
								#+data.Vc[1][0][0][i]*exp(10*(r_c[i]-r_TR_c)/r_TR_c))
				data.Vc[2][0][0][i]	= C.c_double(pre_profile(r_c[i]/(rfs/self.UNIT_LENGTH))*\
								(Mhd[3][r_TR_i])/(pre_profile(0.7)*self.UNIT_DENSITY*\
								self.UNIT_VELOCITY**2.0))

		return True

	def SupressOszilations(self,data,RRES,grd):
		r_c   = array(grd[0].x[0:RRES])			#Contains the cell centers of the grid
		
		#get averages
		av_rho = 0.0
		av_vel = 0.0
		av_pre = 0.0
		i0= 10
		i = i0

		flag=True
		while flag:
			if r_c[i]*self.UNIT_LENGTH > 0.3*self.rfs:
				flag = False
			if i+1 > RRES-1:
				flag = False
			av_rho += data.Vc[0][0][0][i]
			av_vel = data.Vc[1][0][0][i]
			av_pre += data.Vc[2][0][0][i]
			i += 1

		if i-i0 > 1:
			av_rho = av_rho/(i-i0)
			av_pre = av_pre/(i-i0)
			for j in range(i):
				data.Vc[0][0][0][j] = C.c_double(av_rho)
				data.Vc[1][0][0][j] = C.c_double(av_vel)*(r_c[j]/r_c[i-1])
				data.Vc[2][0][0][j] = C.c_double(av_pre)

		return

	#Read shock speed drom rpc2rnorm file if
	def ReadRpc2Rnorm(self):
		FileName = self.setpar.HDDATAOUT+"/rpc2rnorm"	
		if parallel.procID == 0: print "hdtran: reading shock-properties from rpc2rnorm-file..." 
		try:
			f=open(FileName,"r")
			RPN=f.readlines()
			f.close()
		except:
			if parallel.procID == 0: print "hdtran: File not found... ",FileName
			sys.exit(0)

		rpcvalues = zeros((2,len(RPN)))
		for i in range(len(RPN)):
			(a,b,c,d) = RPN[i].split()
			#print "bla", float(a),b,c,float(d), type(float(a)),type(RPN[0][i])
			rpcvalues[0][i] = float(a)
			rpcvalues[1][i] = float(d)

		self.rfs = float(rpcvalues[0][-1])
		self.vfs = float(rpcvalues[0][-1]-rpcvalues[0][-2])/float(rpcvalues[1][-1]-rpcvalues[1][-2])/yr
		if parallel.procID == 0: print "hdtran: read values are ",self.rfs, self.vfs		
		return

	#Gets the CR-distribution and calculates the CR-pressure in Grid Variables
	def SetCrSourceTerms(self,N,mesh_rp,npsteps,nrsteps):
		p_p = m_p*c
		#Use global value
		cc  = mesh_rp.cellCenters
		p   = cc.globalValue[1]
		r   = cc.globalValue[0]
		p1  = exp(p.reshape((npsteps,nrsteps)).transpose())
		dp  = p1-roll(p1,1,axis=1)
		dp  = where(dp<0,0,dp)
		
		N1 = N.globalValue.reshape((npsteps,nrsteps))
		N1 = N1.transpose()
		f  = N1*c*p1/(p1**2+1.0)**0.5

		#CR pressure in cgs-units(?) for each bin of r*
		crp = p_p*(f*dp).sum(axis=1)/3.

		rc  = r.reshape((npsteps,nrsteps))[0]
		drc = rc[1]-rc[0]
		rc1 = ((rc-1)**3.+1)
		r   = rc1*self.rfs/self.UNIT_LENGTH 
		J   = 3.0*(rc-1.0)**2+0.25*(drc)**2
		#add energy losses/gains here
		#diffE=crp/self.UNIT_PRESSURE*1/r**2.*(self.Vlhs_FS_I(rc1,self.g_time()*self.UNIT_TIME/yr)/self.UNIT_VELOCITY*r**2.-roll(self.Vlhs_FS_I(rc1,self.g_time()*self.UNIT_TIME/yr)/self.UNIT_VELOCITY*r**2.,1))/(drc*J*self.rfs/self.UNIT_LENGTH)/yr
		#complete loss
		diffE = 1./self.UNIT_PRESSURE*1/r**2.*(crp*self.Vlhs_FS_I(rc1,self.g_time()*self.UNIT_TIME/yr)/self.UNIT_VELOCITY*r**2.-roll(crp*self.Vlhs_FS_I(rc1,self.g_time()*self.UNIT_TIME/yr)/self.UNIT_VELOCITY*r**2.,1))/(drc*J*self.rfs/self.UNIT_LENGTH)/yr - crp/self.UNIT_PRESSURE*1/r**2.*(self.Vlhs_FS_I(rc1,self.g_time()*self.UNIT_TIME/yr)/self.UNIT_VELOCITY*r**2.-roll(self.Vlhs_FS_I(rc1,self.g_time()*self.UNIT_TIME/yr)/self.UNIT_VELOCITY*r**2.,1))/(drc*J*self.rfs/self.UNIT_LENGTH)/yr


		if parallel.procID == 0:
			print "\tEnergy gain: ", max(diffE*self.UNIT_PRESSURE)
		self.CRP   = interp1d(rc1,crp,bounds_error=False, fill_value = 0, kind=2)
		self.diffE = interp1d(rc1,diffE,bounds_error=False, fill_value = 0, kind=2)
		
		r_c   = array(self.grd[0].x[0:self.RRES])
		dr = (r_c[1]-r_c[0])*self.UNIT_LENGTH/self.rfs
		#print "dr=",dr

		crp_int = zeros(len(rc1))
		diffE_int = zeros(len(rc1))

		for i in range(len(crp_int)):
			crp_int[i]   = quad(self.CRP,rc1[i]-dr*3/2.,rc1[i]+dr*3/2.,epsrel=1e-10)[0]/(3*dr)
			diffE_int[i] = quad(self.diffE,rc1[i]-dr*3/2.,rc1[i]+dr*3/2.,epsrel=1e-10)[0]/(3*dr)
			#if isnan(diffE_int[i]):
			#	print "nan in integration", i, rc[i]
			#	diffE_int[i] = 0 

		self.CRP_INT   = interp1d(rc1,crp_int,bounds_error=False, fill_value = 0, kind=2)
		self.DIFFE_INT = interp1d(rc1,diffE_int,bounds_error=False, fill_value = 0)
		#print sum(isnan(diffE_int))
		return

	##The function changes PLUTOs hydro-grid according to different criteria, that can be set in the Parameters-file
	#	
	#The steps include:
	# - calculate regriding feature-position (critical radius, reverse shock, forward shock, ...) on first call
	# - check if feature position advanced by more than old-feature-position*regriding factor
	# - calculate new boundary positions
	# - Create interpolation objects with hydro data
	# - Reinitalize Pluto --> new grid is created and initial conditions assigned
	# - overwrite inital conditions with persistent hydro
	# - check for NaNs
	# - initalize boundary conditions
	#
	# WARNING: at the interface betwenn initial conditions and persistent hydro, jumps might occur.
	# Those can cause small, shock-like features etc.
	##############################################################################################################
	def Regrid(self):
		#Check if its the first call of Regrid()
		if C.c_int.in_dll(self.plutodll,"py_regrid").value == 0:
			if parallel.procID == 0:
				print "hdtran: Regriding...\n\tFirst call to regriding-routine...\n\tYou're brave to use regriding - make sure you know what you're doing"
			
			if self.regrid_flag == "RC":
			#Moves grid along with critical radius of the ejecta
				if parallel.procID == 0:
					print "\tCalculating initial critical radius..."
				#Combine arrays for RC search
				self.comm.Barrier
				self.Mhd_full=self.CombineMhdArrays(self.comm,self.Mhd,self.RRES)	
				#Find critical radius
				slope = (log(self.Mhd_full[1][5:-5])-log(roll(self.Mhd_full[1][5:-5],-5)))/(log(self.Mhd_full[0][5:-5])-log(roll(self.Mhd_full[0][5:-5],-5)))
				index = argmin(where(slope<-5.,0,1))
				self.RC0 = self.Mhd_full[0][index]
				self.VRC = self.Mhd_full[2][index]
				self.RC  = self.RC0
				self.time_RC = self.g_time()*self.UNIT_TIME
				if parallel.procID == 0:
					print "\tInitial critical radius: ", self.RC, "cm"
					print "\tInitial critical velocity: ", self.VRC, "cm/s"

			elif self.regrid_flag == "RCFS":
			#Moves grid along with critical radius of the ejecta and the forward shock --> resolution decreases with time
				if parallel.procID == 0:
					print "\tCalculating initial critical radius..."
				#Combine arrays for RC search
				self.comm.Barrier
				self.Mhd_full=self.CombineMhdArrays(self.comm,self.Mhd,self.RRES)	
				#Find critical radius
				slope = (log(self.Mhd_full[1][5:-5])-log(roll(self.Mhd_full[1][5:-5],-5)))/(log(self.Mhd_full[0][5:-5])-log(roll(self.Mhd_full[0][5:-5],-5)))
				index = argmin(where(slope<-5.,0,1))
				self.RC0 = self.Mhd_full[0][index]
				self.VRC = self.Mhd_full[2][index]
				self.RC  = self.RC0
				self.time_RC = self.g_time()*self.UNIT_TIME
				if parallel.procID == 0:
					print "\tInitial critical radius: ", self.RC, "cm"
					print "\tInitial critical velocity: ", self.VRC, "cm/s"
					print "\tInitial ratio of outer boundary to forwad-shock: ", self.ini.patch_left_node[0][2]*self.UNIT_LENGTH/self.rfs

			else:
				if parallel.procID == 0:
					print "\tUnknown regriding option - come back when you know, what you want ;-)"
				sys.exit(0)
			
			#Trigger regriding flag
			C.c_int.in_dll(self.plutodll,"py_regrid").value = 1
			
			#End first call
			return
		#Regular call to Regrid
		else:
			if self.regrid_flag == "RC":
				if self.VRC*(self.g_time()*self.UNIT_TIME-self.time_RC)+self.RC0 < self.regrid_fact*self.RC:
					return

			if self.regrid_flag == "RCFS":
				if self.VRC*(self.g_time()*self.UNIT_TIME-self.time_RC)+self.RC0 < self.regrid_fact*self.RC and\
				(self.ini.patch_left_node[0][2]*self.UNIT_LENGTH/self.rfs > 1.5 or self.first_tracking < 4):
					return

			else:
				if parallel.procID == 0:
					print "hdtran: Regridding option not supported...exiting"
				sys.exit(0)
	 
			if parallel.procID == 0:
				print "hdtran: Regriding...\n\tOld grid boundaries: xmin=",self.ini.patch_left_node[0][1], "xmax=",self.ini.patch_left_node[0][2]

			#Save current time
			g_time_old = self.g_time()

			#Get MHD-array
			self.comm.Barrier
			self.Mhd_full = self.CombineMhdArrays(self.comm,self.Mhd,self.RRES)

			#Create Interpolation object to restore MHD-data
			#NaN is assigned to undefined areas - should not be triggered
			r_ip   = self.Mhd_full[0][:]
			rho_ip = interp1d(self.Mhd_full[0][:],self.Mhd_full[1][:],bounds_error=False, fill_value = NaN)
			v_ip   = interp1d(self.Mhd_full[0][:],self.Mhd_full[2][:],bounds_error=False, fill_value = NaN)	
			prs_ip = interp1d(self.Mhd_full[0][:],self.Mhd_full[3][:],bounds_error=False, fill_value = NaN) 

			#Update critical radius if RC-option is provided
			if self.regrid_flag == "RC":
				#########Assign new grid-values###############
				#Inner boundary
				self.ini.patch_left_node[0][1] = 0.9*(self.regrid_fact-1.)*self.RC0/self.UNIT_LENGTH+self.ini.patch_left_node[0][1]
				#Outer boundary
				self.ini.patch_left_node[0][2] = 0.9*(self.regrid_fact-1.)*self.RC0/self.UNIT_LENGTH+self.ini.patch_left_node[0][2]
				#Combine arrays for RC search
				self.comm.Barrier
				self.Mhd_full=self.CombineMhdArrays(self.comm,self.Mhd,self.RRES)	
				#Find critical radius
				slope = (log(self.Mhd_full[1][5:-5])-log(roll(self.Mhd_full[1][5:-5],-5)))/(log(self.Mhd_full[0][5:-5])-log(roll(self.Mhd_full[0][5:-5],-5)))
				slope1= (log(self.Mhd_full[1][5:-5])-log(roll(self.Mhd_full[1][5:-5],-5)))/(log(self.Mhd_full[0][5:-5])-log(roll(self.Mhd_full[0][5:-5],-5)))
				index = min(argmin(where(slope < -5., 0, 1)),argmin(where(slope1 > 5., 0, 1)))
				self.RC0 = self.Mhd_full[0][index]
				self.VRC = self.Mhd_full[2][index]
				self.RC  = self.RC0
				self.time_RC = self.g_time()*self.UNIT_TIME
				if parallel.procID == 0:
					print "\tCritical radius: ", self.RC, "cm"
					print "\tCritical velocity: ", self.VRC, "cm/s"
				#Fail safe for inner boundary
				if self.RC0 < self.ini.patch_left_node[0][1]*self.UNIT_LENGTH:
					self.ini.patch_left_node[0][1] = 0.9*self.RC0/self.UNIT_LENGTH

			elif self.regrid_flag == "RCFS":
				#########Assign new grid-values###############
				#Inner boundary
				self.ini.patch_left_node[0][1] = 0.9*(self.regrid_fact-1.)*self.RC0/self.UNIT_LENGTH+self.ini.patch_left_node[0][1]
				#Outer boundary
				out_old = self.ini.patch_left_node[0][2]
				self.ini.patch_left_node[0][2] = self.regrid_fact*self.rfs/self.UNIT_LENGTH
				#Combine arrays for RC search
				self.comm.Barrier
				self.Mhd_full=self.CombineMhdArrays(self.comm,self.Mhd,self.RRES)	
				#Find critical radius
				slope = (log(self.Mhd_full[1][5:-5])-log(roll(self.Mhd_full[1][5:-5],-5)))/(log(self.Mhd_full[0][5:-5])-log(roll(self.Mhd_full[0][5:-5],-5)))
				slope1= (log(self.Mhd_full[1][5:-5])-log(roll(self.Mhd_full[1][5:-5],-5)))/(log(self.Mhd_full[0][5:-5])-log(roll(self.Mhd_full[0][5:-5],-5)))
				index = min(argmin(where(slope < -5., 0, 1)),argmin(where(slope1 > 5., 0, 1)))
				self.RC0 = self.Mhd_full[0][index]
				self.VRC = self.Mhd_full[2][index]
				self.RC  = self.RC0
				self.time_RC = self.g_time()*self.UNIT_TIME
				if parallel.procID == 0:
					print "\tCritical radius: ", self.RC, "cm"
					print "\tCritical velocity: ", self.VRC, "cm/s"
					print "\tRatio of outer boundary to forwad-shock: ", self.ini.patch_left_node[0][2]*self.UNIT_LENGTH/self.rfs
				#Fail safe for inner boundary
				if self.RC0 < self.ini.patch_left_node[0][1]*self.UNIT_LENGTH:
					self.ini.patch_left_node[0][1] = 0.9*self.RC0/self.UNIT_LENGTH
				#Fail safe for outer boundary
				if self.ini.patch_left_node[0][2] < out_old:
					self.ini.patch_left_node[0][2] = out_old
				
			if parallel.procID == 0:
				print "hdtran: New: xmin=",self.ini.patch_left_node[0][1], "xmax=",self.ini.patch_left_node[0][2]

			#Run Initilisation without reading .ini-file (supressed in setup.c)
			if parallel.procID == 0:
				print "hdtran: Reinitializing..." 
			self.Initialize()
			#self.InitTimeSteps()

			#Assign values to data-structure
			if parallel.procID == 0:
				print "hdtran: Interploating between old and new grid..." 
			r_c   = array(self.grd[0].x[0:self.RRES])*self.UNIT_LENGTH
			for i in range(self.RRES):
				#Asign values only, where previous data exsist - the rest is covered by the initial conditions
				if self.grd[0].x[i]*self.UNIT_LENGTH > r_ip[0] and self.grd[0].x[i]*self.UNIT_LENGTH < r_ip[-1]:
					self.data.Vc[0][0][0][i] = C.c_double(rho_ip(r_c[i])/self.UNIT_DENSITY)
					self.data.Vc[1][0][0][i] = C.c_double(v_ip(r_c[i])/self.UNIT_VELOCITY)
					self.data.Vc[2][0][0][i] = C.c_double(prs_ip(r_c[i])/self.UNIT_PRESSURE)
					#self.data.Vc[3][0][0][i] = C.c_double(prs_ip(r_c[i])/self.UNIT_PRESSURE) #NULL_Pointer access when used with pluto_dbl.so

			#Check for NaN
			#NaN values should appear only if something went really wrong
			for i in range(self.RRES):
				if isnan(self.data.Vc[0][0][0][i]):
					print "Node=",parallel.procID," Position=", i, self.grd[0].x[i]*self.UNIT_LENGTH
					sys.exit(0)


			#Call Boundary function from Pluto
			prototypes.Boundary(C.byref(self.data), -1, self.grd)

			#Restore simulation time
			self.reInitPy()
			C.c_double.in_dll(self.plutodll,"g_time").value = g_time_old
				

			if parallel.procID == 0:
				print "hdtran: Regriding done"
			return

	def savitzky_golay(self,y, window_size, order, deriv=0, rate=1):
	 
		try:
			window_size = np.abs(np.int(window_size))
			order = np.abs(np.int(order))
		except ValueError, msg:
			raise ValueError("window_size and order have to be of type int")
		if window_size % 2 != 1 or window_size < 1:
			raise TypeError("window_size size must be a positive odd number")
		if window_size < order + 2:
			raise TypeError("window_size is too small for the polynomials order")
		order_range = range(order+1)
		half_window = (window_size -1) // 2
		# precompute coefficients
		b = np.mat([[k**i for i in order_range] for k in range(-half_window, half_window+1)])
		m = np.linalg.pinv(b).A[deriv] * rate**deriv * factorial(deriv)
		# pad the signal at the extremes with
		# values taken from the signal itself
		firstvals = y[0] - np.abs( y[1:half_window+1][::-1] - y[0] )
		lastvals = y[-1] + np.abs(y[-half_window-1:-1][::-1] - y[-1])
		y = np.concatenate((firstvals, y, lastvals))
		return np.convolve( m[::-1], y, mode='valid')

	def SupressBoundaryErrors(self,data,grd,dll,RRES,Mhd):
		#The function filters all MHD data inside the reverse shock an removes oszillations 
		#that might occur at the interfaces between different computational domains when using 
		#very high resolutions 
		Mhd_new = zeros(shape(Mhd))


		#Smooth the data using a savitzky golay filter
		Mhd_new[0][:] = Mhd[0][:] #
		Mhd_new[1][:] = where((Mhd[0][:] < self.rfs*0.9999)*(Mhd[0][:] > 9.8e18), self.savitzky_golay(Mhd[1][:],45,1),Mhd[1][:])
		Mhd_new[2][:] = where((Mhd[0][:] < self.rfs*0.9999)*(Mhd[0][:] > 9.8e18), self.savitzky_golay(Mhd[2][:],45,1),Mhd[2][:])
		Mhd_new[3][:] = where((Mhd[0][:] < self.rfs*0.9999)*(Mhd[0][:] > 9.8e18), self.savitzky_golay(Mhd[3][:],45,1),Mhd[3][:])
		Mhd_new[4][:] = where((Mhd[0][:] < self.rfs*0.9999)*(Mhd[0][:] > 9.8e18), self.savitzky_golay(Mhd[4][:],45,1),Mhd[4][:])
#		Mhd_new[1][:] = where((Mhd[0][:] < self.rfs*0.9)*(Mhd[0][:] > self.rfs*0.8), 5*Mhd[1][:],Mhd[1][:])
#		Mhd_new[2][:] = where((Mhd[0][:] < self.rfs*0.9)*(Mhd[0][:] > self.rfs*0.8), 5*Mhd[2][:],Mhd[2][:])
#		Mhd_new[3][:] = where((Mhd[0][:] < self.rfs*0.9)*(Mhd[0][:] > self.rfs*0.8), 5*Mhd[3][:],Mhd[3][:])
#		Mhd_new[4][:] = where((Mhd[0][:] < self.rfs*0.9)*(Mhd[0][:] > self.rfs*0.8), 5*Mhd[4][:],Mhd[4][:])

		#Smoothing the boundary
		index = argmax(where(Mhd[0][:] < 9.8e18, Mhd[0][:],0.))
		delta = 200
		#Mhd_new[1][index-delta:index+delta] = Mhd[1][index-delta]+((Mhd[0][index-delta:index+delta]-Mhd[0][index-delta])*((Mhd[1][index+delta])-(Mhd[1][index-delta]))/(Mhd[0][index+delta]-Mhd[0][index-delta]))
		#Mhd_new[2][index-delta:index+delta] = Mhd[2][index-delta]+((Mhd[0][index-delta:index+delta]-Mhd[0][index-delta])*((Mhd[2][index+delta])-(Mhd[2][index-delta]))/(Mhd[0][index+delta]-Mhd[0][index-delta]))
		#Mhd_new[3][index-delta:index+delta] = Mhd[3][index-delta]+((Mhd[0][index-delta:index+delta]-Mhd[0][index-delta])*((Mhd[3][index+delta])-(Mhd[3][index-delta]))/(Mhd[0][index+delta]-Mhd[0][index-delta]))
		#Mhd_new[4][index-delta:index+delta] = Mhd[4][index-delta]+((Mhd[0][index-delta:index+delta]-Mhd[0][index-delta])*((Mhd[4][index+delta])-(Mhd[4][index-delta]))/(Mhd[0][index+delta]-Mhd[0][index-delta]))



		#if parallel.procID == 0:
		#	print "hdtran: Strange things happening here...",self.rfs, Mhd[0][250], Mhd[0][0],Mhd[0][-1]
	#		if any((Mhd[0][:] < self.rfs*0.9999)*(Mhd[0][:] > self.rfs*1.76)) == True:
	#			print "hdtran: Strange things happening here..."

		RRES = C.c_int.in_dll(dll,"NX1_TOT").value

		rho_ip = interp1d(Mhd_new[0][:],Mhd_new[1][:],bounds_error=False, fill_value = NaN)	
		v_ip   = interp1d(Mhd_new[0][:],Mhd_new[2][:],bounds_error=False, fill_value = NaN)	
		prs_ip = interp1d(Mhd_new[0][:],Mhd_new[3][:],bounds_error=False, fill_value = NaN)
		tem_ip = interp1d(Mhd_new[0][:],Mhd_new[4][:],bounds_error=False, fill_value = NaN)

		#Assign values to data-structure
		r_c   = array(self.grd[0].x[0:self.RRES])*self.UNIT_LENGTH
		for i in range(self.RRES):
			self.data.Vc[0][0][0][i] = C.c_double(rho_ip(r_c[i])/self.UNIT_DENSITY)
			self.data.Vc[1][0][0][i] = C.c_double(v_ip(r_c[i])/self.UNIT_VELOCITY)
			self.data.Vc[2][0][0][i] = C.c_double(prs_ip(r_c[i])/self.UNIT_PRESSURE)
		#inner and outer most ghost cells have to be filled
		#Ghost cells are out of the interpolation range --> NaN-values(should stack-4 in a row), replace with interpolation
			
		if isnan(self.data.Vc[0][0][0][0]):
			#print "NaNs(beginning) on node", parallel.procID
			fit1 = polyfit(r_c[4:8],self.data.Vc[0][0][0][4:8],1)
			fit2 = polyfit(r_c[4:8],self.data.Vc[1][0][0][4:8],1)
			fit3 = polyfit(r_c[4:8],self.data.Vc[2][0][0][4:8],1)

			for i in range(4):
				self.data.Vc[0][0][0][i] = C.c_double(fit1[0]*r_c[i]+fit1[1])	
				self.data.Vc[1][0][0][i] = C.c_double(fit2[0]*r_c[i]+fit2[1])
				self.data.Vc[2][0][0][i] = C.c_double(fit3[0]*r_c[i]+fit3[1])

		if isnan(self.data.Vc[0][0][0][self.RRES-1]):
			#print "NaNs(ending) on node", parallel.procID
			fit1= polyfit(r_c[self.RRES-8:self.RRES-4],self.data.Vc[0][0][0][self.RRES-8:self.RRES-4],1)
			fit2= polyfit(r_c[self.RRES-8:self.RRES-4],self.data.Vc[1][0][0][self.RRES-8:self.RRES-4],1)
			fit3= polyfit(r_c[self.RRES-8:self.RRES-4],self.data.Vc[2][0][0][self.RRES-8:self.RRES-4],1)

			for i in range(self.RRES-4,self.RRES):
				self.data.Vc[0][0][0][i] = C.c_double(fit1[0]*r_c[i]+fit1[1])
				self.data.Vc[1][0][0][i] = C.c_double(fit2[0]*r_c[i]+fit2[1])
				self.data.Vc[2][0][0][i] = C.c_double(fit3[0]*r_c[i]+fit3[1])

		if parallel.procID == 0:
			print "hdtran: Boundary oszillations supressed"

		return True

	def GetLogValue(self,t):
		log_description = ["Total flow energy [erg]",\
	  			   "Total thermal energy [erg]"]

		log_values	= zeros(len(log_description))
		#Assign values
		#Flow energy
		log_values[0]	= sum(1/2.*self.Mhd_full[1][:]*self.Mhd_full[2][:]**2.*4.*pi*self.Mhd_full[0][:]**2.*self.dr)
		#Thermal energy
		log_values[1]	= sum(self.Mhd_full[3][:]/(2./3.)*4.*pi*self.Mhd_full[0][:]**2.*self.dr)


		return log_description,log_values
