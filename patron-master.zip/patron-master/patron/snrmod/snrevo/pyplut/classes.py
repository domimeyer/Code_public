######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  classes.py									
# Author: Robert Brose <robert.brose@mail.com>, 2016
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################
#Implementation of the Pluto-code as source of Hydro-data

#v0.0.1: start of development
#v1.0.0: Containing all relevant classes

__version__='1.0.0'

import ctypes as C

#defined in pluto.h
MAX_OUTPUT_TYPES = 11

#Class definitions of Structures used in pluto
class Data(C.Structure):
	_fields_ = 	[("Vc", C.POINTER(C.POINTER(C.POINTER(C.POINTER(C.c_double)))) ),  #/**< The main four-index data array used for cell-centered primitive variables. The index order is Vc[nv][k][j][i], where nv gives the variable index, k,j and i are the locations of the cell in the \f$x_3\f$, \f$x_2\f$ and \f$x_1\f$ direction. */
  			("Uc",C.POINTER(C.POINTER(C.POINTER(C.POINTER(C.c_double)))) ),  #/**< The main four-index data array used for cell-centered conservative variables. The index order is Uc[k][j][i][nv] (nv fast running index) where nv gives the variable index, k,j and i are the  locations of the cell in the \f$x_3\f$, \f$x_2\f$ and \f$x_1\f$ direction. */
  			("Vs",C.POINTER(C.POINTER(C.POINTER(C.POINTER(C.c_double)))) ),  #/**< The main four-index data array used for face-centered staggered magnetic fields. The index order is Vc[nv][k][j][i], where nv gives the variable index, k,j and i are the locations of the cell in the \f$x_3\f$, \f$x_2\f$ and \f$x_1\f$ direction. */
  			("Vuser", C.POINTER(C.POINTER(C.POINTER(C.POINTER(C.c_double)))) ), # /**< Array storing user-defined supplementary variables written to disk. */ 
  			("Ax1", C.POINTER(C.POINTER(C.POINTER(C.c_double))) ), # /**< Vector potential component in the \f$x_1\f$ direction.*/
			("Ax2", C.POINTER(C.POINTER(C.POINTER(C.c_double))) ), # /**< Vector potential component in the \f$x_2\f$ direction.*/
			("Ax3", C.POINTER(C.POINTER(C.POINTER(C.c_double))) ), # /**< Vector potential component in the \f$x_3\f$ direction.*/
  			("J", C.POINTER(C.POINTER(C.POINTER(C.POINTER(C.c_double)))) ),  # /**< Electric current defined as curl(B). */
  			("flag", C.POINTER(C.POINTER(C.POINTER(C.c_ubyte)))), #/**< Pointer to a 3D array setting useful integration flags that are retrieved during integration. */
			#ANOTHER TYPE: c_char_p might have to be used 
#			("Rhs_pluto",C.POINTER(C.POINTER(C.POINTER(C.POINTER(C.c_double)))) ),
  			("fill", C.c_byte * 28)  #/* make the structure a power of two.  */
			]

class State_1D(C.Structure):
	_fields_ = 	[("v", C.POINTER(C.POINTER(C.c_double)) ),   # /**< Cell-centered primitive varables at the base time level,v[i] = \f$ \vec{V}^n_i \f$ . */
			("vL", C.POINTER(C.POINTER(C.c_double)) ),   #/**< Primitive variables to the left of the interface, \f${\rm vL[i]} \equiv \vec{V}_{i,+} = \vec{V}^L_{i+\HALF} \f$. */
			("vR", C.POINTER(C.POINTER(C.c_double)) ),   #/**< Primitive variables to the right of the interface, \f$\mathrm{vR[i]} \equiv \vec{V}^R_{i+\HALF} \f$. */
			("vm", C.POINTER(C.POINTER(C.c_double)) ),   #/**< prim vars at i-1/2 edge, vm[i] = vR(i-1/2)     */
			("vp", C.POINTER(C.POINTER(C.c_double)) ),   #/**< prim vars at i+1/2 edge, vp[i] = vL(i+1/2)     */

			("uL", C.POINTER(C.POINTER(C.c_double)) ),   #/**< same as vL, in conservative vars */
			("uR", C.POINTER(C.POINTER(C.c_double)) ),   #/**< same as vR, in conservative vars */
			("um", C.POINTER(C.POINTER(C.c_double)) ),   #/**< same as vm, in conservative vars */
			("up", C.POINTER(C.POINTER(C.c_double)) ),   #/**< same as vp, in conservative vars */

			("flux", C.POINTER(C.POINTER(C.c_double)) ), #/**< upwind flux computed with the Riemann solver */
			("visc_flux", C.POINTER(C.POINTER(C.c_double)) ), #/**< Viscosity flux             */
			("visc_src", C.POINTER(C.POINTER(C.c_double)) ),  #/**< Viscosity source term      */
			("tc_flux", C.POINTER(C.POINTER(C.c_double)) ),   #/**< Thermal conduction flux    */
			("res_flux", C.POINTER(C.POINTER(C.c_double)) ),  #/**< Resistive flux (current)   */
						  
			("Lp", C.POINTER(C.POINTER(C.POINTER(C.c_double))) ),
			("Rp", C.POINTER(C.POINTER(C.POINTER(C.c_double))) ), #/**< Left and right primitive eigenvectors */
			
			("lambda", C.POINTER(C.POINTER(C.c_double)) ),     #/**< Characteristic speed associated to Lp and Rp */
			("lmax", C.POINTER(C.c_double) ),   #/**< Define the maximum k-characteristic speed over the domain */
			("a2",C.POINTER(C.c_double) ),     #/**< Sound speed squared */ 
			("h", C.POINTER(C.c_double) ),      #/**< Enthalpy. */
			("src", C.POINTER(C.POINTER(C.c_double)) ),     

			("vh", C.POINTER(C.POINTER(C.c_double)) ),      #/**< Primitive    state at n+1/2 (only for one step method) */
			("rhs", C.POINTER(C.POINTER(C.c_double)) ),     #/**< Conservative right hand side */
			("press", C.POINTER(C.c_double) ),    #/**< Upwind pressure term computed with the Riemann solver */
			("bn", C.POINTER(C.c_double) ),       #/**< Face magentic field, bn = bx(i+1/2) */
			("SL", C.POINTER(C.c_double) ),       #/**< Leftmost  velocity in the Riemann fan at i+1/2 */
			("SR", C.POINTER(C.c_double) ),       #/**< Rightmost velocity in the Riemann fan at i+1/2 */
			("flag", C.POINTER(C.c_ubyte)),
			("fill1", C.c_double),
			("fill2", C.c_double)]

class Grid(C.Structure):
	_fields_ = 	[("xi", C.c_double),
			("xf", C.c_double),        		#/**< Leftmost and rightmost point in the local domain. */
			("x", C.POINTER(C.c_double) ),
			("x_glob", C.POINTER(C.c_double) ),   	#/**< Cell geometrical central points. */
			("xr", C.POINTER(C.c_double) ),
			("xr_glob", C.POINTER(C.c_double) ), 	#/**< Cell right interface. */
			("xl", C.POINTER(C.c_double) ),
			("xl_glob", C.POINTER(C.c_double) ), 	#/**< Cell left interface. */
			("dx", C.POINTER(C.c_double) ), 
			("dx_glob", C.POINTER(C.c_double) ),	#/**< Cell size.  */ 
			("xgc", C.POINTER(C.c_double) ),        #/**< Cell volumetric centroid (!= x when geometry != CARTESIAN).  */
			("dV",  C.POINTER(C.c_double) ),        #/**< Cell volume.  */
			("A", C.POINTER(C.c_double) ),          #/**< Right interface area, A[i] = \f$A_{i+\HALF}\f$. */
			("r_1", C.POINTER(C.c_double) ),        #/**< Geometrical factor 1/r.  */
			("ct", C.POINTER(C.c_double) ),         #/**< Geometrical factor cot(theta).  */
			("inv_dx", C.POINTER(C.c_double) ),     #/**<      */
			("inv_dxi", C.POINTER(C.c_double) ),      #/**< inverse of the distance between the center of two cells, inv_dxi = \f$\DS \frac{2}{\Delta x_i + \Delta x_{i+1}}\f$.     */
			("dl_min", C.c_double),      #/**<  minimum cell length (e.g. min[dr, r*dth r*sin(th)*dphi] (GLOBAL DOMAIN).  */
			("np_tot_glob", C.c_int),	#/**< Total number of points in the global domain  (boundaries included). */
			("np_int_glob", C.c_int),	#/**< Total number of points in the global domain  (boundaries excluded). */
			("np_tot",  C.c_int),      #/**< Total number of points in the local domain  (boundaries included). */
			("np_int", C.c_int),      #/**< Total number of points in the local domain  (boundaries excluded). */
			("nghost", C.c_int),      #/**< Number of ghost zones. */
			("lbound", C.c_int),      #/**< When different from zero, it specifies the boundary condition to be applied at leftmost grid side where the physical boundary is located.  Otherwise, it equals zero if the current processor does not touch the leftmost physical boundary. This evantuality (lbound = 0) is possible only in PARALLEL mode.  */ 
			("rbound", C.c_int),      #/**< Same as lbound, but for the right edge of the grid. */
			("gbeg", C.c_int),        #/**< Global start index for the global array. */
			("gend", C.c_int),        #/**< Global end   index for the global array. */
			("beg", C.c_int),         #/**< Global start index for the local array. */
			("end", C.c_int),         #/**< Global end   index for the local array. */
			("lbeg", C.c_int),        #/**< Local start  index for the local array. */
			("lend", C.c_int),        #/**< Local end    index for the local array. */
			("uniform", C.c_int),     #/* = 1 when the grid is cartesian AND uniform everywhere  */
			("nproc", C.c_int),       #/**< number of processors for this grid. */
			("rank_coord", C.c_int),  #/**< Parallel coordinate in a Cartesian topology. */
			("level", C.c_int),       #/**< The current refinement level (chombo only). */
			("fill", C.c_byte *40)   #/* useless, just to make the structure size a power of 2 */
			]

class Riemann_Solver(C.Structure):
	_fields_ = 	[("a",C.POINTER(State_1D)), 
			("b",C.c_int), 
			("c",C.c_int), 
			("d",C.POINTER(C.c_double) ), 
			("e",C.POINTER(Grid))
			]

class Time_Step(C.Structure):
	_fields_ = 	[("cmax", C.POINTER(C.c_double)),   #/**< Maximum signal velocity for hyperbolic eqns. */
			("inv_dta", C.c_double),   #/**< Inverse of advection (hyperbolic) time step, \f$ \lambda/\Delta l\f$.*/
			("inv_dtp", C.c_double),   #/**< Inverse of diffusion (parabolic)  time step \f$ \eta/\Delta l^2\f$. */
			("dt_cool", C.c_double),   #/**< Cooling time step. */
			("cfl", C.c_double),       #/**< Courant number for advection. */
			("cfl_par", C.c_double),   #/**< Courant number for diffusion (STS only). */
			("rmax_par", C.c_double),  
			("Nsts", C.c_int),      #/**< Maximum number of substeps used in STS. */
			("Nrkc", C.c_int),      #/**< Maximum number of substeps used in RKC. */
			("fill", C.c_byte *24)   #/* useless, just to make the structure size a power of 2 */
			]

class Cmd_Line(C.Structure):
	_fields_ = 	[("restart", C.c_int),       
			("h5restart", C.c_int),       
			("nrestart", C.c_int),      
			("makegrid", C.c_int),      
			("write", C.c_int),         
			("maxsteps", C.c_int),
			("jet", C.c_int),  #/* -- follow jet evolution in a given direction -- */
			("parallel_dim", C.c_int*3),
			("nproc", C.c_int*3),  #/* -- user supplied number of processors -- */
			("show_dec", C.c_int), #/* -- show domain decomposition ? -- */
			("xres", C.c_int), #/* -- change the resolution via command line -- */
			("fill", C.c_int) #/* useless, it makes the struct a power of 2 */ 
			]

class Output(C.Structure):
	_fields_ = 	[("type", C.c_int),            #/**< output format (DBL, FLT, ...) - one per output */
			("nvar", C.c_int),            #/**< tot. # of vars that can be written - same for all   */
			("user_outs", C.c_int),
			("cgs", C.c_int),             #/**< when set to 1 saves data in c.g.s units     */
			("nfile", C.c_int),           #/**< current number being saved - one per output */
			("dn", C.c_int),              #/**< step increment between outputs - one per output */
			("stag_var", C.POINTER(C.c_int)),       #/**< centered or staggered variable - same for all   */
			("dump_var", C.POINTER(C.c_int)),       #/**< select vars being written      - one per output */
			("mode", C.c_char*32),        #/**< single or multiple files       - one per output */
			("var_name", C.POINTER(C.POINTER(C.c_char)) ),      #/**< variable names                 - same for all   */
			("ext", C.c_char*8),          #/**< output extension                            */
			("dir", C.c_char*256),       #/**< output directory name                        */
			("dt", C.c_double),           #/**< time increment between outputs   - one per output */
			("dclock", C.c_double),       #/**< time increment in clock hours     - one per output */
			("V",   C.POINTER(C.POINTER( C.POINTER(C.c_double)))*64 ),     #/**< pointer to arrays being written   - same for all  */
			("fill", C.c_char*168)    #/**< useless, just to make the structure size a power of 2 */
			]

class Input(C.Structure):
	_fields_ = 	[("npoint", C.c_int*3),           #/**< Global number of zones in the interior. */
			("lft_bound_side", C.c_int*3),    #/* left  boundary type */
			("rgt_bound_side", C.c_int*3),    #/* right boundary type */
			("grid_is_uniform", C.c_int*3),   #/* = 1 when grid is uniform, 0 otherwise */
			("npatch", C.c_int*5),         #/* number of grid patches  */
			("patch_npoint", (C.c_int*5)*16), #/* number of points per patch */
			("patch_type", (C.c_int*5)*16),             
			("log_freq", C.c_int),            #/* log frequency */
			("user_var", C.c_int),            #/* number of additional user-variables being held in memory and written to disk */
			("anl_dn", C.c_int),              #/*  number of step increment for ANALYSIS */
			("solv_type", C.c_char*64),
			("user_var_name", (C.c_char*128)*128),
			("output_dir", C.c_char*256),
			("output", Output*MAX_OUTPUT_TYPES),  
			("patch_left_node", (C.c_double*5)*16),   #/*  self-expl. */
			("xbeg", C.c_double*3),
			("xend", C.c_double*3),
			("cfl", C.c_double),             #/* hyperbolic cfl number */
			("cfl_max_var", C.c_double),
			("cfl_par", C.c_double),         #/* (STS) parabolic  cfl number */
			("rmax_par", C.c_double),        #/* (STS) max ratio between current time step and parabolic time step */
			("tstop", C.c_double),
			("first_dt", C.c_double),
			("anl_dt", C.c_double),          #/* time step increment for ANALYSIS */
			("aux", C.c_double*32)         #/* we keep aux inside this structure, since in parallel execution it has to be comunicated to all processors  */
			]


#End of Class definitions
############################################################################################################################
