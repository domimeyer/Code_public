######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  prototypes.py									
# Author: Robert Brose <robert.brose@mail.com>, 2016
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################
#Implementation of the Pluto-code as source of Hydro-data

#v0.0.1: start of development
#v1.0.0: containing all relevant prototypes

__version__='1.0.0'

import ctypes as C
from os import getenv
from classes import *
from patron import setup as setup
from fipy.tools import parallel

#DLL = "pluto_vik_DIAS.so"
DLL = "pluto_vik.so"

plutodll = C.CDLL(getenv("PATRONDIR")+"/lib/"+DLL) #replace later with setpar argument

#Function Prototypes#########################################################################################
def Initialize(argc, argv, Data, Input, Grid, Cmd_line):
	Initializepl	    = plutodll.Initialize
	#PointerData	    = C.pointer(Data)
	#Initialize.argtypes = [C.c_int, C.c_char_p, C.POINTER(Data), C.POINTER(Input), C.POINTER(Grid), C.POINTER(Cmd_Line)] #Rising an error because C.POINTER(no_basic_ctype) is not allowed
	Initialize.restype  = None
	Initializepl(argc, argv, Data, Input, Grid, Cmd_line)
	return

def SetSolver(invar):
	SetSolverpl 		= plutodll.SetSolver
	#SetSolverpl.argtypes    = [C.c_char_p]
	SetSolverpl.restype  	= C.POINTER(Riemann_Solver)   #pointer to Riemann_Solver, not working for pure Riemann_Solver
	return SetSolverpl(invar)
	#Riemann_Solver *SetSolver (const char *);
 
def TextTestforStrings(string):
	#Testfunction
	TextTestforStringspl = plutodll.TextTestforStrings
	TextTestforStringspl.restype  	= C.c_char
	return TextTestforStringspl(string)

def Array1D(nx, dsize, c_type):
	Array1Dpl = plutodll.Array1D
	Array1Dpl.restype = C.POINTER(c_type)
	return Array1Dpl(nx, dsize)

def time(inp):
	timepl = plutodll.time
	timepl.restype = C.c_uint64
	return timepl(inp)

def Restart(ini, nrestart, dtype, grid):
	Restartpl = plutodll.Restart
	Restartpl.restype = None
	Restartpl(ini, nrestart, dtype, grid)
	return

def SetJetDomain(Data, int1, int2, Grid):
	SetJetDomainpl = plutodll.SetJetDomain
	SetJetDomainpl.restype = None
	SetJetDomainpl(Data, int1, int2, Grid)

def UnsetJetDomain(Data, int1, Grid):
	UnsetJetDomainpl = plutodll.UnsetJetDomain
	UnsetJetDomainpl.restype = None
	UnsetJetDomainpl(Data, int1, Grid)
	return

def FreeArray4D(Vc):
	FreeArray4Dpl = plutodll.FreeArray4D
	FreeArray4Dpl.restype = None
	FreeArray4Dpl(Vc)
	return

def NextTimeStep(Time_Step, INPUT, Grid):
	NextTimeSteppl = plutodll.NextTimeStep
	NextTimeSteppl.restype = C.c_double
	return NextTimeSteppl(Time_Step, INPUT, Grid)

def Integrate(Data, Riemann_Solver, Time_Step, Grid):
	Integratepl = plutodll.Integrate
	Integratepl.restype = C.c_int
	return Integratepl(Data, Riemann_Solver, Time_Step, Grid)

def CheckForOutput(Data, Input, Grid):
	CheckForOutputpl = plutodll.CheckForOutput
	CheckForOutputpl.restype = None
	CheckForOutputpl(Data, Input, Grid)
	return

def CheckForAnalysis(Data, Input, Grid):
	CheckForAnalysispl = plutodll.CheckForAnalysis
	CheckForAnalysispl.restype = None
	CheckForAnalysispl(Data, Input, Grid)
	return

def AL_Init(argc, argv):
	AL_Initpl = plutodll.AL_Init
	AL_Initpl.restype = C.c_int
	AL_Initpl(argc,argv)
	return

def AL_Finalize():
	AL_Finalizepl = plutodll.AL_Finalize
	AL_Finalizepl.restype = C.c_int
	AL_Finalizepl()
	return


def pyMPI_1(prank):
	pyMPI_1pl = plutodll.pyMPI_1
	pyMPI_1pl.restype = None
	pyMPI_1pl(prank)
	return

def pyMPI_2(n):
	pyMPI_2pl = plutodll.pyMPI_2
	pyMPI_2pl.restype = None
	pyMPI_2pl(n)
	return

def pyMPI_Barrier(n):
	pyMPI_Barrier = plutodll.pyMPI_Barrier
	pyMPI_Barrier.restype = None
	pyMPI_Barrier(n)
	return

def Boundary(Data, idim, Grid):
	Boundarypl = plutodll.Boundary
	Boundarypl.restype = None
	Boundarypl(Data, idim, Grid)
	return

#End of Function Prototypes
############################################################################################################################
