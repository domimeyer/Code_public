######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  functions.py									
# Author: Robert Brose <robert.brose@mail.com>, 2016
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################
#Implementation of the Pluto-code as source of Hydro-data

#v0.0.1: start of development
#v0.1.0: containing all functions for individual execution 

__version__='1.0.0'

import ctypes as C
from os import getenv
from classes import *
from numpy import array
from numpy import zeros
from numpy import savetxt
from numpy import roll
from numpy import argmin
from numpy import argmax
from numpy import exp
from numpy import argmin
from fipy.tools import parallel
from fipy.tools.numerix import where
#segmentation fault error, when: from scipy.optimize import curve fit, fit error when import scipy oO 
from scipy import optimize		
from prototypes import pyMPI_Barrier
import numpy as np

from patron import setup as setup

m_p   = 1.673e-24	
mu    = 13./21.
yr    = 3.156e+7
pc    = 3.08567758e18

DLL = "pluto_vik.so"

plutodll = C.CDLL(getenv("PATRONDIR")+"/lib/"+DLL) #replace later with setpar argument

#get code-dimensions
UNIT_DENSITY  =  C.c_double.in_dll(plutodll,"pyUNIT_DENSITY").value	#Now global, change to self when modularised
UNIT_LENGTH   =  C.c_double.in_dll(plutodll,"pyUNIT_LENGTH").value
UNIT_VELOCITY =  C.c_double.in_dll(plutodll,"pyUNIT_VELOCITY").value
KELVIN	      =  C.c_double.in_dll(plutodll,"pyKELVIN").value
UNIT_TIME     =  UNIT_LENGTH/UNIT_VELOCITY


#Get globals as functions
def NMAX_POINT():
    return C.c_int.in_dll(plutodll, "NMAX_POINT").value

def g_time():
	return C.c_double.in_dll(plutodll,"g_time").value

def g_dt():
	return C.c_double.in_dll(plutodll,"g_dt").value

#End of Globals

#Functions defined in main.c
def TotalExecutionTime(dt):
	days  = int(dt/86400.0)
  	hours = int((dt - 86400.0*days)/3600.0)
  	mins  = int((dt - 86400.0*days - 3600.0*hours)/60.)
  	secs  = int(dt - 86400.0*days - 3600.0*hours - 60.0*mins)
	return str(days) + "d:" + str(hours) + "h:" + str(mins) + "m:" + str(secs) + "s"



#End of function definitions

#Additional Helper Functions
def GetMhdArrays(data, grd, RRES):
	r_c   = array(grd[0].x[0:RRES])			#Contains the cell centers of the grid
	rho_c = array(data.Vc[0][0][0][0:RRES])		#Contains rho at the cell centers
	v_c   = array(data.Vc[1][0][0][0:RRES])		#Contains v at the cell centers
	prs_c =	array(data.Vc[2][0][0][0:RRES])		#Contains prs at the cell centers
	Mhd   = zeros((5,RRES))
	Mhd[0]= r_c*UNIT_LENGTH
	Mhd[1]= rho_c*UNIT_DENSITY #/m_p
	Mhd[2]= v_c*UNIT_VELOCITY
	Mhd[3]= prs_c*UNIT_DENSITY*UNIT_VELOCITY**2.0
	Mhd[4]= prs_c/rho_c*mu*KELVIN
	return Mhd

def ConvTime(t):
	return t*UNIT_TIME/yr


def CombineMhdArrays1(comm,Mhd,RRES):
	#Turned into Allgather, not working yet
	size = comm.Get_size()
	rank = comm.Get_rank()

	sendbuf = Mhd
	recvbuf = np.empty([size, 5,RRES], dtype='d')

	Mhd_full = zeros((5,size*RRES-size*8))
	
	comm.allgather(sendbuf, recvbuf)

	RRES2=RRES-8

	for i in range(size):	
		Mhd_full[0][i*RRES2:i*RRES2+RRES2] = recvbuf[i][0][4:-4]
		Mhd_full[1][i*RRES2:i*RRES2+RRES2] = recvbuf[i][1][4:-4]
		Mhd_full[2][i*RRES2:i*RRES2+RRES2] = recvbuf[i][2][4:-4]
		Mhd_full[3][i*RRES2:i*RRES2+RRES2] = recvbuf[i][3][4:-4]
		Mhd_full[4][i*RRES2:i*RRES2+RRES2] = recvbuf[i][4][4:-4]


#	print "Allgather 1: ",rank, type(Mhd_full), type(Mhd)
#	print "Allgather 2: ", Mhd_full, "\n\n",Mhd
#	print "Allgather 3: ",rank, len(Mhd_full), len(Mhd)

	return Mhd_full

def CombineMhdArrays(comm,Mhd,RRES):
	size = comm.Get_size()
	rank = comm.Get_rank()

	sendbuf = Mhd 

	recvbuf = None
	if rank == 0:
	    recvbuf = np.empty([size, 5,RRES], dtype='d')
	comm.Gather(sendbuf, recvbuf, root=0)

	Mhd_full = zeros((5,size*RRES-size*8))
	RRES2=RRES-8
	if rank==0:
		for i in range(size):	
			Mhd_full[0][i*RRES2:i*RRES2+RRES2] = recvbuf[i][0][4:-4]
			Mhd_full[1][i*RRES2:i*RRES2+RRES2] = recvbuf[i][1][4:-4]
			Mhd_full[2][i*RRES2:i*RRES2+RRES2] = recvbuf[i][2][4:-4]
			Mhd_full[3][i*RRES2:i*RRES2+RRES2] = recvbuf[i][3][4:-4]
			Mhd_full[4][i*RRES2:i*RRES2+RRES2] = recvbuf[i][4][4:-4]

	Mhd_full = comm.bcast(Mhd_full, root=0)
	return Mhd_full
		

def WriteMhd(Mhd,t,timesout2,outFileName):
		for time in timesout2:
			if round(time - t,5) == 0:
				TIME=str(int(time)).zfill(5)
				fname=outFileName+TIME #+"_"+str(parallel.procID)
				if parallel.procID==0:
					print "evoplu: node(",parallel.procID,")writing file ", fname, "\n"
					savetxt(fname, Mhd.transpose(), fmt='%.18e', delimiter=' ', newline='\n', header='r rho v prs T', footer='', comments='# ')	

#returns the next outputtime in Pluto-code units
def NextOutputTime(g_t,timesout2):
	t=g_t*UNIT_TIME/yr
	timenext = min(where(timesout2-t>0,timesout2,1e7))
	return timenext*yr/UNIT_TIME


def logistic2(x,x0,k):
	return (1)/(1+exp(k*(1)*(x-x0)))


#get shock positions and shock speed
def getShockProperties(MHD,rfs_old,rrs_old,time,time_old,setpar):
	#columns: r, rho, v, pre, T
	#Forward Shock
	i=len(MHD[0])-1

	dv = (MHD[2])-(roll(MHD[2],4))
	dv = where(array(range(len(MHD[0])))>10,dv,0)

	i = argmin(dv)

	dv[i-4:i+4] = 0

	j = argmin(dv)

	if j>i:
		a=j
		j=i
		i=a
	if j<=10 or j>= len(MHD[0])-10:
		j=10
	if i<=10 or i>= len(MHD[0])-10:
		i=10

	#print i, j

	rmax1=max(MHD[0][i-5:i+2])
	rmin1=min(MHD[0][i-5:i+2])
	vmax1=max(MHD[2][i-5:i+2])
	vmin1=min(MHD[2][i-5:i+2])
#	print MHD[0][i-5:i+2], "\n", MHD[2][i-5:i+2]
	try:
		popt1,pcov = optimize.curve_fit(logistic2,(MHD[0][i-5:i+2]-rmin1)/(rmax1-rmin1),(MHD[2][i-5:i+2]-vmin1)/(vmax1-vmin1))
		rfs=popt1[0]*(rmax1-rmin1)+rmin1
	except:
		if parallel.procID == 0:
			print "evoplu: Fit for forward shock failed...i=",i
			print "x: ",(MHD[0][i-5:i+2]-rmin1)/(rmax1-rmin1)
			print "v: ",(MHD[2][i-5:i+2]-vmin1)/(vmax1-vmin1)
		rfs = 1.0 #rfs_old

#	print popt1

	rmax2=max(MHD[0][j-5:j+2])
	rmin2=min(MHD[0][j-5:j+2])
	vmax2=max(MHD[2][j-5:j+2])
	vmin2=min(MHD[2][j-5:j+2])
#	print MHD[0][j-5:j+2], "\n", MHD[2][j-5:j+2]	
	try:
		popt2,pcov = optimize.curve_fit(logistic2,(MHD[0][j-5:j+2]-rmin2)/(rmax2-rmin2),(MHD[2][j-5:j+2]-vmin2)/(vmax2-vmin2))
		rrs=popt2[0]*(rmax2-rmin2)+rmin2
	except:
		if parallel.procID == 0:
			print "evoplu: Fit for reverse shock failed...j=",j 
		rrs = 1.0 #rrs_old

#	print popt2
#	print rfs/(rmax1*popt1[0]), rrs/(rmax2*popt2[0])

#	return MHD[0][i+1], MHD[0][j+1],(MHD[0][i+1]-rfs_old)/(time-time_old),(MHD[0][j+1]-rrs_old)/(time-time_old), i, j
	try:
		vfs = (rfs-rfs_old)/(time-time_old)
	except:
		if parallel.procID == 0:
			print "evoplu: Error in front-shock-speed calculation" 
		vfs = 1.0
	try:	
		vrs = (rrs-rrs_old)/(time-time_old)
	except:
		if parallel.procID == 0:
			print "evoplu: Error in reverse-shock-speed calculation" 
		vrs = 1.0

	if parallel.procID == 0:
		if any(setpar.timeslist == round(time/yr,16)):
			#print "FLAG!: ",time/yr
			Rpc2Rnorm(rfs,setpar.rshellpc1,setpar.rshellpc2,setpar.HDDATAOUT,time/yr)

	return rfs, rrs, vfs, vrs, i, j

#write shock positions to file
def Rpc2Rnorm(RFS,rShellpc1,rShellpc2,hdDataOut,time):
	f=open(hdDataOut+"/rpc2rnorm","a")
	RSHOCK=RFS
	RNORM1=rShellpc1*pc/RSHOCK
	RNORM2=rShellpc2*pc/RSHOCK
	f.write(str(RSHOCK)+" "+str(RNORM1)+" "+str(RNORM2)+" "+str(int(time)).zfill(5)+"\n")
	f.close()

#finds CD and sets velocity to 0 in the interior, set reverse shock flag to true after use
def RemoveReverseShock(data,grd,dll,RRES,Mhd,rfs,rrs,rho_shock, pre_shock, v_shock):
	r_c   = array(grd[0].x[0:RRES])			#Contains the cell centers of the grid
#	rho_c = array(data.Vc[0][0][0][0:RRES])		#Contains rho at the cell centers
#	v_c   = array(data.Vc[1][0][0][0:RRES])		#Contains v at the cell centers
#	prs_c =	array(data.Vc[2][0][0][0:RRES])		#Contains prs at the cell centers

#	Mhd[0]= r_c*UNIT_LENGTH
#	Mhd[1]= rho_c*UNIT_DENSITY #/m_p
#	Mhd[2]= v_c*UNIT_VELOCITY
#	Mhd[3]= prs_c*UNIT_DENSITY*UNIT_VELOCITY**2.0
#	Mhd[4]= prs_c/rho_c*mu*KELVIN

	#Find the CD and its index
	r_CD_i = argmin(where((Mhd[0]<0.95*rfs)*(Mhd[0]>1.05*rrs),Mhd[1],1e40))	
	r_CD   = Mhd[0][r_CD_i]
	r_TR_i = argmin(where((Mhd[0]>0.7*rfs),Mhd[0],1e40))	
	r_TR   = Mhd[0][r_TR_i]
	r_TR_c = r_TR/UNIT_LENGTH

	if parallel.procID == 0:
		print "Removing reverse-shock on node #",parallel.procID,\
		      " CD-radius=",r_CD

	#Making transition to Sedov-solution
	#profiles:
	def rho_profile(r):
		return (((3.*r**8)/8.)+(5./8.))*r**(9./2.)*exp((9./16.)*((r**8)-1.))

	def pre_profile(r):
		return (((3.*r**8)/8.)+(5./8.))**(5./3.)*exp((3./8.)*((r**8)-1.))

	def vel_profile(r):
		return 4.0*r*(1.+r**8)/(5.+3.*r**8)

	#values at shock needed
	if parallel.procID == 0:
		print "Values at shock: ", rho_shock, v_shock, pre_shock 
	

	RRES = C.c_int.in_dll(dll,"NX1_TOT").value
#	old 
# 	for i in range(RRES):
#		if r_c[i] < r_CD/UNIT_LENGTH:
#			data.Vc[0][0][0][i]	= C.c_double(Mhd[1][r_CD_i]/UNIT_DENSITY) 
#			data.Vc[1][0][0][i]	= C.c_double(Mhd[2][r_CD_i]/UNIT_VELOCITY*r_c[i]/(Mhd[0][r_CD_i]/UNIT_LENGTH))
#			data.Vc[2][0][0][i]	= C.c_double(Mhd[3][r_CD_i]/(UNIT_DENSITY*UNIT_VELOCITY**2.0)*,
#						  r_c[i]/(Mhd[0][r_CD_i]/UNIT_LENGTH)) 

	for i in range(RRES):
		if r_c[i] < 0.7*rfs/UNIT_LENGTH:
			data.Vc[0][0][0][i]	= C.c_double(rho_profile(r_c[i]/(rfs/UNIT_LENGTH))*(rho_shock/UNIT_DENSITY))
			if r_c[i] < 0.3*rfs/UNIT_LENGTH:
				data.Vc[0][0][0][i]	= C.c_double(rho_profile(0.3)*(rho_shock/UNIT_DENSITY))
			data.Vc[1][0][0][i]	= C.c_double(vel_profile(r_c[i]/(rfs/UNIT_LENGTH))*(v_shock/UNIT_VELOCITY)*(1-exp(10*(r_c[i]-r_TR_c)/r_TR_c))+data.Vc[1][0][0][i]*exp(10*(r_c[i]-r_TR_c)/r_TR_c))
			data.Vc[2][0][0][i]	= C.c_double(pre_profile(r_c[i]/(rfs/UNIT_LENGTH))*(Mhd[3][r_TR_i])/(pre_profile(0.7)*UNIT_DENSITY*UNIT_VELOCITY**2.0))

	return True



