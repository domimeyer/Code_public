######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  evoplu.py									
# Author: Robert Brose <robert.brose@mail.com>, 2016
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################
#Implementation of the Pluto-code as source of Hydro-data

#v0.0.1: start of development

__version__='0.0.1'

import ctypes as C
from os import getenv
from evoplu.classes import *
from numpy import array
from numpy import zeros
from numpy import savetxt
from numpy import roll
from numpy import argmin
from numpy import argmax
from numpy import exp
from fipy.tools import parallel
from fipy.tools.numerix import where
from scipy.optimize import curve_fit
from evoplu.prototypes import pyMPI_Barrier

m_p   = 1.673e-24	
mu    = 13./21.
yr    = 3.156e+7


plutodll = C.CDLL(getenv("PATRONDIR")+"/source/Pluto/pluto.so") #replace later with setpar argument

#get code-dimensions
UNIT_DENSITY  =  C.c_double.in_dll(plutodll,"pyUNIT_DENSITY").value	#Now global, change to self when modularised
UNIT_LENGTH   =  C.c_double.in_dll(plutodll,"pyUNIT_LENGTH").value
UNIT_VELOCITY =  C.c_double.in_dll(plutodll,"pyUNIT_VELOCITY").value
KELVIN	      =  C.c_double.in_dll(plutodll,"pyKELVIN").value
UNIT_TIME  	      =  UNIT_LENGTH/UNIT_VELOCITY


#Get globals as functions
def NMAX_POINT():
    return C.c_int.in_dll(plutodll, "NMAX_POINT").value

def g_time():
	return C.c_double.in_dll(plutodll,"g_time").value

def g_dt():
	return C.c_double.in_dll(plutodll,"g_dt").value

#End of Globals

#Functions defined in main.c
def TotalExecutionTime(dt):
	days  = int(dt/86400.0)
  	hours = int((dt - 86400.0*days)/3600.0)
  	mins  = int((dt - 86400.0*days - 3600.0*hours)/60.)
  	secs  = int(dt - 86400.0*days - 3600.0*hours - 60.0*mins)
	return str(days) + "d:" + str(hours) + "h:" + str(mins) + "m:" + str(secs) + "s"



#End of function definitions

#Additional Helper Functions
def GetMhdArrays(data, grd, RRES):
	r_c   = array(grd[0].x[0:RRES])			#Contains the cell centers of the grid
	rho_c = array(data.Vc[0][0][0][0:RRES])		#Contains rho at the cell centers
	v_c   = array(data.Vc[1][0][0][0:RRES])		#Contains v at the cell centers
	prs_c =	array(data.Vc[2][0][0][0:RRES])		#Contains prs at the cell centers
	Mhd   = zeros((5,RRES))
	Mhd[0]= r_c*UNIT_LENGTH
	Mhd[1]= rho_c*UNIT_DENSITY/m_p
	Mhd[2]= v_c*UNIT_VELOCITY
	Mhd[3]= prs_c*UNIT_DENSITY*UNIT_VELOCITY**2.0
	Mhd[4]= prs_c/rho_c*mu*KELVIN
	return Mhd

import numpy as np

def CombineMhdArrays(comm,Mhd,RRES):
	size = comm.Get_size()
	rank = comm.Get_rank()

	sendbuf = Mhd #np.zeros((5,RRES), dtype='d')
	recvbuf = None
	if rank == 0:
	    recvbuf = np.empty([size, 5,RRES], dtype='d')
	comm.Gather(sendbuf, recvbuf, root=0)
#	if rank == 0:
#	    for i in range(size):
#		assert np.allclose(recvbuf[i,:], i)
	Mhd_full = zeros((5,size*RRES-size*8))
	RRES2=RRES-8
	if rank==0:
		for i in range(size):	
			Mhd_full[0][i*RRES2:i*RRES2+RRES2] = recvbuf[i][0][4:-4]
			Mhd_full[1][i*RRES2:i*RRES2+RRES2] = recvbuf[i][1][4:-4]
			Mhd_full[2][i*RRES2:i*RRES2+RRES2] = recvbuf[i][2][4:-4]
			Mhd_full[3][i*RRES2:i*RRES2+RRES2] = recvbuf[i][3][4:-4]
			Mhd_full[4][i*RRES2:i*RRES2+RRES2] = recvbuf[i][4][4:-4]
		return Mhd_full
	else:
		return zeros((5,size*RRES))

def WriteMhd(Mhd,t,timesout2,outFileName):
		i=0
		for time in timesout2:
			if round(time - t,12) == 0:
				#TIME=str(int(time)).zfill(5)
				#TIME=str(int(round(time,1))).zfill(5)
				TIME=str(where(timesout2==time)[0][0]+1000)	#Number for comaprison with vikram
				fname=outFileName+TIME #+"_"+str(parallel.procID)
				if parallel.procID==0:
					print "evoplu: node(",parallel.procID,")writing file ", fname, "\n"
					savetxt(fname, Mhd.transpose(), fmt='%.18e', delimiter=' ', newline='\n', header='r rho v prs T', footer='', comments='# ')	
				i=int(where(timesout2==time)[0][0])
		if i!=0:
			#print i, timesout2[i]	
			timesout2[i]=0
		return timesout2

#returns the next outputtime in Pluto-code units
def NextOutputTime(g_t,timesout2):
	t=g_t*UNIT_TIME/yr
	timenext = min(where(timesout2-t>0,timesout2,1e7))
	return timenext*yr/UNIT_TIME


def logistic2(x,x0,k):
	return (1)/(1+exp(k*(1)*(x-x0)))


#get shock positions and shock speed
def getShockProperties(MHD,rfs_old,rrs_old,time,time_old):
	#columns: r, rho, v, pre, T
	#Forward Shock
	i=len(MHD[0])-1

	dv = (MHD[2])-(roll(MHD[2],4))
	dv = where(array(range(len(MHD[0])))>10,dv,0)

	i = argmin(dv)

	dv[i-4:i+4] = 0

	j = argmin(dv)

	if j>i:
		a=j
		j=i
		i=a
	if j<=10 or j>= len(MHD[0])-10:
		j=10
	if i<=10 or i>= len(MHD[0])-10:
		i=10

	#print i, j

	rmax1=max(MHD[0][i-5:i+2])
	rmin1=min(MHD[0][i-5:i+2])
	vmax1=max(MHD[2][i-5:i+2])
	vmin1=min(MHD[2][i-5:i+2])
#	print MHD[0][i-5:i+2], "\n", MHD[2][i-5:i+2]
	try:
		popt1,pcov = curve_fit(logistic2,(MHD[0][i-5:i+2]-rmin1)/(rmax1-rmin1),(MHD[2][i-5:i+2]-vmin1)/(vmax1-vmin1))
		rfs=popt1[0]*(rmax1-rmin1)+rmin1
	except:
		print "evoplu: Fit for forward shock failed..." 
		rfs = rfs_old
#	print popt1

	rmax2=max(MHD[0][j-5:j+2])
	rmin2=min(MHD[0][j-5:j+2])
	vmax2=max(MHD[2][j-5:j+2])
	vmin2=min(MHD[2][j-5:j+2])
#	print MHD[0][j-5:j+2], "\n", MHD[2][j-5:j+2]	
	try:
		popt2,pcov = curve_fit(logistic2,(MHD[0][j-5:j+2]-rmin2)/(rmax2-rmin2),(MHD[2][j-5:j+2]-vmin2)/(vmax2-vmin2))
		rrs=popt2[0]*(rmax2-rmin2)+rmin2
	except:
		print "evoplu: Fit for reverse shock failed..." 
		rrs = rrs_old

#	print popt2
#	print rfs/(rmax1*popt1[0]), rrs/(rmax2*popt2[0])

#	return MHD[0][i+1], MHD[0][j+1],(MHD[0][i+1]-rfs_old)/(time-time_old),(MHD[0][j+1]-rrs_old)/(time-time_old), i, j	
	return rfs, rrs,(rfs-rfs_old)/(time-time_old),(rrs-rrs_old)/(time-time_old), i, j

