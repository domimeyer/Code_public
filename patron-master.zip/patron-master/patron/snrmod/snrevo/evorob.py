######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  evorob.py									
# Author: Robert Brose <robert.brose@mail.de>, 2016
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

# this file provides the possibility to define alle MHD-paramerters needed by the code
# by hand to test code/models or produce radiation profiles/spectra for arbitrary
# particle spectra


#v0.0.1: start of development

__version__='0.0.1'

from os import path
from numpy import loadtxt
from numpy import where
from numpy import exp
from numpy import sqrt
from scipy import interpolate
from fipy.tools import parallel
from patron.auxlib.constants import *


#Constants
# m_p  = 1.6726e-24
# c    = 2.998e10
# p_p  = m_p*c						#speed of light in cm/s
# muh  = 1.4
# mue  = 1.17
# mu   = 0.609
# Rg   = 8.3143e7
# pc   = 3.086e18
# q    = 4.8e-10						#electron charge in statcoulons
# yr   = 3.156e+7						#time step (in years) in seconds

mu = mu_ISM
muh = muh_ISM
mue = mue_ISM


global Radius
global SSpeed
global WSpeed
Radius = 1.5*pc
SSpeed = 5000*1e5
WSpeed = 10*1e5


###TO BE SET in snrmhd!###
E      = 1.0e51
n      = 0.4
Rundir = ""
B      = 5e-6*sqrt(3)
###TO BE SET FROM setpar!###
RHO_SHL=n*2.34e-24
R_Z2 = 50*pc
RWSH = 51*pc
	

#Prel,Urel = loadtxt('/afs/ifh.de/user/b/broserob/Desktop/Up.txt',usecols=[0,1],unpack=True)

def Dr(r,p):
	v  = p*c/(1.0+p**2)**0.5						#particle velocity
	rg = (p*p_p*c)/(q*B)
	return 1.0*rg*v/3.0*1e1

#Transition times for radiative stage, implement for compability purposes
def ttr():
	return 1e6;

def tsf():
	return 1e7;

#Shock radius in cm
def R(t):
	return t*SSpeed*yr+1e15

#Shock speed in cm/s
def D(t):
	return SSpeed

#Downstream plasma speed, set to 3/4. shock speed and uniform
def v(r,t):
	prel = 10**(Prel)
	x    = (Dr(1.0,prel)/(Urel*SSpeed)+R(t))/R(t)
	v_u  = interpolate.interp1d(x, (1.0-Urel)*SSpeed, bounds_error=False, fill_value=0)(r)
	#print prel
	v = where( r <= 1.0, (1.0-0.0829982231161404/3.255)*D(t), v_u)
	#if parallel.procID == 0 and True:
	#	print x
	#	print r[77:105]
	#	print v[77:105]
	return v

#Upstream plasma speed is equal to wind speed, set to 1e6 in setpar
V_Z1 = WSpeed

#Downstream gas-density in g/cm^3
def rho(r,t):
	return 3.2572*n*muh*m_p*(R(20)/(R(t)))**2.

#upstream gas density in g/cm^3
def rho_ism(r,t):
	return n*muh*m_p*(R(20)/(R(t)*r))**2.

#Gas-number density in 1/cm^3
def nh(r,t):
	return rho(r,t)/(muh*m_p)

#Electron-number density in 1/cm^3
def ne(r,t):
	return (muh/mue)*nh(r,t)

#Gas pressure
def P(r,t):
	return 0.75*rho_ism(1,t)*D(t)**2

#Gas Temperature
def T(r,t):
	return (P(r,t)*mu)/(rho(r,t)*Rg)

#Module startup function
#R(t), D(t) and wind speed are read from a parameter file. If it is non-exsistant, a standard one will be created	
def SetupParameters():
	return 0
	fname  = str(Rundir)+"/evorob.pars"
	if path.isfile(fname):
		#file exsists, assign values
		pars = open(fname,'r')
		lines = pars.readlines()
		(dummy, Radius) = lines[0].split()
		(dummy, SSpeed) = lines[1].split()
		(dummy, WSpeed) = lines[2].split()
		pars.close()
		return 	
	else:
		#write file
		pars = open(fname,'w')
		pars.write("Shock_radius\t"+str(globals()["Radius"])+"\n")
		pars.write("Shock_speed\t"+str(globals()["SSpeed"])+"\n")		
		pars.write("Wind_speed\t"+str(globals()["WSpeed"])+"\n")
		pars.close()
		return
