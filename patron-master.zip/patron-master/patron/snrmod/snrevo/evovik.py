######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  evovik.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2010 - 2015
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v2.0.0: working with patron modules starting with v.2.2.x and higher
#v2.1.0: version control added
#v2.1.1: faster time interpolations
#v2.2.0: changed shock finding for reverse shock

__version__='2.2.0'

from os import sys
from scipy import interpolate
from numpy import *
from patron.auxlib.smooth import *
from patron.auxlib import extrap as extrapolate
from patron.auxlib.constants import * 

from fipy.tools import parallel

from scipy import optimize

# yr=3.156E+7
# m_p = 1.6726e-24
# mu = 0.609
# muh = 1.4
# mue = 1.17
# Rg = 8.3143e7
# pi = 3.1415926
# M_sun=2.0e33
# pc=3.08e18

mu = mu_ISM
muh = muh_ISM
mue = mue_ISM

E51=1.0					#Explosion energy
M_ch=1.4*M_sun				#type Ia; Characteristic mass

RHO_ISM = 0 				#type Ia; ISM density (g/cm^3); used in rho_ism(r,t,snrevo)
Mdot = 0				#type II; Mass-loss rate (g/s); used in rho_ism(r,t,snrevo)

M_e=0
V_ism=0
tinit=0

#M_e=1.4*M_sun				#type Ia; Ejecta mass
#M_e=5.45*M_sun				#type II; Ejecta mass 

#V_ism = 0.1e7				#type Ia; ISM velocity
#V_wrb = 0.15e9				#type II; WR bubble wind velocity
#V_rsg = 0.3e8				#type II; RSG wind velocity
#R_WRBUB=7.0*pc				#type II; WR bubble radius

#tinit = 1.36986301369863015e-3*yr	#type Ia; Initial time
#tinit = 4.1095890410959e-2*yr		#type II; Initial time




ADJ=4					#adjusting parameter to choose the best 4x jump at the RS; also for tycho6

class SNR:
	def __init__(self,R,Rho,Rhos,P,V,T,ifps,ifs,Rfps,Rfs,Vfs,irps,irs,Rrps,Rrs,Vrs,dVdR,t):
		self.R=R
		self.Rho=Rho
		self.Rhos=Rhos
		self.P=P
		self.V=V
		self.T=T
		self.ifps=ifps
		self.ifs=ifs
		self.Rfps=Rfps
		self.Rfs=Rfs
		self.Vfs=Vfs
		self.irps=irps
		self.irs=irs
		self.Rrps=Rrps
		self.Rrs=Rrs
		self.Vrs=Vrs
		self.dVdR=dVdR
		self.t=t

#		self.IntTime = INTERPOLATION_TIME()

#class INTERPOLATION_TIME:
#	def __init__(self):
#		self.index_t = 0
#		self.time_old = 0
#
#	def tFind(self,time,snrevo):
#		if time == self.time_old:
#			return self.index_t
#		for i in range(len(snrevo)):
#			if snrevo[i].t > time:
#				self.index_t = i-1
#				return self.index_t

def fillsnrstep(fname,t,FLAG,dr_rho):
	try:
		f=open(fname,"r")
		alllines=f.readlines()
		f.close()
	except IOError:
		print "No file found:",fname

	RAD=[]
	RHO=[]
	PRE=[]
	VEL=[]
	TEM=[]
	
	(rad,rho,pre,vel,tem)=alllines[0].split()
	
	RAD.append(0.0)
	RHO.append(float(rho))
	PRE.append(float(pre))
	VEL.append(0.0)
	TEM.append(float(tem))

########LOOKING FOR VMAX AT FORWARD SHOCK######################	
	i=len(alllines)
	vmax=0.
#	Rfs=1.
	(rad,rho,pre,vel,tem)=alllines[i-2].split()
	vcsm=float(vel)
	while i:
		i-=1
		(rad,rho,pre,vel,tem)=alllines[i].split()
		v = float(vel)
		if v >= vmax:
			vmax=v
#			Rfs=float(rad)
		elif (v < vmax) and (v > 1.1*vcsm):
#		elif (v < vmax) and (v > 1.1*V_ism):
			break
	ifps=i+2
################################################################
	
########LOOKING FOR VMAX AT REVERSE SHOCK#######################		
	j=0
	vmax=0.
#	Rrs=1.
	while j!=ifps:
		(rad,rho,pre,vel,tem)=alllines[j].split()
		v = float(vel)
		if v >= vmax:
			vmax=v
#			Rrs=float(rad)
		elif v < vmax:
			break
		j+=1
	irps=j

#################################################################		
		
	for row in alllines:
		(rad,rho,pre,vel,tem)=row.split()
		R=float(rad)
		Rho=float(rho)  
		P=float(pre)
		V=float(vel)
		T=float(tem)
		RAD.append(R)
		RHO.append(Rho)
		PRE.append(P)
		VEL.append(V)
		TEM.append(T)

	LEN=len(RAD)
	dVdR=arange(LEN,dtype=float)
	for i in xrange(0,LEN):
		if i == 0:
			dVdR[i]=(VEL[i+1]-VEL[i])/RAD[i+1]-RAD[i]
		elif i == LEN-1:
			dVdR[i]=(VEL[i]-VEL[i-1])/RAD[i]-RAD[i-1]
		else:
			dVdR[i]=(VEL[i+1]-VEL[i-1])/(RAD[i+1]-RAD[i-1])
	
	ifs=dVdR[ifps-5:LEN-2].argmin()+ifps-5
#	irs=dVdR[0:ifps-60].argmin()	#ifs-30
	irs=dVdR[0:irps+5].argmin()	#ifs-30
	Rfs=RAD[ifs]
	Rrs=RAD[irs]
########POLYNOMIAL STUFF...##########################
#FORWARD SHOCK:
	X0=RAD[ifs]
	XM=RAD[ifs-1]
	XP=RAD[ifs+1]
	dXM=XM-X0
	dXP=XP-X0
	
	DX3=dXP*dXM**2 - dXM*dXP**2
	
	F0=dVdR[ifs]
	FM=dVdR[ifs-1]
	FP=dVdR[ifs+1]
	dFP=FP-F0
	dFM=FM-F0
	
	B=(dFP*dXM**2 - dFM*dXP**2)/DX3
	C=(dFM*dXP - dFP*dXM)/DX3
		
	Rfs=X0-B/(2.0*C)
	#new algorythm
	def logistic2(x,x0,k):
		return (1)/(1+exp(k*(1)*(x-x0)))

	left  = 1
	right = 3
	if ifs < left:
		ifs=abs(ifs)+left
		if parallel.procID == 0: 
			print "evovik: Forward shock position probably not found in file: ",fname
		
#	print ifs, len(RAD)
	rmax1=max(RAD[ifs-left:ifs+right])
	rmin1=min(RAD[ifs-left:ifs+right])
	vmax1=max(VEL[ifs-left:ifs+right])
	vmin1=min(VEL[ifs-left:ifs+right])
		
	x = (array(RAD[ifs-left:ifs+right])-rmin1)/(rmax1-rmin1)
	y = (array(VEL[ifs-left:ifs+right])-vmin1)/(vmax1-vmin1)
	y = where(y > 0.5,1,0)

	try:
		popt1,pcov = optimize.curve_fit(logistic2,x,y)
		Rfs_new=popt1[0]*(rmax1-rmin1)+rmin1
	except:
		if parallel.procID == 0: 
			print "evovik: Fit for reverse shock failed...ifs=",ifs
			print "x: ",(array(RAD[ifs-left:ifs+right])-rmin1)/(rmax1-rmin1)
			print "v: ",(array(VEL[ifs-left:ifs+right])-vmin1)/(vmax1-vmin1)
		Rfs_new = NaN
		#sys.exit(0)

	#if parallel.procID == 0: print "evovik",t, ifs, Rfs, Rfs_new
	#Has to be tested further
	#Rfs = Rfs_new

#REVERSE SHOCK:
	X0=RAD[irs]
	XM=RAD[irs-1]
	XP=RAD[irs+1]
	dXM=XM-X0
	dXP=XP-X0
	
	DX3=dXP*dXM**2 - dXM*dXP**2
	
	F0=dVdR[irs]
	FM=dVdR[irs-1]
	FP=dVdR[irs+1]
	dFP=FP-F0
	dFM=FM-F0
	
	B=(dFP*dXM**2 - dFM*dXP**2)/DX3
	C=(dFM*dXP - dFP*dXM)/DX3
	
	#if C == 0: C = 1 #DEBUGING weird problem. Shouldn't be here in principle	
	Rrs=X0-B/(2.0*C)

	#new algorythm

	left  = 1
	right = 3
	if irs < left: irs=irs+left
#	print irs, len(RAD)
	rmax1=max(RAD[irs-left:irs+right])
	rmin1=min(RAD[irs-left:irs+right])
	vmax1=max(VEL[irs-left:irs+right])
	vmin1=min(VEL[irs-left:irs+right])
		
	x = (array(RAD[irs-left:irs+right])-rmin1)/(rmax1-rmin1)
	y = (array(VEL[irs-left:irs+right])-vmin1)/(vmax1-vmin1)
	y = where(y > 0.5,1,0)

	try:
		popt1,pcov = optimize.curve_fit(logistic2,x,y)
		Rrs_new=popt1[0]*(rmax1-rmin1)+rmin1
	except:
		if parallel.procID == 0: 
			print "evovik: Fit for reverse shock failed...irs=",irs
			print "x: ",(array(RAD[irs-left:irs+right])-rmin1)/(rmax1-rmin1)
			print "v: ",(array(VEL[irs-left:irs+right])-vmin1)/(vmax1-vmin1)
		Rrs_new = NaN
		#sys.exit(0)

	#if parallel.procID == 0: print "evovik",t, irs, Rrs, Rrs_new

	Rrs = Rrs_new

######################################################
	
	Vfs=0.0				#Calculated by fillsnrevoV after all Rfs and Rrs are filled
	Vrs=0.0				#Calculated by fillsnrevoV after all Rfs and Rrs are filled
	
#	Rfs=numpy.float64(RAD[ifs])
	Rfps=numpy.float64(RAD[ifps])
#	Rrs=numpy.float64(RAD[irs])
	Rrps=numpy.float64(RAD[irps])

	if FLAG == "RS":
		Rnorm=Rrps
	elif FLAG == "FS":
		Rnorm=Rfps
		
	RAD=RAD/Rnorm
	RHO=array(RHO)
	PRE=array(PRE)
	VEL=array(VEL)
	TEM=array(TEM)

	#SMOOTHING RHO DATA	
#	dr_rho=0.005
	W1=RAD[1]
	W2=RAD[-1]
	WIN=(LEN-1)*dr_rho/(W2-W1)
	RHOs=smooth(RHO,WIN,'flat')		
	
	snr=SNR(RAD,RHO,RHOs,PRE,VEL,TEM,ifps,ifs,Rfps,Rfs,Vfs,irps,irs,Rrps,Rrs,Vrs,dVdR,t)
	return snr

def fillsnrevoV(snrevo):
	LEN=len(snrevo)

	for i in xrange(0,LEN):
		if i == 0:
			snrevo[i].Vfs=(snrevo[i].Rfs)/(snrevo[i].t*yr)
			snrevo[i].Vrs=(snrevo[i].Rrs)/(snrevo[i].t*yr)
		elif i == 1:
			dt=((snrevo[i+1].t-snrevo[i-1].t)/2.0)*yr
			snrevo[i].Vfs=(snrevo[i+1].Rfs-snrevo[i-1].Rfs)/(2.0*dt)
			snrevo[i].Vrs=(snrevo[i+1].Rrs-snrevo[i-1].Rrs)/(2.0*dt)
		elif i == LEN-2:
			dt=((snrevo[i+1].t-snrevo[i-1].t)/2.0)*yr
			snrevo[i].Vfs=(snrevo[i+1].Rfs-snrevo[i-1].Rfs)/(2.0*dt)
			snrevo[i].Vrs=(snrevo[i+1].Rrs-snrevo[i-1].Rrs)/(2.0*dt)
		elif i == LEN-1:
			dt=((snrevo[i].t-snrevo[i-2].t)/2.0)*yr
			snrevo[i].Vfs=(snrevo[i-2].Rfs-4.0*snrevo[i-1].Rfs+3.0*snrevo[i].Rfs)/(2.0*dt)
			snrevo[i].Vrs=(snrevo[i-2].Rrs-4.0*snrevo[i-1].Rrs+3.0*snrevo[i].Rrs)/(2.0*dt)
		else:
			dt=((snrevo[i+2].t-snrevo[i-2].t)/4.0)*yr
			snrevo[i].Vfs=(snrevo[i-2].Rfs-8.0*snrevo[i-1].Rfs+8.0*snrevo[i+1].Rfs-snrevo[i+2].Rfs)/(12.0*dt)
			snrevo[i].Vrs=(snrevo[i-2].Rrs-8.0*snrevo[i-1].Rrs+8.0*snrevo[i+1].Rrs-snrevo[i+2].Rrs)/(12.0*dt)

def fillsnrevo(dpath,oname,hist,FLAG="FS",dr_rho=0.005):
	try:
		h=open(dpath+"/"+hist,"r")
		hlines=h.readlines()
		h.close()
	except IOError:
		print "No history file found!!!",dpath+"/"+hist
	
	snrevo=[]		
	i=0
	for row in hlines:
		(ext,t,ts)=row.split()
		time=float(t)
		rtime=(time+tinit)/yr
#		if parallel.procID == 0: print "DEBUG:evovik: ", rtime
#		step=float(ts)
		snr=fillsnrstep(dpath+"/"+oname+"."+ext,rtime,FLAG,dr_rho)
		snrevo.append(snr)
#	print "DEBUG:evovik: BLAH"
	fillsnrevoV(snrevo)
	return snrevo


def tFind(time,snr):
#	print "TEST: ", buf_time_old, duf_index_old
#	if size(time) == buf_time_old:
#		if time == buf_time_old:
#			return buf_index_old
	index_t=[]
#	print type(time)
	if size(time) == 1:
		for i in range(len(snr)):
			if snr[i].t > time:
				index_t.append(i-1)
				index_t.append(i)
#				buf_index_old = index_t
#				buf_time_old=time
				return index_t
	else:
		for j in range(len(time)):
			for i in range(len(snr)):
				if snr[i].t > time[j]:
					index_t.append(i-1)
					index_t.append(i)
					break
#		buf_index_old = index_t
#		buf_time_old=time
		return index_t

def R_ED(t,snrevo):
	TSTEPS=len(snrevo)
	index_t = tFind(t,snrevo)
	ti=arange(len(index_t),dtype=float)
	ri=arange(len(index_t),dtype=float)
	j=0
	for i in index_t:
		ti[j]=snrevo[i].t
		ri[j]=snrevo[i].Rfs
		j=j+1

	return interpolate.interp1d(ti,ri)(t)
	

def D_ED(t,snrevo):
	TSTEPS=len(snrevo)
	index_t = tFind(t,snrevo)
	ti=arange(len(index_t),dtype=float)
	di=arange(len(index_t),dtype=float)
	j=0
	for i in index_t:
		ti[j]=snrevo[i].t
		di[j]=snrevo[i].Vfs
		j=j+1
	return interpolate.interp1d(ti,di)(t)

def R_RS(t,snrevo):
	TSTEPS=len(snrevo)
	index_t = tFind(t,snrevo)
	ti=arange(len(index_t),dtype=float)
	ri=arange(len(index_t),dtype=float)
	j=0
	for i in index_t:
		ti[j]=snrevo[i].t
		ri[j]=snrevo[i].Rrs
		j=j+1
	return interpolate.interp1d(ti,ri)(t)

def D_RS(t,snrevo):
	TSTEPS=len(snrevo)
	index_t = tFind(t,snrevo)
	ti=arange(len(index_t),dtype=float)
	di=arange(len(index_t),dtype=float)
	j=0
	for i in index_t:
		ti[j]=snrevo[i].t
		di[j]=snrevo[i].Vrs
		j=j+1
	return interpolate.interp1d(ti,di)(t)

def RFS(t,snrevo):
	return R_ED(t,snrevo)/R_RS(t,snrevo)

def r_in(t,snrevo):
	TSTEPS=len(snrevo)
	index_t = tFind(t,snrevo)
	ti=arange(len(index_t),dtype=float)
	ri=arange(len(index_t),dtype=float)
	j=0
	for i in index_t:
		ti[j]=snrevo[i].t
		ri[j]=snrevo[i].R[2]		#the inner end of grid
		j=j+1
	return interpolate.interp1d(ti,ri)(t)


def v_ed_rs_u(t,snrevo):
	TSTEPS=len(snrevo)
	index_t = tFind(t,snrevo)
	ti=arange(len(index_t),dtype=float)
	di=arange(len(index_t),dtype=float)
	j=0
	for i in index_t:
		ti[j]=snrevo[i].t
		di[j]=snrevo[i].V[snrevo[i].irps]
		j=j+1
	return interpolate.interp1d(ti,di)(t)

def rho_fs_sh(t,snrevo):
	TSTEPS=len(snrevo)	
	index_t = tFind(t,snrevo)
	ti=arange(len(index_t),dtype=float)
	rhoi=arange(len(index_t),dtype=float)
	j=0
	for i in index_t:
		ti[j]=snrevo[i].t
		rhoi[j]=snrevo[i].Rho[snrevo[i].ifps]
		j=j+1
	return interpolate.interp1d(ti,rhoi)(t)

def nh_fs_sh(t,snrevo):
	return rho_fs_sh(t,snrevo)/(muh*m_p)

def rho_fs_u(t,snrevo):	
	TSTEPS=len(snrevo)
	index_t = tFind(t,snrevo)
	ti=arange(len(index_t),dtype=float)
	rhoi=arange(len(index_t),dtype=float)
	j=0
	for i in index_t:
		ti[j]=snrevo[i].t
		rhoi[j]=snrevo[i].Rho[snrevo[i].ifs+5]
		j=j+1
	return interpolate.interp1d(ti,rhoi)(t)

def nh_fs_u(t,snrevo):
	return rho_fs_u(t,snrevo)/(muh*m_p)

def rho_rs_sh(t,snrevo):
	TSTEPS=len(snrevo)
	index_t = tFind(t,snrevo)
	ti=arange(len(index_t),dtype=float)
	rhoi=arange(len(index_t),dtype=float)
	j=0
	for i in index_t:
		ti[j]=snrevo[i].t
		rhoi[j]=snrevo[i].Rho[snrevo[i].irs+ADJ]
		j=j+1
	return interpolate.interp1d(ti,rhoi)(t)
	
def nh_rs_sh(t,snrevo):
	return rho_rs_sh(t,snrevo)/(muh*m_p)

def rho_rs_u(t,snrevo):
	TSTEPS=len(snrevo)
	index_t = tFind(t,snrevo)
	ti=arange(len(index_t),dtype=float)
	rhoi=arange(len(index_t),dtype=float)
	j=0
	for i in index_t:
		ti[j]=snrevo[i].t
		rhoi[j]=snrevo[i].Rho[snrevo[i].irps]
		j=j+1
	return interpolate.interp1d(ti,rhoi)(t)

def nh_rs_u(t,snrevo):
	return rho_rs_u(t,snrevo)/(muh*m_p)

def Pg_fs_sh(t,snrevo):
	TSTEPS=len(snrevo)
	index_t = tFind(t,snrevo)
	ti=arange(len(index_t),dtype=float)
	rhoi=arange(len(index_t),dtype=float)
	j=0
	for i in index_t:
		ti[j]=snrevo[i].t
		rhoi[j]=snrevo[i].P[snrevo[i].ifps]
		j=j+1
	return interpolate.interp1d(ti,rhoi)(t)

def Pg_rs_sh(t,snrevo):
	TSTEPS=len(snrevo)
	index_t = tFind(t,snrevo)
	ti=arange(len(index_t),dtype=float)
	rhoi=arange(len(index_t),dtype=float)
	j=0
	for i in index_t:
		ti[j]=snrevo[i].t
		rhoi[j]=snrevo[i].P[snrevo[i].irs+ADJ]
		j=j+1
	return interpolate.interp1d(ti,rhoi)(t)

def Tg_fs_sh(t,snrevo):
	TSTEPS=len(snrevo)
	index_t = tFind(t,snrevo)
	ti=arange(len(index_t),dtype=float)
	rhoi=arange(len(index_t),dtype=float)
	j=0
	for i in index_t:
		ti[j]=snrevo[i].t
		rhoi[j]=snrevo[i].T[snrevo[i].ifps]
		j=j+1
	return interpolate.interp1d(ti,rhoi)(t)

def Tg_rs_sh(t,snrevo):
	TSTEPS=len(snrevo)
	index_t = tFind(t,snrevo)
	ti=arange(len(index_t),dtype=float)
	rhoi=arange(len(index_t),dtype=float)
	j=0
	for i in index_t:
		ti[j]=snrevo[i].t
		rhoi[j]=snrevo[i].T[snrevo[i].irs+ADJ]
		j=j+1
	return interpolate.interp1d(ti,rhoi)(t)
	
#profiles: 2D interpolations -> improvered version
def rho_ism_T1(r,t,snrevo):			#type Ia
	return RHO_ISM

def rho_ism_T2(r,t,snrevo):			#type II
	R=r*R_ED(t,snrevo)
	rho_z1=Mdot/(V_Z1*4.0*pi*R**2)
	rho_z2=DJZ1Z2*Mdot/(V_Z1*4.0*pi*R_Z1**2)		#DJZ1Z2=4.0 for WR to RSG; = for RSG to MS
	rho_csm=where(R<=R_Z1,rho_z1,rho_z2)
	rho_shl=where(R<=R_Z2,rho_csm,RHO_SHL)
	rho_ism=where(R<=RWSH,rho_shl,RHO_ISM)
	return rho_ism
	
def rho_in_T1(r,t,snrevo):			#type Ia
	v=r*R_ED(t,snrevo)/(t*yr)
	A=7.67*1.0e6*(M_e/M_ch)**(5/2.)*E51**(-3/2.)
	v_e=2.44*1.0e8*E51**(1/2.)*(M_e/M_ch)**(-1/2.)
	return A*exp(-v/v_e)*(t*yr)**(-3)

def rho_in_T2(r,t,snrevo):			#type II
	v=r*R_ED(t,snrevo)/(t*yr)
	n=9
	A=1.47e85
	rho_ep=6.029e-16*float(t)**(-3)			#ejecta plateu part
	rho_pl=A*v**(-n)*(t*yr)**(-3)			#ejecta power-law part
	v_p=4.515e8					
	return where(v<=v_p,rho_ep,rho_pl)

def nh_ism(r,t,snrevo):
	return rho_ism(r,t,snrevo)/(muh*m_p)

def nh_in(r,t,snrevo):
	return rho_in(r,t,snrevo)/(muh*m_p)


def rho_fs(r,t,snrevo):			#based on v_ed, therefore similar array names
	TSTEPS=len(snrevo)
	RSTEPS=len(r)
	index_t = tFind(t,snrevo)
	vrt=arange(RSTEPS,dtype=float)
	ti=arange(len(index_t),dtype=float)
	vti=ndarray(shape=(len(index_t),RSTEPS),dtype=float)
	j=0
	for i in index_t:
		vti[j]=interpolate.interp1d(snrevo[i].R,snrevo[i].Rho, bounds_error=False, fill_value=snrevo[i].Rho[-1])(r)	#to overcome not full data set
		ti[j]=snrevo[i].t
		j=j+1
	vtir=vti.transpose()
	vrt=interpolate.interp1d(ti,vtir)(t)
	rin=r_in(t,snrevo)
	rhoin=rho_in(r,t,snrevo)
	return where(r<=rin,rhoin,vrt) 

def rho_fs2(r,t,snrevo):		   #smoothed density
	TSTEPS=len(snrevo)
	RSTEPS=len(r)
	index_t = tFind(t,snrevo)
	vrt=arange(RSTEPS,dtype=float)
	ti=arange(len(index_t),dtype=float)
	vti=ndarray(shape=(len(index_t),RSTEPS),dtype=float)
	j=0
	for i in index_t:
		vti[j]=interpolate.interp1d(snrevo[i].R,snrevo[i].Rhos, bounds_error=False, fill_value=snrevo[i].Rhos[-1])(r)	#to overcome not full data set
		ti[j]=snrevo[i].t
		j=j+1
	vtir=vti.transpose()
	vrt=interpolate.interp1d(ti,vtir)(t)
	rin=r_in(t,snrevo)
	rhoin=rho_in(r,t,snrevo)
	return where(r<=rin,rhoin,vrt) 

def nh_fs(r,t,snrevo):
	return rho_fs(r,t,snrevo)/(muh*m_p)

def nh_fs2(r,t,snrevo):
	return rho_fs2(r,t,snrevo)/(muh*m_p)

def rho_rs(r,t,snrevo):
	TSTEPS=len(snrevo)
	RSTEPS=len(r)
	index_t = tFind(t,snrevo)
	vrt=arange(RSTEPS,dtype=float)
	ti=arange(len(index_t),dtype=float)
	vti=ndarray(shape=(len(index_t),RSTEPS),dtype=float)
	j=0
	for i in index_t:
		vti[j]=interpolate.interp1d(snrevo[i].R,snrevo[i].Rho, bounds_error=False, fill_value=snrevo[i].Rho[-1])(r)	#to overcome not full data set
		ti[j]=snrevo[i].t
		j=j+1
	vtir=vti.transpose()
	vrt=interpolate.interp1d(ti,vtir)(t)
	rin=r_in(t,snrevo)
	rfs=r*R_RS(t,snrevo)/R_ED(t,snrevo)
	rhoin=rho_in(rfs,t,snrevo)
	return where(r<=rin,rhoin,vrt)

def nh_rs(r,t,snrevo):
	return rho_rs(r,t,snrevo)/(muh*m_p)


def Pg_fs(r,t,snrevo):			#based on v_ed, therefore similar array names
	TSTEPS=len(snrevo)
	RSTEPS=len(r)
	index_t = tFind(t,snrevo)
	vrt=arange(RSTEPS,dtype=float)
	ti=arange(len(index_t),dtype=float)
	vti=ndarray(shape=(len(index_t),RSTEPS),dtype=float)
	j=0
	for i in index_t:
		IRSA=snrevo[i].irs+ADJ
		for ii in xrange(snrevo[i].irps-2,IRSA):
			snrevo[i].P[ii]=snrevo[i].P[IRSA]
			
		vti[j]=interpolate.interp1d(snrevo[i].R,snrevo[i].P, bounds_error=False, fill_value=snrevo[i].P[-1])(r)	#to overcome not full data set
		ti[j]=snrevo[i].t
		j=j+1
	vtir=vti.transpose()
	vrt=interpolate.interp1d(ti,vtir)(t)
	return vrt 	

def v_ed(r,t,snrevo):				#based on v_ed, therefore similar array names
	TSTEPS=len(snrevo)
	RSTEPS=len(r)
	index_t = tFind(t,snrevo)
	vrt=arange(RSTEPS,dtype=float)
	ti=arange(len(index_t),dtype=float)
	vti=ndarray(shape=(len(index_t),RSTEPS),dtype=float)
	j=0
	for i in index_t:
		vti[j]=interpolate.interp1d(snrevo[i].R,snrevo[i].V, bounds_error=False, fill_value=snrevo[i].V[-1])(r)	#to overcome not full data set
		ti[j]=snrevo[i].t
		j=j+1
	vtir=vti.transpose()
	vrt=interpolate.interp1d(ti,vtir)(t)
	return vrt

def v_ed_WoS(r,t,snrevo):			#WITHOUT RS
	TSTEPS=len(snrevo)
	RSTEPS=len(r)
	index_t = tFind(t,snrevo)
	vrt=arange(RSTEPS,dtype=float)
	ti=arange(len(index_t),dtype=float)
	vti=ndarray(shape=(len(index_t),RSTEPS),dtype=float)
	j=0
	for i in index_t:
		RPFS=snrevo[i].ifps
		RRSH=snrevo[i].irs
		RMIN=RRSH+ADJ+1
		RMAX=len(snrevo[i].R)
		R=copy(snrevo[i].R[0:RMAX])
		V=copy(snrevo[i].V[0:RMAX])
		
		R1=copy(snrevo[i].R[0:RMIN])
		V1=copy(snrevo[i].V[0:RMIN])
		
	#	R2=arange(100,dtype=float)
	#	V2=arange(100,dtype=float)
		
		R2=arange(2,dtype=float)
		R2[0]=snrevo[i].R[RMIN]
		R2[1]=snrevo[i].R[RPFS]
		
		V2=arange(2,dtype=float)
		V2[0]=snrevo[i].V[RMIN]
		V2[1]=snrevo[i].V[RPFS]
		
		R3=copy(snrevo[i].R[RPFS:RMAX])
		V3=copy(snrevo[i].V[RPFS:RMAX])
		
		
	#	for ii in xrange(0,100):
	#		R2[ii]=snrevo[i].R[RMIN]+((ii-0)/float(99-0))*(snrevo[i].R[RPFS]-snrevo[i].R[RMIN])
	#		V2[ii]=snrevo[i].V[RMIN]+((ii-0)/float(99-0))*(snrevo[i].V[RPFS]-snrevo[i].V[RMIN])
		
		R=concatenate((R1,R2,R3))
		V=concatenate((V1,V2,V3))
		
		vti[j]=interpolate.interp1d(R,V, bounds_error=False, fill_value=V[-1])(r)	#to overcome not full data set
		ti[j]=snrevo[i].t
		j=j+1
	vtir=vti.transpose()
	vrt=interpolate.interp1d(ti,vtir)(t)
	return vrt


def v_ed_fs_u_T1(r,t,snrevo):
	return V_ism

def v_ed_fs_u_T2(r,t,snrevo):
	R=r*R_ED(t,snrevo)
	return where(R<R_Z1,V_Z1,V_Z2)

def v_ed_rs_d(r,t,snrevo):
	TSTEPS=len(snrevo)
	RSTEPS=len(r)
	index_t = tFind(t,snrevo)
	vrt=arange(RSTEPS,dtype=float)
	ti=arange(len(index_t),dtype=float)
	vti=ndarray(shape=(len(index_t),RSTEPS),dtype=float)
	j=0		
	for i in index_t:
		RMIN=snrevo[i].irps
		RRSH=snrevo[i].irs
		RMAX=len(snrevo[i].R)
		R=copy(snrevo[i].R[RMIN:RMAX])
		V=copy(snrevo[i].V[RMIN:RMAX])
		for ii in xrange(0,RRSH+1-RMIN+1):
		#	V[ii]=(snrevo[i].V[RRSH+ADJ]+snrevo[i].V[RRSH+ADJ+1])/2.		#!!!wrbub!!!
			V[ii]=(snrevo[i].V[RRSH+ADJ])						#!!!TYCHO6!!!
		
		vti[j]=interpolate.interp1d(R,V, bounds_error=False, fill_value=V[-1])(r)	#to overcome not full data set
		ti[j]=snrevo[i].t
		j=j+1
	vtir=vti.transpose()
	vrt=interpolate.interp1d(ti,vtir)(t)
	vfsup=v_ed_fs_u(r,t,snrevo)
	rfs=RFS(t,snrevo)
	return where(r<=rfs,vrt,vfsup)
	
def Tg_fs(r,t,snrevo):			#based on v_ed, therefore similar array names
	TSTEPS=len(snrevo)
	RSTEPS=len(r)
	index_t = tFind(t,snrevo)
	vrt=arange(RSTEPS,dtype=float)
	ti=arange(len(index_t),dtype=float)
	vti=ndarray(shape=(len(index_t),RSTEPS),dtype=float)
	j=0
	for i in index_t:
		vti[j]=interpolate.interp1d(snrevo[i].R,snrevo[i].T, bounds_error=False, fill_value=snrevo[i].T[-1])(r)	#to overcome not full data set
		ti[j]=snrevo[i].t
		j=j+1
	vtir=vti.transpose()
	vrt=interpolate.interp1d(ti,vtir)(t)
	return vrt 	






###################################################################################################################
#from fillsnrstep
	#SMOOTHING VELOCITY DATA#################################
	#put after:VEL.append(V)				#
	#	if len(VEL) == i+1:				#
	#		LV=len(VEL)				#
	#		tmpVEL=arange(LV,dtype=float)		#
	#		for ii in xrange(0,LV):			#
	#			tmpVEL[ii]=VEL[ii]		#
	#		newVEL=smooth(tmpVEL,window_len=501)	#
	#		VEL=[]					#
	#		VEL.append(0)				#
	#		for ii in xrange(0,LV):			#
	#			VEL.append(newVEL[ii])		#
	#put before:TEM.append(T)		 		#
	#########################################################

#from fillsnrstep
########EXTRAPOLATION...#################################################
#after everything is filled in fillsnrstep, just before snr=SNR...	#
#however, because of strong variations in V doesn't help in sharpening	#
#	INSUBR=RAD[ifps-9:ifps+1]					#
#	INSUBV=VEL[ifps-9:ifps+1]					#
#	EXTRAD=RAD[ifps+1:ifs+1]					#
#	f_i=interpolate.interp1d(INSUBR,INSUBV)				#
#	f_e=extrapolate.extrap1d(f_i)					#
#	for ii in xrange(ifps+1,ifs+1):					#
#		VEL[ii]=f_e(EXTRAD)[ii-(ifps+1)]			#
#########################################################################
