######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  evotru.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2010 - 2015
# 	  Robert Brose <robert.brose@mail.de>, 2016
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v2.0.0: only forward shock evolution (radius and velocity) for N=7 and S=0 or S=2 is implemented. plasma velocity profile downstream is assumed linear
#v2.1.0: contains additional functions and corrections (floating point, etc.)
#v2.2.0: version control added
#v2.2.1: s=0: extended to ST-phase 

__version__='2.2.1'

from numpy import *
from patron.auxlib.constants import *

#global rho_s
#global R_FSstar
#global V_FSstar
#global R_RSstar
#global V_RSstar
#global R_STstar
#global V_SRstar


# yr   = 3.156e7
# km   = 1.0e5
# pc   = 3.086e18
# m_p  = 1.6726e-24
# mu   = 0.609
# muh  = 1.4
# mue  = 1.17
# Rg   = 8.3143e7

mu = mu_ISM
muh = muh_ISM
mue = mue_ISM


# M_sun = 2.0e33

###TO BE SET in snrmhd!###
E    = 1.0e51
n    = 0.4

###TO BE SET FROM setpar!###
#N    = 7						#index of a powerlaw density distribution in SN envelope
#S    = 2						#index of a powerlaw density distribution in CSM
#M_ej = 5.45*M_sun					#ejecta mass
#Mdot = 6.0e21						#mass-loss rate
#V_Z1 = 4.5e6						#stellar wind velocity in zone 1 (closer to the star)
#RHO_SHL=n*2.34e-24
#R_Z2=50.0
#RWSH=51.0
############################

def faket(t):               # This is introduced to avoid devision by zero in analytic solutions 
        return (t + 1e-16)  

def rho0():
	return muh*n*m_p


def rho_s_S0():
	return rho0()

def rho_s_S2():
	return Mdot/(4.0*pi*V_Z1)

#characteristic values used for scaling to get dimensionless (star) parameters
#radius
def Rch():
	return (M_ej/rho_s())**(1.0/(3.0-S))

#time
def tch():
	return E**(-1/2.)*M_ej**((5.0-S)/(2.0*(3.0-S)))*rho_s()**(-1.0/(3.0-S))		

#velocity
def Vch():
	return Rch()/tch()

#mass
def Mch():
	return M_ej

def tstar(t):
	return t*yr/tch()
#################################################################################

###S=0###############
def R_FSstarS0N07(t):
	if tstar(t) < 0.732:
		return 1.060*tstar(t)**(4./7.)
	else:
		return (1.42*tstar(t)-0.312)**(2./5.)

def V_FSstarS0N07(t):
	if tstar(t) < 0.732:
		return 0.606*tstar(t)**(-3./7.)
	else: 
		return 0.569*(1.42*tstar(t)-0.312)**(-3./5.)

def R_RSstarS0N07(t):
	if tstar(t) < 0.363:
		return 0.841*tstar(t)**(4./7.)
	elif tstar(t) >= 0.363 and tstar(t) < 2.1:
		return tstar(t)*(0.815-0.116*tstar(t)-0.511*log(tstar(t)))
	else:
		return "Nan" 

def V_RSstarS0N07(t):
	if tstar(t) < 0.363:
		return 0.361*tstar(t)**(-3./7.)
	elif tstar(t) >= 0.363 and tstar(t) < 2.1:
		return 0.511+0.116*tstar(t)
	else:
		return "Nan" 

def R_STstarS0N07(t):
	return (1.42*tstar(t)-0.312)**(2./5.)

def V_STstarS0N07(t):
	return 0.569*(1.42*tstar(t)-0.312)**(-3./5.)
#####################

###S=2###############
def R_FSstarS2N07(t):
	return 1.190*tstar(t)**(4./5.)

def V_FSstarS2N07(t):
	return 0.954*tstar(t)**(-1./5.)

def R_RSstarS2N07(t):
	return 0.890*tstar(t)**(4./5.)

def V_RSstarS2N07(t):
	return 0.178*tstar(t)**(-1./5.)
#####################

#######################################################
def R_FS(t):
        tt = faket(t)
	return R_FSstar(tt)*Rch()
	
def D_FS(t):
        tt = faket(t)
	return V_FSstar(tt)*Vch()

def R_RS(t):
	return R_RSstar(t)*Rch()
	
def D_RS(t):
	return R_RS(t)/(t*yr)-V_RSstar(t)*Vch()


def rho_profile(r,c):
	return (r**(-3)*(c**3-0.25) + 3.0*(log(1.0/c)-0.25))/(3.0*log(1.0/c) + c**3 - 1.0)
	
def rho_csm(r,t):
	R=r*R_FS(t)
	return Mdot/(V_Z1*4.0*pi*R**2)

def rho_ism(r,t):
	r1=R_Z2/R_FS(t)
	r2=RWSH/R_FS(t)
	return where((r>=r1)&(r<=r2),RHO_SHL,rho_csm(r,t))

def rho(r,t):
	RCD=(R_RS(t)+0.5*(R_FS(t)-R_RS(t)))/R_FS(t)
	rho_ave=3.0*M_ej/(4.0*pi*(RCD*R_FS(t))**3)			#should be power-law plus plateu
	return where((r>=RCD)&(r<=1.0),4.0*rho_profile(r,RCD)*rho_ism(1,t),rho_ave)

def nh(r,t):
	return rho(r,t)/(muh*m_p)

def ne(r,t):
	return (muh/mue)*nh(r,t)

def P_profile(r):
	return 1.0

def P(r,t):
	RRS=R_RS(t)/R_FS(t)
	return where((r>RRS)&(r<=1.0),0.75*P_profile(r)*rho_ism(1,t)*D(t)**2,0.0)

def T(r,t):
	return (P(r,t)*mu)/(rho(r,t)*Rg)

def v_profile(r):
	return r

def v(r,t):
	return where(r<=1.0,0.75*v_profile(r)*D(t)+0.25*V_Z1,V_Z1)

def ttr():
	return 1e6;

def tsf():
	return 1e7;
	
######################################################################

def SetupParameters():
	global rho_s
	global R_FSstar
	global V_FSstar
	global R_RSstar
	global V_RSstar
	global R_STstar
	global V_STstar
	if   S == 0:
		rho_s = rho_s_S0				#ISM density, or CSM density normalization constant
		if   N == 7:
			R_FSstar= R_FSstarS0N07
			V_FSstar= V_FSstarS0N07
			R_RSstar= R_RSstarS0N07
			V_RSstar= V_RSstarS0N07
			R_STstar= R_STstarS0N07
			V_STstar= V_STstarS0N07
	elif S == 2:
		rho_s = rho_s_S2				#ISM density, or CSM density normalization constant
		if   N == 7:
			R_FSstar= R_FSstarS2N07
			V_FSstar= V_FSstarS2N07
			R_RSstar= R_RSstarS2N07
			V_RSstar= V_RSstarS2N07

R=R_FS
D=D_FS
