######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  evocox.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2010 - 2015
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v2.0.0: adjusted to be used in patron as a module. now includes a(r) 
#v2.1.0: contains some additional functions
#v2.2.0: version control added

__version__='2.2.0'

from numpy import *
from patron.auxlib.constants import *

# yr    = 3.156e7
# km    = 1e5
# pc    = 3.086e18
# m_p   = 1.6726e-24
# mu    = 0.609
# muh   = 1.4
# mue   = 1.17
# Rg    = 8.3143e7

mu = mu_ISM
muh = muh_ISM
mue = mue_ISM

alpha = 0.4936

###TO BE SET in snrmhd!###
E = 1.0e51
n = 1.0

###TO BE SET FROM setpar!###
RHO_SHL=n*2.34e-24
R_Z2 = 50*pc
RWSH = 51*pc
V_Z1 = 1e6
############################
def SetupParameters():
	return 0

def rho0():
	return muh*n*m_p

def faket(t):               # This is introduced to avoid devision by zero in analytic solutions 
        return (t + 1e-16)  

def R(t):
	time = faket(t)*yr
	return (E/(alpha*rho0()))**(1/5.)*time**(2./5.)

def D(t):
#	if t >= 750: C=0.5
#	else: C = 1.0
	time =faket(t)*yr
	return (2./5.)*(E/(alpha*rho0()))**(1./5.)*time**(-3./5.)

def rho_profile(r):
	return (((3.*r**8)/8.)+(5./8.))*r**(9./2.)*exp((9./16.)*((r**8)-1.))

def rho_ism(r,t):
	r1=R_Z2/R(t)
	r2=RWSH/R(t)
	return where((r>=r1)&(r<=r2),RHO_SHL,rho0())

def rho(r,t):
	return where(r<=1.0,4.0*rho_profile(r)*rho0(),0.0)

def nh(r,t):
	return rho(r,t)/(muh*m_p)

def ne(r,t):
	return (muh/mue)*nh(r,t)

def P_profile(r):
	return (((3.*r**8)/8.)+(5./8.))**(5./3.)*exp((3./8.)*((r**8)-1.))

def P(r,t):
	return 0.75*P_profile(r)*rho0()*D(t)**2

def T(r,t):
	return (P(r,t)*mu)/(rho(r,t)*Rg)

def v_profile(r):
	return 4.0*r*(1.+r**8)/(5.+3.*r**8)

def v(r,t):
#	if t >= 750: C=2.0
#	else: C = 1.0
	return where(r<=1.0,0.75*v_profile(r)*D(t)+0.25*V_Z1,V_Z1)

def a(r):
	return r**(5./2.)*exp((3./16.)*((r**8)-1.))

def ttr():
	return 1e6;

def tsf():
	return 1e7;
