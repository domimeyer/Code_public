# this is the dummiest dummy ever

class TransportEquation:
	def __init__(self):
		self.CR_feedback = 0
            	self.Mhd_full = 0
        def DoTimeIntervall(self, tstart, tend):
                return
        def ReadRpc2Rnorm(self):
                return
        def SetCrSourceTerms(self, a,b,c,d):
                return

        def EndSimulation(self): 
  	        return
        def WriteMhd(self, a,b,c,d):
                return
        def ConvTime(self, a):
                return 0
        def g_time(self):
                return

	def GetLogValue(self,t):
		return [],[]            
