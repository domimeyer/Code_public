######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  snrmap.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2007 - 2015
# 	  Robert Brose 	<robert.brose@mail.com>, 2016 - 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v2.0.0: skipped. parameters module setpar v.1.0.0 introduction will not be supported
#v2.1.0: skipped. running with old data structure and parameters module will not be supported
#v2.2.0: introducing main function to allow import as a module alone with independent run, parameters changed to work with global setpar module compliant with patron 2.2.x and higher
#v2.3.0: re-arranging map related tasks into a function dealing with them
#v2.4.0: version control added, sp changed to patron.setpar
#	 Changed for use with setup-routine
#v2.4.1: Reached compability for SL7-setup


__version__='2.4.1'

import patron.setpar

from numpy import *
import weave
from scipy.ndimage.interpolation import rotate
from scipy.ndimage.interpolation import zoom
from scipy import interpolate
from os import getenv

from astropy.io import fits
import warnings
warnings.filterwarnings('ignore', category=UserWarning, append=True)

pc=3.08e18
ORDER=1
global SNR,Bf,N,V,A,R,MF1DTOT,MF2DRAD,MF2DTAN,RCR,ECR,NCR

def B(r,MFR,MFB):
	B=interpolate.interp1d(MFR,MFB, bounds_error=False, fill_value=0.0)(r)
	return B

def ni(r,HDR,HDN):
	n=interpolate.interp1d(HDR,HDN, bounds_error=False, fill_value=0.0)(r)
	return n

def Tg(r,HDR,HDT):
	Tg=interpolate.interp1d(HDR,HDT, bounds_error=False, fill_value=0.0)(r)
	return Tg

def FillCell1D_TH(i,t,E,HDR,HDN,HDT):
	dr  = 1.0/N
	r   = (i+0.5)*dr	
	T_g = Tg(array([r]),HDR,HDT)[0]
	ne  = ni(array([r]),HDR,HDN)[0]*1.2
	return patron.setpar.thermx.F_atE_vol_intTH(E,ne,T_g,V,A)

def FillCell1D_SY(i,t,E,HDR,HDN,HDT):
	dr = 1.0/N
	r  = (i+0.5)*dr	
	MF = Bf*MF1DTOT[i]								#SNR.B(array([r]),t)[0]
	patron.setpar.synchr.spe=patron.setpar.psread.spe_dif(r,dr,(RCR,ECR,NCR))
	return patron.setpar.synchr.F_atE_vol_intSY(E,MF,V,A)

def FillCell2D_SY(i,j,t,E):
	dr = 1.0/N
	mc = n										#central cell called mc to avoid confusion with n which is the size of 1D array to be rotated
	r  = sqrt((mc-(i+0.5))**2+(j+0.5)**2)*dr
	if r >= (n-0.5)*dr:
		return 0.0
	else:
		MFr=MF2DRAD[i][j]
		MFt=MF2DTAN[i][j]*1.4142
		
		COSA=(mc-(i+0.5))*dr/r
		SINA=(j+0.5)*dr/r
#		alpha=math.atan2((j+0.5),(mc-(i+0.5)))
		
		ksi=pi/4.
		COSK=cos(ksi)
		SINK=sin(ksi)
		
		MF=sqrt(MFt**2*SINK**2*COSA**2 + MFt**2*COSK**2 + MFr**2*SINA**2 + 2.0*MFt*MFr*SINK*SINA*COSA)
		
		patron.setpar.synchr.spe=patron.setpar.psread.spe_dif(r,dr,(RCR,ECR,NCR))				
		return patron.setpar.synchr.F_atE_vol_intSY(E,MF,V,A)


def FillCell1D_IC(i,t,E,HDR,HDN,HDT):
	dr=1.0/N
	r = (i+0.5)*dr
	patron.setpar.incomp.spe=patron.setpar.psread.spe_dif(r,dr,(RCR,ECR,NCR))
	return patron.setpar.incomp.F_atE_vol_intIC(E,V,A)

def FillCell1D_PD(i,t,E,HDR,HDN,HDT):
	if E < 1e7:
		return 0.0
	dr=1.0/N
	r = (i+0.5)*dr
	n = []
        for i,hdn in enumerate(HDN):
                n.append(ni(r,HDR,hdn))
        nh = asarray(n)	
	#nh= ni(array([r]),HDR,HDN)[0]
	patron.setpar.pdecay.spe=patron.setpar.psread.spe_dif(r,dr,(RCR,ECR,NCR))
	return patron.setpar.pdecay.F_atE_vol_intPD(E,nh,V,A,crSpecies)


def FillCell2D_PD_MC(i,j,t,E):
	if E < 1e7:
		return 0.0
	
	dr=1.0/N
	mc = n
	r  = sqrt((mc-(i+0.5))**2+(j+0.5)**2)*dr
	if r >= (N-0.5)*dr:	#N instead n because we don't want emission beyond Rmcl and not beyond Rmax as in SNR case
		return 0.0
	else:
		r_snr=sqrt((Dmcl-R+(i+0.5)*h)**2+((j+0.5)*h)**2)/Rsnr
		patron.setpar.pdecay.spe=patron.setpar.psread.spe_dif(r_snr,dr,(RCR,ECR,NCR))
		return patron.setpar.pdecay.F_atE_vol_intPD(E,nmcl,V,A)

		
def FillMFMatrix1D(mfInpFn,MFC,timeInOut,HDR,MFB):
	dr=1.0/N
	r=arange(0.5*dr,n*dr,dr)
	return B(r,HDR,MFB)
	RBT=patron.setpar.mfread.fill_rbt(mfInpFn,MFC,"FSH",timeInOut,0)
	SNR.MFR=RBT.R
	SNR.MFB=RBT.B
	return SNR.B(r,timeInOut)

def FillMFMatrix2D(mfInpFn,MFC,timeInOut,HDR,MFR):
	MF1D=FillMFMatrix1D(mfInpFn,MFC,timeInOut,HDR,MFR)
	
	MF2D=ndarray(shape=(n,n),dtype=float)
	for i in range(0,n):
		for j in range(0,n):
			x=int(sqrt((i+0.5)**2+(j+0.5)**2))
			if x<n:
				MF2D[n-1-i][j]=MF1D[x]
			else:
				MF2D[n-1-i][j]=0
	return MF2D

def FillRadiationMatrix1D(t,E,HDR,HDN,HDT):
	print "snrmap: filling 1D matrix"
	ATIME=patron.setpar.time.time()
	ML=ndarray(shape=(n),dtype=float)
	for i in range(0,n):
		ML[i]=FillCell1D(i,t,E,HDR,HDN,HDT)
	print "snrmap: 1D matrix filled, spent",patron.setpar.time.time()-ATIME,"secs"
	return ML

def FillRadiationMatrix2D_SNR(ML,t,E):
	if  all(ML) != None:
		print "snrmap: filling 2D matrix from 1D matrix ..."
		ATIME=patron.setpar.time.time()
		MS=ndarray(shape=(2*n,n),dtype=float)
		for i in range(0,2*n):
			for j in range(0,n):
			
				if i < n :
					x=int(sqrt((i+0.5)**2+(j+0.5)**2))
					if x<n:
						MS[n-1-i][j]=ML[x]
					else:
						MS[n-1-i][j]=0
				if i >= n:
					ii=i-n
					x=int(sqrt((ii+0.5)**2+(j+0.5)**2))
					if x<n:
						MS[i][j]=ML[x]
					else:
						MS[i][j]=0
		print "snrmap: 2D matrix filled, spent",patron.setpar.time.time()-ATIME,"secs"
	elif ML == None:
		print "snrmap: filling 2D matrix directly (for synchrotron calc. ksi=pi/4. is assumed)..."
		ATIME=patron.setpar.time.time()
		MS1of2=ndarray(shape=(n,n),dtype=float)
		for i in range(0,n): 
			for j in range(0,n):
				MS1of2[i][j]=FillCell2D(i,j,t,E)
		
		MS2of2=flipud(MS1of2)
		MS=concatenate((MS1of2,MS2of2),0)
		print "snrmap: 2D matrix filled, spent",patron.setpar.time.time()-ATIME,"secs"
	
	return MS


def FillRadiationMatrix2D_MC(ML,t,E):
	print "snrmap: filling 2D matrix for molecular cloud directly ..."
	ATIME=patron.setpar.time.time()
	MS=ndarray(shape=(2*n,n),dtype=float)
	for i in range(0,2*n):
		for j in range(0,n):
			MS[i][j]=FillCell2D(i,j,t,E)
	
	print "snrmap: 2D matrix filled, spent",patron.setpar.time.time()-ATIME,"secs"
	return MS


def FillRadiationMatrix3D_TOT(MS):
	print "snrmap: filling 3D matrix with",2*n,"side..."
	ATIME=patron.setpar.time.time()
	MV=ndarray(shape=(2*n,2*n,2*n),dtype=float)
	for i in range(0,2*n):
		for j in range(0,2*n):
			for k in range(0,2*n):
				if (j>=n) and (j<2*n) and (k<n):
					js=j-n
					x=int(sqrt((js+0.5)*(js+0.5)+(k+0.5)*(k+0.5)))
					if x<n:
						MV[i][j][n-1-k]=MS[i][x]
					else:
						MV[i][j][n-1-k]=0
				if (j<n) and (k<n):
					x=int(sqrt((j+0.5)*(j+0.5)+(k+0.5)*(k+0.5)))
					if x<n:
						MV[i][n-1-j][n-1-k]=MS[i][x]
					else:
						MV[i][n-1-j][n-1-k]=0
				if (j<n) and (k>=n) and (k<2*n):
					ks=k-n
					x=int(sqrt((j+0.5)*(j+0.5)+(ks+0.5)*(ks+0.5)))
					if x<n:
						MV[i][n-1-j][k]=MS[i][x] 
					else:
						MV[i][n-1-j][k]=0
				if (j>=n) and (j<2*n) and (k>=n) and (k<2*n):
					js=j-n
					ks=k-n
					x=int(sqrt((js+0.5)*(js+0.5)+(ks+0.5)*(ks+0.5)))
					if x<n:
						MV[i][j][k]=MS[i][x]
					else:
						MV[i][j][k]=0
	
	print "snrmap: 3D matrix filled, spent",patron.setpar.time.time()-ATIME,"secs"
	return MV

def FillRadiationMatrix3D_TOT_W(MS):
	print "snrmap: filling 3D matrix (using weave) with",2*n,"pixels side..."
	ATIME=patron.setpar.time.time()
	MV=ndarray(shape=(2*n,2*n,2*n),dtype=float)
	cpp_code = """
	int i,j,k;
	for(i=0;i<2*n;i++)
		for(j=0;j<2*n;j++)
			for(k=0;k<2*n;k++)
			{
				if ((j>=n) && (j<2*n) && (k<n))				//top left quater in fits
				{
					int js=j-n;
					int x=int(sqrt((js+0.5)*(js+0.5)+(k+0.5)*(k+0.5)));
					if (x<n)
						MV3(i,j,n-1-k)=MS2(i,x);
					else
						MV3(i,j,n-1-k)=0.0;
				}
				else if ((j<n) && (k<n))				//bottom left quater in fits
				{
					int x=int(sqrt((j+0.5)*(j+0.5)+(k+0.5)*(k+0.5)));
					if (x<n)
						MV3(i,n-1-j,n-1-k)=MS2(i,x);
					else
						MV3(i,n-1-j,n-1-k)=0.0;
				}
				else if ((j<n) && (k>=n) && (k<2*n))			//bottom right quater in fits
				{
					int ks=k-n;
					int x=int(sqrt((j+0.5)*(j+0.5)+(ks+0.5)*(ks+0.5)));
					if (x<n)
						MV3(i,n-1-j,k)=MS2(i,x);
					else
						MV3(i,n-1-j,k)=0.0;
				}
				else if ((j>=n) && (j<2*n) && (k>=n) && (k<2*n))	//top right quater in fits	
				{
					int js=j-n;
					int ks=k-n;
					int x=int(sqrt((js+0.5)*(js+0.5)+(ks+0.5)*(ks+0.5)));
					if (x<n)
						MV3(i,j,k)=MS2(i,x);
					else
						MV3(i,j,k)=0.0;
				}
			}
	"""
	weave.inline(cpp_code, ["MS","MV","n"])
	print "snrmap: 3D matrix filled, spent",patron.setpar.time.time()-ATIME,"secs"
	return MV

def FillRadiationMatrix3D_LHS_W(MS):							#Left Hemisphere
	print "snrmap: filling left hemisphere of 3D matrix (using weave)..."
	ATIME=patron.setpar.time.time()
	MV=ndarray(shape=(2*n,2*n,2*n),dtype=float)
	cpp_code = """
	int i,j,k;
	for(i=0;i<2*n;i++)
		for(j=0;j<2*n;j++)
			for(k=0;k<2*n;k++)
			{
				if ((j>=n) && (j<2*n) && (k<n))				//top left quater in fits
				{
					int js=j-n;
					int x=int(sqrt((js+0.5)*(js+0.5)+(k+0.5)*(k+0.5)));
					if (x<n)
						MV3(i,j,n-1-k)=MS2(i,x);
					else
						MV3(i,j,n-1-k)=0.0;
				}
				else if ((j<n) && (k<n))				//bottom left quater in fits
				{
					int x=int(sqrt((j+0.5)*(j+0.5)+(k+0.5)*(k+0.5)));
					if (x<n)
						MV3(i,n-1-j,n-1-k)=MS2(i,x);
					else
						MV3(i,n-1-j,n-1-k)=0.0;
				}
				else if ((j<n) && (k>=n) && (k<2*n))			//bottom right quater in fits
				{
					MV3(i,n-1-j,k)=0.0;
				}
				else if ((j>=n) && (j<2*n) && (k>=n) && (k<2*n))	//top right quater in fits	
				{
					MV3(i,j,k)=0.0;
				}
			}
	"""
	weave.inline(cpp_code, ["MS","MV","n"])
	print "snrmap: left hemisphere of 3D matrix filled, spent",patron.setpar.time.time()-ATIME,"secs"
	return MV


def FillRadiationMatrix3D_RHS_W(MS):					#Right Hemisphere
	print "snrmap: filling right hemisphere of 3D matrix (using weave)..."
	ATIME=patron.setpar.time.time()
	MV=ndarray(shape=(2*n,2*n,2*n),dtype=float)
	pi = acos(-1.)
	theta = pi*20./180.
	cpp_code = """
	int i,j,k;
	for(i=0;i<2*n;i++)
		for(j=0;j<2*n;j++)
			for(k=0;k<2*n;k++)
			{
				if ((j>=n) && (j<2*n) && (k<n))				//top left quater in fits
				{
					MV3(i,j,n-1-k)=0.0;
				}
				else if ((j<n) && (k<n))				//bottom left quater in fits
				{
					MV3(i,n-1-j,n-1-k)=0.0;
				}
                                // else if ((k>=n) && (k<2*n) && (j>k*tan(theta)) && (i>k*tan(theta)))
                                // {
                                //         MV3(i,n-1-j,n-1-k)=0.0;                         //outside the cone
                                // }
				else if ((j<n) && (k>=n) && (k<2*n))			//bottom right quater in fits
				{
					int ks=k-n;
					int x=int(sqrt((j+0.5)*(j+0.5)+(ks+0.5)*(ks+0.5)));
					if (x<n)
						MV3(i,n-1-j,k)=MS2(i,x);
					else
						MV3(i,n-1-j,k)=0.0;
				}
				else if ((j>=n) && (j<2*n) && (k>=n) && (k<2*n))	//top right quater in fits	
				{
					int js=j-n;
					int ks=k-n;
					int x=int(sqrt((js+0.5)*(js+0.5)+(ks+0.5)*(ks+0.5)));
					if (x<n)
						MV3(i,j,k)=MS2(i,x);
					else
						MV3(i,j,k)=0.0;
				}
			}
	"""
	weave.inline(cpp_code, ["MS","MV","n"])
	print "snrmap: right hemisphere of 3D matrix filled, spent",patron.setpar.time.time()-ATIME,"secs"
	return MV


# def FillRadiationMatrix3D_RHS_W(MS):	#full with cone of enhanced emission						#Right Hemisphere
# 	print "snrmap: filling right hemisphere of 3D matrix (using weave)..."
# 	ATIME=patron.setpar.time.time()
# 	MV=ndarray(shape=(2*n,2*n,2*n),dtype=float)
# 	#pi = acos(-1.)
# 	cpp_code = """
# 	int i,j,k;
# 	double theta = acos(-1.)*15./180.;
#         double norm_cone = 12.;
#         double norm_rest = (2. - norm_cone*(1.-cos(theta)))/(1+cos(theta));
#         for(i=0;i<2*n;i++)
# 		for(j=0;j<2*n;j++)
# 			for(k=0;k<2*n;k++)
# 			{
# 				if ((j>=n) && (j<2*n) && (k<n))				//top left quater in fits
# 				{
# 					int js=j-n;
# 					int x=int(sqrt((js+0.5)*(js+0.5)+(k+0.5)*(k+0.5)));
# 					if (x<n)
# 						MV3(i,j,n-1-k)=norm_rest*MS2(i,x);
# 					else
# 						MV3(i,j,n-1-k)=0.0;
# 				}
# 				else if ((j<n) && (k<n))				//bottom left quater in fits
# 				{
# 					int x=int(sqrt((j+0.5)*(j+0.5)+(k+0.5)*(k+0.5)));
# 					if (x<n)
# 						MV3(i,n-1-j,n-1-k)=norm_rest*MS2(i,x);
# 					else
# 						MV3(i,n-1-j,n-1-k)=0.0;
# 				}
                               
				 
# 				//if ((j>=n) && (j<2*n) && (k<n))				//top left quater in fits
# 				//{
# 				//	MV3(i,j,n-1-k)=0.0;
# 				//}
# 				//else if ((j<n) && (k<n))				//bottom left quater in fits
# 				//{
# 				//	MV3(i,n-1-j,n-1-k)=0.0;
# 				//}
				

# 				else if ((k>=n)  && (k<2*n) && (j>=n) && (j<2*n))
# 				  {
# 				    int is = i-n;
# 				    int js = j-n;
# 				    int ks = k-n;
# 				    int xx = int(sqrt(is*is + js*js));
# 				    int x=int(sqrt((js + 0.5)*(js + 0.5)+(ks + 0.5)*(ks + 0.5) ));
# 				    if ( (xx < ks*tan(theta)) && (x < n ))
# 				      MV3(i,j,k) = norm_cone * MS2(i,x);
#                                     else if ( (xx > ks*tan(theta)) && (x < n ))
#                                       MV3(i,j,k) = norm_rest * MS2(i,x);
# 				    else MV3(i,j,k) = 0.0;
# 				  }

# 				else if ((k>=n) && (k<2*n) && (j<n))
# 				  {
# 				    int is = i-n;
# 				    int js = j-n;
# 				    int ks = k-n;
# 				    int xx = int(sqrt(is*is+js*js));
# 				    int x=int(sqrt((js + 0.5)*(js + 0.5)+(ks + 0.5)*(ks + 0.5) ));
# 				    if ( (xx < ks*tan(theta)) && (x < n ))
# 				      MV3(i,j,k) = norm_cone * MS2(i,x);
#                                     else if ( (xx > ks*tan(theta)) && (x < n ))
# 				      MV3(i,j,k) = norm_rest * MS2(i,x);
# 				    else MV3(i,j,k) = 0.0;
# 				  }
				
                                
# 			}


# 	"""
# 	scipy.weave.inline(cpp_code, ["MS","MV","n"])
# 	print "snrmap: right hemisphere of 3D matrix filled, spent",patron.setpar.time.time()-ATIME,"secs"
# 	return MV


# def FillRadiationMatrix3D_RHS_W(MS):		#just the cone					#Right Hemisphere
# 	print "snrmap: filling right hemisphere of 3D matrix (using weave)..."
# 	ATIME=patron.setpar.time.time()
# 	MV=ndarray(shape=(2*n,2*n,2*n),dtype=float)
# 	#pi = acos(-1.)
# 	cpp_code = """
# 	int i,j,k;
# 	double theta = acos(-1.)*30./180.;
#         for(i=0;i<2*n;i++)
# 		for(j=0;j<2*n;j++)
# 			for(k=0;k<2*n;k++)
# 			{
# 				if (k<n) MV3(i,j,k)=0.0;
# 				/* 
# 				if ((j>=n) && (j<2*n) && (k<n))				//top left quater in fits
# 				{
# 					MV3(i,j,n-1-k)=0.0;
# 				}
# 				else if ((j<n) && (k<n))				//bottom left quater in fits
# 				{
# 					MV3(i,n-1-j,n-1-k)=0.0;
# 				}
# 				*/

# 				else if ((k>=n)  && (k<2*n) && (j>=n) && (j<2*n))
# 				  {
# 				    int is = i-n;
# 				    int js = j-n;
# 				    int ks = k-n;
# 				    int xx = int(sqrt(is*is + js*js));
# 				    int x=int(sqrt((js + 0.5)*(js + 0.5)+(ks + 0.5)*(ks + 0.5) ));
# 				    if ( (xx < ks*tan(theta)) && (x < n ))
# 				      MV3(i,j,k) = MS2(i,x);
# 				    else MV3(i,j,k) = 0.0;
# 				  }

# 				else if ((k>=n) && (k<2*n) && (j<n))
# 				  {
# 				    int is = i-n;
# 				    int js = j-n;
# 				    int ks = k-n;
# 				    int xx = int(sqrt(is*is+js*js));
# 				    int x=int(sqrt((js + 0.5)*(js + 0.5)+(ks + 0.5)*(ks + 0.5) ));
# 				    if ( (xx < ks*tan(theta)) && (x < n ))
# 				      MV3(i,j,k) = MS2(i,x);
# 				    else MV3(i,j,k) = 0.0;
# 				  }
				
                                
# 			}


# 	"""
# 	scipy.weave.inline(cpp_code, ["MS","MV","n"])
# 	print "snrmap: right hemisphere of 3D matrix filled, spent",patron.setpar.time.time()-ATIME,"secs"
# 	return MV

# def FillRadiationMatrix3D_RHS_W(MS):		#1D profile					#Right Hemisphere
# 	print "snrmap: filling right hemisphere of 3D matrix (using weave)..."
# 	ATIME=patron.setpar.time.time()
# 	MV=ndarray(shape=(2*n,2*n,2*n),dtype=float)
# 	#pi = acos(-1.)
# 	cpp_code = """
# 	int i,j,k;
#         for(i=0;i<2*n;i++)
#  		for(j=0;j<2*n;j++)
# 	               for(k=0;k<2*n;k++)
# 		       {
#                             if ((i!=n) || (j!=n)) MV3(i,j,k)=0.0;
# 		 	    else 
#                             {
#                                   if (k<n) MV3(i,j,k)=0.0;
# 			          else if ((k>=n)  && (k<2*n)) MV3(i,j,k) = MS2(i,k);     
#                 		  else MV3(i,j,k) = 0.0;
#                             }
# 		       }


# 	"""
# 	scipy.weave.inline(cpp_code, ["MS","MV","n"])
# 	print "snrmap: right hemisphere of 3D matrix filled, spent",patron.setpar.time.time()-ATIME,"secs"
# 	return MV

def RotateMap3D(MV,rotMapXYZ):
	print "snrmap: rotating 3D matrix by",rotMapXYZ,"around XYZ (screwdriver rule) as seen in fits file"
	ATIME=patron.setpar.time.time()

	#in fits file axes are swapeed wrt numpy array: X=2, Y=1, Z=0; rotation angles around X and Z are multiplied by -1 to correspond screwdriver rule
	angleAroundX=(-1.0)*rotMapXYZ[0];planeYZ=(0,1)
	angleAroundY= rotMapXYZ[1];planeXZ=(0,2)
	angleAroundZ=(-1.0)*rotMapXYZ[2];planeXY=(1,2)
	
	if angleAroundX != 0.0:
		print "snrmap: rotating around X (points right) in YZ plane (top->front->bottom)..."
		MV=rotate(MV,angleAroundX,planeYZ,order=ORDER,reshape=False)
	if angleAroundY != 0.0:
		print "snrmap: rotating around Y (points up) in XZ plane (front->right->back)..."
		MV=rotate(MV,angleAroundY,planeXZ,order=ORDER,reshape=False)
	if angleAroundZ != 0.0:
		print "snrmap: rotating around Z (points to observer) in XY plane (top->left->bottom)..."
		MV=rotate(MV,angleAroundZ,planeXY,order=ORDER,reshape=False)
	print "snrmap: rotation of 3D matrix is done, spent",patron.setpar.time.time()-ATIME,"secs"
	return MV
	
def RotateMap3D_W(MV,rotMapXYZ):
	print "snrmap: rotating 3D matrix by",rotMapXYZ,"around XYZ (using weave)..."
	ATIME=patron.setpar.time.time()
	cpp_code = """
	
	"""
	weave.inline(cpp_code, ["MV","n"])
	print "snrmap: rotation of 3D matrix is done, spent",patron.setpar.time.time()-ATIME,"secs"
	return MV

def RebinSter(mapToRebin,newShape):
	s = newShape[0],mapToRebin.shape[0]//newShape[0],newShape[1],mapToRebin.shape[1]//newShape[1]
	return apToRebin.reshape(sh).mean(-1).mean(1)

def RebinFlux(mapToRebin,newShape):
	s = newShape[0],mapToRebin.shape[0]//newShape[0],newShape[1],mapToRebin.shape[1]//newShape[1]
	return mapToRebin.reshape(s).sum(-1).sum(1)

def ScaleMap(MAP,scaleInPC,steRadian):
	print "snrmap: scaling map to",scaleInPC,"pc..."
	ATIME=patron.setpar.time.time()
	shapeFactor=size(MAP.shape)
	zoomFactor=(2.0*R*n/N)/(scaleInPC*pc)
	print "snrmap: zoom factor is", zoomFactor
	if steRadian == "SR":
		ZMAP=zoom(MAP,zoomFactor,order=ORDER,cval=0.0)
	else:
		ZMAP=zoom(MAP,zoomFactor,order=ORDER,cval=0.0)/zoomFactor**shapeFactor
	print "snrmap: scaling map is done, spent",patron.setpar.time.time()-ATIME,"secs"
	return ZMAP

def RestoreOrigDim(MAP):
	print "snrmap: restoring original map dimesnions..."
	ATIME=patron.setpar.time.time()
	RMAP=zeros(4*n**2).reshape(2*n,2*n)
	print "snrmap: original map sides are",2*n,2*n
	xMap=MAP.shape[0]
	yMap=MAP.shape[1]
	print "snrmap: scaled map sides are", xMap, yMap
	xStart=n-round(xMap/2)
	yStart=n-round(yMap/2)
	RMAP[xStart:xStart+xMap,yStart:yStart+yMap]=MAP
	print "snrmap: restoring is done, spent",patron.setpar.time.time()-ATIME,"secs"
	return RMAP

def WriteSurfaceMapSMAP(rmOutFn,SMAP,scale):
	f=open(rmOutFn+".smap","w")
	f.write("#"+str(scale)+"\n")
	for i in range(0,2*n):
		for j in range(0,2*n):
			f.write(str(SMAP[i][j])+"\t")
		f.write("\n")
	f.close()

def WriteSurfaceMapFITS(rmOutFn,SMAP,mapEnergy,rotMapXYZ,scaleInPC,steRadian):
	if steRadian == "SR":units="1/(GeV s cm^2 sr)"
	else:units="1/(GeV s cm^2)"
#	if isinstance(mapEnergy,basestring): energy=mapEnergy
#	else:energy=mapEnergy/1e9
	energy=mapEnergy
	
	hdr=fits.Header()
	hdr['ENERGY  ']=energy,"[eV]"
	hdr['UNITS   ']=units
	hdr['ROTAXISX']=rotMapXYZ[0]
	hdr['ROTAXISY']=rotMapXYZ[1]
	hdr['ROTAXISZ']=rotMapXYZ[2]
	hdr['SCALEDPC']=scaleInPC
	ima=fits.PrimaryHDU(SMAP, header=hdr)
	ima.writeto(rmOutFn+".fits.gz",clobber=True)
#	prihdr=fits.PrimaryHDU(header=hdr)
#	ima=fits.ImageHDU(SMAP)
#	hdulist=fits.HDUList([prihdr,ima])
#	hdulist.writeto(rmOutFn+".fits",clobber=True)

def WriteProfile(rmOutFn,PROF):
	PMAX=PROF.max()
	f=open(rmOutFn+".prof","w")
	f.write("#MAX="+str(PMAX)+"\n")
	for i in range(0,n):
		f.write(str(i/float(n))+" "+str(PROF[i]/PMAX)+"\n")
	f.close()


def ProduceMapProfile(task,mapEnergy,radType,radObject,createMap,hemiSpher,steRadian,rotMapXYZ,scaleInPC,mfCompDim,mfInpFn,crInpFn,rmOutFn,rStepsNum,pStepsNum,timeInOut,HDR,HDN,HDT,MFB, SP):
	global RCR,ECR,NCR,MF1DTOT,MF2DRAD,MF2DTAN,FillCell1D,FillCell2D
	print "snrmap: preparing for production of a map/profile..."
	print "snrmap: requested energy is",mapEnergy
	if   radObject == "SNR":
		print "snrmap: object is SNR"
		if   radType == "THR":
			FillCell1D=FillCell1D_TH
			ML=FillRadiationMatrix1D(timeInOut,mapEnergy,HDR,HDN,HDT)
		elif radType == "SYR":
			FillCell1D=FillCell1D_SY
			FillCell2D=FillCell2D_SY
			(RCR,ECR,NCR)=patron.setpar.psread.fill_ren(rStepsNum,pStepsNum,crInpFn)
			if   mfCompDim == "1D":
				MF1DTOT=FillMFMatrix1D(mfInpFn,"TOT",timeInOut,HDR,MFB)
				ML=FillRadiationMatrix1D(timeInOut,mapEnergy,HDR,HDN,HDT)
			elif mfCompDim == "2D":
				MF2DRAD=FillMFMatrix2D(mfInpFn,"RAD",timeInOut)
				MF2DTAN=FillMFMatrix2D(mfInpFn,"TAN",timeInOut)
				ML=None
			else:
				print "snrmap: MF dimentionality is not supported! Aborting!"
				patron.setpar.sys.exit(0)
		elif radType == "ICR":
			patron.setpar.incomp.Uc=SP.ucmb		
			patron.setpar.incomp.Ud=SP.udust	
			patron.setpar.incomp.Us=SP.ustarlight
			FillCell1D=FillCell1D_IC
			(RCR,ECR,NCR)=patron.setpar.psread.fill_ren(rStepsNum,pStepsNum,crInpFn)
			ML=FillRadiationMatrix1D(timeInOut,mapEnergy,HDR,HDN,HDT)
		elif radType == "PDR":
			FillCell1D=FillCell1D_PD
			(RCR,ECR,NCR)=patron.setpar.psread.fill_ren(rStepsNum,pStepsNum,crInpFn)
			ML=FillRadiationMatrix1D(timeInOut,mapEnergy,HDR,HDN,HDT)
		else:
			print "snrmap: this type of radiation process is not supported! Aborting!"
			patron.setpar.sys.exit(0)
		FillRadiationMatrix2D=FillRadiationMatrix2D_SNR
	elif radObject == "MCL":
		print "snrmap: object is MCL"
		if radType == "PDR":
			FillCell2D=FillCell2D_PD_MC
			(RCR,ECR,NCR)=patron.setpar.psread.fill_ren(rStepsNum,pStepsNum,crInpFn)
			ML=None
		else:
			print "snrmap: this type of radiation process for Molecular Cloud is not supported! Aborting!"
			patron.setpar.sys.exit(0)
		FillRadiationMatrix2D=FillRadiationMatrix2D_MC
	elif radObject == "SHL":
		print "snrmap: emission map from the shell is computed together with SNR. Specify outer boundary (R2) that would encompass the shell."
		patron.setpar.sys.exit(0)
	else:
		print "snrmap: wrong radiation object provided!"
		patron.setpar.sys.exit(0)
	
	MS=FillRadiationMatrix2D(ML,timeInOut,mapEnergy)
	
	if   createMap == "FALSE":
		print "snrmap: producing intensity profile..."
		PROF=MS.sum(0)
		WriteProfile(rmOutFn,PROF)
		print "snrmap: profile was produced!"
		
	elif createMap == "TRUE":
		print "snrmap: producing surface intensity map..."
		if   hemiSpher == "":
			FillRadiationMatrix3D=FillRadiationMatrix3D_TOT_W
		elif hemiSpher == "LHS":
			FillRadiationMatrix3D=FillRadiationMatrix3D_LHS_W
		elif hemiSpher == "RHS":
			FillRadiationMatrix3D=FillRadiationMatrix3D_RHS_W
		else:
			print "snrmap: Invalid input(", hemiSpher, ") for hemiSpher..."
			patron.setpar.sys.exit(0)		

		MV=FillRadiationMatrix3D(MS)
		
#		if   scaleInPC != 0.0:
#			MV=ScaleMap(MV,scaleInPC,steRadian)
		
		if   rotMapXYZ == (0.0, 0.0, 0.0):
			SMAP=MV.sum(0)
		else:
			MV=RotateMap3D(MV,rotMapXYZ)
			SMAP=MV.sum(0)
		
		if   scaleInPC != 0.0:
			SMAP=ScaleMap(SMAP,scaleInPC,steRadian)
			SMAP=RestoreOrigDim(SMAP)
	#		SMAP[300][300]=1e-15
				
#		WriteSurfaceMapSMAP(rmOutFn,SMAP,scaleInPC)
		if   task == "RADMAP" or task == "MAPSPE_PARALLEL":
			WriteSurfaceMapFITS(rmOutFn,SMAP,mapEnergy,rotMapXYZ,scaleInPC,steRadian)
			print "snrmap: map was produced!"
		elif task == "RADM3D":
			WriteSurfaceMapFITS(rmOutFn,MV,mapEnergy,rotMapXYZ,scaleInPC,steRadian)
			print "snrmap: 3D map was produced!"
		elif task == "MAPSPE" or task == "MAPINT":
			return SMAP

def ExecuteAnyMapTask(task,mapEnergy,radType,radObject,createMap,hemiSpher,steRadian,rotMapXYZ,scaleInPC,mfCompDim,mfInpFn,crInpFn,rmOutFn,rStepsNum,pStepsNum,timeInOut,SP):
	#Get the hydro information from file
	MHYDRO = patron.setpar.mhdread.fill_mhydro(SP.MHDINPFN,SP.TIMEINOUT)
	HDR = MHYDRO.r
	if radType != "PDR":
		HDN = MHYDRO.nh
	else:
		HDN = [MHYDRO.nh, MHYDRO.nhe, MHYDRO.nc, MHYDRO.nox]
		patron.setpar.pdecay.target = ["H", "He", "C", "Ox"]
		global crSpecies
		crSpecies = SP.CRSPECIES		
		patron.setpar.pdecay.SP = SP
		patron.setpar.pdecay.target = ["H", "He", "C", "Ox"]
			
		del patron.setpar.pdecay.gmatr[:]
		del patron.setpar.pdecay.cmatr[:]			
			
		for i,tar in enumerate(patron.setpar.pdecay.target):
			gdata = getenv("PATRONDIR")+"/data/piondecay/"+crSpecies+"/gdata_"+tar+".dat"
#			gdata = getenv("PATRONDIR")+"/data/piondecay/gdata.dat"
#			gdata = getenv("PATRONDIR")+"/data/piondecay/HE_old/gdata.dat"
			try:
				print "Matrix filled with data from file opened: ", gdata
				patron.setpar.pdecay.gmatr.append(fromfile(gdata, sep=' ', count=-1, dtype=float).reshape(201,374))
			except IOError:
				print "No file found:",gdata
				

			cdata = getenv("PATRONDIR")+"/data/piondecay/"+crSpecies+"/cdata_"+tar+".dat"
#			cdata = getenv("PATRONDIR")+"/data/piondecay/cdata.dat"
#			cdata = getenv("PATRONDIR")+"/data/piondecay/HE_old/cdata.dat"
			try:	
				print "Matrix filled with data from file opened: ", cdata
				patron.setpar.pdecay.cmatr.append(1.0e-27*fromfile(cdata, sep=' ', count=-1, dtype=float))	#.reshape(201,374)
			except IOError:
				print "No file found:",cdata
	HDT = MHYDRO.T
	MFB = MHYDRO.B

	if   task == "RADMAP" or task == "RADM3D" or task == "MAPSPE_PARALLEL":
		#print "snrmap: ENERGY:",mapEnergy
		mapEnergy1=float(mapEnergy.split('-')[0])
		ProduceMapProfile(task,mapEnergy1,radType,radObject,createMap,hemiSpher,steRadian,rotMapXYZ,scaleInPC,mfCompDim,mfInpFn,crInpFn,rmOutFn,rStepsNum,pStepsNum,timeInOut,HDR,HDN,HDT,MFB,SP)
	elif task == "MAPSPE":
		print "snrmap: --------- building radiation spectrum by looping over map energies ---------"
		if   radType == "THR":
			i=arange(-1.0,4.1,0.1)
		elif radType == "SYR":
			i=arange(-8.0,6.1,0.1)
		elif radType == "ICR":
			i=arange(5.0,15.1,0.1)
		elif radType == "PDR":
			i=arange(5.0,15.1,0.1)

		E=10**i
		
		ME=[]
		J=1;L=len(i)
		f=open(rmOutFn,"w")
		for mapEnergy in E:
			print "snrmap: --- processing map",J,"out of",L,"---"
			SMAP=ProduceMapProfile(task,mapEnergy,radType,radObject,createMap,hemiSpher,steRadian,rotMapXYZ,scaleInPC,mfCompDim,mfInpFn,crInpFn,rmOutFn,rStepsNum,pStepsNum,timeInOut,HDR,HDN,HDT,MFB,SP)
			F=SMAP.sum()
			f.write(str(mapEnergy/1e9)+"\t"+str(F)+"\n")
			ME.append(SMAP)
			J=J+1
		f.close()
		ME=array(ME)
		mapEnergy="log10="+str(i[0])+".."+str(i[-1])+", step=0.1"
		WriteSurfaceMapFITS(rmOutFn,ME,mapEnergy,rotMapXYZ,scaleInPC,steRadian)
	elif task == "MAPINT":
		N=20
		mapEnergy1,mapEnergy2=mapEnergy.split('-')
		E1=float(mapEnergy1)
		E2=float(mapEnergy2)
		print "snrmap: --------- --------- energy integrated map: E1 =",E1,"E2 =",E2,"--------- ---------"
		i1=log10(E1)
		i2=log10(E2)
		di=(i2-i1)/N
		i=arange(i1+0.5*di,i2,di)
		dE=10**(i+0.5*di)-10**(i-0.5*di)
		E=10**i
#		print "snrmap: E1 =",E1,"E2 =",E2,"E =",E,"dE",dE
#		ME=[]
		L=len(i)
		f=open(rmOutFn,"w")
		IMAP=0
		for i in range(L):
			print "snrmap: --- processing map",i+1,"out of",L,"---"
			SMAP=ProduceMapProfile(task,E[i],radType,radObject,createMap,hemiSpher,steRadian,rotMapXYZ,scaleInPC,mfCompDim,mfInpFn,crInpFn,rmOutFn,rStepsNum,pStepsNum,timeInOut,HDR,HDN,HDT,MFB,SP)
#			print "snrmap: SMAP", SMAP
			IMAP=IMAP+SMAP*(dE[i]/1e9)
			Fv=(SMAP*(dE[i]/1e9)).sum()
			f.write(str(E[i]/1e9)+"\t"+str(Fv)+"\n")
			#ME.append(SMAP)
		f.close()
		#ME=array(ME)
		#mapEnergy="log10="+str(i[0])+".."+str(i[-1])+", step ="+str(di)
		WriteSurfaceMapFITS(rmOutFn,IMAP,mapEnergy,rotMapXYZ,scaleInPC,steRadian)
	else:
		print "snrmap: this task is not supported!"
		patron.setpar.sys.exit(0)


	
def main(argv=None):
	if argv is None: argv=patron.setpar.sys.argv
	SP = patron.setpar.SimParams()
	patron.setpar.SetupSimParams(SP,argv[1:])
	
	global SNR,Bf,R,A,V,N,n,Dmcl,nmcl,Rsnr #,E
	
	SNR=patron.setpar.tecf.TranEqnCoeffFuncs(shockType=SP.SHOCKTYPE,nhDensity=SP.nhdensity,expEnergy=SP.expenergy, crSpecies=SP.CRSPECIES,\
               			      mfProfile="TRA",alfvDrift=SP.ALFVDRIFT, \
				      hdDataInp=SP.HDDATAINP,hdFileInp=SP.HDFILEINP,mfDataInp=SP.MFDATAINP, mfFileInp=SP.MFFILEINP)
			
	Bf = 0.8
	
	RM = SP.radnormax
	N  = SP.radintres
	n  = int(RM*N)
		
	if   SP.RADOBJECT == "SNR" or SP.RADOBJECT == "SHL": R = SNR.Rsh(SP.timeinout)
	elif SP.RADOBJECT == "MCL":
		R    = 0.5*(SP.rshellpc2-SP.rshellpc1)*pc
		Dmcl = SP.rshellpc1*pc + R
		Rsnr = SNR.Rsh(SP.timeinout)
	
	d  = SP.snrdistpc*pc
	h  = R/N
	if   SP.STERADIAN == "NO": A = d**2
	elif SP.STERADIAN == "SR": A = h**2
	V  = h**3				#one cell volume
	nmcl=SP.shdensity
#	E  = SP.mapenergy
	
	ExecuteAnyMapTask(task=SP.CALCULATE,mapEnergy=SP.MAPENERGY,radType=SP.RADIATION,radObject=SP.RADOBJECT,createMap=SP.CREATEMAP,hemiSpher=SP.HEMISPHER,steRadian=SP.STERADIAN,rotMapXYZ=SP.rotmapxyz,scaleInPC=SP.scaleinpc,\
			  mfCompDim=SP.MFCOMPDIM,mfInpFn=SP.MFINPFN,crInpFn=SP.CRINPFN,rmOutFn=SP.RPOUTFN,rStepsNum=SP.rstepsnum,pStepsNum=SP.pstepsnum,timeInOut=SP.timeinout)	
if __name__ == "__main__":patron.setpar.sys.exit(main())
