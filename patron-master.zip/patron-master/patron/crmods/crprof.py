######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  crprof.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2010 - 2015
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v1.0.0: initial version
#v1.1.0: version control added
#v2.0.0: parameters changed to work with global setpar module compliant with patron 2.2.x and higher

__version__='2.0.0'

from numpy import arange
from scipy import interpolate

import patron.setpar
from patron.reader import psread as psread

#global RCR,ECR,NCR

def J(E,r,dr,(RCR,ECR,NCR)):
	spe=patron.setpar.psread.spe_dif(r,dr,(RCR,ECR,NCR))
	return interpolate.interp1d(spe.E,spe.J, bounds_error=False, fill_value=0.0)(E)

def ProduceCRsProfile(R1,R2,crsEnergy,inFileName,rStepsNum,pStepsNum,timeInOut):
#	global RCR,ECR,NCR
	print "crprof: preparing for production of cosmic rays profile..."
	print "crprof: requested energy is",crsEnergy,"GeV"
	EN=eval(crsEnergy)
	TIME=timeInOut
	crDataOut="/".join(inFileName.split("/")[:-1])
	
	(RCR,ECR,NCR)=patron.setpar.psread.fill_ren(rStepsNum,pStepsNum,inFileName)
	
	N=1000.
	dr=1./N
	r=arange(R1,R2+dr,dr)

	print "crprof: producing cosmic ray profiles..."
	f=open(crDataOut+"/"+"NAR"+TIME+"_"+crsEnergy,"w")
	for i in range(len(r)):
		f.write(str(r[i])+" "+str(J(EN,r[i],dr,(RCR,ECR,NCR)))+"\n")
	f.close()
	print "crprof: cosmic rays profile is done!"

def main(argv=None):
	if argv is None: argv=patron.setpar.sys.argv

	if len(argv) > 2:
		SP = patron.setpar.SimParams()
		patron.setpar.SetupSimParams(SP,argv[1:])
		patron.setpar.WriteSimParams(SP)
	else:
		temp,pfile=argv[1].split("=")
		SP = patron.setpar.ReadSimParams(pfile)
	patron.setpar.InitSimulation(SP)
	
	RM=SP.rcoordmax
	
	R1=SP.rspenorm1
	R2=SP.rspenorm2
	
	if R1 != R2:
		ProduceCRsProfile(R1,R2,crsEnergy=SP.CRSENERGY,inFileName=SP.CRINPFN,rStepsNum=SP.rstepsnum,pStepsNum=SP.pstepsnum,timeInOut=SP.TIMEINOUT)
	else:
		ProduceCRsProfile(0.,RM,crsEnergy=SP.CRSENERGY,inFileName=SP.CRINPFN,rStepsNum=SP.rstepsnum,pStepsNum=SP.pstepsnum,timeInOut=SP.TIMEINOUT)


if __name__ == "__main__":patron.setpar.sys.exit(main())
