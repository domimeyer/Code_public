######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  crspe2.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2010 - 2015
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v2.0.0: renamed version of stable sumsh_v2.0.py
#v2.1.0: introducing main function to allow import as a module alone with independent run
#v2.2.0: parameters changed to work with global setpar module compliant with patron 2.2.x and higher
#v2.3.0: version control added, new initialization in standalone mode
#v2.3.1: Changed to work with cluster

__version__='2.3.0'

from numpy import *
from scipy import interpolate

import patron.setpar

pi  = 3.1415926
c   = 2.998e10							#speed of light in cm/s
m_e = 9.109e-28							#electron mass in grams
p_e = m_e*c							#electron momentum
m_p = 1.673e-24							#proton mass in grams
p_p = m_p*c							#proton momentum
m_he=4.*m_p							#helium mass
p_he=m_he*c							#helium momentum
m_c = 12.*m_p							#carbon mass
p_c = m_c*c							#carbon momentum
m_ox = 16.*m_p							#oxygen mass
p_ox = m_ox*c							#oxygen momentum
m_fe = 56*m_p							#iron mass
p_fe = m_fe*c							#iron momentum

def NP2NE(Ndlp,dimlesp,crSpecies):
	m=0
	if crSpecies == "EL":
		N=Ndlp/p_e
		p=dimlesp*p_e
		m=m_e
	elif crSpecies == "PR":
		N=Ndlp/p_p
		p=dimlesp*p_p
		m=m_p
	elif crSpecies == "HE":
		N=Ndlp/p_he
		p=dimlesp*p_he
		m=m_he
	elif crSpecies == "C":
		N=Ndlp/p_c
		p=dimlesp*p_c
		m=m_c
	elif crSpecies == "OX":
		N=Ndlp/p_ox
		p=dimlesp*p_ox
		m=m_ox
	elif crSpecies == "FE":
		N=Ndlp/p_fe
		p=dimlesp*p_fe
		m=m_fe
	return N/(0.624e3*((p*c**2)/sqrt(p**2*c**2 + m**2*c**4)))	#dN/dp -> dN/dE, E in GeV

def p2E(dimlesp,crSpecies):
	m=0
	if crSpecies == "EL":
		p=dimlesp*p_e
		m=m_e
	elif crSpecies == "PR":
		p=dimlesp*p_p
		m=m_p
	elif crSpecies == "HE":
		p=dimlesp*p_he
		m=m_he
	elif crSpecies == "C":
		p=dimlesp*p_c
		m=m_c
	elif crSpecies == "OX":
		p=dimlesp*p_ox
		m=m_ox
	elif crSpecies == "FE":
		p=dimlesp*p_fe
		m=m_fe
	return 0.624e3*(sqrt(p**2*c**2 + m**2*c**4)-m*c**2)		#p2E, E in GeV

def ConvertRaw2DatSUM(inFileNameRS,inFileNameFS,crDataOut,crFileOut,crSpecies,rStepsNumRS,rStepsNumFS,rCoordMaxRS,rCoordMaxFS,pStepsNum,RRS,timeInOut):
	print "crspe2: producing CR spectra for total, down-, and upstream regions in SUM/S, SUM/F, SUM/R directories..."
	SP = patron.setpar	

	(Rrs,Prs,Nrs)=SP.psread.fill_ren(rStepsNumRS,pStepsNum,inFileNameRS,RRS)
	(Rfs,Pfs,Nfs)=SP.psread.fill_ren(rStepsNumFS,pStepsNum,inFileNameFS)
	NatR=SP.psread.NatR
	Efs=p2E(Pfs,crSpecies)
	
	LRFS=len(Rfs)
	Ifs=arange(0,rStepsNumFS)
	Irs=arange(0,rStepsNumRS)

#	print "RS:", rCoordMaxRS, rStepsNumRS,"len(Rrs):",len(Rrs),"len(Prs):",len(Prs)
#	print "FS:", rCoordMaxFS, rStepsNumFS,"len(Rfs):",LRFS,"len(Pfs):",len(Pfs)
	drs=rCoordMaxFS/rStepsNumFS
#	print "drs:", drs
	rst=arange(drs,rCoordMaxFS+drs,drs)
	
	dr1=0.0500
	dr2=0.0025
	dr3=0.0250
	dr4=0.0025
	
	if RRS < 0.9:
		rr1=arange(0,RRS-0.05,dr1)			#;print "rr1 =", len(rr1)
		rr2=arange(RRS-0.05,RRS+0.05,dr2)		#;print "rr2 =", len(rr2)
		rr4=arange(0.95,1.05,dr4)			#;print "rr4 =", len(rr4)
		rr5=Rfs[Rfs>1.05]				#;print "rr5 =", len(rr5)
		ncdr=LRFS-len(concatenate((rr1,rr2,rr4,rr5)))	#;print "ncdr=", ncdr
		rr3=linspace(RRS+0.05,0.95,ncdr,endpoint=False)	#;print "rr3 =", len(rr3)
		rfs=concatenate((rr1,rr2,rr3,rr4,rr5))		#;print "rfs =", len(rfs)
	else:
		rr234=arange(RRS-0.05,1.05,dr2) 		#;print "rr234=",len(rr234)
		rr5=Rfs[Rfs>1.05]				#;print "rr5  =",len(rr5)
		ncdr=LRFS-len(concatenate((rr234,rr5))) 	#;print "ncdr =",ncdr
		rr1=linspace(0,RRS-0.05,ncdr,endpoint=False)	#;print "rr1  =",len(rr1)
		rfs=concatenate((rr1,rr234,rr5))		#;print "rfs  =",len(rfs)
		
	Lrfs=len(rfs)
	
	if Lrfs != LRFS:
		print "crspe2: NEW ARRAY IS NOT EQUAL IN SIZE TO THE OLD ARRAY!!!ABORTING!"
		print "crspe2: Lrfs",Lrfs,"LRFS",LRFS
		SP.sys.exit(1)
#	sp.sys.exit(0)
	
	rpfs=interpolate.interp1d(Ifs,rfs,bounds_error=False,fill_value=0)(Ifs+0.5)
	rmfs=interpolate.interp1d(Ifs,rfs,bounds_error=False,fill_value=0)(Ifs-0.5)
	dVfs=(rpfs-rmfs)*rfs**2
	
	FSI=int(where((rfs>=1.0))[0][0]-1)
	
	NRAWFSHlst=[]
	NRAWRSHlst=[]
	
	for i in range(0,LRFS):
		Ri=Rfs[i]
		
		if i == 0:
			r1=0.0
			r2=0.5*Rfs[1]
		elif i > 0 and i < LRFS-1:
			drm=Ri-Rfs[i-1]
			drp=Rfs[i+1]-Ri
			r1=Ri-0.5*drm
			r2=Ri+0.5*drp
		elif i == LRFS-1:
			drm=Ri-Rfs[i-1]
			r1=Ri-0.5*drm
			r2=Ri
		
		I1fs=interpolate.interp1d(Rfs,Ifs,bounds_error=False,fill_value=0)(r1)
		I2fs=interpolate.interp1d(Rfs,Ifs,bounds_error=False,fill_value=0)(r2)
			
		FI1fs= int(floor(I1fs))
		CI1fs= int(ceil(I1fs))
		MI1fs= modf(I1fs)[0]
		
		FI2fs= int(floor(I2fs))
		CI2fs= int(ceil(I2fs))
		MI2fs= modf(I2fs)[0]
		
		if CI1fs == FI2fs:
			rrfs=array([r1,r2])
		else:
			RRfs=Rfs[CI1fs:FI2fs+1]
			rrfs=concatenate((array([r1]),RRfs,array([r2])))
		
		NRAWFSHlst.append(NatR(rrfs,Rfs,Nfs).mean(1))
		
		I1rs=interpolate.interp1d(Rrs,Irs,bounds_error=False,fill_value=0)(r1)
		I2rs=interpolate.interp1d(Rrs,Irs,bounds_error=False,fill_value=0)(r2)
		
		FI1rs= int(floor(I1rs))
		CI1rs= int(ceil(I1rs))
		MI1rs= modf(I1rs)[0]
		
		FI2rs= int(floor(I2rs))
		CI2rs= int(ceil(I2rs))
		MI2rs= modf(I2rs)[0]
		
		if CI1rs == FI2rs:
			rrrs=array([r1,r2])
		else:
			RRrs=Rrs[CI1rs:FI2rs+1]
			rrrs=concatenate((array([r1]),RRrs,array([r2])))
		
		NRAWRSHlst.append(NatR(rrrs,Rrs,Nrs).mean(1))
		
		NRAWFSH=float64(NRAWFSHlst).swapaxes(0,1)
		NRAWRSH=float64(NRAWRSHlst).swapaxes(0,1)
		NRAWSUM=NRAWFSH+NRAWRSH
		
#############
		NPRFSHlst=[]
		NPRRSHlst=[]
		
	for i in range(0,LRFS):
		ri=rfs[i]
		
		if i == 0:
			r1=0.0
			r2=0.5*dr1
		elif i > 0 and i < LRFS-1:
			drm=ri-rfs[i-1]
			drp=rfs[i+1]-ri
			r1=ri-0.5*drm
			r2=ri+0.5*drp
		elif i == LRFS-1:
			drm=ri-rfs[i-1]
			r1=ri-0.5*drm
			r2=ri
		
		I1fs=interpolate.interp1d(Rfs,Ifs,bounds_error=False,fill_value=0)(r1)
		I2fs=interpolate.interp1d(Rfs,Ifs,bounds_error=False,fill_value=0)(r2)
		
		FI1fs= int(floor(I1fs))
		CI1fs= int(ceil(I1fs))
		MI1fs= modf(I1fs)[0]
		
		FI2fs= int(floor(I2fs))
		CI2fs= int(ceil(I2fs))
		MI2fs= modf(I2fs)[0]
		
		if CI1fs == FI2fs:
			rrfs=array([r1,r2])
		else:
			RRfs=Rfs[CI1fs:FI2fs+1]
			rrfs=concatenate((array([r1]),RRfs,array([r2])))
		
		NPRFSHlst.append(NatR(rrfs,Rfs,Nfs).mean(1))
		
		I1rs=interpolate.interp1d(Rrs,Irs,bounds_error=False,fill_value=0)(r1)
		I2rs=interpolate.interp1d(Rrs,Irs,bounds_error=False,fill_value=0)(r2)
		
		FI1rs= int(floor(I1rs))
		CI1rs= int(ceil(I1rs))
		MI1rs= modf(I1rs)[0]
		
		FI2rs= int(floor(I2rs))
		CI2rs= int(ceil(I2rs))
		MI2rs= modf(I2rs)[0]
		
		if CI1rs == FI2rs:
			rrrs=array([r1,r2])
		else:
			RRrs=Rrs[CI1rs:FI2rs+1]
			rrrs=concatenate((array([r1]),RRrs,array([r2])))
		
		NPRRSHlst.append(NatR(rrrs,Rrs,Nrs).mean(1))
		
	NPRFSH=float64(NPRFSHlst).swapaxes(0,1)
	NPRRSH=float64(NPRRSHlst).swapaxes(0,1)
	NPRSUM=NPRFSH+NPRRSH
	
	FP=NPRFSH*dVfs
	RP=NPRRSH*dVfs
	
	NPTFSH=3.0*(FP).sum(1)		#3.0 ahead is to normalize by volume. if 1.0 then normalization is 4.0*pi*R^3
	NPTRSH=3.0*(RP).sum(1)
	NPTSUM=NPTFSH+NPTRSH
	
	NPDFSH=3.0*(FP)[:,0:FSI+1].sum(1)
	NPDRSH=3.0*(RP)[:,0:FSI+1].sum(1)
	NPDSUM=NPDFSH+NPDRSH
	
	NPUFSH=3.0*(FP)[:,FSI:].sum(1)
	NPURSH=3.0*(RP)[:,FSI:].sum(1)
	NPUSUM=NPUFSH+NPURSH
	
	NETFSH=NP2NE(NPTFSH,Pfs,crSpecies)
	NETRSH=NP2NE(NPTRSH,Pfs,crSpecies)
	NETSUM=NP2NE(NPTSUM,Pfs,crSpecies)
	
	NEDFSH=NP2NE(NPDFSH,Pfs,crSpecies)
	NEDRSH=NP2NE(NPDRSH,Pfs,crSpecies)
	NEDSUM=NP2NE(NPDSUM,Pfs,crSpecies)
	
	NEUFSH=NP2NE(NPUFSH,Pfs,crSpecies)
	NEURSH=NP2NE(NPURSH,Pfs,crSpecies)
	NEUSUM=NP2NE(NPUSUM,Pfs,crSpecies)
		
	fraw_s=open(crDataOut+"/SUM/S/"+crFileOut+timeInOut,"w")
	
	fnpr_f=open(crDataOut+"/SUM/F/"+"NPR"+timeInOut,"w")
	fnpr_r=open(crDataOut+"/SUM/R/"+"NPR"+timeInOut,"w")
	fnpr_s=open(crDataOut+"/SUM/S/"+"NPR"+timeInOut,"w")
	
	fner_f=open(crDataOut+"/SUM/F/"+"NER"+timeInOut,"w")
	fner_r=open(crDataOut+"/SUM/R/"+"NER"+timeInOut,"w")
	fner_s=open(crDataOut+"/SUM/S/"+"NER"+timeInOut,"w")
	
	fnpt_f=open(crDataOut+"/SUM/F/"+"NPT"+timeInOut,"w")
	fnpt_r=open(crDataOut+"/SUM/R/"+"NPT"+timeInOut,"w")
	fnpt_s=open(crDataOut+"/SUM/S/"+"NPT"+timeInOut,"w")
	
	fnet_f=open(crDataOut+"/SUM/F/"+"NET"+timeInOut,"w")
	fnet_r=open(crDataOut+"/SUM/R/"+"NET"+timeInOut,"w")
	fnet_s=open(crDataOut+"/SUM/S/"+"NET"+timeInOut,"w")
	
	fnpd_f=open(crDataOut+"/SUM/F/"+"NPD"+timeInOut,"w")
	fnpd_r=open(crDataOut+"/SUM/R/"+"NPD"+timeInOut,"w")
	fnpd_s=open(crDataOut+"/SUM/S/"+"NPD"+timeInOut,"w")
	
	fned_f=open(crDataOut+"/SUM/F/"+"NED"+timeInOut,"w")
	fned_r=open(crDataOut+"/SUM/R/"+"NED"+timeInOut,"w")
	fned_s=open(crDataOut+"/SUM/S/"+"NED"+timeInOut,"w")
	
	fnpu_f=open(crDataOut+"/SUM/F/"+"NPU"+timeInOut,"w")
	fnpu_r=open(crDataOut+"/SUM/R/"+"NPU"+timeInOut,"w")
	fnpu_s=open(crDataOut+"/SUM/S/"+"NPU"+timeInOut,"w")
	
	fneu_f=open(crDataOut+"/SUM/F/"+"NEU"+timeInOut,"w")
	fneu_r=open(crDataOut+"/SUM/R/"+"NEU"+timeInOut,"w")
	fneu_s=open(crDataOut+"/SUM/S/"+"NEU"+timeInOut,"w")
	
	fraw_s.write("N\n")
	fraw_s.write("x\ty\tN\n")
	
	for i in range(pStepsNum):
		for j in range(rStepsNumFS):
			
			fraw_s.write(str(rst[j])+" "+str(log(Pfs[i]))+" "+str(NRAWSUM[i][j]*Pfs[i])+"\n")
				
			fnpr_f.write(str(rfs[j])+" "+str(Pfs[i])+" "+str(NPRFSH[i][j])+"\n")
			fnpr_r.write(str(rfs[j])+" "+str(Pfs[i])+" "+str(NPRRSH[i][j])+"\n")
			fnpr_s.write(str(rfs[j])+" "+str(Pfs[i])+" "+str(NPRSUM[i][j])+"\n")
			
			fner_f.write(str(rfs[j])+" "+str(Efs[i])+" "+str(NP2NE(NPRFSH[i][j],Pfs[i],crSpecies))+"\n")
			fner_r.write(str(rfs[j])+" "+str(Efs[i])+" "+str(NP2NE(NPRRSH[i][j],Pfs[i],crSpecies))+"\n")
			fner_s.write(str(rfs[j])+" "+str(Efs[i])+" "+str(NP2NE(NPRSUM[i][j],Pfs[i],crSpecies))+"\n")
	
	fraw_s.close()
	
	fnpr_f.close()
	fnpr_r.close()
	fnpr_s.close()
	
	fner_f.close()
	fner_r.close()
	fner_s.close()
	
	for i in range(pStepsNum):
		fnpt_f.write(str(Pfs[i])+" "+str(NPTFSH[i])+"\n")
		fnpt_r.write(str(Pfs[i])+" "+str(NPTRSH[i])+"\n")
		fnpt_s.write(str(Pfs[i])+" "+str(NPTSUM[i])+"\n")
			
		fnet_f.write(str(Efs[i])+" "+str(NETFSH[i])+"\n")
		fnet_r.write(str(Efs[i])+" "+str(NETRSH[i])+"\n")
		fnet_s.write(str(Efs[i])+" "+str(NETSUM[i])+"\n")
		
		fnpd_f.write(str(Pfs[i])+" "+str(NPDFSH[i])+"\n")
		fnpd_r.write(str(Pfs[i])+" "+str(NPDRSH[i])+"\n")
		fnpd_s.write(str(Pfs[i])+" "+str(NPDSUM[i])+"\n")
		
		fned_f.write(str(Efs[i])+" "+str(NEDFSH[i])+"\n")
		fned_r.write(str(Efs[i])+" "+str(NEDRSH[i])+"\n")
		fned_s.write(str(Efs[i])+" "+str(NEDSUM[i])+"\n")
	
		fnpu_f.write(str(Pfs[i])+" "+str(NPUFSH[i])+"\n")
		fnpu_r.write(str(Pfs[i])+" "+str(NPURSH[i])+"\n")
		fnpu_s.write(str(Pfs[i])+" "+str(NPUSUM[i])+"\n")
		
		fneu_f.write(str(Efs[i])+" "+str(NEUFSH[i])+"\n")
		fneu_r.write(str(Efs[i])+" "+str(NEURSH[i])+"\n")
		fneu_s.write(str(Efs[i])+" "+str(NEUSUM[i])+"\n")

	
	fnpt_f.close()
	fnpt_r.close()
	fnpt_s.close()
	
	fnet_f.close()
	fnet_r.close()
	fnet_s.close()
	
	fnpd_f.close()
	fnpd_r.close()
	fnpd_s.close()
	
	fned_f.close()
	fned_r.close()
	fned_s.close()
	
	fnpu_f.close()
	fnpu_r.close()
	fnpu_s.close()
	
	fneu_f.close()
	fneu_r.close()
	fneu_s.close()
	
	print "crspe2: done!"


def main(argv=None):
	if argv is None: argv=sp.sys.argv
#	SP = sp.SimParams()
#	sp.SetupSimParams(SP,argv[1:])	

	if len(argv) > 2:
		SP = patron.setpar.SimParams()
		patron.setpar.SetupSimParams(SP,argv[1:])
		patron.setpar.WriteSimParams(SP)
	else:
		temp,pfile=argv[1].split("=")
		SP = patron.setpar.ReadSimParams(pfile)
	patron.setpar.InitSimulation(SP)
	
#	CFFS=sp.tecf.TranEqnCoeffFuncs(shockType="FSH",nhDensity=SP.nhdensity,expEnergy=SP.expenergy, crSpecies=SP.CRSPECIES,\
#                		mfProfile=SP.MFPROFILE,alfvDrift=SP.ALFVDRIFT, \
#				hdDataInp=SP.HDDATAINP,hdFileInp=SP.HDFILEINP,mfDataInp=SP.MFDATAINP, mfFileInp=SP.MFFILEINP)
#	RRS=CFFS.RRS(SP.timeinout)
	
	RRS=SP.FindRrs(hdDataInp=SP.HDDATAINP,timeInOut=SP.TIMEINOUT)
#	print "crspe2: time:",SP.timeinout,"reverse shock position:", RRS
	ConvertRaw2DatSUM(inFileNameRS=SP.CRINPFNRS,inFileNameFS=SP.CRINPFNFS,crDataOut=SP.CRDATAOUT,crFileOut=SP.CRFILEOUT,crSpecies=SP.CRSPECIES, \
	                   rStepsNumRS=SP.rstepsnumrs,rStepsNumFS=SP.rstepsnumfs,rCoordMaxRS=SP.rcoordmaxrs,rCoordMaxFS=SP.rcoordmaxfs,\
			   pStepsNum=SP.pstepsnum,RRS=RRS,timeInOut=SP.TIMEINOUT)

if __name__ == "__main__":SP.sys.exit(main())
