######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  crspe1.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2010 - 2015
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v2.0.0: renamed version of stable mkspe_v2.0.py
#v2.1.0: introducing main function to allow import as a module alone with independent run, functions renamed
#v2.2.0: parameters changed to work with global setpar module compliant with patron 2.2.x and higher
#v2.3.0: version control added, new initialization in standalone mode
#v2.3.1: patron.setpar.sys is used

__version__='2.3.1'

from numpy import exp
from numpy import sqrt
from numpy import size
from numpy import arange

import patron.setpar

pi  = 3.1415926
c   = 2.998e10							#speed of light in cm/s
m_e = 9.109e-28							#electron mass in grams
p_e = m_e*c							#electron momentum
m_p = 1.673e-24							#proton mass in grams
p_p = m_p*c							#proton momentum
m_he = 4.*m_p							#helium mass
p_he = m_he*c							#helium momentum
m_c = 12.*m_p							#carbon mass
p_c = m_c*c							#carbon momentum
m_ox = 16.*m_p							#oxygen mass
p_ox = m_ox*c							#oxygen momentum
m_fe = 56*m_p							#iron mass
p_fe = m_fe*c							#iron momentum
pc=3.08e18

def NP2NE(Ndlp,dimlesp,crSpecies):
	m=0
	if crSpecies == "EL":
		N=Ndlp/p_e
		p=dimlesp*p_e
		m=m_e
	elif crSpecies == "PR":
		N=Ndlp/p_p
		p=dimlesp*p_p
		m=m_p
	elif crSpecies == "HE":
		N=Ndlp/p_he
		p=dimlesp*p_he
		m=m_he
	elif crSpecies == "C":
		N=Ndlp/p_c
		p=dimlesp*p_c
		m=m_c
	elif crSpecies == "OX":
		N=Ndlp/p_ox
		p=dimlesp*p_ox
		m=m_ox
	elif crSpecies == "FE":
		N=Ndlp/p_fe
		p=dimlesp*p_fe
		m=m_fe
	return N/(0.624e3*((p*c**2)/sqrt(p**2*c**2 + m**2*c**4)))	#c 	#((p*c**2)/sqrt(p**2*c**2 + m**2*c**4))		#dN/dp -> dN/dE, E in GeV

def p2E(dimlesp,crSpecies):
	m=0
	if crSpecies == "EL":
		p=dimlesp*p_e
		m=m_e
	elif crSpecies == "PR":
		p=dimlesp*p_p
		m=m_p
	elif crSpecies == "HE":
		p=dimlesp*p_he
		m=m_he
	elif crSpecies == "C":
		p=dimlesp*p_c
		m=m_c
	elif crSpecies == "OX":
		p=dimlesp*p_ox
		m=m_ox
	elif crSpecies == "FE":
		p=dimlesp*p_fe
		m=m_fe
	return 0.624e3*(sqrt(p**2*c**2 + m**2*c**4)-m*c**2)	#p*c	#sqrt(p**2*c**2 + m**2*c**4) 			#p2E, E in GeV

def JAC(r,dr):
	return 3.0*(r - 1.0)**2 + 0.25*dr**2

def ConvertRaw2DatTDU(Rshw, Rmax, DRSTAR,inFileName,crSpecies,timeInOut):
	print "crspe1: producing CR spectra for total, down-, and upstream regions..."
	crDataOut="/".join(inFileName.split("/")[:-1])
	TIME=timeInOut
	
	NPT=0.0
	NPD=0.0
	NPU=0.0
	
	try:
		fraw=open(inFileName,"r")
		FRAW=fraw.readlines()
		LEN=len(FRAW)-2
		fnpr=open(crDataOut+"/"+"NPR"+TIME,"w")
		fner=open(crDataOut+"/"+"NER"+TIME,"w")
		fnpt=open(crDataOut+"/"+"NPT"+TIME,"w")
		fnpd=open(crDataOut+"/"+"NPD"+TIME,"w")
		fnpu=open(crDataOut+"/"+"NPU"+TIME,"w")
		fnet=open(crDataOut+"/"+"NET"+TIME,"w")
		fned=open(crDataOut+"/"+"NED"+TIME,"w")
		fneu=open(crDataOut+"/"+"NEU"+TIME,"w")

		for i in range(0,LEN):
		#for row in fraw:
		#	(a,b,c)=row.split()
			(a,b,c)=FRAW[i+2].split()
			RSTAR=float(a)
			R=1.0+(RSTAR-1.0)**3
			lnp=float(b)
			P=exp(lnp)
			NPR=float(c)/(P)
			fnpr.write(str(R)+" "+str(P)+" "+str(NPR)+"\n")
			
			E=p2E(P,crSpecies)
			NER=NP2NE(NPR,P,crSpecies)
			fner.write(str(R)+" "+str(E)+" "+str(NER)+"\n")

			if R <= 1.0+(Rmax-1.0)**3: #Rmax:
				NPT=NPT+NPR*(R**2)*JAC(RSTAR,DRSTAR)*(DRSTAR)
				if R == 1.0+(Rmax-1.0)**3: #Rmax:
					fnpt.write(str(P)+" "+str(3.0*NPT/R**3)+"\n")
					E=p2E(P,crSpecies)
					NET=NP2NE(NPT,P,crSpecies)
					fnet.write(str(E)+" "+str(3.0*NET/R**3)+"\n")
					NPT=0.0
			
			if R <= Rshw:
				NPD=NPD+NPR*(R**2)*JAC(RSTAR,DRSTAR)*(DRSTAR)	
				#NPD=NPD+NPR*(R**2)*(DRSTAR)	
				if R == Rshw:
					fnpd.write(str(P)+" "+str(3.0*NPD)+"\n")
					E=p2E(P,crSpecies)
					NED=NP2NE(NPD,P,crSpecies)
					fned.write(str(E)+" "+str(3.0*NED)+"\n")
					NPD=0.0
			
			if R > Rshw:
				NPU=NPU+NPR*(R**2)*JAC(RSTAR,DRSTAR)*(DRSTAR)
				if R == 1.0+(Rmax-1.0)**3: #Rmax:
					fnpu.write(str(P)+" "+str(3.0*NPU/(R**3-1.0))+"\n")
					E=p2E(P,crSpecies)
					NEU=NP2NE(NPU,P,crSpecies)
					fneu.write(str(E)+" "+str(3.0*NEU/(R**3-1.0))+"\n")
					NPU=0.0
	
		fraw.close()
		fnpr.close()
		fner.close()
		fnpt.close()
		fnpd.close()
		fnpu.close()
		fnet.close()
		fned.close()
		fneu.close()

		print "crspe1: done!"
	except IOError:
		print "crspe1: no input file!!!", inFileName

def ConvertRaw2DatR12(R1,R2,DRSTAR,inFileName,crSpecies,timeInOut):
	print "crspe1: producing CR spectra for the shell region..."
	crDataOut="/".join(inFileName.split("/")[:-1])
	TIME=timeInOut
	
	NPS=0.0
	
	if R1 >= 1.0: RSTAR1=(R1-1.0)**(1/3.)+1.0
	else:         RSTAR1=-(abs(R1-1.0))**(1/3.)+1.0
	
	if R2 >= 1.0: RSTAR2=(R2-1.0)**(1/3.)+1.0
	else:         RSTAR2=-(abs(R2-1.0))**(1/3.)+1.0
	
	print "crspe1: R1(RSTAR1)=",R1,"(",RSTAR1,")","R2(RSTAR2)=",R2,"(",RSTAR2,")"
	
	try:
		fraw=open(inFileName,"r")
		FRAW=fraw.readlines()
		LEN=len(FRAW)-2
		fps=open(crDataOut+"/"+"NPS"+TIME,"w")
		fes=open(crDataOut+"/"+"NES"+TIME,"w")
		
		for i in range(0,LEN):
		#for row in fraw:
		#	(a,b,c)=row.split()
			(a,b,c)=FRAW[i+2].split()
			RSTAR=float(a)
			R=1.0+(RSTAR-1.0)**3
			lnp=float(b)
			P=exp(lnp)
			N=float(c)/(P)
			
			if (RSTAR1 < RSTAR) and (RSTAR <= RSTAR2):
				NPS=NPS+N*(R**2)*JAC(RSTAR,DRSTAR)*(DRSTAR)
				if abs(RSTAR-RSTAR2) <= DRSTAR:
					fps.write(str(P)+" "+str(3.0*NPS/(R2**3-R1**3))+"\n")
					E=p2E(P,crSpecies)
					NES=NP2NE(NPS,P,crSpecies)
					fes.write(str(E)+" "+str(3.0*NES/(R2**3-R1**3))+"\n")
					NPS=0.0
#				
				
		fps.close()
		fes.close()
		print "crspe1: range done!!!"
	except IOError:
		print "crspe1: no input file!!!", inFileName	

def main(argv=None):
	if argv is None: argv=patron.setpar.sys.argv
#	SP = sp.SimParams()
#	sp.SetupSimParams(SP,argv[1:])	

	if len(argv) > 2:
		SP = patron.setpar.SimParams()
		patron.setpar.SetupSimParams(SP,argv[1:])
		patron.setpar.WriteSimParams(SP)
	else:
		temp,pfile=argv[1].split("=")
		SP = patron.setpar.ReadSimParams(pfile)
	patron.setpar.InitSimulation(SP)

	dr=SP.rcoordmax/SP.rstepsnum
	RM=SP.rcoordmax
	
	R1=SP.rspenorm1
	R2=SP.rspenorm2
	
	if R1 != R2:
		ConvertRaw2DatR12(R1,R2,dr,inFileName=SP.CRINPFN,crSpecies=SP.CRSPECIES,timeInOut=SP.TIMEINOUT)
	else:
		ConvertRaw2DatTDU(1.,RM,dr,inFileName=SP.CRINPFN,crSpecies=SP.CRSPECIES,timeInOut=SP.TIMEINOUT)

if __name__ == "__main__":patron.setpar.sys.exit(main())
