######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  crtran.py									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2010 - 2015
#         Robert Brose <robert.brose@desy.de>, 2013 - 2016
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#new version tracking start with 2.0.0; the last version of pspec2d is 19.2
#v2.0.0: transport equation object is implemented
#v2.1.0: accepts all needed functions as an object parameter
#v2.1.1: dependence of SetupEquation on external diffusion coefficient is implemented to couple with turbulence TE; method allowing for external sweeping added
#v2.1.2: methods setting new diffusion term of transport equation added
#v2.2.0: parameters renamed and reordered to comply with patron v2.2.0; bugfix CRBKG to work with RSH
#v2.3.0: adding SOFA for SS shock (version given to Alina)
#v2.4.0: adding switching on/off equation terms (involved some fipy variables re-arrangements); adding SOFA for PP shock
#v2.5.0: adding inverse Compton losses
#v2.6.0: version control added
#v2.6.1: Adaptive time step improved
#v2.7.0: DoTimeIntervall introduced
#v2.7.1: Added GetLogValues and helper functions therefore
#v2.7.2: Removed compression of CRBK inside the remnant

__version__='2.721'

import sys
import fipy as fipy
from fipy.tools import parallel
from fipy.tools.numerix import exp
from fipy.tools.numerix import sqrt
from fipy.tools.numerix import diff
from fipy.tools.numerix import array
from fipy.tools.numerix import where
from fipy.tools.numerix import arange
from fipy.tools.numerix import concatenate
from fipy.tools.numerix import *
from numpy import pi

yr  = 3.156e+7
c   = 2.998e10
m_p = 1.673e-24
m_e = 9.109e-28
m_he = 4.*m_p
m_c = 12.*m_p
m_ox = 16.*m_p
m_fe = 56.*m_p

class TransportEquation:
	def __init__(self,rStepsNum,pStepsNum,rCoordMax,pCoordMax,timeInit,shockGeom,crInitCon,inFileName,teCoeffFuncs):
		if parallel.procID == 0: print "crtran: initializing transport equations object..."
		
		self.tecf    = teCoeffFuncs
		
		self.rshw    = 1.0
		
		self.nrsteps = rStepsNum
		self.npsteps = pStepsNum
		self.rmax    = rCoordMax
		self.pmax    = pCoordMax
		self.dr      = rCoordMax/float(rStepsNum)
		self.dp      = pCoordMax/float(pStepsNum)
		
		self.mesh_rp = fipy.Grid2D(dx=self.dr,dy=self.dp,nx=self.nrsteps,ny=self.npsteps)+((self.dr/2.,),(-self.pmax/4.,))
		
		self.rc,self.pc = self.mesh_rp.cellCenters
		self.rf,self.pf = self.mesh_rp.faceCenters
		
		self.rcv     = self.mesh_rp.cellCenters[0]
		self.pcv     = self.mesh_rp.cellCenters[1]
		
		self.Rc      = self.R(self.rc)
		self.Rf      = self.R(self.rf)
		self.Jc      = self.J(self.rc,self.dr)
		self.Jf      = self.J(self.rf,self.dr)
		
		self.Left    = self.mesh_rp.facesLeft
		self.Right   = self.mesh_rp.facesRight
		self.Bottom  = self.mesh_rp.facesBottom
		self.Top     = self.mesh_rp.facesTop
		
		#initial time has to agree with Plutos initial time: check if simulation is continued, otherwise Pluto is at time=0	
		if self.tecf.SP.timecont != None:
			timeStart = float(self.tecf.SP.timecont)
		elif teCoeffFuncs.SP.usesedsol == 5:
			timeStart = 0 
		else:
			timeStart = timeInit

		
		if   shockGeom == "SS":
			self.SetupEquation = self.SetupEquation_SS
			self.SetupDiffTerm = self.SetupDiffTerm_SS
			if parallel.procID == 0: print "crtran: shock geometry spherically-symmetric"
		elif shockGeom == "PP":
			self.SetupEquation = self.SetupEquation_PP
			self.SetupDiffTerm = self.SetupDiffTerm_PP
			if parallel.procID == 0: print "crtran: shock geometry plane-parallel"

		if   inFileName == "":
			self.D       = self.tecf.Dgln(self.rf,self.pf,timeStart)
		else:
			self.D       = self.tecf.Dln(self.rf,self.pf,timeStart)
		
		self.CFL_D   = fipy.FaceVariable(mesh=self.mesh_rp, rank=2)
		
		#Additional stuff
		if   self.tecf.crSpecies == "PR":
			self.pm=m_p*c
		elif self.tecf.crSpecies == "EL":
			self.pm=m_e*c
		elif self.tecf.crSpecies == "HE":
			self.pm=m_he*c
		elif self.tecf.crSpecies == "C":
			self.pm=m_c*c
		elif self.tecf.crSpecies == "OX":
			self.pm=m_ox*c
		elif self.tecf.crSpecies == "FE":
			self.pm=m_fe*c
	
		self.SetupVariable(timeStart,crInitCon,inFileName)
		self.SetupBoundCon(timeStart,crInitCon)
		self.SetTranEqTerm("AllTerms","On")
		#self.SetTranEqTerm(termName,status)
		#self.SetTranEqTerm("SynchrotronLosses","Off")
		#self.SetTranEqTerm("InverseComptonLosses","Off")
		
		self.SetupEquation(timeStart,self.D)

		self.solver  = fipy.DefaultAsymmetricSolver(tolerance=1e-16)
		self.viewer  = fipy.TSVViewer(vars=(self.N))

		self.tecf.SetSrcSclPar(self.ScP(timeStart,self.tecf.SP.injsclindex))
 		
		if parallel.procID == 0: print "crtran: transport equations object is initialized."
			
	
	#coordinate transformation
	def R(self,rstar):
		return (rstar-1.0)**3+1.0
	
	#descrete jacobian; otherwise 0 at rstar = 1
	def J(self,rstar,dr):
		return 3.0*(rstar-1.0)**2+0.25*dr**2
	
	#method setups the solution variable
	def SetupVariable(self,t,crInitCon,inFileName):
		if inFileName == "":
			if   crInitCon == "NOBKG":
				self.N = fipy.CellVariable(mesh=self.mesh_rp, name = "N", value=0.0, hasOld=1)
			elif crInitCon == "CRBKG":
				self.N = fipy.CellVariable(mesh=self.mesh_rp, name = "N", value=0.0, hasOld=1)
				self.N.setValue(1.0*self.tecf.Nbkgln(self.pc),where=(self.rc<=self.rshw*self.tecf.RFS(t)+self.dr/3.))
				self.N.setValue(self.tecf.Nbkgln(self.pc),    where=(self.rc> self.rshw*self.tecf.RFS(t)+self.dr/3.))
				self.N.updateOld()
		else:
			try:
				f=open(inFileName,"r")
				RPN=f.readlines()
				f.close()
			except IOError:
				if parallel.procID == 0: print "crtran: no file found:",inFileName
				sys.exit(0)
			if parallel.procID == 0: print "crtran: reading...", inFileName
			LEN=len(RPN)-2
			NN=arange(LEN,dtype=float)
			for i in range(0,LEN):
				(rrr,ppp,NNN)=RPN[i+2].split()
				NN[i]=float(NNN)
			if parallel.procID == 0: print "crtran: reading is done"
			self.N = fipy.CellVariable(mesh=self.mesh_rp, name = "N", value=NN, hasOld=1)
			if parallel.procID == 0: print "crtran: variable is set"
	
	#method writes the solution variable to file
	def WriteVariable(self,t,timesOut,outFileName):
		for time in timesOut:
			#if (time == t):
			if round(time - t,5) == 0:
				#TIME=str(int(time)).zfill(5)
				TIME=str(time)
				fname=outFileName+TIME
				if parallel.procID == 0: print "crtran: writing file", fname, "\n"
				self.viewer.plot(filename=fname)
	
	#method setups boundary conditions for the solution variable
	def SetupBoundCon(self,t,crInitCon):
		#self.N.faceGrad.constrain(0.0,self.Left) #together with (zero) diff-conv. coefficients is more proper new way to constrain flux through boundary
		if   crInitCon == "NOBKG":
			self.N.constrain(self.N.faceValue(),              self.Left)	#old style (fipy 2.0) zero-grad constraint
			self.N.constrain(0.0,                             self.Right)
			self.N.constrain(0.0,                             self.Bottom)
			self.N.constrain(0.0,                             self.Top)
		elif crInitCon == "CRBKG":
			self.N.constrain(self.N.faceValue(),              self.Left)
			self.N.constrain(self.tecf.Nbkgln(self.pf),       self.Right)
			self.N.constrain(self.N.faceValue(),              self.Bottom)
			self.N.constrain(self.tecf.Nbkgln(self.pf),       self.Top)		#max*0.75
	
	def SetTranEqTerm(self,termName,status):
		if status == "On":
			statusConst = 1.0
		elif status == "Off":
			statusConst = 0.0
		else:
			if parallel.procID == 0: print "crtran: terms status undefined"
			sys.exit(0)
		
		if   termName == "AllTerms":
			self.tranTerm = statusConst
			self.injecSrc = statusConst
			self.spacConv = statusConst
			self.spacDiff = statusConst
			self.fermiAc1 = statusConst
			self.fermiAc2 = statusConst
			self.synchLos = statusConst
			self.iCompLos = statusConst
		elif termName == "TransientTerm":
			self.tranTerm = statusConst
		elif termName == "Injection":
			self.injecSrc = statusConst
		elif termName == "SpacialConvection":
			self.spacConv = statusConst
		elif termName == "SpacialDiffusion":
			self.spacDiff = statusConst
		elif termName == "FermiAcceleration1":
			self.fermiAc1 = statusConst
		elif termName == "FermiAcceleration2":
			self.fermiAc2 = statusConst
		elif termName == "SynchrotronLosses":
			self.synchLos = statusConst
		elif termName == "InverseComptonLosses":
			self.iCompLos = statusConst
		
		if parallel.procID == 0: print "crtran:",termName,"set to",status
	
	#method setups spherically-symmetric CR transport equation
	def SetupEquation_SS(self,t,Dx):
		if parallel.procID == 0: print "crtran: setting up equation for time",t
		
		Q           = fipy.CellVariable(mesh=self.mesh_rp)
		isrcCoeff   = fipy.CellVariable(mesh=self.mesh_rp)
		tranCoeff   = fipy.CellVariable(mesh=self.mesh_rp)
		v           = fipy.FaceVariable(mesh=self.mesh_rp, rank=1)
		convCoeff   = fipy.FaceVariable(mesh=self.mesh_rp, rank=1)
		diffCoeff   = fipy.FaceVariable(mesh=self.mesh_rp, rank=2)
		
		lnpi        = fipy.numerix.log(self.tecf.pinj(t))
		ainv        = self.tecf.Rsh(t)**(-1)
		adot        = self.tecf.Vsh(t)
		
		Dp          = self.tecf.Dpln(self.rf,self.pf,t) 
		
		tranCoeff.setValue(self.tranTerm*self.Jc*self.Rc**2)					#transient term coefficient
		
		isrcCoeff.setValue(self.spacConv*3.0*adot*ainv*self.Jc*self.Rc**2)			#implicit source coefficient due to co-moving frame
		
		Q.setValue(0.0)										#source term

		Q.setValue(self.injecSrc*self.tecf.Q0(t)*self.Rc**2*ainv/(self.dr*self.dp),
		    where=(self.rc>=self.rshw-self.dr/3.) & (self.rc<=self.rshw+self.dr/3.)
		        & (self.pc>=     lnpi-self.dp/2.) & (self.pc<=     lnpi+self.dp/2.))
		v.setValue(self.tecf.Vlhsrs(self.rf,t), where=(self.rf<=self.rshw+self.dr/3.))
		v.setValue(self.tecf.Vrhsrs(self.rf,t), where=(self.rf> self.rshw+self.dr/3.))
		v[1] = 0.0
		
		divVr2c = (v*self.Rf**2).divergence
		divVr2f = divVr2c.arithmeticFaceValue()
		
		#Check if weird stuff hapens: get compression ratio from log-function
		description, values = self.GetLogValue(t)
		#if values[2] >= 4.75:
		#	if parallel.procID == 0: print "crtran: compression-ratio exceeds 4.75 at time=",t, "\n\t Diasabeling injection and acceleration term"
		#if (t>2.5 and t<3.0) or (t>3.5 and t<4.0):
		#	divVr2f = divVr2f*0
		#	Q.setValue(0.0)

		#Debugging
		#divVr2f = where(self.rf > 0.8,divVr2f,0) # --> still compression(?) at the RS
		
		convCoeff[0]   = self.spacConv*(-ainv*v[0]*self.Rf**2 + adot*ainv*self.Rf**3)		#spatial convection coefficient: flow velocity + term due to co-moving frame
		convCoeff[1]   = (									#energy  convection coefficient:
			 	 self.fermiAc1*ainv*divVr2f/3.						#Fermi I  acceleration
			       - self.fermiAc2*3.0*Dp*self.Jf*self.Rf**2				#Fermi II acceleration
			       + self.synchLos*self.tecf.Lsln(self.rf,self.pf,t)*self.Jf*self.Rf**2	#synchrotron losses
			       + self.iCompLos*self.tecf.Lcln(self.rf,self.pf,t)*self.Jf*self.Rf**2)	#inverse Compton losses
			       
		diffCoeff[0,0] = self.spacDiff*Dx*ainv**2/self.Jf*self.Rf**2				#spacial diffusion coefficient
		diffCoeff[0,1] = 0.0
		diffCoeff[1,0] = 0.0
		diffCoeff[1,1] = self.fermiAc2*Dp*self.Jf*self.Rf**2					#energy  diffusion coefficient (Fermi II)
		
		
                self.TranTerm = fipy.TransientTerm(tranCoeff)
		self.DiffTerm = fipy.ImplicitDiffusionTerm(diffCoeff)
		self.ConvTerm = fipy.PowerLawConvectionTerm(convCoeff)
		self.QsrcTerm = Q
		self.IsrcTerm = fipy.ImplicitSourceTerm(isrcCoeff)
		
		self.TranEqn = self.TranTerm == self.DiffTerm + self.ConvTerm + self.QsrcTerm - self.IsrcTerm
	
	#method setups plane-parallel CR transport equation
	def SetupEquation_PP(self,t,Dx):
		if parallel.procID == 0: print "crtran: setting up equation for time",t
		
		Q           = fipy.CellVariable(mesh=self.mesh_rp)
		isrcCoeff   = fipy.CellVariable(mesh=self.mesh_rp)
		tranCoeff   = fipy.CellVariable(mesh=self.mesh_rp)
		v           = fipy.FaceVariable(mesh=self.mesh_rp, rank=1)
		convCoeff   = fipy.FaceVariable(mesh=self.mesh_rp, rank=1)
		diffCoeff   = fipy.FaceVariable(mesh=self.mesh_rp, rank=2)
	
		lnpi        = fipy.numerix.log(self.tecf.pinj(t))
		ainv        = self.tecf.Rsh(t)**(-1)
		adot        = self.tecf.Vsh(t)
		
		Dp          = self.tecf.Dpln(self.rf,self.pf,t) 
		
		tranCoeff.setValue(self.tranTerm*self.Jc)						#transient term coefficient
		
		isrcCoeff.setValue(self.spacConv*adot*ainv*self.Jc)					#implicit source coefficient due to co-moving frame
		
		Q.setValue(0.0)										#source
		Q.setValue(self.injecSrc*self.tecf.Q0(t)*ainv/(self.dr*self.dp),
		    where=(self.rc>=self.rshw-self.dr/3.) & (self.rc<=self.rshw+self.dr/3.)
		        & (self.pc>=     lnpi-self.dp/2.) & (self.pc<=     lnpi+self.dp/2.))
		
		v.setValue(self.tecf.Vlhsrs(self.rf,t), where=(self.rf<=self.rshw+self.dr/3.))
		v.setValue(self.tecf.Vrhsrs(self.rf,t), where=(self.rf> self.rshw+self.dr/3.))
		v[1] = 0.0
		
		divVc = v.divergence
		divVf = divVc.arithmeticFaceValue()
		
		#Check if weird stuff hapens: get compression ratio from log-function
		description, values = self.GetLogValue(t)
		#if values[2] >= 4.75:
		#	if parallel.procID == 0: print "crtran: compression-ratio exceeds 4.75 at time=",t, "\n\t Diasabeling injection and acceleration term"
		#	divVf = divVf*0
		#	Q.setValue(0.0)
				
		
		convCoeff[0]   = self.spacConv*(-ainv*v[0] + adot*ainv*self.Rf)				#spatial convection coefficient: flow velocity + term due to co-moving frame
		convCoeff[1]   = (									#energy  convection coefficient:
			 	 self.fermiAc1*ainv*divVf/3.						#Fermi I  acceleration
			       - self.fermiAc2*3.0*Dp*self.Jf						#Fermi II acceleration
			       + self.synchLos*self.tecf.Lsln(self.rf,self.pf,t)*self.Jf)		#synchrotron losses
	        
		diffCoeff[0,0] = self.spacDiff*Dx*ainv**2/self.Jf					#spacial diffusion coefficient
		diffCoeff[0,1] = 0.0
		diffCoeff[1,0] = 0.0
		diffCoeff[1,1] = self.fermiAc2*Dp*self.Jf						#energy  diffusion coefficient (Fermi II)
		
		
		self.TranTerm = fipy.TransientTerm(tranCoeff)
		self.DiffTerm = fipy.ImplicitDiffusionTerm(diffCoeff)
		self.ConvTerm = fipy.PowerLawConvectionTerm(convCoeff)
		self.QsrcTerm = Q
		self.IsrcTerm = fipy.ImplicitSourceTerm(isrcCoeff)
		
		self.TranEqn = self.TranTerm == self.DiffTerm + self.ConvTerm + self.QsrcTerm - self.IsrcTerm
	
	#method setups just diffusion term of spherically-symmetric CR transport equation keeping other terms unchanged
	def SetupDiffTerm_SS(self,t,Dx):
		if parallel.procID == 0: print "crtran: setting up diffusion term for time",t
		diffCoeff = fipy.FaceVariable(mesh=self.mesh_rp, rank=2)
		ainv      = self.tecf.Rsh(t)**(-1)
		Dp        = self.tecf.Dpln(self.rf,self.pf,t) 
		
		diffCoeff[0,0] = self.spacDiff*Dx*ainv**2/self.Jf*self.Rf**2				#spacial diffusion coefficient
		diffCoeff[0,1] = 0.0
		diffCoeff[1,0] = 0.0
		diffCoeff[1,1] = self.fermiAc2*Dp*self.Jf*self.Rf**2					#energy  diffusion coefficient (Fermi II)
		
		self.DiffTerm = fipy.ImplicitDiffusionTerm(diffCoeff)
		self.TranEqn = self.TranTerm == self.DiffTerm + self.ConvTerm + self.QsrcTerm - self.IsrcTerm
	
	#method setups just diffusion term of plane-parallel CR transport equation keeping other terms unchanged
	def SetupDiffTerm_PP(self,t,Dx):
		if parallel.procID == 0: print "crtran: setting up diffusion term for time",t
		diffCoeff = fipy.FaceVariable(mesh=self.mesh_rp, rank=2)
		ainv      = self.tecf.Rsh(t)**(-1)
		Dp        = self.tecf.Dpln(self.rf,self.pf,t) 
		
		diffCoeff[0,0] = self.spacDiff*Dx*ainv**2/self.Jf					#spacial diffusion coefficient
		diffCoeff[0,1] = 0.0
		diffCoeff[1,0] = 0.0
		diffCoeff[1,1] = self.fermiAc2*Dp*self.Jf						#energy  diffusion coefficient (Fermi II)
		
		self.DiffTerm = fipy.ImplicitDiffusionTerm(diffCoeff)
		self.TranEqn = self.TranTerm == self.DiffTerm + self.ConvTerm + self.QsrcTerm - self.IsrcTerm
	
	#method makes one time step with dt=timeStep
	def DoOneTimeStep(self,t,timeStep):
		if parallel.procID == 0: 
			sys.stdout.write('crtran: making step from time {0:6.4f} to time {1:6.4f}, '.format(t,t+timeStep))
		lim = 1e-2
		nsw = 1
		res = 1e4
		while res > lim and nsw<10:
			res = self.TranEqn.sweep(solver=self.solver,var=self.N,dt=timeStep)
			if parallel.procID == 0: sys.stdout.write('swept {0:d} time(s), res={1:e}\n'.format(nsw,float(res)))
			nsw=nsw+1
			if nsw == 10:
				if parallel.procID == 0:
					print "crtran: WARNING - residuals above defined limits!"
						
	def DoTimeIntervall(self,time,timeEnd,timelist):
		if parallel.procID == 0: print "crtran: Doing time-intervall from ",time, " to ", timeEnd
		time_1 = time		
		while time_1 < timeEnd:
			step = min(self.AdaptTimeStep(time_1,timelist),timeEnd-time_1)
			self.DoOneTimeStep(time_1,step)
			self.N.updateOld()
			time_1 += step
			self.EvalDiffCoeff(time_1) #needed?
			self.SetupEquation(time_1,self.D) 
		if parallel.procID == 0: print "crtran: Reached final Intervall-time: ", time_1	


	#method makes one sweep within dt=timeStep
	def DoOneSweep(self,t,timeStep):
		return self.TranEqn.sweep(solver=self.solver,var=self.N,dt=timeStep)
	
	#method solves transport equation and writes solution variable at predefined steps
	def SolveEquation(self,timeInit,timeStop,timeStepInit,timesOut,outFileName):
		time = timeInit
		timeStep = timeStepInit
		while time <= timeStop:
			self.WriteVariable(time,timesOut,outFileName)
			self.DoOneTimeStep(time,timeStep)
			self.N.updateOld()
			time=time+timeStep
			self.SetupEquation(time,self.D)
			timeStep=self.AdaptTimeStep(time)
	
	#simple method to adapt timeStep to given time
	def AdaptTimeStep(self,t,timelist):
		timestep = 0.01
		timenext = min(where(timelist-t>0,timelist,1e7))
		if t < 0.1:
			timestep = 0.002
		elif t >= 0.1 and t < 1.0:
			timestep = 0.01
		elif t >= 1.0 and t < 10.0:
			timestep = 0.05 #0.25
		elif t >= 10.0 and t < 20.0:
			timestep = 0.25		
		elif t >= 20.0 and t < 50.0:
			timestep = 1.0
		elif t >= 50.0  and t < 100.0:
			timestep = 5.0
		elif t >= 100.0 and t < 1000.0:
			timestep = 25.0
		elif t >= 1000.0:
			timestep = 50.0
		#timestep = 1.0
		if (t+timestep)>timenext:
			timestep = timenext-t
		return timestep

	#For Olehs stuff
#	def AdaptTimeStep(self,t,timelist):
#		timestep = 1.0e-3
#		timenext = min(where(timelist-t>0,timelist,1e7))
#
#		if t < 50.0:
#			timestep = 1.0e-2
#		elif t >= 50.0  and t < 100.0:
#			timestep = 5.0e-2
#		elif t >= 100.0 and t < 1000.0:
#			timestep = 25.0e-2
#		elif t >= 1000.0:
#			timestep = 50.0e-2
#		if (t+timestep)>timenext:
#			timestep = timenext-t
#		return timestep	

	def EvalDiffCoeff(self,t):
		if parallel.procID == 0: print "crtran: evaluating diffusion coefficient for time", t
		self.D = self.tecf.Dln(self.rf,self.pf,t)
	
	#cosmic rays' pressure at shock
	def CRsPressShock(self):
		p_p = self.pm	
		lnp = arange(0,self.pmax,self.dp)-self.pmax/4.
		p   = exp(lnp)
		zero= array([0.0])
		dp  = concatenate((diff(p),zero))
#		Nsh = self.N(((1.0,),lnp))
		Nsh = self.N.globalValue[where(self.rcv.globalValue==1.0)]
		f   = Nsh*c*p/(p**2+1.0)**0.5
		crp = p_p*(f*dp).sum()/3.
		return crp

	#Total energy in cosmic rays's;
	#No background subtraction
	def CRsEnergy(self,t):
		p_p = self.pm
		rp  = self.mesh_rp.cellCenters
		lnp = rp.globalValue[1]
		p   = exp(lnp)	
		rs  = rp.globalValue[0]
		r_l = ((rs-self.dr-1)**3.+1)*self.tecf.Rsh(t)
		r_r = ((rs+self.dr-1)**3.+1)*self.tecf.Rsh(t)
		V   = 4/3.*pi*(r_r**3.-r_l**3.)
		dp  = exp(lnp+self.dp/2.)-exp(lnp-self.dp/2.)
		N   = self.N.globalValue
		f   = N*c*p/(p**2+1.0)**0.5	#Not kinetic energy, so maybe wrong by a factor of 2...
		cre = p_p*(f*dp*V).sum()
		return cre

	def GetLogValue(self,t):
		log_description = ["CR Pressure at shock",\
	  			   "P_cr/P_ram",\
				   "Compression ratio",\
				   "Total energy in CRs",\
				   "Shock radius",\
				   "Shock speed",\
				   "Upstream density",\
				   "Temperature at shock",\
				   "Upstream magnetic field",\
				   "Downstream magnetic field",\
				   "Injection efficency"]

		log_values	= zeros(len(log_description))
		#Assign values		
		#CR pressure
		log_values[0]	= self.CRsPressShock()
		#Pressure ratio
		log_values[1]	= self.CRsPressShock()/(0.25*self.tecf.rho(array([1.0]),t)*self.tecf.Vsh(t)**2./yr**2.)
		#Compression ratio
		try:	
			log_values[2]	= (self.tecf.Vsh(t)-self.tecf.Vrhsrs((1.+2.*self.dr),t))/(self.tecf.Vsh(t)-self.tecf.Vlhsrs((1.-2*self.dr),t)) #Modify later
		except:
			log_values[2]	= 4 #Problem when used without hydro
		#Total CR energy
		log_values[3]	= self.CRsEnergy(t)
		#Shock radius
		log_values[4]	= self.tecf.Rsh(t)
		#Shock speed
		log_values[5]	= self.tecf.Vsh(t)/yr
		#Upstream density
		log_values[6]	= self.tecf.nh_u(t)
		#Temperature at shock
		log_values[7]	= self.tecf.Tg_sh(t)
		#Upstream field
		log_values[8]	= self.tecf.B(array([1+6e-5]),t)	
		#Downstream field
		log_values[9]	= self.tecf.B(array([1-6e-5]),t)
		#Injection efficiency
		log_values[10]	= self.tecf.eta_i(t,self.tecf.InP)
		return log_description,log_values
		

	def ScP(self,t,index):
		crinittime = self.tecf.SP.crinittime
		ramp	   = self.tecf.SP.ramptime #0.009
		#return self.tecf.injSclPar*((t+1e-16)/(crinittime))**-index
		#return self.tecf.injSclPar*(1-exp((crinittime-t)/ramp))*((t+1e-16)/(crinittime))**-index
		if t < crinittime+ramp:
			return 10**(-3+3*(t-crinittime)/ramp)*self.tecf.injSclPar*((t+1e-16)/(crinittime))**-index
		else:
			return self.tecf.injSclPar*((t+1e-16)/(crinittime))**-index	


