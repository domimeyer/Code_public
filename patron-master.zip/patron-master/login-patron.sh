#!/bin/bash
######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  login-patron.sh									
# Author: Igor Telezhinsky <telezhinsky@gmail.com>, 2014 - 2015
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v1.1.0: login (initialization) script for patron code
#v1.1.1: changed for cluster compability

SCRIPTPATH="${BASH_SOURCE[0]}"

#echo "Script path: ${SCRIPTPATH}"
#SCRIPTDIR="$(cd "$(dirname "${SCRIPTPATH}")" ; pwd)"
#echo "Script path: ${SCRIPTDIR}/$(basename "${SCRIPTPATH}")"

SCRIPTDIR=`dirname ${SCRIPTPATH}`

#echo "Script dir: ${SCRIPTDIR}"
USEMODE=${1}
#PATHDIR=${2}
PATHDIR=${2:-${SCRIPTDIR}}

echo "USEMODE",${USEMODE}
echo "PATHDIR",${PATHDIR}

if [ "${USEMODE}" == "" -o "${PATHDIR}" == "" ];then
	echo "---"
	echo "Please provide a user mode as the first parameter and"
	echo "the directory of PATRON code as the second parameter!"
	echo "source login-patron.sh --[user|developer] --path/to/patron"
	echo "If the current script is in the desired PATRON directory,"
	echo "you may omit the second argument."
	echo "---"
	return
fi

export PATRONDIR=`echo ${PATHDIR} | sed 's/--//g'`

if [ "${THAT}" == "" ];then
	echo "---"
	echo "Please login to THAT group environment and initialize"
	echo "your Python Virtual Environment!"
	echo "---"
fi

unlink ${PATRONDIR}/data/snrmhd
unlink ${PATRONDIR}/data/hii

ln -s ${THAT}/data/snrmhd            ${PATRONDIR}/data/snrmhd
ln -s ${THAT}/data/cloudy/output/hii ${PATRONDIR}/data/hii


echo "PATRONDIR is set to ${PATRONDIR}"

if   [ "${USEMODE}" == "" ];then
	echo "Please, enter patron mode to use: \"public\", \"user\", or \"developer\""
	echo "e.g., inimod.sh user"
elif [ "${USEMODE}" == "--user"      -o "${USEMODE}" == "--use" ];then
	export PYTHONPATH=$PYTHONPATH:${PATRONDIR}/lib
	#check if no files ask for install
	echo "You will be running in User mode."
elif [ "${USEMODE}" == "--developer" -o "${USEMODE}" == "--dev" ];then
#	export PYTHONPATH=$PYTHONPATH:${PATRONDIR}/patron
	export PYTHONPATH=$PYTHONPATH:${PATRONDIR}
	echo "You will be running in Developer mode."
fi
