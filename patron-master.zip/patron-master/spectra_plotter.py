######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  spectra_plotter.py									
# Author: Guadalupe Canas Herrera <g.canas.herrera@umail.leidenuniv.nl>, Summer 2016
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

import numpy as np
import matplotlib.pyplot as plt
import sys
from scipy import interpolate
import seaborn as sns

#Define path to file

PATH=str(sys.argv[1])
FLAG=str(sys.argv[2])

#sns.set(style="whitegrid")

sns.set_style("whitegrid", {"xtick.major.size": 10, "ytick.major.size": 10})

names_gamma=['energy', 'flux_gamma']
data_gamma = np.genfromtxt('../run_RXJ1713/RADIATIONS/SPE/SHLPDV01600', names=names_gamma)

names_hess=['energy', 'flux_gamma_E2', 'err', 'err_E2']
data_hess = np.genfromtxt('HESS', names=names_hess)


names_IC=['energy', 'flux_sum']
data_IC = np.genfromtxt('../run_RXJ1713/RADIATIONS/SPE/SNRSUM01600', names=names_IC)


if FLAG=='n':

	names=['energy', 'flux_neutrinos_e', 'flux_neutrinos_mu']
	data = np.genfromtxt(PATH, names=names)

	energy_square=data['energy']**2

	plt.figure(1)
	#plt.plot(data['energy'], energy_square*data['flux_neutrinos_e'], 'ko', label='$\nu_e$')
	plt.plot(data['energy']*1000, 1000*energy_square*data['flux_neutrinos_e'], 'r-', label='$\\nu_e$')
	#plt.plot(data['energy'], energy_square*data['flux_neutrinos_mu'], 'bo', label='$\nu_{\mu}$')
	plt.plot(data['energy']*1000, 1000*energy_square*(data['flux_neutrinos_mu']), 'b-', label='$\\nu_{\mu}$')
	plt.legend(loc=1,prop={'size':16}, frameon=True)
	plt.xlabel('$E$ $(MeV)$', labelpad=10, fontsize=16)
	plt.ylabel('$E^2Flux$ $(MeV \\times cm^{-2}s^{-1})$', fontsize=16)
	plt.xticks(color='k', size=16)
        plt.yticks(color='k', size=16)
	#plt.ylim(0, 1e-22)
	#plt.xlim(0, 4E5)
	plt.show()


	to_ergs=0.0016021766
	to_ergs_square=to_ergs**2

	plt.figure(2)
	#plt.plot(data['energy'], energy_square*data['flux_neutrinos_e'], 'ko', label='$\nu_e$')
	plt.plot(data['energy'], to_ergs_square*energy_square*(data['flux_neutrinos_e']/to_ergs), 'r-', label='$\\nu_e$')
	#plt.plot(data['energy'], energy_square*data['flux_neutrinos_mu'], 'bo', label='$\nu_{\mu}$')
	plt.plot(data['energy'], to_ergs_square*energy_square*(data['flux_neutrinos_mu']/to_ergs), 'b-', label='$\\nu_{\mu}$')
	plt.legend()
	plt.xlabel('$E$ $(erg)$')
	plt.ylabel('$E^2Flux$ $(ergs \\times cm^{-2}s^{-1})$')
	#plt.ylim(0, 1e-22)
	#plt.xlim(0, 4E5)
	plt.show()

elif FLAG=='theon':

	names=['energy', 'flux_neutrinos_e', 'flux_neutrinos_mu_1', 'flux_neutrinos_mu_2']
	data = np.genfromtxt(PATH, names=names)

	energy_square=data['energy']**2

	ydata1=interpolate.interp1d(data['energy'], data['flux_neutrinos_mu_1'], bounds_error=False, fill_value=0)(data['energy'])

	plt.figure(1)

	#plt.plot(data['energy']*1000, energy_square*data['flux_neutrinos_e'], 'ko', label='$\nu_e$')
	plt.plot(data['energy']*1000, 1000*energy_square*data['flux_neutrinos_e'], 'm--', label='analytical $\\nu_e$')
	#plt.plot(data['energy'], energy_square*data['flux_neutrinos_mu'], 'bo', label='$\nu_{\mu}$')
	plt.plot(data['energy']*1000, 1000*energy_square*(data['flux_neutrinos_mu_2']+ydata1), 'g--', label='analytical $\\nu_{\mu}$')
	plt.legend(loc=2,prop={'size':16}, frameon=True)
	plt.xlabel('$E$ $(MeV)$', labelpad=10, fontsize=16)
	plt.ylabel('$E^2Flux$ $(MeV \\times cm^{-2}s^{-1})$', fontsize=16)
	plt.xticks(color='k', size=16)
        plt.yticks(color='k', size=16)
	#plt.ylim(0, 1e-22)
	#plt.xlim(0, 4E5)
	plt.show()



elif FLAG=='p':

	names=['energy', 'flux_gamma']
	data = np.genfromtxt(PATH, names=names)

	energy_square=data['energy']**2

	plt.figure(1)
	#plt.plot(data['energy'], energy_square*data['flux_neutrinos_e'], 'ko', label='$\nu_e$')
	plt.plot(data['energy'], energy_square*data['flux_gamma'], 'r-', label='gamma')
	plt.legend()
	plt.xlabel('$E$ $(MeV)$')
	plt.ylabel('$E^2Flux$ $(MeV \\times cm^{-2}s^{-1})$')
	#plt.ylim(0, 1e-15)

	#test for neutrino spectra from gamma ray
	
	
	plt.figure(2)
	plt.plot(data['energy']/3, (data['energy']/3)**2*data['flux_gamma'], 'r-', label='e')

	#Need to interpolate

	ydata1=interpolate.interp1d(data['energy'], data['flux_gamma'], bounds_error=False, fill_value=0)(data['energy']/3)
	

	plt.plot(data['energy']/3, (data['energy']/3)**2*(ydata1+data['flux_gamma']), 'b-', label='mu')
	plt.xlabel('$E/GeV$')
	plt.ylabel('$E^2J/cm^{-2}s^{-1}GeV{-1}$')
	plt.title('Gamma check')
	plt.legend()
	#plt.ylim(0, 1e-15)
	#plt.xlim(0, 4E5)
	plt.show()


	

else:
	
	names=['energy', 'flux_neutrinos_e', 'flux_neutrinos_mu']
	data = np.genfromtxt(PATH, names=names)

	#names_2=['energy', 'flux_gamma']
		
	names_2=['energy', 'flux_neutrinos_e', 'flux_neutrinos_mu_1', 'flux_neutrinos_mu_2', 'flux_protons']
	data_2 = np.genfromtxt(FLAG, names=names_2)

	energy_square=data['energy']*data['energy']
	energy_square_2=data_2['energy']*data_2['energy']
	energy_square_gamma=data_gamma['energy']**2

	plt.figure(1)

	#GOOD NEUTRINOS	
	plt.plot(data['energy']*1000, 1000*energy_square*data['flux_neutrinos_e'], 'r-', label='$\\nu_{e}$')
	plt.plot(data['energy']*1000, 1000*energy_square*data['flux_neutrinos_mu'], 'b-', label='$\\nu_{\mu}$')

	#GOOD GAMMA	
	plt.plot(data_gamma['energy']*1000, 1000*energy_square_gamma*data_gamma['flux_gamma'], 'k-', label='$\gamma$')
	#HESS DATA
	plt.plot(data_hess['energy'], data_hess['flux_gamma_E2'], 'y^', label='HESS')

	#IC+GAMMA	
	#ydata1=interpolate.interp1d(data_IC['energy'], data_IC['flux_ic'], bounds_error=False, fill_value=0)(data_gamma['energy'])

	plt.plot(data_IC['energy']*1000, 1000*data_IC['energy']**2*(data_IC['flux_sum']), 'y-', label='$\gamma$ + IC')
	
	#PARENT PROTON SPECTRA
	plt.plot(data_2['energy']*1000, 1000*energy_square_2*data_2['flux_protons'], 'k--', label='$p$')

	#ANALYTICAL NEUTRINO
	plt.plot(data_2['energy']*1000, 1000*energy_square_2*data_2['flux_neutrinos_e'], 'm--', label='analytical $\\nu_e$')
	plt.plot(data_2['energy']*1000, 1000*energy_square_2*(data_2['flux_neutrinos_mu_2']+data_2['flux_neutrinos_mu_1']), 'g--', label='analytical $\\nu_{\mu}$')


	#PLOT FEATURES
	plt.legend(loc=3,prop={'size':16}, frameon=True)
	plt.xlabel('$E$ $(MeV)$', labelpad=10, fontsize=16)
	plt.ylabel('$E^2Flux$ $(MeV \\times cm^{-2}s^{-1})$', fontsize=16)
	plt.xticks(color='k', size=16)
        plt.yticks(color='k', size=16)
	#plt.ylim(0, 1e-22)
	#plt.xlim(0, 4E5)
	plt.show()



	
	
	#plt.plot(data_2['energy']*1000, 1000*data_2['energy']**2*data_2['flux_gamma'], 'k-', label='$\gamma$')


	#ydata1=interpolate.interp1d(1000*data_2['energy']/4, 1000*data_2['flux_gamma'], bounds_error=False, fill_value=0)(data_2['energy']/4)
	
	#plt.plot(data_2['energy']/2*1000, 1000*(data_2['energy']/2)**2*data_2['flux_gamma'], 'r.', label='check $\\nu_{e}$')
	#plt.plot(data_2['energy']/2*1000, 1000*(data_2['energy']/2)**2*(2*data_2['flux_gamma']), 'b.', label='check $\\nu_{\mu}$')

	#plt.legend(loc=1,prop={'size':16})
	#plt.legend(loc=1,prop={'size':16}, frameon=True)
	#plt.xlabel('$E$ $(MeV)$', labelpad=10, fontsize=16)
	#plt.ylabel('$E^2Flux$ $(MeV \\times cm^{-2}s^{-1})$', fontsize=16)
	#plt.xticks(color='k', size=16)
        #plt.yticks(color='k', size=16)
	#plt.ylim(0, 1e-22)
	#plt.xlim(0, 4E5)
	#plt.show()

















