######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  setup.py									
# Author: Robert Brose <robert.brose@mail.de>, 2015 - 
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################
#This script uses mathplotlib to automatically plot the patron-logfiles. The comparison of two runs is possible.  

#v0.0.1 Start of devolpment

import sys
import getopt

import matplotlib.pyplot as plt	
from matplotlib.ticker import FormatStrFormatter

import seaborn as sns

from numpy import loadtxt
from numpy import shape
from numpy import arange
from numpy import nan

from scipy.interpolate import interp1d

def main(argv=None):
	print "\nReading runtime parameters..."
	keywords = ['species=', 'run1=', 'run2=']

	argv=sys.argv
	try: opt_arg, extrapar = getopt.getopt(argv[1:],"",keywords)
	except:
		print "Wrong patron command line option provided!"
		sys.exit(0)
	
	for opt,arg in opt_arg:
		if   opt == "--run1": Run1=arg
		elif opt == "--run2": Run2=arg
		elif opt == "--species": Species=arg

	print "Creating plots for ", Species
	print "Plotting files from:\n\t", Run1, "\n\t", Run2

	RUN1=Run1+"/ALLSUBDIR/CRSPE0/logs/log_file"+Species
	RUN2=Run2+"/ALLSUBDIR/CRSPE0/logs/log_file"+Species

	if Run2=="":
		Run2 = None

	#Reading the logfile(s)
	#Datafile, containing all data to plot
	data1=loadtxt(RUN1,skiprows=1)
	data2=None
	if Run2 != None: data2=loadtxt(RUN2,skiprows=1)
	#Header information, containing the type of the logged data
	#Ignore last column, its always empty	
	head1=loadtxt(RUN1, delimiter="\t",dtype=str)[0,:-1]
	if Run2 != None: 
		head2=loadtxt(RUN2, delimiter="\t",dtype=str)[0,:-1]
		if len(head1)!=len(head2):
			print "Number of columns disagree! Aborting..."
			sys.exit(0)

	print "Found ", len(head1), "data columns.\n", "Data columns found:"
	for i in range(len(head1)):
		print "\t", head1[i]

	fig, axs = plt.subplots((len(head1)-1), 1, sharex=True)	#,figsize=(15,3*(len(head1)-1)))
	# Remove horizontal space between axes
	fig.subplots_adjust(hspace=0)

	# Plot each graph, and manually set the y tick values
	for i in range(len(axs)):
		if Run2 != None:
			axs[i].plot(data1[:,0], data1[:,i+1],'b-',data1[:,0], interp1d(data2[:,0],data2[:,i+1], bounds_error=False, fill_value=nan)(data1[:,0]), 'r-')#, label=head1[i+1])
		else:
			axs[i].plot(data1[:,0], data1[:,i+1],'b-')
		#axs[i].legend(loc="upper right")
		axs[i].set_ylabel(head1[i+1])	#,rotation=0)
		
		if Run2 != None:
			ma=max([max(data1[:,i+1]), max(data2[:,i+1])])
			mi=min([min(data1[:,i+1]), min(data2[:,i+1])])
		else:
			ma=max(data1[:,i+1])
			mi=min(data1[:,i+1])
	
		st=(1.05*ma-0.95*mi)/3.5
		axs[i].set_ylim((0.9*mi,1.1*ma))
		axs[i].yaxis.set_ticks(arange(0.95*mi,1.05*ma,st))
		axs[i].yaxis.set_major_formatter(FormatStrFormatter('%.2E'))

	axs[-1].set_xlabel('time[yr]')
	axs[i].xaxis.set_ticks(arange(0.95*min(data1[:,0]),1.05*max(data1[:,0]),(1.025*max(data1[:,0]-0.975*min(data1[:,0]))/10.)))
	
	for i in range(len(head1)-1):
		for item in ([axs[i].xaxis.label, axs[i].yaxis.label] + axs[i].get_xticklabels() + axs[i].get_yticklabels()):
	    		item.set_fontsize(5)
	plt.show()







if __name__ == "__main__":sys.exit(main())
