import matplotlib.pyplot as mp
from patron.setpar import *

SP = SimParams()
SetupSimParams(SP,['--paramfile=/lustre/fs17/group/that/rb/output/GITHUB/02/Parameters.xml', '--crspecies=EL', '--shocktype=FSH'])
InitSimulation(SP)

SNR = tecoef.TranEqnCoeffFuncs(shockType=SP.SHOCKTYPE,nhDensity=SP.nhdensity,\
expEnergy=SP.expenergy,useSedSol=SP.usesedsol,\
crSpecies=SP.CRSPECIES,injectPar=SP.injectpar,injSclPar=SP.injsclpar,\
mfProfile=SP.MFPROFILE,alfvDrift=SP.ALFVDRIFT,\
hdDataInp=SP.HDDATAINP,hdFileInp=SP.HDFILEINP,mfDataInp=SP.MFDATAINP,mfFileInp=SP.MFFILEINP)

t=440
dr=0.001
r=arange(dr,1+dr,dr)

SNR.Rsh(t)

SNR.Vsh(t)

SNR.nh(r,t)
SNR.Pg(r,t)
SNR.Tg(r,t)
