#!/bin/bash

#This file renames the HD-rofiles created by PyPluto and converts them into a format usable similar to the VH-1 files

HISTOPRY_FILE=history
rm $HISTOPRY_FILE
i=1000 
yr=31536000

for f in HRAW_*
do
  echo "Processing $f file, i=$i"
  time="`echo ${f:7}*"$yr" | bc -l`"
  echo "$i  $time $(($i-1000))" >> $HISTOPRY_FILE
  NAME=`echo ${f:0:4}".""$i"`
  cp $f $NAME	
  sed -i -e "1d" $NAME
  i=$(($i+1)) 	
  #cat $f
done
