######################################################################################
### PATRON - Particle Acceleration Transport Radiation Object-orieNted PYthon Code ###
#=====================================================================================
# File:	  setup.py									
# Author: Robert Brose <robert.brose@mail.de>, 2015 - 2016
# 
#
#=====================================================================================
# This software can be redistributed and/or modified freely
# provided that any derivative works bear some notice that they are
# derived from it, and any modified versions bear some notice that
# they have been modified.
# The author(s) assume(s) no responsibility whatsoever for its use by
# other parties, and makes no guarantees, expressed or implied, about
# its quality, reliability, or any other characteristic.
######################################################################################

#v0.0.1 start of devolpment for replacing startup script. Creating XML-parameter file

#from patron.setup import 


#programm reads the .xml-parameter file and replaces the given Parameters with the specified values
def main(argv=None):

	print "in progress..."






if __name__ == "__main__":sys.exit(main())
