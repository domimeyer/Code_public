#creates MHD-files using the analytic approximations of truelove and mckee

from numpy import *
from scipy.special import cbrt
from patron.snrmod.snrevo import evotru as evotru

Msun = 2.0e33
#global rho_s
#global R_FSstar
#global V_FSstar
#global R_RSstar
#global V_RSstar
#global R_STstar
#global V_SRstar


yr   = 3.156e7
km   = 1.0e5
pc   = 3.086e18
m_p  = 1.6726e-24
mu   = 0.609
muh  = 1.4
mue  = 1.17
Rg   = 8.3143e7

Msun = 2.0e33

yr   = 3.156e7
km   = 1.0e5
pc   = 3.086e18
m_p  = 1.6726e-24
mu   = 0.609
muh  = 1.4
mue  = 1.17
Rg   = 8.3143e7

Msun = 2.0e33


###TO BE SET in snrmhd!###
evotru.E    = 1.0e51
evotru.n    = 1.0

###TO BE SET FROM setpar!###
evotru.N    = 7						#index of a powerlaw density distribution in SN envelope
evotru.S    = 0						#index of a powerlaw density distribution in CSM
evotru.M_ej = 1.4*Msun					#ejecta mass
evotru.Mdot = 6.0e21						#mass-loss rate
evotru.V_Z1 = 4.5e6						#stellar wind velocity in zone 1 (closer to the star)
evotru.RHO_SHL=evotru.n*2.34e-24
evotru.R_Z2=50.0
evotru.RWSH=51.0
############################

evotru.SetupParameters()


dt = 10
tstop = 900
t = arange(1,tstop,dt)


outFileName="/lustre/fs17/group/that/rb/PLOTS/Jun_1996/Plutodata_Mckee_SHOCK"
#write shock positions to file
shock_file = open(outFileName,'w')
for i in range(len(t)):
	shock_file.write(str(t[i])+"\t"+str(evotru.R_FS(t[i]))+"\t"+str(evotru.R_RS(t[i]))+"\t"+str(evotru.D_FS(t[i]))+"\t"+str(evotru.D_RS(t[i]))+"\n")
shock_file.close

