import os
import file
import string
import menu
import shutil
import hashlib

entries_RADIATION_SOR_SOLVER = []
options_RADIATION_SOR_SOLVER = []
default_RADIATION_SOR_SOLVER = []

def show_radiation_sor_solver_menue(work_dir,AUTO_UPDATE):
  del entries_RADIATION_SOR_SOLVER[:]
  del options_RADIATION_SOR_SOLVER[:]
  del default_RADIATION_SOR_SOLVER[:]
  entries_RADIATION_SOR_SOLVER.append('RADIATION_SOR_OMEGA_MODE')
  options_RADIATION_SOR_SOLVER.append(['SOR_FIXED_OMEGA','SOR_ADAPTIVE_OMEGA'])
  default_RADIATION_SOR_SOLVER.append('SOR_ADAPTIVE_OMEGA')
  
  entries_RADIATION_SOR_SOLVER.append('RADIATION_SOR_NORM')
  options_RADIATION_SOR_SOLVER.append(['NORM_PETSC','NORM_RELATIVE_L2','NORM_RELATIVE_MAX','NORM_RESIDUAL_L2','NORM_RESIDUAL_MAX','NORM_RESIDUAL_RELATIVE_L2', 'NORM_RESIDUAL_RELATIVE_MAX'])
  default_RADIATION_SOR_SOLVER.append('NORM_RESIDUAL_L2')
    
  #Read pre-existing options, if they exists
    
  if (os.path.exists(work_dir+'/definitions.h')):
    for x in entries_RADIATION_SOR_SOLVER:
      try:
        scrh = file.string_list(work_dir+'/definitions.h',x)
        tmp  = string.split(scrh[0])
        default_RADIATION_SOR_SOLVER[entries_RADIATION_SOR_SOLVER.index(x)] = tmp[2]
      except IndexError:
        continue
    
  if AUTO_UPDATE == 0:
    selection = ''
    menu.SetTitle("Radiation SOR Solver Menu")
    selection = menu.Browse(entries_RADIATION_SOR_SOLVER, default_RADIATION_SOR_SOLVER, options_RADIATION_SOR_SOLVER)

entries_RADIATION = []
options_RADIATION = []
default_RADIATION = []

def show_radiation_menue(work_dir,pluto_dir,AUTO_UPDATE):
  del entries_RADIATION[:]
  del options_RADIATION[:]
  del default_RADIATION[:]

  entries_RADIATION.append('RADIATION_FLUXLIMITER')
  options_RADIATION.append(['FLUXLIMITER_MINERBO','FLUXLIMITER_KLEY','FLUXLIMITER_LEVERMORE_POMRANING','FLUXLIMITER_CONST'])
  default_RADIATION.append('FLUXLIMITER_MINERBO')

  entries_RADIATION.append('RADIATION_PRESSURE')
  options_RADIATION.append(['YES','NO'])
  default_RADIATION.append('NO')

  entries_RADIATION.append('RADIATION_SOLVER')
  options_RADIATION.append(['PETSC_LIBRARY','SOLVER_SOR'])
  default_RADIATION.append('PETSC_LIBRARY')
   
  entries_RADIATION.append('IRRADIATION')
  options_RADIATION.append(['YES','NO'])
  default_RADIATION.append('NO')
  
  #If the files init.c and pluto,ini are the same as in the directory $PLUTO_DIR/Src/Templates/
  #then replace them with the the init.c and pluto.ini from $PLUTO_DIR/Src/Radiation/Templates/
  
  def isFileEqual(filepath1, filepath2):
    f1 = open(filepath1)
    f2 = open(filepath2)
    
    if not f1:
      return False
    if not f2:
      return False
    
    hash1 = hashlib.md5(f1.read()).hexdigest()
    hash2 = hashlib.md5(f2.read()).hexdigest()
    f1.close()
    f2.close()
    return hash1 == hash2
  
  if (os.path.exists(work_dir+'/init.c')):
    if isFileEqual(pluto_dir+'/Src/Templates/init.c',work_dir+'/init.c'):
      shutil.copy(pluto_dir+'/Src/Radiation/Templates/init.c',work_dir+'/init.c')
        
  if (os.path.exists(work_dir+'/pluto.ini')):
    if isFileEqual(pluto_dir+'/Src/Templates/pluto.ini',work_dir+'/pluto.ini'):
      shutil.copy(pluto_dir+'/Src/Radiation/Templates/pluto.ini',work_dir+'/pluto.ini')
    
  #Read Radiation pre-existing Radiation submenu defaults, if they exists
    
  if (os.path.exists(work_dir+'/definitions.h')):
    for x in entries_RADIATION:
      try:
        scrh = file.string_list(work_dir+'/definitions.h',x)
        tmp  = string.split(scrh[0])
        default_RADIATION[entries_RADIATION.index(x)] = tmp[2]
      except IndexError:
        continue
    
  if AUTO_UPDATE == 0:
    selection = ''
    menu.SetTitle("Radiation Menu")
    selection = menu.Browse(entries_RADIATION, default_RADIATION, options_RADIATION)
  
  if default_RADIATION[entries_RADIATION.index('RADIATION_SOLVER')] == 'SOLVER_SOR':
      show_radiation_sor_solver_menue(work_dir,AUTO_UPDATE)

def modify_definitions(work_dir,tmp):
  tmp.append('\n/* -- radiation dependent declarations -- */\n\n');

  for x in entries_RADIATION:
    i = entries_RADIATION.index(x)
    tmp.append('#define    '+x.ljust(24)+'   '+default_RADIATION[i]+'\n')
      
  for x in entries_RADIATION_SOR_SOLVER:
    i = entries_RADIATION_SOR_SOLVER.index(x)
    tmp.append('#define    '+x.ljust(24)+'   '+default_RADIATION_SOR_SOLVER[i]+'\n')
    
  tmp.append('\n/* -- radiation begin additional options -- */\n');
  
  if os.path.isfile( work_dir+'/definitions.h'):
    definitions_file = open(work_dir+'/definitions.h', 'r')
    definitions_lines = definitions_file.readlines()
    definitions_file.close()
    definitions_begin_pos = 0
    definitions_end_pos = 0
    definitions_current_pos = 0;
    for line in definitions_lines:
      if line.find("radiation begin additional options") != -1:
        definitions_begin_pos = definitions_current_pos + 1
      if line.find("radiation end additional options") != -1:
        definitions_end_pos = definitions_current_pos
      definitions_current_pos += 1
    
    for i in xrange(definitions_begin_pos,definitions_end_pos):
      line = definitions_lines[i]
      if len(line.replace("\n","")) > 0:
        tmp.append(line)

  tmp.append('/* -- radiation end additional options -- */\n');
