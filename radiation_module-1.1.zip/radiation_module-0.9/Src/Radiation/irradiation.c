/**
Copyright (C) 2011-2013 Stefan Kolb.

This file is part of the radiation module for the code PLUTO.

The radiation module is free software: you can redistribute it
and/or modify it under the terms of the GNU General Public
License as published by the Free Software Foundation, either
version 2 of the License, or (at your option) any later version.

The radiation module is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty
of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the radiation module. If not, see <http://www.gnu.org/licenses/>.
*/

#include "irradiation.h"
#include "radiation.h"

#if IRRADIATION == YES

#if GEOMETRY != SPHERICAL
    #error IRRADIATION needs spherical coordinates!
#endif

IrradiationData irradiation;

/**
    Initializes the irradiation submodule:

    \param[in]  grid
*/
void IrradiationInit( Grid *grid )
{
    int n = 0, k, j, i;
    irradiation.neighbour.receive_rank = -1;
    irradiation.neighbour.send_rank = -1;

    irradiation.S = ( double ** * )Array3D( NX3_TOT, NX2_TOT, NX1_TOT, sizeof( double ) );

    irradiation.data_buffer = malloc( sizeof( double ) * ( NX2 * NX3 ) );
    irradiation.optical_depth_offset = malloc( sizeof( double ) * ( NX2 * NX3 ) );

    for( n = 0; n < NX2 * NX3; ++n )
    {
        irradiation.optical_depth_offset[n] = 0.;
    }

    IrradiationFindCommunicationNeighbours( grid );
}

/**
    Frees all the allocated memory
*/
void IrradiationFinalise( void )
{
    FreeArray3D( ( void * ) irradiation.S );
    free( irradiation.data_buffer );
    free( irradiation.optical_depth_offset );
}

/**
    In this function we iterate over all local domains and search for the neighbors of a specific processor with prank == \a current_rank.
    The found neighbors are stored in \a cn as the \a cn->receive_rank and \a cn->send_rank.

    \note
    If \a cn->receive_rank or \a cn->send_rank is set to -1 this means there is no neighbor before or after the local domain of the processor with
    prank == \a current_rank.

    \param[in]  current_rank
    \param[in]  domain_info_array
    \param[in]  nproc
    \param[out] cn

*/
void IrradiationFindCommunicationNeighbour( int current_rank, LocalDomainInfo *domain_info_array, int nproc, CommunicationNeighbour *cn )
{
    int n = 0;
    LocalDomainInfo *cdi = &domain_info_array[current_rank];

    cn->receive_rank = -1;
    cn->send_rank = -1;

    for( n = 0; n < nproc; ++n )
    {
        if( n != current_rank )
        {
            if( cdi->x1_begin - 1 == domain_info_array[n].x1_end && cdi->x2_begin == domain_info_array[n].x2_begin && cdi->x2_end == domain_info_array[n].x2_end && cdi->x3_begin == domain_info_array[n].x3_begin && cdi->x3_end == domain_info_array[n].x3_end )
            {
                cn->receive_rank = n;
            }
            else if( cdi->x1_end + 1 == domain_info_array[n].x1_begin && cdi->x2_begin == domain_info_array[n].x2_begin && cdi->x2_end == domain_info_array[n].x2_end && cdi->x3_begin == domain_info_array[n].x3_begin && cdi->x3_end == domain_info_array[n].x3_end )
            {
                cn->send_rank = n;
            }
        }
    }
}

/**
    This function computes the radial neighbors for each process.\n
    As a simple example we assume a one dimensional domain starting at 0 and ending at 9. If we use 3 processors the local domain for the processor with prank == 0
    starts at 0 and ends at 3 for prank == 1 it starts at 3 and ends at 6 and for the last processor with prank == 2 it starts at 6 and ends at 9. For this example
    this function will find the following:\n
    prank == 0: \n
        irradiation.neighbour.receive_rank = -1 \n
        irradiation.neighbour.send_rank = 1 \n
    prank == 1: \n
        irradiation.neighbour.receive_rank = 0 \n
        irradiation.neighbour.send_rank = 2 \n
    prank == 2: \n
        irradiation.neighbour.receive_rank = 1 \n
        irradiation.neighbour.send_rank = -1 \n
    \n
    This function is needed because for computing the energy brought by the radiation of the central star to a specific grid cell we need to compute the optical
    depth \f$ \tau_{i,j,k} \f$.
    \f[
        \tau_{i,j,k} \approx \sum_{n=0}^{i}  \kappa_{R_{i,j,k}} \rho_{i,j,k} \Delta r_i
    \f]
    The optical depth at the grid cell \f$ r_i, \theta_j, \phi_k \f$ depends on the optical depth of the grid cell \f$ r_{i-1}, \theta_j, \phi_k \f$. In the case
    that the simulation is done with only one core(processor) this is no problem. If we do the simulation in parallel the optical depth at a specific grid cell can
    depend on the optical depth which is computed by a different processor. This is the reason that we need to find the neighbors in r direction on which the computation
    of the optical depth depends on.

    The neighbors are then stored in a structure so that we can do the communication without further checks!

    \param[in]  grid
*/
void IrradiationFindCommunicationNeighbours( Grid *grid )
{
    int nproc = 0, n = 0;
    LocalDomainInfo ldi;
    LocalDomainInfo *domain_info_array = NULL;
    LocalDomainInfo *item = NULL;
    CommunicationNeighbour *neighbour_info_array = NULL;
    MPI_Status status;

    MPI_Comm_size( MPI_COMM_WORLD, &nproc );

    ldi.x1_begin = grid[IDIR].beg;
    ldi.x1_end = grid[IDIR].end;

    ldi.x2_begin = grid[JDIR].beg;
    ldi.x2_end = grid[JDIR].end;

    ldi.x3_begin = grid[KDIR].beg;
    ldi.x3_end = grid[KDIR].end;


    if( prank == 0 )
    {
        domain_info_array = malloc( sizeof( LocalDomainInfo ) * nproc );
        neighbour_info_array = malloc( sizeof( CommunicationNeighbour ) * nproc );
    }

    MPI_Gather( &ldi, sizeof( LocalDomainInfo ), MPI_CHAR, domain_info_array, sizeof( LocalDomainInfo ), MPI_CHAR, 0, MPI_COMM_WORLD );

    if( prank == 0 )
    {
//      for(n = 0; n < nproc; ++n)
//      {
//          item = &domain_info_array[n];
//          print("rank = %3d || x1b = %3d x1e = %3d | x2b = %3d x2e = %3d | x3b = %3d x3e = %3d \n",n,item->x1_begin,item->x1_end,item->x2_begin,item->x2_end,item->x3_begin,item->x3_end);
//      }
//      print("\n\n");

        for( n = 0; n < nproc; ++n )
        {
            IrradiationFindCommunicationNeighbour( n, domain_info_array, nproc, &neighbour_info_array[n] );
//          print("rank = %3d || receive_id = %3d send_id = %3d\n",n,neighbour_info_array[n].receive_rank,neighbour_info_array[n].send_rank);
        }

        for( n = 0; n < nproc; ++n )
        {
            if( n != 0 )
            {
                MPI_Send( &neighbour_info_array[n], sizeof( CommunicationNeighbour ), MPI_CHAR, n, 0, MPI_COMM_WORLD );
            }
        }

        irradiation.neighbour.receive_rank = neighbour_info_array[0].receive_rank;
        irradiation.neighbour.send_rank = neighbour_info_array[0].send_rank;

        free( domain_info_array );
        free( neighbour_info_array );
    }
    else
    {
        MPI_Recv( &irradiation.neighbour, sizeof( CommunicationNeighbour ), MPI_CHAR, 0, 0, MPI_COMM_WORLD, &status );
    }
}

/**
    In this function we compute the optical depth \f$ \tau_{i,j,k} \f$.
    \f[
        \tau_{i,j,k} \approx \sum_{n=0}^{i}  \kappa_{R_{i,j,k}} \rho_{i,j,k} \Delta r_i
    \f]
    for each local domain where we assume that the local domain is for each processor the total domain.
    By doing this there is for each local domain an offset missing. In the case that the local domain
    of a processor is the innermost domain the offset is zero else the offset is greater than zero.
    \n
    In three dimensions the offset depends on \f$ \theta \f$ and \f$ \phi \f$ so it is not a
    single number but an array which represents an slice in the \f$ \theta \f$, \f$ \phi \f$
    plain of the each local domain. The initial offsets are the \f$ \tau_{i,j,k} \f$ values with the
    highest values of \f$ r \f$ in the innermost domain. The offsets are then send from the innermost
    processor to its next radial neighbor. This neighbor receives the offset, adds to each offset
    the corresponding \f$ \tau_{i,j,k} \f$ values with the highest value of \f$ r \f$ in its local domain
    and sends it to the its radial neighbor and so on.

    \note
    The calculated optical depth is temporary stored in \a irradiation.S

    \param[in]  grid
    \param[in]  data

*/
void IrradiationCalculateOpticalDepthPerDomain( Grid *grid, Data *data )
{
    int k, j, i, n;
    double optical_depth = 0.;
    double cgs_temperature = 0.0;
    double density = 0.0, cgs_density = 0.0;
    MPI_Status status;

    for( k = KBEG; k <= KEND; k++ )
    {
        for( j = JBEG; j <= JEND; j++ )
        {
            optical_depth = 0.0;
            irradiation.S[k][j][IBEG] = optical_depth;
            for( i = IBEG; i <= IEND; i++ )
            {
                cgs_temperature = GetTemperature( k, j, i, data ) * g_unitTemperature;
                density = data->Vc[RHO][k][j][i];
                cgs_density = density * g_unitDensity;

                optical_depth += ( IrradiationOpacity( cgs_density, cgs_temperature ) * g_unitDensity * g_unitLength ) * density * grid[IDIR].dx[i];

                irradiation.S[k][j][i + 1] = optical_depth;
            }
        }
    }

    #ifdef IRRADIATION_INERTIAL_OPTICAL_DEPTH_OFFSET
        if( irradiation.neighbour.receive_rank == -1 && irradiation.neighbour.send_rank != -1 ) //no neighbor in between the star and the current domain
        {
            n = 0;
            for( k = 0; k < KBEG; k++ )
            {
                for( j = 0; j < JBEG; j++ )
                {
                    optical_depth = 0.0;
                    for( i = 0; i < IBEG; i++ )
                    {
                        cgs_temperature = GetTemperature( k, j, i, data ) * g_unitTemperature;
                        density = data->Vc[RHO][k][j][i];
                        cgs_density = density * g_unitDensity;

                        optical_depth += ( IrradiationOpacity( cgs_density, cgs_temperature ) * g_unitDensity * g_unitLength ) * density * grid[IDIR].dx[i];
                    }
                    irradiation.optical_depth_offset[n] = optical_depth;
                    n++;
                }
            }
        }
    #endif

    if( irradiation.neighbour.receive_rank != irradiation.neighbour.send_rank ) //check if more than one process is in the communicator (nproc > 1)
    {
        if( irradiation.neighbour.receive_rank == -1 && irradiation.neighbour.send_rank != -1 ) //no neighbor in between the star and the current domain
        {
            n = 0;
            i = IEND + 1;
            for( k = KBEG; k <= KEND; k++ )
            {
                for( j = JBEG; j <= JEND; j++ )
                {
                    irradiation.data_buffer[n] = irradiation.S[k][j][i];
                    #ifndef IRRADIATION_INERTIAL_OPTICAL_DEPTH_OFFSET
                        irradiation.optical_depth_offset[n] = 0.;
                    #endif
                    n++;
                }
            }
            MPI_Send( irradiation.data_buffer, sizeof( double ) * ( NX2 * NX3 ), MPI_CHAR, irradiation.neighbour.send_rank, 0, MPI_COMM_WORLD );
        }
        else
        {
            MPI_Recv( irradiation.optical_depth_offset , sizeof( double ) * ( NX2 * NX3 ), MPI_CHAR, irradiation.neighbour.receive_rank, 0, MPI_COMM_WORLD, &status );

            n = 0;
            i = IEND + 1;
            for( k = KBEG; k <= KEND; k++ )
            {
                for( j = JBEG; j <= JEND; j++ )
                {
                    irradiation.data_buffer[n] = irradiation.optical_depth_offset[n] + irradiation.S[k][j][i];
                    n++;
                }
            }

            if( irradiation.neighbour.send_rank != -1 )
            {
                MPI_Send( irradiation.data_buffer, sizeof( double ) * ( NX2 * NX3 ), MPI_CHAR, irradiation.neighbour.send_rank, 0, MPI_COMM_WORLD );
            }

        }
        MPI_Barrier( MPI_COMM_WORLD );
    }
}

/**
    This function calculates \f$ S \f$
    \f[
        S_{i,j,k} =  \frac{3 \sigma T_\star^4 R^2_\star \left( e^{-\tau_i} - e^{-\tau_{i+1}}\right) }{r_{i+1}^3 - r_i^3}
    \f]


    \f$ S \f$ is a term which is added to the right hand side of the equations of radiation transport. This equations then look like

    \f[
        \frac{\partial E}{\partial t}  = \nabla \overbrace{K\nabla E}^{-\vec{F}} + \kappa_P\rho c \left( a_R T^4 - E\right)
    \f]
    \f[
        \frac{\partial \rho \epsilon}{\partial t} = -\kappa_P \rho c ( a_R T^4 - E) + S
    \f]

    \param[in]  grid
    \param[in]  data

**/
void IrradiationCalculateS( Grid *grid, Data *data )
{
    int k, j, i, n;
//  double optical_depth,density,temperature;
    double optical_depth_i, optical_depth_ip1;

    IrradiationCalculateOpticalDepthPerDomain( grid, data );

    n = 0;
    for( k = KBEG; k <= KEND; k++ )
    {
        for( j = JBEG; j <= JEND; j++ )
        {
            for( i = IBEG; i <= IEND; i++ )
            {
                optical_depth_i = irradiation.optical_depth_offset[n] + irradiation.S[k][j][i];
                optical_depth_ip1 = irradiation.optical_depth_offset[n] + irradiation.S[k][j][i + 1];

                irradiation.S[k][j][i] = ( 3.0 * irradiation.star.Ln * ( exp( -1.0 * optical_depth_i ) - exp( -1.0 * optical_depth_ip1 ) ) ) / ( POW3( grid[IDIR].xr[i] ) - POW3( grid[IDIR].xl[i] ) );
            }
            n++;
        }
    }
}

/**
    Sets the radius and the temperature of the central star.

    \note
    The luminosity \f$ L \f$ is given by
    \f[
        L = 4 \pi R^2 \sigma T^4
    \f]
    with
    \f[
        \sigma = \frac{2\pi^5 k_B^4}{15h^3 c^2}
    \f]
    In the code we define \f$ Ln \f$ which is given by
    \f[
        Ln = \frac{L}{4 \pi}
    \f]

    \param[in]  R   the radius of the star in code units
    \param[in]  T   the temperature of the star in code units (note normally UNIT_TEMPERATURE is set to 1 so code units mean Kelvin)

**/
void IrradiationSetStarProperties( double R, double T )
{
//  double code_h = CONST_h / (g_unitDensity * POW4(UNIT_LENGTH) * g_unitVelocity);
//  double sigma = 2.0 * POW5(M_PI) * POW4(code_kB) / (15.0 * POW3(code_h) * POW2(code_c));

    double sigma = ( 2.0 * POW5( CONST_PI ) * POW4( CONST_kB ) / ( 15.0 * POW3( CONST_h ) * POW2( CONST_c ) ) ) / ( g_unitDensity * POW3( g_unitVelocity ) );


    irradiation.star.R = R;
    irradiation.star.T = T;

    irradiation.star.Ln = POW2( irradiation.star.R ) * sigma * POW4( irradiation.star.T );
    irradiation.star.L = 4.0 * M_PI * irradiation.star.Ln;

    irradiation.star.x = 0.;
    irradiation.star.y = 0.;
    irradiation.star.z = 0.;

    irradiation.star.central = 1;
}

#endif //if IRRADIATION==YES
