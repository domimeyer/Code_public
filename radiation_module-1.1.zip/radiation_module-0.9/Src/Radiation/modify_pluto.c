/**
Copyright (C) 2011-2013 Stefan Kolb.

This file is part of the radiation module for the code PLUTO.

The radiation module is free software: you can redistribute it
and/or modify it under the terms of the GNU General Public
License as published by the Free Software Foundation, either
version 2 of the License, or (at your option) any later version.

The radiation module is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty
of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the radiation module. If not, see <http://www.gnu.org/licenses/>.
*/

#include "radiation.h"
#include "modify_pluto.h"

#include "string.h"

/**
    This function modifies the element \a output[i] of the struct Input in that way that pluto can save
    the the content of \a array to the disc in the same way as the common PLUTO variables.

    \note For more information look at the file set_output.c and initialize.c

    \param[in]  input
    \param[in]  var_name    the short name of the variable stored int \a array (this is used in the files like dbl.out,...)
    \param[in]  array
*/
void AppendArrayToPlutoFileOutput( Input *input, char *var_name, double *** array )
{
    int n = 0;
    int nvar = input->output[0].nvar, current_pos = nvar;


    for( n = 0; n < MAX_OUTPUT_TYPES; n++ )
    {
        input->output[n].nvar = nvar + 1;

        strcpy( input->output[n].var_name[current_pos], var_name );
        input->output[n].V[current_pos] = array;
        input->output[n].stag_var[current_pos] = -1;
//      input->output[n].mode[current_pos] = input->output[n].mode[0];

        switch( input->output->type )
        {
            case DBL_OUTPUT:
            case FLT_OUTPUT:
            case VTK_OUTPUT:
            case TAB_OUTPUT:
            case DBL_H5_OUTPUT:
            case FLT_H5_OUTPUT:
                input->output[n].dump_var[current_pos] = YES;
                break;

            default:
                input->output[n].dump_var[current_pos] = NO;
                break;
        }
    }
}
