/**
Copyright (C) 2011-2013 Stefan Kolb.

This file is part of the radiation module for the code PLUTO.

The radiation module is free software: you can redistribute it
and/or modify it under the terms of the GNU General Public
License as published by the Free Software Foundation, either
version 2 of the License, or (at your option) any later version.

The radiation module is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty
of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the radiation module. If not, see <http://www.gnu.org/licenses/>.
*/

#include "radiation.h"
#include "petsc.h"
#include "petsc_tools.h"

/**
    Writes the PETSc matrix \a A to the file given by \a filename. The matrix is stored binary

    \note For reading the stored matrix look at $PLUTO_DIR/Src/Radiation/tests/petsc/read_petsc_data.py

    \param[in]  A
    \param[in]  filename
*/
int PetscWriteMatrixToFile( char *filename, Mat A )
{
    PetscViewer viewer;
    PetscErrorCode ierr;

//  ierr = PetscViewerCreate(PETSC_COMM_WORLD, &viewer);CHKERR(ierr);

    ierr = PetscViewerBinaryOpen( PETSC_COMM_WORLD, filename, FILE_MODE_WRITE, &viewer ); CHKERR( ierr );
    ierr = MatView( A, viewer ); CHKERR( ierr );
    #if PETSC_VERSION_MAJOR >= 3 && PETSC_VERSION_MINOR > 1
        ierr = PetscViewerDestroy( &viewer ); CHKERR( ierr );
    #else
        ierr = PetscViewerDestroy( viewer ); CHKERR( ierr );
    #endif

    return 0;
}

/**
    Writes the PETSc vector b to the file given by filename. The vector is stored binary

    \note For reading the stored vector look at $PLUTO_DIR/Src/Radiation/tests/petsc/read_petsc_data.py

    \param[in]  b
    \param[in]  filename
*/
int PetscWriteVectorToFile( char *filename, Vec b )
{
    PetscViewer viewer;
    PetscErrorCode ierr;

//  ierr = PetscViewerCreate(PETSC_COMM_WORLD, &viewer);CHKERR(ierr);

    ierr = PetscViewerBinaryOpen( PETSC_COMM_WORLD, filename, FILE_MODE_WRITE, &viewer ); CHKERR( ierr );
    ierr = VecView( b, viewer ); CHKERR( ierr );
    #if PETSC_VERSION_MAJOR >= 3 && PETSC_VERSION_MINOR > 1
        ierr = PetscViewerDestroy( &viewer ); CHKERR( ierr );
    #else
        ierr = PetscViewerDestroy( viewer ); CHKERR( ierr );
    #endif

    return 0;
}
