/**
Copyright (C) 2011-2013 Stefan Kolb.

This file is part of the radiation module for the code PLUTO.

The radiation module is free software: you can redistribute it
and/or modify it under the terms of the GNU General Public
License as published by the Free Software Foundation, either
version 2 of the License, or (at your option) any later version.

The radiation module is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty
of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the radiation module. If not, see <http://www.gnu.org/licenses/>.
*/

#include <stdio.h>
#include <string.h>
#include <execinfo.h>

#include <signal.h>
#include <fenv.h>       //for handling float point exceptions
//to prevent an warning message
int feenableexcept( int excepts );

#include "radiation.h"
#include "radiation_tools.h"

/**
    Shows the current used domain composition by PLUTO. This version is better
    than the version provided by PLUTO because we show here for each process the
    exact number of cells per direction. The PLUTO version shows only the
    typical (the values from prank == 0) number of cells per direction.
*/
void ShowDomainDecompositionAdvanced( Grid *grid )
{
    int i = 0;
    int domain_size[9];
    int *domain_size_received = NULL;
    int nproc = 1;          //default value is 1 for the single process case

    domain_size[0] = NX1;
    domain_size[1] = NX2;
    domain_size[2] = NX3;

    domain_size[3] = grid[IDIR].beg - grid[IDIR].gbeg;
    domain_size[4] = grid[IDIR].end - grid[IDIR].gbeg;
    domain_size[5] = grid[JDIR].beg - grid[JDIR].gbeg;
    domain_size[6] = grid[JDIR].end - grid[JDIR].gbeg;
    domain_size[7] = grid[KDIR].beg - grid[KDIR].gbeg;
    domain_size[8] = grid[KDIR].end - grid[KDIR].gbeg;

    domain_size_received = domain_size; //is set for the single process case

    #ifdef PARALLEL
        if( prank == 0 )
        {
            MPI_Comm_size( MPI_COMM_WORLD, &nproc );
            domain_size_received = malloc( 9 * nproc * sizeof( int ) );
            CHECK_ALLOCATED_MEMORY( domain_size_received );
        }
        MPI_Gather( domain_size, 9, MPI_INT, domain_size_received, 9, MPI_INT, 0, MPI_COMM_WORLD );

        if( prank == 0 )
        {
    #endif
        print( "\n> Domain decomposition [nproc=%d]\n", nproc );

        for( i = 0; i < nproc; i++ )
        {
            //print(" process %4d: \t Nx1=%-6d Nx2=%-6d Nx3=%-6d %-4d,%-4d,%-4d <-> %-4d,%-4d,%-4d\n",i,domain_size_received[i*9],domain_size_received[i*9+1],domain_size_received[i*9+2],domain_size_received[i*9+3],domain_size_received[i*9+5],domain_size_received[i*9+7],domain_size_received[i*9+4],domain_size_received[i*9+6],domain_size_received[i*9+8]);
            print( " process %4d: \t Nx1=%-6d Nx2=%-6d Nx3=%-6d\n", i, domain_size_received[i * 9], domain_size_received[i * 9 + 1], domain_size_received[i * 9 + 2] );
        }
        print( "\n" );

    #ifdef PARALLEL
            free( domain_size_received );
        }
    #endif
}

/**
    Registers signal handler for float point exceptions
*/
void RegisterFpeSignalHandler()
{
    /* Can also be any of the value below:
        FE_INEXACT inexact result
        FE_DIVBYZERO division by zero
        FE_UNDERFLOW result not representable due to underflow
        FE_OVERFLOW result not representable due to overflow
        FE_INVALID invalid operation
        FE_ALL_EXCEPT bitwise OR of all supported exceptions
    */
    feenableexcept( FE_DIVBYZERO | FE_INVALID );
    signal( SIGFPE, HandleFPESignals );
}

/**
    Function that handles the float point exceptions
*/
void HandleFPESignals( int signal )
{
    print( "\n\nFloat point exception\n" );
    PrintBacktrace();
    QUIT_PLUTO( 1 );
}

/**
    This function increases the time step by the factor \a timestep_increase_factor
    if in average less than \a iterations_limit iterations are used by the solver.

    \note This function is only used in some test cases to speed up the simulation.
        It is only useful if \f$ \Delta t \f$ is not handled by PLUTO
*/
void RadiationIncreaseTimestepSimple( Grid *grid, Data *data, int iterations )
{
#define analyse_number 400
    static int analyse_iterations_array[analyse_number];
    static int array_pos = 0;
    static int do_once = 1;
#ifndef iterations_limit
#define iterations_limit 5.
#endif
    const double timestep_increase_factor = 10.;

//  #define iterations_limit 5.
//  #define timestep_increase_factor 2.

    int n = 0;
    double average_iteration = 0.;

    if( do_once )
    {
        do_once = 0;
        for( n = 0; n < analyse_number; ++n )
        {
            analyse_iterations_array[n] = 1000;
        }
    }

    array_pos = array_pos % analyse_number;

    analyse_iterations_array[array_pos] = iterations;
    array_pos++;

    average_iteration = 0.;
    for( n = 0; n < analyse_number; ++n )
    {
        average_iteration += ( double )analyse_iterations_array[n];
    }
    average_iteration = average_iteration / ( ( double )analyse_number );

//  if(prank == 0)
//  {
//      print("average_iterations %2f\n",average_iteration);
//  }

    if( average_iteration < iterations_limit )
    {
        g_dt = g_dt * timestep_increase_factor;

        for( n = 0; n < analyse_number; ++n )
        {
            analyse_iterations_array[n] = 1000;
        }
    }

//  if(g_dt > 10e-2)
//  {
//      g_dt = 10e-2;
//  }

#undef analyse_number
#undef iterations_limit
}

void RadiationCollectGlobal1DArray( const Data *data, Grid *grid, int quantity, double( *compute_value )( int, int, int, Data *, Grid * ), int dir, int i_glob, int j_glob, int k_glob, double **result, int *result_size, int root, MPI_Comm communicator )
{
    int local_array_start = grid[dir].beg - grid[dir].gbeg;
    int local_array_end = grid[dir].end - grid[dir].gbeg + 1;
    int local_array_size = local_array_end - local_array_start;
    int domain_size = ( grid[dir].gend - grid[dir].gbeg + 1 );
    int n = 0, i = 0, j = 0, k = 0, var = -1;
    int nproc = 0;

    double *local_buffer = NULL;

    int *recvcnts = NULL;
    int *displs = NULL;

    *result_size = domain_size;


    MPI_Comm_size( communicator, &nproc );

    //ceck if local domain contains needed data
    if( dir == IDIR )
    {
        if( ( j_glob < grid[JDIR].beg || j_glob > grid[JDIR].end ) || ( k_glob < grid[KDIR].beg || k_glob > grid[KDIR].end ) )
        {
            local_array_start = 0;
            local_array_end = 0;
            local_array_size = 0;
        }
    }
    else if( dir == JDIR )
    {
        if( ( i_glob < grid[IDIR].beg || i_glob > grid[IDIR].end ) || ( k_glob < grid[KDIR].beg || k_glob > grid[KDIR].end ) )
        {
            local_array_start = 0;
            local_array_end = 0;
            local_array_size = 0;
        }

    }
    else if( dir == KDIR )
    {
        if( ( i_glob < grid[IDIR].beg || i_glob > grid[IDIR].end ) || ( j_glob < grid[JDIR].beg || j_glob > grid[JDIR].end ) )
        {
            local_array_start = 0;
            local_array_end = 0;
            local_array_size = 0;
        }
    }

    i = ( i_glob - grid[IDIR].beg ) + grid[IDIR].lbeg;
    j = ( j_glob - grid[JDIR].beg ) + grid[JDIR].lbeg;
    k = ( k_glob - grid[KDIR].beg ) + grid[KDIR].lbeg;

    if( prank == 0 )
    {
        recvcnts = malloc( sizeof( int ) * nproc );
        CHECK_ALLOCATED_MEMORY( recvcnts );
        displs = malloc( sizeof( int ) * nproc );
        CHECK_ALLOCATED_MEMORY( displs );

        *result = malloc( sizeof( double ) * domain_size );
        CHECK_ALLOCATED_MEMORY( displs );
    }

    MPI_Gather( &local_array_size, 1, MPI_INT, recvcnts, 1, MPI_INT, root, communicator );
    MPI_Gather( &local_array_start, 1, MPI_INT, displs, 1, MPI_INT, root, communicator );

    local_buffer = malloc( sizeof( double ) * local_array_size );

    if( compute_value == NULL )
    {
        if( dir == IDIR )
        {
            for( i = grid[IDIR].lbeg; i <= grid[IDIR].lend; i++ )
            {
                local_buffer[i - grid[IDIR].lbeg] = data->Vc[quantity][k][j][i];
            }
        }
        else if( dir == JDIR )
        {
            for( j = grid[JDIR].lbeg; j <= grid[JDIR].lend; j++ )
            {
                local_buffer[j - grid[JDIR].lbeg] = data->Vc[quantity][k][j][i];
            }
        }
        else if( dir == KDIR )
        {
            for( k = grid[KDIR].lbeg; k <= grid[KDIR].lend; k++ )
            {
                local_buffer[k - grid[KDIR].lbeg] = data->Vc[quantity][k][j][i];
            }
        }
    }
    else
    {
        if( dir == IDIR )
        {
            for( i = grid[IDIR].lbeg; i <= grid[IDIR].lend; i++ )
            {
                local_buffer[i - grid[IDIR].lbeg] = ( *compute_value )( k, j, i, ( Data * )data, grid );
            }
        }
        else if( dir == JDIR )
        {
            for( j = grid[JDIR].lbeg; j <= grid[JDIR].lend; j++ )
            {
                local_buffer[j - grid[JDIR].lbeg] = ( *compute_value )( k, j, i, ( Data * )data, grid );
            }
        }
        else if( dir == KDIR )
        {
            for( k = grid[KDIR].lbeg; k <= grid[KDIR].lend; k++ )
            {
                local_buffer[k - grid[KDIR].lbeg] = ( *compute_value )( k, j, i, ( Data * )data, grid );
            }
        }
    }

    MPI_Gatherv( local_buffer, local_array_size, MPI_DOUBLE, *result, recvcnts, displs, MPI_DOUBLE, root, communicator );

    free( local_buffer );
    free( recvcnts );
    free( displs );
}


