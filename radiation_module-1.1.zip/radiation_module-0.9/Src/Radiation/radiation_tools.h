/**
Copyright (C) 2011-2013 Stefan Kolb.

This file is part of the radiation module for the code PLUTO.

The radiation module is free software: you can redistribute it
and/or modify it under the terms of the GNU General Public
License as published by the Free Software Foundation, either
version 2 of the License, or (at your option) any later version.

The radiation module is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty
of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the radiation module. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef RADIATION_TOOLS_H
#define RADIATION_TOOLS_H

#include "pluto.h"
#include "error.h"
#include "backtrace.h"

void ShowDomainDecompositionAdvanced( Grid *grid );

void RegisterFpeSignalHandler();
void HandleFPESignals( int signal );

void RadiationIncreaseTimestepSimple( Grid *grid, Data *data, int iterations );

void RadiationCollectGlobal1DArray( const Data *data, Grid *grid, int quantity, double( *compute_value )( int, int, int, Data *, Grid * ), int dir, int i_glob, int j_glob, int k_glob, double **result, int *result_size, int root, MPI_Comm communicator );
#endif
