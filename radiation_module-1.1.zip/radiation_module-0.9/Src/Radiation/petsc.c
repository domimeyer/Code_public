/**
Copyright (C) 2011-2013 Stefan Kolb.
Copyright (C) 2012-2013 Moritz Stoll (shearing box boundary conditions)

This file is part of the radiation module for the code PLUTO.

The radiation module is free software: you can redistribute it
and/or modify it under the terms of the GNU General Public
License as published by the Free Software Foundation, either
version 2 of the License, or (at your option) any later version.

The radiation module is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty
of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the radiation module. If not, see <http://www.gnu.org/licenses/>.
*/

#include <string.h>
#include <execinfo.h>
#include <signal.h>
#include <stdlib.h>

#include "radiation.h"
#include "petsc.h"
#include "petsc_tools.h"

#include "modify_pluto.h"
#include "radiation_tools.h"
#include "opacity.h"
#include "assert.h"
#include "petsc_initialize_advanced.h"

Mat RadiationMatrix;
Vec RadiationSolution, RadiationRightHandSide;
KSP ksp;

/**
    This function computes in the MPI topology (created with MPI_Cart_create) for each direction
    and each node in this direction, the number of grid cells.


    \param[in]  grid
    \param[in]  topology_grid_size  number of cells (nodes) in each direction of the cartesian mpi topology grid
    \param[in]  topology_dims       number of dimensions of the cartesian mpi topology grid created with MPI_Cart_create
    \param[in]  comm                mpi communicator

    \param[out] topology_grid
*/
void GenerateTopologyGrid( Grid *grid, NeighbourGridItem **topology_grid, int *topology_grid_size, int topology_dims , MPI_Comm comm )
{
    int n = 0, size = 0, nproc = 1, rank = 0, position = 0, dir = 0;
    int domain_size[6];
    int *domain_size_received = NULL;

    MPI_Comm_rank( comm, &rank );

    domain_size[0] = grid[IDIR].rank_coord;
    domain_size[1] = NX1;

    domain_size[2] = grid[JDIR].rank_coord;
    domain_size[3] = NX2;

    domain_size[4] = grid[KDIR].rank_coord;
    domain_size[5] = NX3;

    if( topology_dims != DIMENSIONS )
    {
        print( "MPI Topology with the wrong number of dimmensions.\n" );
        QUIT_PLUTO( 1 );
    }

    size = 0;
    for( n = 0; n < topology_dims; n++ )
    {
        size += topology_grid_size[n];
    }

    if( rank == 0 )
    {
        MPI_Comm_size( comm, &nproc );
        domain_size_received = malloc( 6 * nproc * sizeof( int ) );
        CHECK_ALLOCATED_MEMORY( domain_size_received );
    }
    MPI_Gather( domain_size, 6, MPI_INT, domain_size_received, 6, MPI_INT, 0, comm );

    if( rank == 0 )
    {
        for( n = 0; n < nproc * 6; n += 6 )
        {
            topology_grid[IDIR][domain_size_received[n]].np = domain_size_received[n + 1];
        }

        for( n = 2; n < nproc * 6; n += 6 )
        {
            topology_grid[JDIR][domain_size_received[n]].np = domain_size_received[n + 1];
        }

        for( n = 4; n < nproc * 6; n += 6 )
        {
            topology_grid[KDIR][domain_size_received[n]].np = domain_size_received[n + 1];
        }
        free( domain_size_received );
    }
    MPI_Bcast( topology_grid[0], sizeof( NeighbourGridItem ) * size, MPI_CHAR, 0, comm );

    //Setting up the rest of the topology_grid
    for( dir = 0; dir < 3; ++dir )
    {
        position = grid[dir].gbeg;
        for( n = 0; n < topology_grid_size[dir]; ++n )
        {
            topology_grid[dir][n].beg = position;
            topology_grid[dir][n].end = topology_grid[dir][n].beg + topology_grid[dir][n].np - 1;

            position = topology_grid[dir][n].end + 1;
        }
    }
}

/**
    This function returns the rank mapping form communicator \a comm1 to \a comm2
    \note
        The \a mapping array must have a size \a s of MPI_Comm_size(comm1,&s),MPI_Comm_size(comm2,&s).
        The \a mapping array must be allocated for all processes.

    \param[in]  comm1
    \param[in]  comm2
    \param[out] mapping
*/
void GetRankMapping( MPI_Comm comm1, MPI_Comm comm2, int *mapping )
{
    int n = 0;
    int nproc1 = 0, nproc2 = 0;
    int rank1 = 0, rank2 = 0;
    int send_buffer[2];
    int *receive_buffer = NULL;

    MPI_Comm_size( comm1, &nproc1 );
    MPI_Comm_size( comm2, &nproc2 );

    if( nproc1 != nproc2 )
    {
        print( "The communicators must have the same size!!" );
        QUIT_PLUTO( 1 );
    }

    MPI_Comm_rank( comm1, &rank1 );
    MPI_Comm_rank( comm2, &rank2 );

    send_buffer[0] = rank1;
    send_buffer[1] = rank2;

    if( rank1 == 0 )
    {
        receive_buffer = malloc( sizeof( int ) * nproc1 * 2 );
        CHECK_ALLOCATED_MEMORY( receive_buffer );
    }

    MPI_Gather( send_buffer, 2, MPI_INT, receive_buffer, 2, MPI_INT, 0, comm1 );

    if( rank1 == 0 )
    {
        for( n = 0; n < nproc1 * 2; n = n + 2 )
        {
            mapping[receive_buffer[n]] = receive_buffer[n + 1];
        }
        free( receive_buffer );
    }

    MPI_Bcast( mapping, nproc1, MPI_INT, 0, comm1 );
}

/**
    Helper function for \ref PetscOffsetTestCase.

    \param[in]  nproc
    \param[in]  topology_grid
    \param[in]  topology_grid_size
    \param[in]  topology_dims
    \param[in]  comm_petsc
    \param[in]  comm_topology
    \param[out] offset_array
*/
void CalculateOffsets( int nproc, NeighbourGridItem **topology_grid, int *topology_grid_size, int topology_dims, int *offset_array, MPI_Comm comm_petsc, MPI_Comm comm_topology )
{
    int offset = 0, petsc_rank = 0, pluto_rank = 0;
    int *coords = NULL;
    int *rank_mapping = NULL;

    rank_mapping = malloc( sizeof( int ) * nproc );
    CHECK_ALLOCATED_MEMORY( rank_mapping );
    GetRankMapping( comm_petsc, comm_topology, rank_mapping );

    coords = malloc( sizeof( int ) * topology_dims );
    CHECK_ALLOCATED_MEMORY( coords );

    for( petsc_rank = 0; petsc_rank < nproc; ++petsc_rank )
    {
        MPI_Cart_coords( comm_topology, petsc_rank, topology_dims, coords );
        pluto_rank = rank_mapping[petsc_rank];

        offset_array[pluto_rank] = offset;
        offset +=  topology_grid[IDIR][coords[0]].np * topology_grid[JDIR][coords[1]].np * topology_grid[KDIR][coords[2]].np;
    }

    free( rank_mapping );
    free( coords );
}

/**
    This function checks if the offset is computed correctly

    \param[in]  grid
*/
void PetscOffsetTestCase( Grid *grid )
{
    MPI_Comm comm_topology;
    int rank, coords[3], nproc, topology_dims;
    int i = 0, j = 0, k = 0, pos = 0, current_offset = 0, tmp = 0;

    AL_Get_cart_comm( SZ, &comm_topology );
    MPI_Cartdim_get( comm_topology, &topology_dims );
    MPI_Comm_size( comm_topology, &nproc );

    for( rank = 0; rank < nproc; ++rank )
    {
        MPI_Cart_coords( comm_topology, rank, topology_dims, coords );

        current_offset = radiation_data.offset_array[rank];
        assert( current_offset == PetscGetVectorPosition( radiation_data.topology_grid[KDIR][coords[KDIR]].beg, radiation_data.topology_grid[JDIR][coords[JDIR]].beg, radiation_data.topology_grid[IDIR][coords[IDIR]].beg, grid ) );
        tmp = current_offset;
        for( k = radiation_data.topology_grid[KDIR][coords[KDIR]].beg; k <= radiation_data.topology_grid[KDIR][coords[KDIR]].end; ++k )
        {
            for( j = radiation_data.topology_grid[JDIR][coords[JDIR]].beg; j <= radiation_data.topology_grid[JDIR][coords[JDIR]].end; ++j )
            {
                for( i = radiation_data.topology_grid[IDIR][coords[IDIR]].beg; i <= radiation_data.topology_grid[IDIR][coords[IDIR]].end; ++i )
                {
                    pos = PetscGetVectorPosition( k, j, i, grid );
                    assert( pos == tmp );
                    tmp = tmp + 1;
                }
            }
        }
    }
}
/**
    Computes the offset needed to make the correct mapping from the local domain to the PETSc matrix done by the function
    \ref PetscGetVectorPosition.

    \param[in] grid
*/
void PetscCalculateVectorOffset( Grid *grid )
{
    MPI_Comm comm_topology;
    int topology_dims, size = 0, n = 0, position = 0, nproc = 0, dir = 0;
    int *periods, *coords;

    AL_Get_cart_comm( SZ, &comm_topology );
    MPI_Comm_size( comm_topology, &nproc );

    //BEGIN obtaining the topology_grid_size
    MPI_Cartdim_get( comm_topology, &topology_dims );
    radiation_data.topology_grid_size = malloc( topology_dims * sizeof( int ) );
    CHECK_ALLOCATED_MEMORY( radiation_data.topology_grid_size );
    periods = malloc( topology_dims * sizeof( int ) );
    coords =  malloc( topology_dims * sizeof( int ) );
    MPI_Cart_get( comm_topology, topology_dims, radiation_data.topology_grid_size, periods, coords );
    //END

    //BEGIN allocating and setting up the topology grid
    radiation_data.topology_grid =  malloc( sizeof( NeighbourGridItem * ) * topology_dims );
    CHECK_ALLOCATED_MEMORY( radiation_data.topology_grid );
    size = 0;
    for( n = 0; n < topology_dims; n++ )
    {
        size += radiation_data.topology_grid_size[n];
    }
    radiation_data.topology_grid[0] = malloc( sizeof( NeighbourGridItem ) * size );
    CHECK_ALLOCATED_MEMORY( radiation_data.topology_grid[0] );
    position = 0;
    for( n = 1; n < topology_dims; n++ )
    {
        position += radiation_data.topology_grid_size[n - 1];
        radiation_data.topology_grid[n] = &radiation_data.topology_grid[0][position];
    }
    GenerateTopologyGrid( grid, radiation_data.topology_grid, radiation_data.topology_grid_size, topology_dims, comm_topology );
    //END

    //BEGIN consistency check
    if( grid[IDIR].np_int != radiation_data.topology_grid[IDIR][coords[0]].np || grid[JDIR].np_int != radiation_data.topology_grid[JDIR][coords[1]].np || grid[KDIR].np_int != radiation_data.topology_grid[KDIR][coords[2]].np )
    {
        print( "Function GenerateTopologyGrid failed on rank=%d\n", prank );
        QUIT_PLUTO( 1 );
    }
    //END

    //BEGIN allocating and setting up the offset array
    radiation_data.offset_array =  malloc( sizeof( int ) * nproc );
    CHECK_ALLOCATED_MEMORY( radiation_data.offset_array );

    CalculateOffsets( nproc, radiation_data.topology_grid, radiation_data.topology_grid_size, topology_dims, radiation_data.offset_array, PETSC_COMM_WORLD, comm_topology );
    //END

    for( dir = 0; dir < 3; ++dir )
    {
        radiation_data.num_low_part[dir] = grid[dir].np_int_glob % radiation_data.topology_grid_size[dir];
        radiation_data.np_high_part[dir] = grid[dir].np_int_glob / radiation_data.topology_grid_size[dir];
        radiation_data.np_low_part[dir] = radiation_data.num_low_part[dir] == 0 ? radiation_data.np_high_part[dir] : radiation_data.np_high_part[dir] + 1;
    }
    AL_Get_cart_comm( SZ, &radiation_data.comm_topology );

#ifdef DEBUG
    PetscOffsetTestCase( grid );
    PetscComputeToplology1DPositionTestCase();
#endif

//  #ifdef DEBUG
//  if(prank == 0)
//  {
//      for(position = 0; position < 3; ++position)
//      {
//          for(n = 0; n < radiation_data.topology_grid_size[position]; ++n)
//          {
//              print("%5d  ", radiation_data.topology_grid[position][n].np);
//          }
//          print("\n");
//      }
//
//      print("\n\n");
//
//      for(position = 0; position < nproc; ++position)
//      {
//          print("%5d  ", radiation_data.offset_array[position]);
//      }
//      print("\n");
//
//  }
//  QUIT_PLUTO(1);
//  #endif

    free( periods );
    free( coords );
}

/**
    This function checks if function \ref ComputeToplology1DPositionthe correct.

    \param[in]  grid
*/
int PetscComputeToplology1DPositionTestCase()
{
    int topology_1D_size = 1, domain_np = 1, position = 0, position_check = 0;
    int coordinate_check = 0, coordinate = 0;
    int copy_np_low_part, copy_np_high_part, copy_num_low_part;
    int n = 0;

    copy_np_low_part = radiation_data.np_low_part[0];
    copy_np_high_part = radiation_data.np_high_part[0];
    copy_num_low_part = radiation_data.num_low_part[0];


    for( topology_1D_size = 1; topology_1D_size < 50; ++topology_1D_size )
    {
        for( domain_np = topology_1D_size; domain_np < 1000; ++domain_np )
        {
            radiation_data.num_low_part[0] = domain_np % topology_1D_size;
            radiation_data.np_high_part[0] = domain_np / topology_1D_size;
            radiation_data.np_low_part[0] = radiation_data.num_low_part[0] == 0 ? radiation_data.np_high_part[0] : radiation_data.np_high_part[0] + 1;

            for( position = 0; position < domain_np; ++position )
            {
                coordinate = ComputeToplology1DPosition( 0, position );

                position_check = 0;
                coordinate_check = 0;
                for( n = 0; n < topology_1D_size; ++n )
                {
                    if( coordinate_check < radiation_data.num_low_part[0] )
                    {
                        position_check += radiation_data.np_low_part[0];
                    }
                    else
                    {
                        position_check += radiation_data.np_high_part[0];
                    }

                    if( position < position_check )
                    {
                        break;
                    }
                    coordinate_check++;
                }

                assert( coordinate == coordinate_check );
            }
        }
    }

    radiation_data.np_low_part[0] = copy_np_low_part;
    radiation_data.np_high_part[0] = copy_np_high_part;
    radiation_data.num_low_part[0] = copy_num_low_part;
}

/**
    This function computes the position inside the MPI topology for a specific direction from
    the global position of a grid cell.

    \param[in] dir          coordinate direction dir=IDIR,JDIR or KDIR
    \param[in] position     global position of a grid cell in direction \a dir

    \returns the position inside the topology
*/
int ComputeToplology1DPosition( int dir, int position )
{
    int c_low = 0, c_high = 0;

    c_low = position / radiation_data.np_low_part[dir];

    if( c_low >= radiation_data.num_low_part[dir] )
    {
        c_low = radiation_data.num_low_part[dir];
        c_high = ( position - ( radiation_data.np_low_part[dir] * c_low ) ) / radiation_data.np_high_part[dir];
    }
    return abs( c_low + c_high );
}

/**
    In this function we map the index (k,j,i) of the active cells to a continuing number.This is
    useful if we want to store the active cells of the global 3D grid in a 1D array. Here it is
    used to calculate the positions inside PETSc's vectors and matrices to set the entries there.

    \note
    This function can only return valid results if \a k, \a j, \a i are valid cells and no global
    ghost cells. If The function is called with an index set which points to such a ghost cell
    then the position 0 is returned.

    \warning
    This function is complicated because of the parallelization. In the case that the computation
    is not parallel then this function can be reduced to:

    return k * grid[JDIR].np_int_glob * grid[IDIR].np_int_glob + j * grid[IDIR].np_int_glob + i;

    \param[in]  k   global index k
    \param[in]  j   global index j
    \param[in]  i   global index i
    \param[in]  grid

    \returns    the mapped position (i,j,k) -> position
*/
int PetscGetVectorPosition( int k, int j, int i, Grid *grid )
{
    int topology_coord[3];
    int rank = 0, offset = 0, position = 0;

    topology_coord[0] = ComputeToplology1DPosition( IDIR, i - grid[IDIR].gbeg );
    topology_coord[1] = ComputeToplology1DPosition( JDIR, j - grid[JDIR].gbeg );
    topology_coord[2] = ComputeToplology1DPosition( KDIR, k - grid[KDIR].gbeg );

    if( topology_coord[0] >= radiation_data.topology_grid_size[0] || topology_coord[1] >= radiation_data.topology_grid_size[1] || topology_coord[2] >= radiation_data.topology_grid_size[2] )
    {
        return -2;
    }

    MPI_Cart_rank( radiation_data.comm_topology, topology_coord, &rank );

    offset = radiation_data.offset_array[rank];

    int li = i - radiation_data.topology_grid[IDIR][topology_coord[0]].beg;
    int lj = j - radiation_data.topology_grid[JDIR][topology_coord[1]].beg;
    int lk = k - radiation_data.topology_grid[KDIR][topology_coord[2]].beg;

    int in = radiation_data.topology_grid[IDIR][topology_coord[0]].np;
    int jn = radiation_data.topology_grid[JDIR][topology_coord[1]].np;
    int kn = radiation_data.topology_grid[KDIR][topology_coord[2]].np;

    position = offset + lk * jn * in + lj * in + li;

    assert( position - offset  < in * jn * kn );
    return position;
}

/**
    Maps the local index local_k,local_j,local_i to the global index global_k,global_j,global_i.

    \param[in]  local_k
    \param[in]  local_j
    \param[in]  local_i
    \param[in]  grid

    \param[out] global_k
    \param[out] global_j
    \param[out] global_i
*/
void PetscMapLocalToGlobalIndex( int local_k, int local_j, int local_i, Grid *grid, int *global_k, int *global_j, int *global_i )
{
    *global_k = local_k - KBEG + grid[KDIR].beg;
    *global_j = local_j - JBEG + grid[JDIR].beg;
    *global_i = local_i - IBEG + grid[IDIR].beg;
}

/**
    Generates the matrix and right hand side vector of the system of equations to solve.

    \note
        dir = KDIR,JDIR,IDIR \n
        grid[dir].gbeg is the first active cell in the global array \n
        grid[dir].gend is the last active cell in the global array \n

    \param[in]  grid
    \param[in]  d
    \param[out] A
    \param[out] b
*/
void PetscGenerateSystemOfEquations( Mat A, Vec b, Grid *grid, Data *d )
{
    int local_k = 0, local_j = 0, local_i = 0;
    int global_k = 0, global_j = 0, global_i = 0;

    int n = 0;

    double coefficient[7], coefficientB = 0.;
    int column_position_coefficient[7], row = 0;

#ifdef SHEARINGBOX
    double t = g_time;
    double scrh;
    int Delta_j;

    double sb_Ly;
    double Lx;
    double sb_vy;
    int sheared_j;

    Lx = grid[IDIR].xr_glob[grid[IDIR].gend] - grid[IDIR].xl_glob[grid[IDIR].gbeg];
    sb_Ly = grid[JDIR].xr_glob[grid[JDIR].gend] - grid[JDIR].xl_glob[grid[JDIR].gbeg];
    sb_vy = fabs( 2.0 * sb_A * Lx );

    scrh    = ( fmod( sb_vy * t, sb_Ly ) ) / grid[JDIR].dx[JBEG];
    Delta_j = ( int )scrh;
#endif

//  coefficient[0]  -> if there is no boundary affected this variable is coefficient_U1
//  ...
//  coefficient[6]  -> if there is no boundary affected this variable is coefficient_U7

//  column_position_coefficient[0] -> column position of coefficient[0] in the matrix
//  ...
//  column_position_coefficient[6] -> column position of coefficient[6] in the matrix
//  column_position_coefficientB   -> not needed: vector has no columns

//  MatZeroEntries(A);  //is needed because use matrix insert mode ADD_VALUES on second run of generateSystemOfEquations
//  VecZeroEntries(b);  // same argument as line above
//  PetscCacheReset();

    DOM_LOOP( local_k, local_j, local_i )
    {
        PetscMapLocalToGlobalIndex( local_k, local_j, local_i, grid, &global_k, &global_j, &global_i );

        row = PetscGetVectorPosition( global_k, global_j, global_i, grid );

        assert( row < grid[KDIR].np_int_glob * grid[JDIR].np_int_glob * grid[IDIR].np_int_glob );
        assert( row >= 0 );

//      coefficient[0] = ComputeCoefficientU1(local_k,local_j,local_i,d,grid);
//      column_position_coefficient[0] = row;

        coefficient[1] = ComputeCoefficientU2( local_k, local_j, local_i, d, grid );
        column_position_coefficient[1] = PetscGetVectorPosition( global_k - 1, global_j, global_i, grid ); //it is possible that this function will return a wrong result because global_k - 1 can be a ghost cell an so the returned position is not correct. This doesn't matter because in this case the boundary condition which is set later will correct this. This is the same for the following calls to the function getVectorPosition.

        coefficient[2] = ComputeCoefficientU3( local_k, local_j, local_i, d, grid );
        column_position_coefficient[2] = PetscGetVectorPosition( global_k + 1, global_j, global_i, grid );

        coefficient[3] = ComputeCoefficientU4( local_k, local_j, local_i, d, grid );
        column_position_coefficient[3] = PetscGetVectorPosition( global_k, global_j - 1, global_i, grid );

        coefficient[4] = ComputeCoefficientU5( local_k, local_j, local_i, d, grid );
        column_position_coefficient[4] = PetscGetVectorPosition( global_k, global_j + 1, global_i, grid );

        coefficient[5] = ComputeCoefficientU6( local_k, local_j, local_i, d, grid );
        column_position_coefficient[5] = PetscGetVectorPosition( global_k, global_j, global_i - 1, grid );

        coefficient[6] = ComputeCoefficientU7( local_k, local_j, local_i, d, grid );
        column_position_coefficient[6] = PetscGetVectorPosition( global_k, global_j, global_i + 1, grid );

        coefficient[0] = ComputeCoefficientU1Advanced( local_k, local_j, local_i, d, grid, coefficient[1], coefficient[2], coefficient[3], coefficient[4], coefficient[5], coefficient[6] );
        column_position_coefficient[0] = row;

        coefficientB = ComputeCoefficientB( local_k, local_j, local_i, d, grid );

        if( global_k - 1 < grid[KDIR].gbeg ) //check if global_k - 1 is a global ghost cell
        {
            switch( radiation_data.boundary_conditions[KDIR].bc_beg )
            {
                case RADIATION_BC_PERIODIC:
                    column_position_coefficient[1] = PetscGetVectorPosition( grid[KDIR].gend, global_j, global_i, grid );
                    break;

                case RADIATION_BC_SYMMETRIC:
                case RADIATION_BC_REFLECTIVE:
                case RADIATION_BC_OUTFLOW:
                    coefficient[0] = coefficient[0] + coefficient[1];
                    column_position_coefficient[1] = -1;
                    break;

                case RADIATION_BC_FIXEDVALUE:
                    coefficientB = coefficientB - coefficient[1] * radiation_data.boundary_conditions[KDIR].beg_fixedvalue;
                    column_position_coefficient[1] = -1;
                    break;
            }
        }
        else if( global_k + 1 > grid[KDIR].gend ) //check if global_k + 1 is a global ghost cell
        {
            switch( radiation_data.boundary_conditions[KDIR].bc_end )
            {
                case RADIATION_BC_PERIODIC:
                    column_position_coefficient[2] = PetscGetVectorPosition( grid[KDIR].gbeg, global_j, global_i, grid );
                    break;

                case RADIATION_BC_SYMMETRIC:
                case RADIATION_BC_REFLECTIVE:
                case RADIATION_BC_OUTFLOW:
                    coefficient[0] = coefficient[0] + coefficient[2];
                    column_position_coefficient[2] = -1;
                    break;

                case RADIATION_BC_FIXEDVALUE:
                    coefficientB = coefficientB - coefficient[2] * radiation_data.boundary_conditions[KDIR].end_fixedvalue;
                    column_position_coefficient[2] = -1;
                    break;
            }
        }

        if( global_j - 1 < grid[JDIR].gbeg )
        {
            switch( radiation_data.boundary_conditions[JDIR].bc_beg )
            {
                case RADIATION_BC_PERIODIC:
                    column_position_coefficient[3] = PetscGetVectorPosition( global_k, grid[JDIR].gend, global_i, grid );
                    break;

                case RADIATION_BC_SYMMETRIC:
                case RADIATION_BC_REFLECTIVE:
                case RADIATION_BC_OUTFLOW:
                    coefficient[0] = coefficient[0] + coefficient[3];
                    column_position_coefficient[3] = -1;
                    break;

                case RADIATION_BC_FIXEDVALUE:
                    coefficientB = coefficientB - coefficient[3] * radiation_data.boundary_conditions[JDIR].beg_fixedvalue;
                    column_position_coefficient[3] = -1;
                    break;
            }
        }
        else if( global_j + 1 > grid[JDIR].gend )
        {
            switch( radiation_data.boundary_conditions[JDIR].bc_end )
            {
                case RADIATION_BC_PERIODIC:
                    column_position_coefficient[4] = PetscGetVectorPosition( global_k, grid[JDIR].gbeg, global_i, grid );
                    break;

                case RADIATION_BC_SYMMETRIC:
                case RADIATION_BC_REFLECTIVE:
                case RADIATION_BC_OUTFLOW:
                    coefficient[0] = coefficient[0] + coefficient[4];
                    column_position_coefficient[4] = -1;
                    break;

                case RADIATION_BC_FIXEDVALUE:
                    coefficientB = coefficientB - coefficient[4] * radiation_data.boundary_conditions[JDIR].end_fixedvalue;
                    column_position_coefficient[4] = -1;
                    break;
            }
        }

        if( global_i - 1 < grid[IDIR].gbeg )
        {
            switch( radiation_data.boundary_conditions[IDIR].bc_beg )
            {
                case RADIATION_BC_PERIODIC:
                    column_position_coefficient[5] = PetscGetVectorPosition( global_k, global_j, grid[IDIR].gend, grid );
                    break;

                case RADIATION_BC_SYMMETRIC:
                case RADIATION_BC_REFLECTIVE:
                case RADIATION_BC_OUTFLOW:
                    coefficient[0] = coefficient[0] + coefficient[5];
                    column_position_coefficient[5] = -1;
                    break;

                case RADIATION_BC_FIXEDVALUE:
                    coefficientB = coefficientB - coefficient[5] * radiation_data.boundary_conditions[IDIR].beg_fixedvalue;
                    column_position_coefficient[5] = -1;
                    break;
                    
                #ifdef SHEARINGBOX
                    case RADIATION_BC_SHEARINGBOX:
                        sheared_j = ( global_j - Delta_j );
                        if( sheared_j < grid[JDIR].gbeg ) sheared_j += ( grid[JDIR].gend - grid[JDIR].gbeg + 1 );
                        if( sheared_j > grid[JDIR].gend ) sheared_j -= ( grid[JDIR].gend - grid[JDIR].gbeg + 1 );
                        column_position_coefficient[5] = PetscGetVectorPosition( global_k, sheared_j, grid[IDIR].gend, grid );
                        break;
                #endif
            }
        }
        else if( global_i + 1 > grid[IDIR].gend )
        {
            switch( radiation_data.boundary_conditions[IDIR].bc_end )
            {
                case RADIATION_BC_PERIODIC:
                    column_position_coefficient[6] = PetscGetVectorPosition( global_k, global_j, grid[IDIR].gbeg, grid );
                    break;

                case RADIATION_BC_SYMMETRIC:
                case RADIATION_BC_REFLECTIVE:
                case RADIATION_BC_OUTFLOW:
                    coefficient[0] = coefficient[0] + coefficient[6];
                    column_position_coefficient[6] = -1;
                    break;

                case RADIATION_BC_FIXEDVALUE:
                    coefficientB = coefficientB - coefficient[6] * radiation_data.boundary_conditions[IDIR].end_fixedvalue;
                    column_position_coefficient[6] = -1;
                    break;
                    
                #ifdef SHEARINGBOX
                    case RADIATION_BC_SHEARINGBOX:
                        sheared_j = ( global_j + Delta_j );
                        if( sheared_j < grid[JDIR].gbeg ) sheared_j += ( grid[JDIR].gend - grid[JDIR].gbeg + 1 );
                        if( sheared_j > grid[JDIR].gend ) sheared_j -= ( grid[JDIR].gend - grid[JDIR].gbeg + 1 );
                        column_position_coefficient[6] = PetscGetVectorPosition( global_k, sheared_j, grid[IDIR].gbeg, grid );
                        break;
                #endif
            }
        }

        #ifdef DEBUG
            int local_rows_start = 0, local_rows_end = 0;
            MatGetOwnershipRange( RadiationMatrix, &local_rows_start, &local_rows_end );
            if( !( local_rows_start <= row && row <= local_rows_end ) )
            {
                printf( "prank=%3d: Current row=%6d is not stored local.\n", prank, row );
            }
        #endif

        for( n = 0; n < 7; ++n )
        {
            if( column_position_coefficient[n] != -1 )
            {
                assert( column_position_coefficient[n] < grid[KDIR].np_int_glob * grid[JDIR].np_int_glob * grid[IDIR].np_int_glob );
                assert( column_position_coefficient[n] >= 0 );
                MatSetValue( A, row, column_position_coefficient[n], coefficient[n], INSERT_VALUES ); //FIXME use local access functions
            }
        }
        VecSetValue( b, row, coefficientB, INSERT_VALUES ); //FIXME use local access functions
    }
    MatAssemblyBegin( A, MAT_FINAL_ASSEMBLY );
    MatAssemblyEnd( A, MAT_FINAL_ASSEMBLY );

    VecAssemblyBegin( b );
    VecAssemblyEnd( b );
}

/**
    Computes the next time step by using the PETSc library

    \param[in]  grid
    \param[in]  data

    \returns the number of used iterations
*/
int PetscImplicitTimestep( Grid *grid, Data *data )
{
    KSPConvergedReason converged_reason;
    int iterations = 0;
    PetscErrorCode ierr;

    #ifdef SHEARINGBOX
        static int do_once = 1;
        static int *rows;
        static int num_rows = 0;
        int row_start = 0, row_end = 0, i = 0;

        if( do_once )
        {
            do_once = 0;
            ierr = MatGetOwnershipRange( RadiationMatrix, &row_start, &row_end );
            num_rows = ( row_end - row_start );
            rows = malloc( sizeof( int ) * num_rows );
            CHECK_ALLOCATED_MEMORY( rows );

            row_list[0] = row_start;
            for( i = 1; i < num_rows; ++i )
            {
                rows[i] = rows[i - 1] + 1;
            }
        }

        ierr = MatZeroRowsLocal( RadiationMatrix, num_rows, rows, 0.0, 0, 0 ); CHKERR( ierr );
        ierr = KSPSetOperators( ksp, RadiationMatrix, RadiationMatrix, DIFFERENT_NONZERO_PATTERN ); CHKERR( ierr );
    #endif


    PetscGenerateSystemOfEquations( RadiationMatrix, RadiationRightHandSide, grid, data );

//  char buffer[512];
//  sprintf(buffer,"matrix.%04ld.mat",NSTEP);
//  writeMatrixToFile(buffer,RadiationMatrix);

    ierr = KSPSetOperators( ksp, RadiationMatrix, RadiationMatrix, SAME_NONZERO_PATTERN ); CHKERR( ierr );
    ierr = KSPSolve( ksp, RadiationRightHandSide, RadiationSolution ); CHKERR( ierr );

    ierr = KSPGetConvergedReason( ksp, &converged_reason ); CHKERR( ierr );

    //for more details look at http://www.mcs.anl.gov/petsc/petsc-as/snapshots/petsc-current/docs/manualpages/KSP/KSPConvergedReason.html
    if( converged_reason < 0 )
    {
        print( "Iterative solver not converged\n" );
        QUIT_PLUTO( 1 );
    }
    else
    {
        ierr = KSPGetIterationNumber( ksp, &iterations ); CHKERR( ierr );
    }

    PetscCollectData( RadiationSolution, radiation_data.Erad );

    RadiationBoundaryCondition( grid, data );

    UpdatePlutoPressure( grid, data );
    return iterations;
}

/**
    Collects the data from the PETSc vector \a b (The result from the matrix solver which
    means the new radiation energy density) and writes it in the array \a Erad.
*/
void PetscCollectData( Vec b, double *** Erad )
{
    PetscScalar *local_array = NULL;
    int n = 0, local_k = 0, local_j = 0, local_i = 0;

    PetscErrorCode ierr;

    ierr = VecGetArray( b, &local_array ); CHKERR( ierr );

    n = 0;
    DOM_LOOP( local_k, local_j, local_i )
    {
        Erad[local_k][local_j][local_i] = local_array[n];
        n++;
    }
    ierr = VecRestoreArray( b, &local_array ); CHKERR( ierr );
}

/**
    Initializes all the PETSc library and all necessary things needed for the solver based on PETSc,

    \param[in] argc the number of command line arguments given to PLUTO
    \param[in] argv the command line arguments given to PLUTO
    \param[in] input
    \param[in] grid
    \param[in] data
*/
void PetscInit( int argc, char **argv, Input *input, Grid *grid, Data *data )
{
    PetscErrorCode ierr;
    int nproc = 0;
    int mat_global_rows = grid[KDIR].np_int_glob * grid[JDIR].np_int_glob * grid[IDIR].np_int_glob, mat_global_columns = mat_global_rows;
    int mat_local_rows = grid[KDIR].np_int * grid[JDIR].np_int * grid[IDIR].np_int, mat_local_columns = mat_global_columns;

    if( prank == 0 )
    {
        print( "\n> Radiation Solver Settings\n" );
        print( " %-25s %s\n", "SOLVER:", "PETSc" );

        print( " %-25s %5.3e\n", "absolute-tolerance:", radiation_data.absolute_tolerance );
        print( " %-25s %5.3e\n", "relative-tolerance:" , radiation_data.relative_tolerance );
        print( " %-25s %d\n", "max-iterations:", radiation_data.max_iterations );
    }

    MPI_Comm_size( MPI_COMM_WORLD, &nproc );
    //PetscInitialize(&argc,&argv,(char *)0,(char *)0);
    PetscInitializeAdvanced( argc, argv );

    PetscCalculateVectorOffset( grid );

    ierr = MatCreate( PETSC_COMM_WORLD, &RadiationMatrix ); CHKERR( ierr );
    ierr = MatSetType( RadiationMatrix, MATMPIAIJ ); CHKERR( ierr );
    ierr = MatSetSizes( RadiationMatrix, mat_local_rows, mat_local_rows, mat_global_rows, mat_global_columns ); CHKERR( ierr );
//  ierr = MatSetSizes(RadiationMatrix,mat_local_rows,PETSC_DECIDE,mat_global_rows,mat_global_columns); CHKERR(ierr);
//  ierr = MatSetSizes(RadiationMatrix,PETSC_DECIDE,PETSC_DECIDE,mat_global_rows,mat_global_columns); CHKERR(ierr);
//      ierr = MatSetFromOptions(RadiationMatrix);CHKERR(ierr); //Note since PETSc version above 3.1 MatSetFromOptions is only working if it is called bevore the function MatSetType

    /*
        If there is a reaseon to not use \a PetscMatrixMemoryPreallocation then it is necessary to call

        ierr = MatSetUp(RadiationMatrix); CHKERR(ierr);

        Note: without preallocation the first generation of the matrix is more than 100 times slower than
        with \a PetscMatrixMemoryPreallocation
    */
//  ierr = MatSetUp(RadiationMatrix); CHKERR(ierr);
    ierr = MatMPIAIJSetPreallocation( RadiationMatrix, 8, PETSC_NULL, 8, PETSC_NULL ); CHKERR( ierr );

    ierr = MatGetVecs( RadiationMatrix, &RadiationSolution, PETSC_NULL ); CHKERR( ierr );
    ierr = VecDuplicate( RadiationSolution, &RadiationRightHandSide ); CHKERR( ierr );

    ierr = KSPCreate( PETSC_COMM_WORLD, &ksp ); CHKERR( ierr );
    #ifdef SHEARINGBOX
        ierr = KSPSetOperators( ksp, RadiationMatrix, RadiationMatrix, DIFFERENT_NONZERO_PATTERN ); CHKERR( ierr );
    #else
        ierr = KSPSetOperators( ksp, RadiationMatrix, RadiationMatrix, SAME_NONZERO_PATTERN ); CHKERR( ierr );
    #endif
    ierr = KSPSetTolerances( ksp, radiation_data.relative_tolerance, radiation_data.absolute_tolerance, PETSC_DEFAULT, radiation_data.max_iterations ); CHKERR( ierr );
    ierr = KSPSetInitialGuessNonzero( ksp, PETSC_TRUE ); CHKERR( ierr );
    ierr = KSPSetFromOptions( ksp ); CHKERR( ierr );
}

/**
    Frees all memory used by PETSc and also calls PetscFinalize()
*/
void PetscCleanup()
{
    #if PETSC_VERSION_MAJOR >= 3 && PETSC_VERSION_MINOR > 1
        KSPDestroy( &ksp );
        MatDestroy( &RadiationMatrix );
        VecDestroy( &RadiationRightHandSide );
        VecDestroy( &RadiationSolution );
    #else
        KSPDestroy( ksp );
        MatDestroy( RadiationMatrix );
        VecDestroy( RadiationRightHandSide );
        VecDestroy( RadiationSolution );
    #endif

    free( radiation_data.topology_grid[0] );
    free( radiation_data.topology_grid );
    free( radiation_data.topology_grid_size );
    free( radiation_data.offset_array );

    PetscFinalize();
}
