/**
Copyright (C) 2011-2013 Stefan Kolb.

This file is part of the radiation module for the code PLUTO.

The radiation module is free software: you can redistribute it
and/or modify it under the terms of the GNU General Public
License as published by the Free Software Foundation, either
version 2 of the License, or (at your option) any later version.

The radiation module is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty
of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the radiation module. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef ASSERT_H
#define ASSERT_H

#include <stdlib.h>
#include <stdio.h>

#include "backtrace.h"

#define BACKTRACE_COMMAND PrintBacktrace()
#define PRINT_COMMAND(condition) print("\nAssert\n\t(%s)==false \n\tfile: %s:%d function: %s\n",#condition,__FILE__, __LINE__,__FUNCTION__);

#ifdef QUIT_PLUTO //check if pluto is used
    #define EXIT_COMMAND(status) QUIT_PLUTO(status);
    #ifdef PARALLEL
        #undef PRINT_COMMAND
        #define PRINT_COMMAND(condition) print("\nAssert: Process %d \n\t(%s)==false \n\tfile: %s:%d function: %s\n",prank,#condition,__FILE__, __LINE__,__FUNCTION__);
    #endif
#else
    #define EXIT_COMMAND(status) exit(status);
#endif

#ifdef DEBUG
    #define assert(condition)\
        if(!(condition))\
        {\
            PRINT_COMMAND(condition);\
            print("\n\n");\
            BACKTRACE_COMMAND;\
            EXIT_COMMAND(1);\
        }
#else
    #define assert(condition)
#endif

#endif
