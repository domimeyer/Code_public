/**
Copyright (C) 2011-2013 Stefan Kolb.

This file is part of the radiation module for the code PLUTO.

The radiation module is free software: you can redistribute it
and/or modify it under the terms of the GNU General Public
License as published by the Free Software Foundation, either
version 2 of the License, or (at your option) any later version.

The radiation module is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty
of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the radiation module. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef IRRADIATION_H
#define IRRADIATION_H

#include "pluto.h"

typedef struct LOCAL_DOMAIN_INFO
{
    int x1_begin;
    int x1_end;

    int x2_begin;
    int x2_end;

    int x3_begin;
    int x3_end;

} LocalDomainInfo;

typedef struct COMMUNICATION_NEIGHBOUR
{
    int receive_rank;
    int send_rank;
} CommunicationNeighbour;

typedef struct STAR_PROPERTIES
{
    double R;           /// Radius
    double T;           /// Temperature of the star
    double Ln;          /// \f$ Ln = R_\star^2 \sigma T_\star^4 \f$
    double L;           /// \f$ L = 4 \pi R_\star^2 \sigma T_\star^4 \f$

    double x, y, z;     /// the position of the star (in Cartesian coordinates)
    int central;        ///if central == 1 then the star is in the center of the coordinate system (only important in spherical coordinates)
} StarProperties;

typedef struct IRRADIATION_DATA
{
    CommunicationNeighbour neighbour;
    double **   *S;
    double *data_buffer;
    double *optical_depth_offset;

    StarProperties star;

} IrradiationData;


extern IrradiationData irradiation;

void IrradiationInit( Grid *grid );
void IrradiationFinalise( void );

void IrradiationFindCommunicationNeighbours( Grid *grid );
void IrradiationCalculateS( Grid *grid, Data *data );

void IrradiationSetStarProperties( double R, double T );

void IrradiationFindCommunicationNeighbour( int current_rank, LocalDomainInfo *domain_info_array, int nproc, CommunicationNeighbour *cn );
void IrradiationCalculateOpticalDepthPerDomain( Grid *grid, Data *data );

double IrradiationOpacity( double density, double temperature );
#endif
