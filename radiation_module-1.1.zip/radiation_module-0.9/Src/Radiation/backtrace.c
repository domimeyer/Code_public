/**
Copyright (C) 2011-2013 Stefan Kolb.

This file is part of the radiation module for the code PLUTO.

The radiation module is free software: you can redistribute it
and/or modify it under the terms of the GNU General Public
License as published by the Free Software Foundation, either
version 2 of the License, or (at your option) any later version.

The radiation module is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty
of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the radiation module. If not, see <http://www.gnu.org/licenses/>.
*/

#include "pluto.h"
#include "backtrace.h"

#include <unistd.h>     //for function access
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <execinfo.h>

/**
    Executes the command given by \a command and reads size bytes form is
    output and stores it in \a output

    \param[in]  command
    \param[in]  size
    \param[out] output

    \returns    the number of read bytes
*/
int ExecuteCommand( char *command, char *output, unsigned int size )
{
    unsigned int blocksize = 128;
    unsigned int read_size = 0, remaining_size = size - 1, total_read = 0;
    char *current_buffer_start = output;

    FILE *program = popen( command, "r" );
    if( !program )
    {
        return 0;
    }

    while( !feof( program ) && !ferror( program ) )
    {
        if( remaining_size < blocksize )
        {
            blocksize = remaining_size;
        }

        read_size = fread( current_buffer_start, 1, blocksize, program );
        remaining_size = remaining_size - read_size;
        current_buffer_start = current_buffer_start + read_size;
        total_read += read_size;
    }
    output[total_read] = '\0';
    pclose( program );
    return total_read;
}

/**
    This function parses a string (line) returned by the function backtrace_symbols()
    and prints the parsed components.

    \param[in]  str
*/
void PrintBacktraceString( char *str )
{
    const int buffer_size = 1024;
    int string_length = 0, i = 0;
    char buffer[buffer_size];
    char *empty_string = " ";

    const unsigned int addr2line_buffer_size = 512;
    unsigned int addr2line_size = 0;
    char addr2line_buffer[addr2line_buffer_size];
    char addr2line_command[addr2line_buffer_size];

    char *program = NULL;
    char *function = NULL;
    char *function_offset = NULL;
    char *return_adress = NULL;
    char *file = empty_string;

    if( str == NULL )
    {
        print( "\t%-30s %-50s %-8s %-16s %s\n", "file", "function name", "f. offset", "return adress", "programm" );
        print( "\t---------------------------------------------------------------------------------------------------------------------\n" );
        return;
    }

    string_length = strlen( str );

    if( string_length < buffer_size )
    {
        memcpy( buffer, str, string_length );

        program = buffer;
        for( i = 0; i < string_length; ++i )
        {
            if( buffer[i] == '(' )
            {
                buffer[i] = '\0';
                function = &buffer[i + 1];
            }
            else if( buffer[i] == '+' )
            {
                buffer[i] = '\0';
                function_offset = &buffer[i + 1];
            }
            else if( buffer[i] == ')' )
            {
                buffer[i] = '\0';
            }
            else if( buffer[i] == '[' )
            {
                buffer[i] = '\0';
                return_adress = &buffer[i + 1];
            }
            else if( buffer[i] == ']' )
            {
                buffer[i] = '\0';
            }
        }

        if( program == NULL ) program = empty_string;
        if( function == NULL ) function = empty_string;
        if( function_offset == NULL ) function_offset = empty_string;
        if( return_adress == NULL ) return_adress = empty_string;

        snprintf( addr2line_command, addr2line_buffer_size, "addr2line -i -s -e %s %s", program, return_adress );
        addr2line_size = ExecuteCommand( addr2line_command, addr2line_buffer, addr2line_buffer_size );
        for( i = 0; i < addr2line_size; ++i )
        {
//          printf("%d %c\n",addr2line_buffer[i],addr2line_buffer[i]);
            if( addr2line_buffer[i] == '\n' || addr2line_buffer[i] == '\r' )
            {
                addr2line_buffer[i] = '\0';
            }
        }
        if( addr2line_size )
        {
            if( strcmp( addr2line_buffer, "??:0" ) != 0 )
            {
                file = addr2line_buffer;
            }
        }
        print( "\t%-30s %-50s %-10s %-16s %s\n", file, function, function_offset, return_adress, program );
    }
    else
    {
        print( "%s\n", str );
    }
}

/**
    Prints the current functions on the stack
*/
void PrintBacktrace()
{
    const int buffer_size = 100;
    void *buffer[buffer_size];
    int nptrs = 0, i = 0;
    char **strings;

    nptrs = backtrace( buffer, buffer_size );
    print( "Functions on stack\n" );
    strings = backtrace_symbols( buffer, nptrs );
    PrintBacktraceString( NULL );
    for( i = 0; i < nptrs; i++ )
    {
        PrintBacktraceString( strings[i] );
    }

    free( strings );
}
