/**
Copyright (C) 2011-2013 Stefan Kolb.

This file is part of the radiation module for the code PLUTO.

The radiation module is free software: you can redistribute it
and/or modify it under the terms of the GNU General Public
License as published by the Free Software Foundation, either
version 2 of the License, or (at your option) any later version.

The radiation module is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty
of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the radiation module. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef ERROR_H
#define ERROR_H

#ifdef QUIT_PLUTO
    #define QUIT_COMMAND(exit_code) QUIT_PLUTO(exit_code)
#else
    #define QUIT_COMMAND(exit_code) exit(exit_code)
#endif

/**
    Macro that checks if an error occurred while memory allocation by malloc, calloc,... .
*/
#define CHECK_ALLOCATED_MEMORY(pointer) if(pointer == NULL) {print("\nMemory allocation failed:\n\t process %d: in file %s:%d inside function %s\n",prank,__FILE__, __LINE__,__FUNCTION__); QUIT_COMMAND(1);}

#define ERROR(args...)\
    print("Error:\n  %-10s: %s \n  %-10s: %s:%d\n  %-10s: ","function",__PRETTY_FUNCTION__,"file",__FILE__,__LINE__,"message");\
    print (args);\
    print("\n");\
    QUIT_COMMAND(1);

#endif
