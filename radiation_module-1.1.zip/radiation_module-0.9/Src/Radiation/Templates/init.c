/**
    \file
    \brief Contains basic functions for problem initialization.

    The file was modified to contain all needed function to use the
    radiation module.

    The init.c file collects most of the user-supplied functions useful
    for problem configuration.
    It is automatically searched for by the makefile.

    \author A. Mignone (mignone@ph.unito.it)
    \author S. Kolb

    \date   March 14, 2013
*/

#include "pluto.h"

/**
    The Init() function can be used to assign initial conditions as
    as a function of spatial position.

    \param [out] v   a pointer to a vector of primitive variables
    \param [in] x1   coordinate point in the 1st dimension
    \param [in] x2   coordinate point in the 2nd dimension
    \param [in] x3   coordinate point in the 3rdt dimension

    The meaning of x1, x2 and x3 depends on the geometry:
    \f[ \begin{array}{cccl}
        x_1  & x_2    & x_3  & \mathrm{Geometry}    \\ \noalign{\medskip}
        \hline
        x    &   y    &  z   & \mathrm{Cartesian}   \\ \noalign{\medskip}
        R    &   z    &  -   & \mathrm{cylindrical} \\ \noalign{\medskip}
        R    & \phi   &  z   & \mathrm{polar}       \\ \noalign{\medskip}
        r    & \theta & \phi & \mathrm{spherical}
        \end{array}
    \f]

    Variable names are accessed by means of an index v[nv], where
    nv = RHO is density, nv = PRS is pressure, nv = (VX1, VX2, VX3) are
    the three components of velocity, and so forth.

*/
void Init( double *v, double x1, double x2, double x3 )
{
    v[RHO] = 1.0;
    v[VX1] = 0.0;
    v[VX2] = 0.0;
    v[VX3] = 0.0;
    v[PRS] = 1.0;
    v[TRC] = 0.0;

    RadiationSetMu( 0.6 );

    #if PHYSICS == MHD || PHYSICS == RMHD
        v[BX1] = 0.0;
        v[BX2] = 0.0;
        v[BX3] = 0.0;

        v[AX1] = 0.0;
        v[AX2] = 0.0;
        v[AX3] = 0.0;
    #endif
}

#if RADIATION == YES
/**
    This function is called at the initialization of the radiation module to set the initial values of the
    radiation energy density \f$ E \f$. The default is to call the function \ref RadiationSetInitialEradBlackBody
    which sets \f$ E \f$ to \f$ E=a_R T^4\f$.

    To customize this function iterate over all array element of the local domain (ghost cells included). And
    set \f$ E \f$ to the value you want. To access the radiation energy density data you have to use the
    attribute Erad of the global struct radiation_data.

    To set all cells in \f$ E \f$ to 1 in code units you can write:

    \code{.c}
    int k,j,i;

    TOT_LOOP(k,j,i)
    {
        radiation_data.Erad[k][j][i] = 1.0;
    }
    \endcode
*/
void RadiationSetInitialErad( Grid *grid, Data *data )
{
    RadiationSetInitialEradBlackBody( grid, data );
}

/**
    This function can be used to initialize the opacity as needed for example to use the Semenov opacities.

    To use the Semenov opacities call the function \ref SemenovOpacityInit() here
*/
void RadiationOpacityInit()
{

}

/**
    This function is called every time the Rosseland opacity is needed in the radiation module.
    \Note It is essential implement this function.

    There are different available routines which can be used here.

    Rosseland mean opacity after paper Lin & Papaloizou (1985): \ref RosselandOpacityLinPapaloizou1985(density,temperature)

    Rosseland mean opacity after paper Bell & Lin (1994): \ref RosselandOpacityBellLin1994(density,temperature)

    Rosseland mean opacity after paper Semenov et al. (2003): \ref SemenovRosselandOpacity(density,temperature)
    \Note It is necessary to call \ref SemenovOpacityInit() in \ref RadiationOpacityInit() to use the Semenov opacities.

    \param[in] density      density in cgs units
    \param[in] temperature  temperature in cgs units
    \return the Rosseland mean opacity in cgs units
*/
double RadiationRosselandOpacity( double density, double temperature )
{
    return RosselandOpacityLinPapaloizou1985( density, temperature );
}

/**
    Same as \ref RadiationRosselandOpacity but for the Planck opacity.

    \Note Except for the Semenov opacities there is currently no Planck mean opacity routine
    implemented. A solution to this is to use here for simplicity also the Rosseland mean opacity.

    If you want to use the Semenov opacities use the function \ref SemenovPlanckOpacity(density,temperature)

    \param[in] density      density in cgs units
    \param[in] temperature  temperature in cgs units
    \return the Planck mean opacity in cgs units
*/
double RadiationPlanckOpacity( double density, double temperature )
{
    return RosselandOpacityLinPapaloizou1985( density, temperature );
}

#if IRRADIATION == YES
/**
    Same as \ref RadiationRosselandOpacity and \ref RadiationPlanckOpacity but for the opacity used for irradiation.

    \param[in] density      density in cgs units
    \param[in] temperature  temperature in cgs units
    \return opacity in cgs units
*/
double IrradiationOpacity( double density, double temperature )
{
    return RosselandOpacityLinPapaloizou1985( density, temperature );
}
#endif

#endif

/**
    Perform runtime data analysis.

    \param [in] d the PLUTO Data structure
    \param [in] grid   pointer to array of Grid structures
*/
void Analysis( const Data *d, Grid *grid )
{

}

#if PHYSICS == MHD
/**
    Define the component of a static, curl-free background
    magnetic field.

    \param [in] x1  position in the 1st coordinate direction \f$x_1\f$
    \param [in] x2  position in the 2nd coordinate direction \f$x_2\f$
    \param [in] x3  position in the 3rd coordinate direction \f$x_3\f$
    \param [out] B0 array containing the vector components of the background magnetic field
*/
void BackgroundField( double x1, double x2, double x3, double *B0 )
{
    B0[0] = 0.0;
    B0[1] = 0.0;
    B0[2] = 0.0;
}
#endif

/**
    Assign user-defined boundary conditions.

    \param [in,out] d  pointer to the PLUTO data structure containing
        cell-centered primitive quantities (d->Vc) and staggered
        magnetic fields (d->Vs, when used) to be filled.
    \param [in] box    pointer to a RBox structure containing the lower
        and upper indices of the ghost zone-centers/nodes or edges at
        which data values should be assigned.
    \param [in] side   specifies the boundary side where ghost zones need
        to be filled. It can assume the following pre-definite values:
        X1_BEG, X1_END, X2_BEG, X2_END, X3_BEG, X3_END. The special value
        side == 0 is used to control a region inside the computational domain.
    \param [in] grid  pointer to an array of Grid structures.
*/
void UserDefBoundary( const Data *d, RBox *box, int side, Grid *grid )
{
    int   i, j, k, nv;
    double  *x1, *x2, *x3;

    x1 = grid[IDIR].x;
    x2 = grid[JDIR].x;
    x3 = grid[KDIR].x;

    if( side == 0 )     /* -- check solution inside domain -- */
    {
        DOM_LOOP( k, j, i ) {};
    }

    if( side == X1_BEG )  /* -- X1_BEG boundary -- */
    {
        if( box->vpos == CENTER )
        {
            BOX_LOOP( box, k, j, i ) {  }
        }
        else if( box->vpos == X1FACE )
        {
            BOX_LOOP( box, k, j, i ) {  }
        }
        else if( box->vpos == X2FACE )
        {
            BOX_LOOP( box, k, j, i ) {  }
        }
        else if( box->vpos == X3FACE )
        {
            BOX_LOOP( box, k, j, i ) {  }
        }
    }

    if( side == X1_END )  /* -- X1_END boundary -- */
    {
        if( box->vpos == CENTER )
        {
            BOX_LOOP( box, k, j, i ) {  }
        }
        else if( box->vpos == X1FACE )
        {
            BOX_LOOP( box, k, j, i ) {  }
        }
        else if( box->vpos == X2FACE )
        {
            BOX_LOOP( box, k, j, i ) {  }
        }
        else if( box->vpos == X3FACE )
        {
            BOX_LOOP( box, k, j, i ) {  }
        }
    }

    if( side == X2_BEG )  /* -- X2_BEG boundary -- */
    {
        if( box->vpos == CENTER )
        {
            BOX_LOOP( box, k, j, i ) {  }
        }
        else if( box->vpos == X1FACE )
        {
            BOX_LOOP( box, k, j, i ) {  }
        }
        else if( box->vpos == X2FACE )
        {
            BOX_LOOP( box, k, j, i ) {  }
        }
        else if( box->vpos == X3FACE )
        {
            BOX_LOOP( box, k, j, i ) {  }
        }
    }

    if( side == X2_END )  /* -- X2_END boundary -- */
    {
        if( box->vpos == CENTER )
        {
            BOX_LOOP( box, k, j, i ) {  }
        }
        else if( box->vpos == X1FACE )
        {
            BOX_LOOP( box, k, j, i ) {  }
        }
        else if( box->vpos == X2FACE )
        {
            BOX_LOOP( box, k, j, i ) {  }
        }
        else if( box->vpos == X3FACE )
        {
            BOX_LOOP( box, k, j, i ) {  }
        }
    }

    if( side == X3_BEG )  /* -- X3_BEG boundary -- */
    {
        if( box->vpos == CENTER )
        {
            BOX_LOOP( box, k, j, i ) {  }
        }
        else if( box->vpos == X1FACE )
        {
            BOX_LOOP( box, k, j, i ) {  }
        }
        else if( box->vpos == X2FACE )
        {
            BOX_LOOP( box, k, j, i ) {  }
        }
        else if( box->vpos == X3FACE )
        {
            BOX_LOOP( box, k, j, i ) {  }
        }
    }

    if( side == X3_END )  /* -- X3_END boundary -- */
    {
        if( box->vpos == CENTER )
        {
            BOX_LOOP( box, k, j, i ) {  }
        }
        else if( box->vpos == X1FACE )
        {
            BOX_LOOP( box, k, j, i ) {  }
        }
        else if( box->vpos == X2FACE )
        {
            BOX_LOOP( box, k, j, i ) {  }
        }
        else if( box->vpos == X3FACE )
        {
            BOX_LOOP( box, k, j, i ) {  }
        }
    }
}

#if BODY_FORCE != NO
/**
    * Prescribe the acceleration vector as a function of the coordinates
    * and the vector of primitive variables *v.

    \param [in] v  pointer to a cell-centered vector of primitive variables
    \param [out] g acceleration vector
    \param [in] x1  position in the 1st coordinate direction \f$x_1\f$
    \param [in] x2  position in the 2nd coordinate direction \f$x_2\f$
    \param [in] x3  position in the 3rd coordinate direction \f$x_3\f$

*/
void BodyForceVector( double *v, double *g, double x1, double x2, double x3 )
{
    g[IDIR] = 0.0;
    g[JDIR] = 0.0;
    g[KDIR] = 0.0;
}

/**
    Return the gravitational potential as function of the coordinates.

    \param [in] x1  position in the 1st coordinate direction \f$x_1\f$
    \param [in] x2  position in the 2nd coordinate direction \f$x_2\f$
    \param [in] x3  position in the 3rd coordinate direction \f$x_3\f$

    \return The body force potential \f$ \Phi(x_1,x_2,x_3) \f$.
*/
double BodyForcePotential( double x1, double x2, double x3 )
{
    return 0.0;
}
#endif
