/**
Copyright (C) 2011-2013 Stefan Kolb.

This file is part of the radiation module for the code PLUTO.

The radiation module is free software: you can redistribute it
and/or modify it under the terms of the GNU General Public
License as published by the Free Software Foundation, either
version 2 of the License, or (at your option) any later version.

The radiation module is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty
of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the radiation module. If not, see <http://www.gnu.org/licenses/>.
*/

#include "petsc_initialize_advanced.h"
#include "pluto.h"
/**
    Reads the file pluto.ini from the path \a filepath

    \param[in]  filepath
    \param[out] line_count_     the number of stored lines
    \param[out] lines           all none empty lines of file file path
*/
void ReadPlutoConfigFile( char *filepath, int *line_count, char *** lines )
{
    char buffer[1024];
    FILE *file = NULL;
    int n = 0;

    *lines = NULL;
    file = fopen( filepath, "r" );
    if( file == NULL )
    {
        printf( " ! Error: file %s not found\n", filepath );
        QUIT_PLUTO( 1 );
    }
    *line_count = 0;

    while( fgets( buffer, 1024, file ) != NULL )
    {
        strtok( buffer, "\n" );
        /*for(n = 0; n < 1024; ++n)
        {
            if(buffer[n] == '\n')
            {
                buffer[n] = '\0';
            }

        }*/

        if( strlen( buffer ) > 0 )
        {
            *lines = realloc( *lines, sizeof( char ** ) * ( *line_count + 1 ) );
            ( *lines )[*line_count] = malloc( sizeof( char ) * strlen( buffer ) + 1 );
            strcpy( ( *lines )[*line_count], buffer );
            ( *line_count )++;
        }
    }
    fclose( file );
}

/**
    Frees the 2D array \a array.

    \param[in]  array
    \param[in]  size
*/
void Free2DArray( void **array, int size )
{
    int n = 0;

    for( n = 0; n < size; ++n )
    {
        free( array[n] );
        array[n] = NULL;
    }
    free( array );
    array = NULL;
}

/**
    Searches in each line of \a lines for the occurrence of \a label and sets result to
    this line without \a label.

    \note
    No memory is allocated for \a result. This means if the 2D array \a lines is freed \a result
    becomes invalid.

    \param[in]  label
    \param[in]  line_count
    \param[in]  lines
    \param[out] result
*/
void FindLine( const char *label, int line_count, char **lines, char **result )
{
    const char  delimiters[] = " \t\r\f";
    char buffer[1024], *str = NULL;
    int n = 0, start_pos = 0;

    for( n = 0; n < line_count; ++n )
    {
        snprintf( buffer, 1024, "%s", lines[n] );
        str = strtok( buffer, delimiters );

        if( str != NULL && strcmp( str, label ) == 0 )
        {
            str = strtok( NULL, delimiters );
            start_pos = str - buffer;

            snprintf( buffer, 1024, "%s", lines[n] );

            *result = &lines[n][start_pos];
            return;
        }
    }
    *result = NULL;
}

/**
    Extracts the option "-i" for the PLUTO command line. This is done to obtain the path
    to the file pluto.ini if the standard is not used.

    \param[in]  argc    PLUTO argc
    \param[in]  argv    PLUTO argv
    \param[out] inifile
*/
void ExtractConfigPathFromCommandLine( int argc, char **argv, char *inifile )
{
    int n = 0, found = 0;

    for( n = 0; n < argc; ++n )
    {
        if( strcmp( argv[n], "-i" ) == 0 )
        {
            sprintf( inifile, "%s", argv[n + 1] );
            found = 1;
            break;
        }
    }

    if( !found )
    {
        sprintf( inifile, "%s", "pluto.ini" );
    }

    return;
}

/**
    Generates an argc and argv pseudo command line for PETSc which contains the options from
    the entry "petsc-options" in the pluto.ini file.

    \param[out] argc
    \param[out] argv
    \param[in]  petsc_options
*/
void GeneratePetscCommandLineOptions( int *argc, char *** argv, char *petsc_options )
{
    int n = 0;
    char *str = NULL;
    char buffer[1024];
    const char delimiters[] = " ";
    const char first_entry[] = "./pluto";
    snprintf( buffer, 1024, "%s", petsc_options );
    *argv = NULL;
    *argc = 0;

    *argv = realloc( *argv, sizeof( char ** ) * ( *argc + 1 ) );
    ( *argv )[*argc] = malloc( sizeof( char ) * strlen( first_entry ) + 1 );
    strcpy( ( *argv )[*argc], first_entry );
    ( *argc )++;

    str = strtok( buffer, delimiters );
    while( str != NULL )
    {
        *argv = realloc( *argv, sizeof( char ** ) * ( *argc + 1 ) );
        ( *argv )[*argc] = malloc( sizeof( char ) * strlen( str ) + 1 );
        strcpy( ( *argv )[*argc], str );
        str = strtok( NULL, delimiters );
        ( *argc )++;
    }
}

/**
    Calls PetscInitialize with the options specified in pluto.ini with the label petsc-options

    \param[in]  pluto_argc
    \param[in]  pluto_argv
*/
void PetscInitializeAdvanced( int pluto_argc, char **pluto_argv )
{
    int line_count = 0;
    char **lines = NULL;
    char *str;
    char inifile[1024], petsc_options[1024];

    int petsc_argc;
    char **petsc_argv = NULL;

    memset( petsc_options, 0, 1024 );
    memset( inifile, 0, 1024 );

    if( prank == 0 )
    {
        if( ParQuery( "petsc-options" ) )
        {
            ExtractConfigPathFromCommandLine( pluto_argc, pluto_argv, inifile );

            ReadPlutoConfigFile( inifile, &line_count, &lines );
            FindLine( "petsc-options", line_count, lines, &str );
            if( str )
            {
                snprintf( petsc_options, 1024, "%s", str );
            }
            Free2DArray( lines, line_count );
        }
    }

    MPI_Bcast( petsc_options, 1024, MPI_CHAR, 0, MPI_COMM_WORLD );

    GeneratePetscCommandLineOptions( &petsc_argc, &petsc_argv, petsc_options );

    if( petsc_argc > 1 )
    {
        print( "\n> Used PETSc options\n" );
        for( line_count = 1; line_count < petsc_argc; ++line_count )
        {
            print( " %s\n", petsc_argv[line_count] );
        }
    }

    PetscInitialize( &petsc_argc, &petsc_argv, ( char * )0, ( char * )0 );
    Free2DArray( petsc_argv, petsc_argc );
}

