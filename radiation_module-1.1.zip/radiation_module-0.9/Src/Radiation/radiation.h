/**
Copyright (C) 2011-2013 Stefan Kolb.
Copyright (C) 2013 Moritz Stoll (shearing box boundary conditions)

This file is part of the radiation module for the code PLUTO.

The radiation module is free software: you can redistribute it
and/or modify it under the terms of the GNU General Public
License as published by the Free Software Foundation, either
version 2 of the License, or (at your option) any later version.

The radiation module is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty
of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the radiation module. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef RADIATION_H
#define RADIATION_H

#include <al.h>
#include "radiation_tools.h"
#include "opacity.h"
#include "pluto.h"

#include "error.h"

#ifndef PLUTO4
    #define ParGet(a,b) PAR_GET(a,b)
    #define ParQuery(a) PAR_QUERY(a)
#endif

#ifndef ARTIFICIAL_DISSIPATION
    #define ARTIFICIAL_DISSIPATION NO
#endif

//to remove some warnings
int AL_Exchange_dim( char *buf, int *dims, int sz_ptr );

/**
    \note
    (index of the last element means length(data->Vc) - 1 = NVAR + 1 - 1 = NVAR)
*/
#define ERAD (NVAR)

#define POW2(val)   ((val) * (val))
#define POW3(val)   ((val) * (val) * (val))
#define POW4(val)   ((val) * (val) * (val) * (val))
#define POW5(val)   ((val) * (val) * (val) * (val) * (val))
#define POW6(val)   ((val) * (val) * (val) * (val) * (val) * (val))
#define POW7(val)   ((val) * (val) * (val) * (val) * (val) * (val) * (val))

#ifndef RADIATION_SMALL_NUMBERS_FIX
    #define RADIATION_SMALL_NUMBERS_FIX NO
#endif

#ifndef RADIATION_SMALL_NUMBERS_FIX_VALUE
    #define RADIATION_SMALL_NUMBERS_FIX_VALUE 1e-20
#endif

extern double g_unitTemperature;
#define CONST_aR ((8. * POW5(CONST_PI) * POW4(CONST_kB)) / (15. * POW3(CONST_c) * POW3(CONST_h)) )

#define NO_SHIFT                        0  /**<Use position i,j,k depending on usage */
#define IDIR_pOH                        1  /**<Use position \f$ i+\frac{1}{2}\f$*/
#define IDIR_mOH                        2  /**<Use position \f$ i-\frac{1}{2}\f$*/
#define JDIR_pOH                        3  /**<Use position \f$ j+\frac{1}{2}\f$*/
#define JDIR_mOH                        4  /**<Use position \f$ j-\frac{1}{2}\f$*/
#define KDIR_pOH                        5  /**<Use position \f$ k+\frac{1}{2}\f$*/
#define KDIR_mOH                        6  /**<Use position \f$ k-\frac{1}{2}\f$*/

#define RADIATION_BC_NO_BOUNDARY        0   /**<Definition for invalid boundary condition*/
#define RADIATION_BC_PERIODIC           1   /**<periodic boundary condition*/
#define RADIATION_BC_SYMMETRIC          2   /**<symmetric boundary condition*/
#define RADIATION_BC_REFLECTIVE         3   /**<reflecting boundary condition*/
#define RADIATION_BC_OUTFLOW            4   /**<outflow boundary condition*/
#define RADIATION_BC_FIXEDVALUE         5   /**<fixedvalue boundary condition*/
#define RADIATION_BC_SHEARINGBOX        6   /**<shearing Box boundary condition*/

#define SOR_FIXED_OMEGA                 0   /**<Definitions for the computation of omega in the function \ref SuccessiveOverrelaxation*/
#define SOR_ADAPTIVE_OMEGA              1

#ifndef RADIATION_SOR_OMEGA_MODE
    #define RADIATION_SOR_OMEGA_MODE    SOR_FIXED_OMEGA
#endif

#define FLUXLIMITER_MINERBO             0
#define FLUXLIMITER_KLEY                1
#define FLUXLIMITER_LEVERMORE_POMRANING 2
#define FLUXLIMITER_CONST               3

#define PETSC_LIBRARY                   0
#define SOLVER_SOR                      1

#define NORM_RELATIVE_L2                0   /**<Definitions for the norm computation in the function \ref SuccessiveOverrelaxation*/
#define NORM_RELATIVE_MAX               1
#define NORM_RESIDUAL_L2                2
#define NORM_RESIDUAL_MAX               3
#define NORM_RESIDUAL_RELATIVE_L2       4
#define NORM_RESIDUAL_RELATIVE_MAX      5
#define NORM_PETSC                      6

#ifndef RADIATION_SOR_NORM
    #define RADIATION_SOR_NORM NORM_RESIDUAL_L2
#endif

#if RADIATION_SOLVER == PETSC_LIBRARY
    #include "petsc.h"
#endif

typedef struct BOUNDARY_CONDITION_INFO
{
    int bc_beg;         /**<boundary condition (RADIATION_BC_PERIODIC,RADIATION_BC_SYMMETRIC,RADIATION_BC_REFLECTIVE,RADIATION_BC_FIXEDVALUE) at the start (low index)*/
    int bc_end;         /**<same as bc_beg but at the end (high index)*/

    double beg_fixedvalue;  /**storage for the value used by the boundary condition RADIATION_BC_FIXEDVALUE */
    double end_fixedvalue;  /**same as beg_fixedvalue*/
} BoundaryConditionInfo;

#define RADIATION_REGISTER_FUNCTION_INIT                    1   /**<If this option is used in function \ref RadiationRegisterCustomFunction then the function is called in \ref RadiationInit*/
#define RADIATION_REGISTER_FUNCTION_TIMESTEP_BEGIN          2   /**<If this option is used in function \ref RadiationRegisterCustomFunction then the function is called at the begining of function \ref RadiationImplicitTimestep*/
#define RADIATION_REGISTER_FUNCTION_TIMESTEP_END            3   /**<If this option is used in function \ref RadiationRegisterCustomFunction then the function is called at the end of function \ref RadiationImplicitTimestep*/
#define RADIATION_REGISTER_FUNCTION_UPDATE_PRESSURE_BEGIN   4   /**<If this option is used in function \ref RadiationRegisterCustomFunction then the function is called at the begining of function \ref UpdatePlutoPressure*/
#define RADIATION_REGISTER_FUNCTION_UPDATE_PRESSURE_END     5   /**<If this option is used in function \ref RadiationRegisterCustomFunction then the function is called at the end of function \ref UpdatePlutoPressure*/

typedef struct SOR_ADAPTIVE_OMEGA_DATA
{
    double omega;
    double direction;
    int iterations;
} SorAdaptiveOmegaData;

typedef struct RADIATION_DATA
{
    double mu;                  /**<mean molecular wight \f$ \mu \f$ which is dimensionless \note the function MEAN_MOLECULAR_WEIGHT() is only used for cooling in PLUTO \note set this in the problem init file init.c*/
    double code_c;              /**<light speed in code units \note is set in RADIATION_INIT()*/
    double code_amu;            /**<atomic mass unit in code units \note is set in RADIATION_INIT()*/
    double code_mH;             /**<Hydrogen atom mass in code units \note is set in RADIATION_INIT()*/
    double code_aR;             /**<\f$ a_R \f$ in code units \note is set in RADIATION_INIT()*/
    double code_kB;             /**<Boltzmann constant in code units \note is set in RADIATION_INIT()*/

    int default_init_Erad;      /** If \a radiation_default_init_Erad is 1 then \ref SetInitialValues is called in function \ref RadiationInit else not*/

    double ** *Erad;            /**pointer to the array of Erad to free the memory in the function RADIATION_FINALISE()**/

    BoundaryConditionInfo boundary_conditions[3];

    double absolute_tolerance;  ///used by petsc and the sor solver
    double relative_tolerance;  ///used by petsc and the sor solver
    int max_iterations;         ///used by petsc and the sor solver

    #if RADIATION_SOLVER == SOLVER_SOR
        double ****sor_coefficients;
    #endif

    #if RADIATION_SOLVER == PETSC_LIBRARY
        NeighbourGridItem **topology_grid;
        int *topology_grid_size;
        int *offset_array;

        /*
            The following arrays are used in the function ComputeToplology1DPosition.

            np stands here for the local number of points in the local domain
            (boundaries excluded) of a processor,

            dir = IDIR,JDIR,KDIR

            np_high_part[dir] = grid[dir].np_int_glob / topology_grid_size[dir]
            num_low_part[dir] = grid[dir].np_int_glob % topology_grid_size[dir]

            In the case that grid[dir].np_int_glob devidable by topology_grid_size without
            an rest np_low_part[dir] is equal to np_high_part[dir] else
            np_low_part[dir] = np_high_part[dir] + 1
        */
        int np_low_part[3];
        int np_high_part[3];
        int num_low_part[3];

        MPI_Comm comm_topology;
    #endif

} RadiationData;
extern RadiationData radiation_data;

void RadiationSetEradInitBehaviour( int b );
void RadiationSetMu( double mu );
void RadiationSetInitialErad( Grid *grid, Data *data );
void RadiationSetInitialEradBlackBody( Grid *grid, Data *data );

void PrintBoundaryConditions();
void RadiationPrintUnits();
void SegfaultHandleFunction( int sig );

double ComputeNewTemperature( int k, int j, int i, Grid *grid, Data *data );
void UpdatePlutoPressure( Grid *grid, Data *data );

void FixedValueBoundaryCondition( double ***q, RBox *box, int side );
void ReflectiveBoundaryCondition( double ***q, RBox *box, int side );
void PeriodicBoundaryCondition( double ***q, RBox *box, int side );
void RadiationBoundaryCondition( Grid *grid, Data *data );
void SetupBoundaryConditions( Grid *grid );
void CheckBoundaryConditions( Grid *grid );

void RadiationInit( int argc, char **argv, Input *input, Grid *grid, Data *data, int restart );
void RadiationAllocateMemory( Input *input );

void RadiationCleanup();

void RadiationImplicitTimestep( Grid *grid, Data *data, Input *input );

int SuccessiveOverrelaxationImplicitTimestep( Grid *grid, Data *data );

void SuccessiveOverrelaxationInit();
void SuccessiveOverrelaxationFinalise();
double ComputeAdaptiveOmega( double omega, int iterations, double increase, int averageing_timesteps );
int SuccessiveOverrelaxation( Grid *grid, Data *data, double rtol, double atol, int max_iterations );

double ComputeIntermediateValue( int k, int j, int i, int shift, double ***quantity );
double ComputeIntermediateValueWithFunction( int k, int j, int i, int shift, Data *data, double( getVariable )( int, int, int, Data * ) );

double Fluxlimiter( double R );
double FluxlimiterR( int k, int j, int i, int shift, Data *d, Grid *grid );

void RadiationOpacityInit();
double RadiationRosselandOpacity( double density, double temperature );
double RadiationPlanckOpacity( double density, double temperature );

double ComputeRosselandOpacity( int k, int j, int i, int shift, Data *d, Grid *grid );
double ComputePlanckOpacity( int k, int j, int i, Data *d, Grid *grid );
// double RosselandOpacity(double density, double temperature);
// double PlanckOpacity(double density, double temperature);

void ComputeRadiationAcceleration( int k, int j, int i, Grid *grid, double *v, double *a );

double ComputeArtificialDissipation( int k, int j, int i, Data *data, Grid *grid );
double ComputeCoefficientK( int k, int j, int i, int shift, Data *d, Grid *grid );

double ComputeGeometryCoefficientGrx1( int k, int j, int i, Grid *grid );
double ComputeGeometryCoefficientGlx1( int k, int j, int i, Grid *grid );
double ComputeGeometryCoefficientGrx2( int k, int j, int i, Grid *grid );
double ComputeGeometryCoefficientGlx2( int k, int j, int i, Grid *grid );
double ComputeGeometryCoefficientGrx3( int k, int j, int i, Grid *grid );
double ComputeGeometryCoefficientGlx3( int k, int j, int i, Grid *grid );

double ComputeCoefficientU1( int k, int j, int i, Data *d, Grid *grid );
double ComputeCoefficientU1Advanced( int k, int j, int i, Data *d, Grid *grid, double U2, double U3, double U4, double U5, double U6, double U7 );

double ComputeCoefficientU2( int k, int j, int i, Data *d, Grid *grid );
double ComputeCoefficientU3( int k, int j, int i, Data *d, Grid *grid );
double ComputeCoefficientU4( int k, int j, int i, Data *d, Grid *grid );
double ComputeCoefficientU5( int k, int j, int i, Data *d, Grid *grid );
double ComputeCoefficientU6( int k, int j, int i, Data *d, Grid *grid );
double ComputeCoefficientU7( int k, int j, int i, Data *d, Grid *grid );
double ComputeCoefficientB( int k, int j, int i, Data *d, Grid *grid );

double GetTemperature( int k, int j, int i, Data *d );

double ComputeSpecificHeatCapacity( int k, int j, int i, Data *d );

#ifdef RADIATION_CUSTOM_IMPLICITE_TEMESTEP_BEGIN
    void RadiationCustomImplicitTimestepBegin( Grid *grid, Data *data );
#endif
#ifdef RADIATION_CUSTOM_IMPLICITE_TEMESTEP_END
    void RadiationCustomImplicitTimestepEnd( Grid *grid, Data *data, int iterations );
#endif

#endif
