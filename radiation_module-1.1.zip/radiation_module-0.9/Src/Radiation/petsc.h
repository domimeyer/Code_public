/**
Copyright (C) 2011-2013 Stefan Kolb.
Copyright (C) 2012-2013 Moritz Stoll (shearing box boundary conditions)

This file is part of the radiation module for the code PLUTO.

The radiation module is free software: you can redistribute it
and/or modify it under the terms of the GNU General Public
License as published by the Free Software Foundation, either
version 2 of the License, or (at your option) any later version.

The radiation module is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty
of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the radiation module. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef DD_PETSC_H
#define DD_PETSC_H

#include "petscksp.h"

/**
    Macro to check the return value of the PETSc functions. If an error is occurred then PetscError is called
*/
#if PETSC_VERSION_MAJOR >= 3 && PETSC_VERSION_MINOR > 1
    #define CHKERR(n)    if (PetscUnlikely(n)) {PetscError(PETSC_COMM_WORLD,__LINE__,__FUNCT__,__FILE__,__SDIR__,n,0," ");QUIT_PLUTO(1);}
#else
    #define CHKERR(n)    if (PetscUnlikely(n)) {PetscError(__LINE__,__FUNCT__,__FILE__,__SDIR__,n,0," ");QUIT_PLUTO(1);}
#endif

typedef struct NEIGHBOUR_GRID_ITEM
{
    int beg;    /**< Global start index for the local array. */
    int end;    /**< Global start index for the local array. */
    int np;     /**< Total number of points in the local domain (boundaries excluded). */
} NeighbourGridItem;


void PetscCollectData( Vec b, double *** Erad );
void PetscCalculateVectorOffset( Grid *grid );
int PetscGetProcessIdByMatrixRow( int row, int row_count, int nproc );
void PetscMatrixFunctionsCheck( Mat A, int nproc );
int PetscGetLocalMatrixRowCountByProcessId( int rank, int row_count, int nproc );
void PetscMatrixMemoryPreallocation( Mat A, Grid *grid );
int PetscGetVectorPosition( int k, int j, int i, Grid *grid );
void PetscMapLocalToGlobalIndex( int local_k, int local_j, int local_i, Grid *grid, int *global_k, int *global_j, int *global_i );

void PetscGenerateSystemOfEquations( Mat A, Vec b, Grid *grid, Data *d );

int PetscImplicitTimestep( Grid *grid, Data *data );

void PetscInit( int argc, char **argv, Input *input, Grid *grid, Data *data );
void PetscCleanup();

#endif
