#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "generate_opacity.h"

/*
    This file is originally from the website
    http://www.mpia.de/homes/henning/Dust_opacities/Opacities/opacities.html

    The original file opacity.f can be found in the zip archive
    http://www.mpia.de/homes/henning/Dust_opacities/Opacities/Code/opacity.zip

    The file opacity.f was converted from fortran to c by using the tool f2c. After the conversion
    we manually removed the dependencies to the f2c library. The only function which was changed in its
    functionality is the function main which is not needed in our context.
*/

/*
program  opacity.f
.........................................................................
.  Version 1.0 (16/10/2002)
.........................................................................
.  Copyright (c) 2001-2002, Dmitry Semenov, AIU, Jena
.  E-mail: dima@astro.uni-jena.de
.........................................................................
.  License: one can freely use, modify, or redistribute all parts of the
.  code.
.  [Please, inform me about all bugs which you will find in the code!]
.........................................................................
.  DESCRIPTION OF THE MODEL:
.........................................................................
.  Calculation of the Rosseland and Planck mean opacities of the gas
.  and dust in the temperature range 5[K]<T<~10,000[K] and for gas
.  density between ~2*10^-18 [g/cm^3] and ~2*10^-7[g/cm^3]. The solar
.  composition of the elements is adopted from the compilations of
.  Anders & Grevesse (1989, all but carbon) and Grevesse et al.
.  (1991, carbon).
.
.  It is supposed that in the temperature range 0<T<~1500[K] (depending
.  on the gas density) the opacity is dominated by dust grains, whereas
.  for higher temperatures gas species are the only possible source of
.  the opacity.
.........................................................................
.  I. DUST OPACITIES:
.........................................................................
.  Dust grains are supposed to consist of silicates, iron, troilite,
.  organics, and ice (Pollack et al. 1994, Henning & Stognienko 1996).
.  We applied a modified MRN size distribution as proposed by Pollack et
.  al. (1985):
.
.  a~a^-q1, amin<a<amax1,
.  a~a^-q2, amax1<a<amax2,
.  where q1=3.5, q2=5.5, amin=0.005 mkm, amax1=1 mkm, amax2=5 mkm.
.
.  The silicates - amorphous olivine and pyroxene - are considered to be
.  three various types, depending on their iron content. However, the
.  absolute amount of solid metallic iron in the model is kept unchanged:
.
.  1) "iron-poor" silicates, Fe/(Fe+Mg)=0.0 ("high" Fe abundance),
.  2) "iron-rich" silicates, Fe/(Fe+Mg)=0.4 ("low" Fe & FeS abundance),
.  3) "normal" silicates,    Fe/(Fe+Mg)=0.3 ("normal" Fe abundance).
.
.  We modelled dust grains as aggregates or spherical particles with
.  different distribution of the dust constituents:
.
.  a) Homogeneous dust particles, where each particle consists of the
.     only one dust material:
.     1) homogeneous compact spherical dust,
.     2) homogeneous dust aggregates,
.
.  b) Composite particles, where each particle includes all dust
.     materials according their mass fraction:
.     3) composite dust aggregates,
.     4) composite compact spherical dust,
.     5) 5-layered compact spherical dust,
.
.  c) Porous composite particles, where each particle consists of all
.     dust materials according their mass fraction + 50% of vacuum
.     (by volume):
.     6) porous composite spherical dust,
.     7) porous 5-layered spherical dust.
.
.........................................................................
.  II. GAS OPACITIES:
.........................................................................
.  For temperatures between roughly 1500 [K] and 10,000 [K], where all
.  dust grains have evaporated, a new gas opacity table of the Berlin
.  group (Ch. Helling and E. Sedlmayr) is used (Ch. Helling et al. 2000,
.  Ch. Helling 2001, 2002, private communications). We wrote a special
.  subroutine "eint" to interpolate these data for a chosen temperature
.  and density.
.
.........................................................................
.  III. DUST-TO-GAS TRANSITIONAL REGION (T~1500 K):
.........................................................................
.  For this region, our model may produce unreliable results as the
.  interpolation between totally gas-dominated and dust-dominated
.  opacities is elaborated. However, as it has been shown by many
.  authors, this approach is still quite accurate (eg. Lenzuni et al.
.  1995). The reason is that the gas opacities are much, much lower
.  (about few orders of magnitude) then the dust opacities. Given that
.  evaporation of the last refractory dust materials occurs under quite
.  restricted temperature range (~200 K), one can simply make the
.  interpolation between purely gas-dominated and dust-dominated
.  opacities for such temperatures without introducing significant errors.
.
.........................................................................
.  IV.REFERENCES:
.........................................................................
.  1) Anders, E., Grevesse, N. (1989), Geochim. Cosmochim. Acta, 53, 19
.  2) Grevesse, N., Lambert, D.L., Sauval et al. (1991), A&A, 242, 488
.  3) Helling, Ch., Winters, J., Sedlmayr, E. (2000), A&A, 358, 651
.  4) Henning, Th., Stognienko, R. (1996), A&A, 311, 291
.  5) Lenzuni, P., Gail, H.-P., Henning, Th. (1995), ApJ, 447, 848
.  6) Pollack, J., McKay, C.P., Christofferson, B.M. (1985), Icarus, 64,
.     471
.  7) Pollack, J., Hollenbach, D., Beckwith, S. et al. (1994), ApJ,
.     421, 615
.  8) Semenov, D., Henning, Th., Ilgner, M. et al. (2003), A&A, in
.     preparation.
..........................................................................
.  DESCRIPTION OF THE CODE:
..........................................................................
.  The algorithm of the code is very simple. We found out that the
.  Rosseland and Planck mean dust opacities can be accurately represented
.  in the form of a polynom of the fifth degree in every temperature
.  region. We considered 5 different temperature regions:
.    1. All dust components are present: 5 K<T<~100 K,
.    2. All dust components but water ice are present: ~100 K<T<275 K,
.    3. Silicates, iron, troilite, and refractory organics are present:
.       275 K<T<425 K,
.    4. Silicates, iron and troilite are present: 425 K<T<680 K,
.    5. Silicates and iron are present: 680 K<T<~1500 K.C
.  In our model, we added a weak dependence of evaporation temperatures
.  of ice, silicates, and iron on the gas density.
.
.  The code uses these pre-computed polynomial coefficients for all
.  possible dust models. Unfortunately, it is not possible to apply the
.  same method for the gas-dominated opacities. In this case,
.  interpolation is utilised, which is numerically costy.
.
.  The polynomial fit coefficients are stored within the code in
.  subroutines "xxx_y_z", where names "xxx", "y", and "z" are the
.  following:
.  1) "xxx" means mineraint composition of the silicates, i.e.,
.     "nrm" ("normal" silicates, see above), "ips" ("iron-poor"
.     silicates), and "irs" ("iron-rich" silicates);
.  2) "y" means the distribution of dust materials within the particles,
.     i.e., "c" (composite), "p" (porous composite), and "h"
.     (homogeneous),
.  3) "z" means the shape of the particles, i.e., "a" (aggregates),
.     "s" (spheres), "5" (5-layered spheres)
.
.  In total, 7x3=21 various dust models can be considered.
.
.  The gas-dominated opacities are stored in two external files
.  "kR_h2001.dat" (Rosseland) and "kP_h2001.dat" (Planck). The code
.  makes two-order interpolation within these data, when it is necessary
.  to compute gas opacities, with routine "eint".
.
.  The main subroutine is "COP" ("Calculation of OPacities"). For a
.  chosen dust model, the opacity kind and given gas temperature and
.  density values, it returns the opacity value.
.
.  In the header of any subroutine excessive information about
.  input/output parameters and its purpose are given.
.
..........................................................................
.  INPUT:
..........................................................................
.  FILE: 'opacity.inp'
.     'model': specify a silicate type,
.            = 'nrm' - "normal" silicate dust model,    Fe/(Fe+Mg)=0.3,
.            = 'ips' - "iron-poor" silicate dust model, Fe/(Fe+Mg)=0.0,
.            = 'irs' - "iron-rich" silicate dust model, Fe/(Fe+Mg)=0.4,
.       'top': specify a topology of the grains,
.            = 'h' - homogeneous particles,
.            = 'c' - composite particles,
.            = 'p' - porous composite particles,
.     'shape': specify a shape of the particles,
.            = 's' - spherical dust,
.            = 'a' - aggregate dust,
.            = '5' - 5-layered spherical dust,
.      'ross': choose a kind of opacity:
.            = '.true.'  - Rosseland mean,
.            = '.false.' - Planck mean,
.       'rho': gas density,
.        'NT': number of temperatures to be considered,
.        'T0': initial temperature of the gas,
.        'T1': last temperature of the gas
.
..........................................................................
.  OUTPUT:
...........................................................................
.  FILES: 'kR.out' - Rosseland mean,
.         'kP.out' - Planck mean,
.            'T': a set of temperatures,
.        'aKext': a set of corresponding mean opacities (extinction)
.
...........................................................................
.  SUBROUTINES (alphabetically):
...........................................................................
.    'bint' - quadratic interpolation routine to compute the evaporation
.             temperatures for a given gas density value,
.     'cop' - main routine to calculate opacity,
.    'eint' - quadractic interpolation/extrapolation routine for
.             gas-dominated opacity calculations,
.     'gop' - gas-dominated opacity calculation,
.  'init_d' - a routine to initialise dust model parameters,
.  'init_g' - the same as 'init_d' but for gas opacities,
.
...........................................................................
*/

#ifdef TEST_SEMINOV_OPACITY_SEPERATE

int main( int argc, char **argv )
{
    double *OpacTable_Planck, *OpacTable_Ross;

    /* PARAMETERS DEFINING THE OPACITY TABLES ---------------------------------- */
    int nt      = 2048;              // Number of temperature points.
    int nrho    = 2048;              // Number of density points.
    double t0   = 1.000e+01;         // Initial temperature.
    double t1   = 9.999e+03;         // Last temperature.
    double rho0 = 1.000e-16;         // Initial density.
    double rho1 = 9.999e-9;          // Last density.
    char top[1]     = "h";               // 'c'/'p'/'h' dust topologies.
    char model[3]   = "nrm";             // 'nrm'/'ips'/'irs' silicate types.
    char shape[1]   = "s";               // 's'/'a'/'5' dust shapes.
    /* ------------------------------------------------------------------------- */

    int bytes_written;

    /* Local variables */
    double t,  ed[30]   /* was [5][6] */, eg[5041]  /*
        was [71][71] */, dt, drho;
    int it, irho;
    double rho;
    int ross;
    double akext;

    /* Allocate memory for opacity tables */
    OpacTable_Ross = malloc( nt * nrho * sizeof( double ) );
    OpacTable_Planck = malloc( nt * nrho * sizeof( double ) );

    if( ( OpacTable_Ross == NULL ) || ( OpacTable_Planck == NULL ) )
    {
        printf( "Error allocating memory for opacity tables.\n" );
        exit( 1 );
    }


    for( ross = 0; ross <= 1; ross++ )
    {

        /* Initialization of all necessary data for a chosen dust model: */
        init_d( &ross, model, top, shape, ed, ( int )3, ( int )1, ( int )1 );
        /* Initialization of data for the gas model: */
        init_g( &ross, eg );

        rho = rho0;
        drho = exp( log( rho1 / rho0 ) / ( nrho - 1 ) );
        for( irho = 1; irho <= nrho; ++irho )
        {

            t = t0;
            dt = exp( log( t1 / t0 ) / ( nt - 1 ) );
            for( it = 1; it <= nt; ++it )
            {
                /* ----------------------------------------------------------------------------- */
                /* Calculation of Rosseland or Planck mean opacities using a chosen density,     */
                /* temperature, silicate dust model, shape of the grains and their topology:     */
                /* ----------------------------------------------------------------------------- */
                cop( ed, eg, &rho, &t, &akext );

                if( ross )
                {
                    OpacTable_Ross[nrho * ( irho - 1 ) + ( it - 1 )] = akext;
                }
                else
                {
                    OpacTable_Planck[nrho * ( irho - 1 ) + ( it - 1 )] = akext;
                }

                t *= dt;
            }

            rho *= drho;
        }
    }

    /* Write opacity tables */
    FILE *fOpacPlanck = fopen( "kP.dat", "w" );
    bytes_written = fwrite( OpacTable_Planck, sizeof( double ), nt * nrho, fOpacPlanck );
    printf( "Wrote Planck opacity table (%d bytes written).\n", bytes_written );
    fclose( fOpacPlanck );

    FILE *fOpacRoss = fopen( "kR.dat", "w" );
    bytes_written = fwrite( OpacTable_Ross, sizeof( double ), nt * nrho, fOpacRoss );
    printf( "Wrote Rosseland opacity table (%d bytes written).\n", bytes_written );
    fclose( fOpacRoss );
    return 0;
}

#endif

/* ............................................................................. */
/* Subroutine that initialize the polynomial fit coefficients for a chosen */
/* opacity kind and dust model */
/* ............................................................................. */
/* Input parameter(s): */
/* ............................................................................. */

/*   'ross': choose a kind of opacity: */
/*         = '.true.'  - Rosseland mean, */
/*         = '.false.' - Planck mean, */
/*  'model': specify a silicate type, */
/*         = 'nrm' - "normal" silicate dust model,    Fe/(Fe+Mg)=0.3, */
/*         = 'ips' - "iron-poor" silicate dust model, Fe/(Fe+Mg)=0.0, */
/*         = 'irs' - "iron-rich" silicate dust model, Fe/(Fe+Mg)=0.4, */
/*    'top': specify a topology of the grains, */
/*         = 'h' - homogeneous particles, */
/*         = 'c' - composite particles, */
/*         = 'p' - porous composite particles, */
/*  'shape': specify a shape of the particles, */
/*         = 's' - spherical dust, */
/*         = 'a' - aggregate dust, */
/*         = '5' - 5-layered spherical dust */

/* ............................................................................. */
/* Output parameter(s): */
/* ............................................................................. */

/*    'eD': eD(I,J),I=1,5,J=1,6 -> opacity fit coefficients (extinction), */
/*            where I describe a temperature region and J - position of */
/*            a fit coefficient in the fit polynom. */

/* ............................................................................. */
int init_d( int *ross, char *model, char *top, char *shape, double *ed, int model_len, int top_len, int shape_len )
{
    /* Search among possible models: */
    /* Parameter adjustments */
    ed -= 6;

    /* Function Body */
    if( strncmp( model, "nrm", 3 ) == 0 )
    {
        /* "normal" silicate models, */
        if( *top == 'h' )
        {
            /* homogeneous */
            if( *shape == 's' )
            {
                /* spherical particles, */
                nrm_h_s( ross, &ed[6] );
            }
            else if( *shape == 'a' )
            {
                /* aggregate particles, */
                nrm_h_a( ross, &ed[6] );
            }
            else
            {
                printf( "Chosen dust model is not correct!\n" );
                exit( 1 );
            }
        }
        else if( *top == 'c' )
        {
            /* composite compact */
            if( *shape == 's' )
            {
                /* spherical particles, */
                nrm_c_s( ross, &ed[6] );
            }
            else if( *shape == 'a' )
            {
                /* aggregate particles, */
                nrm_c_a( ross, &ed[6] );
            }
            else if( *shape == '5' )
            {
                /* 5-layered spherical particles, */
                nrm_c_5( ross, &ed[6] );
            }
            else
            {
                printf( "Chosen dust model is not correct!\n" );
                exit( 1 );
            }
        }
        else if( *top == 'p' )
        {
            /* porous composite */
            if( *shape == 's' )
            {
                /* spherical particles, */
                nrm_p_s( ross, &ed[6] );
            }
            else if( *shape == '5' )
            {
                /* 5-layered spherical particles, */
                nrm_p_5( ross, &ed[6] );
            }
            else
            {
                printf( "Chosen dust model is not correct!\n" );
                exit( 1 );
            }
        }
        else
        {
            printf( "Chosen dust model is not correct!\n" );
            exit( 1 );
        }
    }
    else if( strncmp( model, "ips", 3 ) == 0 )
    {
        /* "iron-poor" silicate models, */
        if( *top == 'h' )
        {
            /* homogeneous */
            if( *shape == 's' )
            {
                /* spherical particles, */
                ips_h_s( ross, &ed[6] );
            }
            else if( *shape == 'a' )
            {
                /* aggregate particles, */
                ips_h_a( ross, &ed[6] );
            }
            else
            {
                printf( "Chosen dust model is not correct!\n" );
                exit( 1 );
            }
        }
        else if( *top == 'c' )
        {
            /* composite compact */
            if( *shape == 's' )
            {
                /* spherical particles, */
                ips_c_s( ross, &ed[6] );
            }
            else if( *shape == 'a' )
            {
                /* aggregate particles, */
                ips_c_a( ross, &ed[6] );
            }
            else if( *shape == '5' )
            {
                /* 5-layered spherical particles, */
                ips_c_5( ross, &ed[6] );
            }
            else
            {
                printf( "Chosen dust model is not correct!\n" );
                exit( 1 );
            }
        }
        else if( *top == 'p' )
        {
            /* porous composite */
            if( *shape == 's' )
            {
                /* spherical particles, */
                ips_p_s( ross, &ed[6] );
            }
            else if( *shape == '5' )
            {
                /* 5-layered spherical particles, */
                ips_p_5( ross, &ed[6] );
            }
            else
            {
                printf( "Chosen dust model is not correct!\n" );
                exit( 1 );
            }
        }
        else
        {
            printf( "Chosen dust model is not correct!\n" );
            exit( 1 );
        }
    }
    else if( strncmp( model, "irs", 3 ) == 0 )
    {
        /* "iron-rich" silicate models, */
        if( *top == 'h' )
        {
            /* homogeneous */
            if( *shape == 's' )
            {
                /* spherical particles, */
                irs_h_s( ross, &ed[6] );
            }
            else if( *shape == 'a' )
            {
                /* aggregate particles, */
                irs_h_a( ross, &ed[6] );
            }
            else
            {
                printf( "Chosen dust model is not correct!\n" );
                exit( 1 );
            }
        }
        else if( *top == 'c' )
        {
            /* composite compact */
            if( *shape == 's' )
            {
                /* spherical particles, */
                irs_c_s( ross, &ed[6] );
            }
            else if( *shape == 'a' )
            {
                /* aggregate particles, */
                irs_c_a( ross, &ed[6] );
            }
            else if( *shape == '5' )
            {
                /* 5-layered spherical particles, */
                irs_c_5( ross, &ed[6] );
            }
            else
            {
                printf( "Chosen dust model is not correct!\n" );
                exit( 1 );
            }
        }
        else if( *top == 'p' )
        {
            /* porous composite */
            if( *shape == 's' )
            {
                /* spherical particles, */
                irs_p_s( ross, &ed[6] );
            }
            else if( *shape == '5' )
            {
                /* 5-layered spherical particles, */
                irs_p_5( ross, &ed[6] );
            }
            else
            {
                printf( "Chosen dust model is not correct!\n" );
                exit( 1 );
            }
        }
        else
        {
            printf( "Chosen dust model is not correct!\n" );
            exit( 1 );
        }
    }
    else
    {
        printf( "Chosen dust model is not correct!\n" );
        exit( 1 );
    }
    return 0;
}

/* ............................................................................. */
/* Subroutine that initialize Rosseland or Planck mean gas opacity data. */
/* ............................................................................. */
/* Input parameter(s): */
/* ............................................................................. */

/* 'ross': a kind of opacity, */
/*       = '.true.'  - Rosseland opacity, */
/*       = '.false.' - Planck opacity, */

/* ............................................................................. */
/* Output parameter(s): */
/* ............................................................................. */

/*   'eG': eG(71,71) - Rosseland or Planck mean gas opacity grids */
/* ............................................................................. */
int init_g( int *ross, double *eg )
{
    FILE *file = NULL;
    int i, j, k, res;
    double seq[5041];

    if( *ross )
    {
        file = fopen( "kR_h2001.dat", "r" );
    }
    else
    {
        file = fopen( "kP_h2001.dat", "r" );
    }

    if( file == NULL )
    {
        printf( "Unable to open file!" );
        exit( 1 );
    }

    res = fscanf( file, "%lf", &seq[0] ); //dummy read

    for( k = 0; k < 5041; ++k )
    {
        res = fscanf( file, "%lf", &seq[k] );
    }

    /* Convert it to the input form: */
    k = 0;
    for( i = 0; i < 71; ++i )
    {
        for( j = 0; j < 71; ++j )
        {
            eg[i + j * 71] = seq[k];
            ++k;
        }
    }
    fclose( file );
    return 0;
}

int init_g2( char *filepath, double *eg )
{
    FILE *file = NULL;
    int i, j, k, res;
    double seq[5041];

    file = fopen( filepath, "r" );
    if( file == NULL )
    {
        printf( "Unable to open file %s!", filepath );
        exit( 1 );
    }

    res = fscanf( file, "%lf", &seq[0] ); //dummy read

    for( k = 0; k < 5041; ++k )
    {
        res = fscanf( file, "%lf", &seq[k] );
    }

    /* Convert it to the input form: */
    k = 0;
    for( i = 0; i < 71; ++i )
    {
        for( j = 0; j < 71; ++j )
        {
            eg[i + j * 71] = seq[k];
            ++k;
        }
    }
    fclose( file );
    return 0;
}


/* ............................................................................. */
/* Unification of dust- and gas-dominated opacities */
/* ............................................................................. */
/* Input parameter(s): */
/* ............................................................................. */

/*     'eD': eD(5,6) - dust opacity fit coefficients, */

/*     'eG': eG(71,71) - gas opacity grid, */

/* 'rho_in': chosen gas density, g/cm^3, */

/*   'T_in': chosen gas temperature, K */

/* ............................................................................. */
/* Output parameter(s): */
/* ............................................................................. */

/*  'aKext': Rosseland or Planck mean opacities (extinction), cm^2/g */

/* ............................................................................. */
int cop( double *ed, double *eg, double *rho_in__, double *t_in__, double *akext )
{
    /* Initialized data */

    double ro[8] = { 1e-18, 1e-16, 1e-14, 1e-12, 1e-10, 1e-8, 1e-6, 1e-4 };
    double tt[32]   /* was [8][4] */ = { 109., 118., 129., 143., 159.,
                                         180., 207., 244., 835., 908., 994., 1100., 1230., 1395., 1612., 1908., 902.,
                                         980., 1049., 1129., 1222., 1331., 1462., 1621., 929., 997., 1076., 1168.,
                                         1277., 1408., 1570., 1774.
                                       };

    /* System generated locals */
    double d__1;

    /* Local variables */
    int i__, j;
    double t[5], t1, t2, aa, bb, ff;
    int kk;
    double dt[5], pi, td;
    int it;
    double akrl;
    double t_ev__[4], akrr, temp[8], tmin, tmax1, tmax2;
    int smooth, c8 = 8;
    double akg_ext__;

    /* Global variable(s): */
    /* Local variable(s): */
    /* Data related to the evaporation temperatures of silicates, iron and ice: */
    /* Parameter adjustments */
    eg -= 72;
    ed -= 6;

    /* Function Body */
    /*                                                    !'ro' */
    /* Initialization of the output parameters: */
    /* Water ice evaporat */
    /* temperature, */
    /* then metallic iron */

    /* orthopyroxene */
    /* and */
    /* olivine */
    /* depending on densi */
    *akext = 0.;
    if( *t_in__ < 1. )
    {
        return 0;
    }
    /* ............................................................................. */
    /* Constant(s): */
    /* ............................................................................. */
    /* T must be more that few degrees [K] */
    pi = atan( 1. ) * 4.;
    /* ............................................................................. */
    /* Interpolation of a matrix of evaporation temperatures for a given density */
    /* 'rho_in': */
    /* ............................................................................. */
    /* Pi */
    for( i__ = 1; i__ <= 4; ++i__ )
    {
        for( j = 1; j <= 8; ++j )
        {
            temp[j - 1] = tt[j + ( i__ << 3 ) - 9];
        }
        bint( rho_in__, &c8, ro, &t_ev__[i__ - 1], temp );
    }
    /* ............................................................................. */
    /*  Set up the evaporation temperature array 'T(1:5)': */
    /* ............................................................................. */
    t[0] = t_ev__[0];
    /* accretion disks: */
    /* evaporation temperature of water ice, */
    t[1] = 275.;
    /* evaporation temperature of volatile organics, */
    t[2] = 425.;
    /* evaporation temperature of refractory organic */
    t[3] = 680.;
    /* evaporation temperature of troilite, */
    tmax1 = fmax( t_ev__[1], t_ev__[2] );
    tmax2 = fmax( t_ev__[2], t_ev__[3] );
    tmin = fmin( tmax1, tmax2 );
    t[4] = tmin;
    /*                         !olivine, and orthopyroxene */
    /* ............................................................................. */
    /* Determination of a temperature regime where smoothing is necessary */
    /* ............................................................................ */
    /* average evaporation temperatures of iron, */
    dt[0] = 5.;
    /* an interval of T where ice is evaporating, */
    dt[1] = 5.;
    /* an interval of T where vol. organics is evaporat */
    dt[2] = 15.;
    /* an interval of T where ref. organics is evapora */
    dt[3] = 5.;
    /* an interval of T where troilite is evaporating, */
    dt[4] = 100.;
    /*                            !olivine are evaporating, */
    /* ............................................................................. */
    /* Determination of a temperature regime for a given temperature: */
    /* ............................................................................. */
    /* an wide interval of T where iron, pyroxe, and */
    kk = 6;
    /* default value -> gas-dominated opacity, */
    if( *t_in__ <= t[0] + dt[0] )
    {
        kk = 1;
    }
    for( it = 2; it <= 5; ++it )
    {
        if( *t_in__ > t[it - 2] + dt[it - 2] && *t_in__ <= t[it - 1] + dt[it
                - 1] )
        {
            kk = it;
        }
    }
    /* ............................................................................. */
    /* The gas-dominated opacity: */
    /* ............................................................................. */
    if( kk == 6 )
    {
        gop( &eg[72], rho_in__, t_in__, akext );
        return 0;
    }
    /* ............................................................................. */
    /* The dust-dominated opacity: */
    /* ............................................................................. */
    /* Switch to smoothing of the opacity if a temperature is near an */
    /* evaporation temperature of a dust material: */
    /* ............................................................................. */
    smooth = 0;
    for( i__ = 1; i__ <= 5; ++i__ )
    {
        if( ( d__1 = *t_in__ - t[i__ - 1], fabs( d__1 ) ) <= dt[i__ - 1] )
        {
            smooth = 1;
        }
    }
    /* ----------------------------------------------------------------------------- */
    /* If 'T_in' inside of (Tev-dT, Tev+dT) then start smoothing: */
    /* ----------------------------------------------------------------------------- */
    if( smooth )
    {
        t1 = t[kk - 1] - dt[kk - 1];
        t2 = t[kk - 1] + dt[kk - 1];
        td = *t_in__ - t[kk - 1];
        /* ----------------------------------------------------------------------------- */
        /* Calculation of a mean opacity (extinction): */
        /* ----------------------------------------------------------------------------- */
        akrl = ( ( ( ( ed[kk + 5] * t1 + ed[kk + 10] ) * t1 + ed[kk + 15] ) * t1 +
                   ed[kk + 20] ) * t1 + ed[kk + 25] ) * t1 + ed[kk + 30];

        if( kk == 5 )
        {
            gop( &eg[72], rho_in__, &t2, &akg_ext__ );
            akrr = akg_ext__;
        }
        else
        {
            akrr = ( ( ( ( ed[kk + 6] * t2 + ed[kk + 11] ) * t2 + ed[kk + 16] ) *
                       t2 + ed[kk + 21] ) * t2 + ed[kk + 26] ) * t2 + ed[kk + 31];
        }

        aa = ( akrl - akrr ) * .5;
        bb = ( akrl + akrr ) * .5;
        ff = pi / 2. / dt[kk - 1];
        *akext = bb - aa * sin( ff * td );

    }
    else
    {
        /* ............................................................................. */
        /*  Smoothing is not necessary, direct calculation by a fit polinom of */
        /*  fifth degree: y=a*x^5+b*x^4+c*x^3+d*x^2+e*x+f */
        /* ............................................................................. */
        *akext = ( ( ( ( ed[kk + 5] * *t_in__ + ed[kk + 10] ) * *t_in__ + ed[kk +
                       15] ) * *t_in__ + ed[kk + 20] ) * *t_in__ + ed[kk + 25] ) * *
                 t_in__ + ed[kk + 30];
    }
    /* Exit: */
    return 0;
} /* cop */

/* ............................................................................. */
/* Gas-dominated opacities, ~1,500 K<T<10,000 K */
/* ............................................................................. */
/* The master grid of Rosseland and Planck mean gas opacities. */
/* It has been calculated for me by Ch. Helling (2001): */
/* chris@astro.physik.tu-berlin.de */

/* ............................................................................. */
/* Input parameter(s): */
/* ............................................................................. */

/*     'eG': eG(71,71) - gas opacity grids, */

/* 'rho_in': gas density, g/cm^3, */

/*   'T_in': gas temperature, K */

/* ............................................................................. */
/* Output parameter(s): */
/* ............................................................................. */

/*     'aK': Rosseland or Planck mean opacities (extinction), cm^2/g */

/* ............................................................................. */
int gop( double *eg, double *rho_in__, double *t_in__, double *ak )
{
    /* Initialized data */

    double t[71] = { 500., 521.86, 544.68, 568.5, 593.35, 619.3, 646.38,
                     674.64, 704.14, 734.93, 767.06, 800.6, 835.61, 872.15, 910.28, 950.08,
                     991.63, 1034.99, 1080.24, 1127.47, 1176.77, 1228.23, 1281.93, 1337.99,
                     1396.49, 1457.55, 1521.28, 1587.8, 1657.23, 1729.69, 1805.32, 1884.26,
                     1966.65, 2052.64, 2142.39, 2236.07, 2333.84, 2435.89, 2542.4, 2653.56,
                     2769.59, 2890.69, 3017.09, 3149.01, 3286.7, 3430.41, 3580.41, 3736.96,
                     3900.36, 4070.91, 4248.91, 4434.69, 4628.6, 4830.98, 5042.22, 5262.69,
                     5492.8, 5732.98, 5983.65, 6245.29, 6518.36, 6803.38, 7100.86, 7411.34,
                     7735.41, 8073.64, 8426.66, 8795.12, 9179.68, 9581.07, 1e4
                   };
    double rho[71] = { 2.364e-7, 1.646e-7, 1.147e-7, 7.985e-8, 5.56e-8,
                       3.872e-8, 2.697e-8, 1.878e-8, 1.308e-8, 9.107e-9, 6.342e-9, 4.417e-9,
                       3.076e-9, 2.142e-9, 1.492e-9, 1.039e-9, 7.234e-10, 5.038e-10, 3.508e-10,
                       2.443e-10, 1.701e-10, 1.185e-10, 8.252e-11, 5.746e-11, 4.002e-11,
                       2.787e-11, 1.941e-11, 1.352e-11, 9.412e-12, 6.554e-12, 4.565e-12,
                       3.179e-12, 2.214e-12, 1.542e-12, 1.074e-12, 7.476e-13, 5.206e-13,
                       3.626e-13, 2.525e-13, 1.758e-13, 1.225e-13, 8.528e-14, 5.939e-14,
                       4.136e-14, 2.88e-14, 2.006e-14, 1.397e-14, 9.727e-15, 6.774e-15,
                       4.717e-15, 3.285e-15, 2.288e-15, 1.593e-15, 1.109e-15, 7.726e-16,
                       5.381e-16, 3.747e-16, 2.609e-16, 1.817e-16, 1.265e-16, 8.813e-17,
                       6.137e-17, 4.274e-17, 2.976e-17, 2.073e-17, 1.443e-17, 1.005e-17, 7e-18,
                       4.875e-18, 3.395e-18, 2.364e-18
                     };

    int iflag, c71 = 71;
    double akext;

    /* The temperature array for which the calculation have been performed: */
    /* Parameter adjustments */
    eg -= 72;

    /* Function Body */
    /* The density array for which the calculation have been performed: */

    /* Initialization of output parameter(s): */
    *ak = 0.;
    iflag = 0;

    /* Check if the input parameters "rho_in", "T_in" are inside */
    /* the ranges: */
    if( *rho_in__ > 1e-7 )
    {
        return 0;
    }
    if( *rho_in__ < 1e-19 )
    {
        return 0;
    }
    if( *t_in__ < 500.f )
    {
        return 0;
    }
    if( *t_in__ > 1e4 )
    {
        return 0;
    }
    /* The parameters are outside the ranges, send "stop" signal: */
    if( iflag == 1 )
    {
        printf( "gop: input parameters outside the ranges::\n" );
        printf( "rho_in = %lf T_in = %lf\n", *rho_in__, *t_in__ );
        exit( 1 );
    }
    /* Calculate the opacity: */
    eint( &c71, rho, &c71, t, &eg[72], rho_in__, t_in__, &akext );
    /* Convert it to the linear scale: */
    *ak = exp( akext * log( 10. ) );
    /* Exit: */
    return 0;
} /* gop */

/* ............................................................................. */
/* Quadratic interpolation inside a given array of values. */
/* ............................................................................. */
/* Input parameter(s): */
/* ............................................................................. */

/*  'xa': the value for which interpolation must be performed, */

/*   'x': X(N) - arrayies of values, */

/*  'ri': RI(N) - arrayies of values */

/* ............................................................................. */
/* Output parameter(s): */
/* ............................................................................. */

/* 'res': result of the interpolation */

/* ............................................................................. */
int bint( double *xa, int *n, double *x, double *res, double *ri )
{
    int i1, i2, hi, mid, low;

    /* Parameter adjustments */
    --ri;
    --x;

    /* Function Body */
    if( *xa >= x[1] )
    {
        goto L5;
    }
    i2 = 2;
    goto L99;
L5:
    if( *xa <= x[*n] )
    {
        goto L7;
    }
    i2 = *n;
    goto L99;
L7:
    /* 2 SEARCH IN THE 'X(N)' */
    low = 1;
    hi = *n + 1;
L10:
    mid = ( hi + low ) / 2;
    if( *xa <= x[mid] )
    {
        goto L20;
    }
    low = mid;
    goto L90;
L20:
    hi = mid;
    if( *xa >= x[mid - 1] )
    {
        goto L30;
    }
L90:
    goto L10;
L30:
    i2 = mid;
L99:
    /* 3 QUAD. INTERPOLATION IN 'RI(N)' */
    i1 = i2 - 1;
    *res = ( ri[i2] - ri[i1] ) / ( x[i2] - x[i1] ) * ( *xa - x[i1] ) + ri[i1];
    return 0;
} /* bint */

/* ............................................................................. */
/* Quadratic interpolation inside a given array of values. */
/* ............................................................................. */
/* Input parameter(s): */
/* ............................................................................. */

/*  'N': dimension of first array X, */

/*  'X': X(1:N) - array that contains first set of grid points, */

/*  'M': dimension of second array Y, */

/*  'Y': Y(1:M) - array that contains second set of grid points, */

/*  'D': D(1:N,1:M) - two-dimensional table to be interpolated/extrapolated, */

/* 'XP': first value for that interpolation/extrapolation will be */
/*       performed, */

/* 'YP': second value for that interpolation/extrapolation will be */
/*       performed, */

/* ............................................................................. */
/* Output parameter(s): */
/* ............................................................................. */

/* 'DP': a result of interpolation/extrapolation */

/* ............................................................................. */
int eint( int *n, double *x, int *m, double *y, double *d__, double *xp, double *yp, double *dp )
{
    /* System generated locals */
    int d_dim1, d_offset, i__1;

    /* Local variables */
    double a, b, c__;
    int i__, ip;
    double xtmp[71];

    /* Global variable(s): */
    /* Local variable(s): */
    /* ATTENTION: n=71 now hardcoded (necessary to avoid error when using f2c). */
    /* M.F. Thu Aug  9 13:26:36 EDT 2012 */
    /*     DIMENSION xtmp(n) */
    /* Parameter adjustments */
    --x;
    d_dim1 = *n;
    d_offset = 1 + d_dim1;
    d__ -= d_offset;
    --y;

    /* Function Body */
    if( *n != 71 )
    {
        printf( "EINT: n should equal 71.\n" );
        exit( 1 );
    }
    /* Search the nearest grid point to the 'YP': */
    i__ = 1;
    ip = 0;
L10:
    if( i__ > *m )
    {
        goto L20;
    }
    /* if 'YP' outside the range of 'Y' then exit, */
    if( *yp <= y[i__] )
    {
        /* find the nearest knot, exit */
        ip = i__ - 1;
        goto L20;
    }
    ++i__;
    goto L10;
    /* increase a counter and search again, */
L20:
    /* If 'YP' outside the range of 'Y' then print an error message and stop: */
    if( ip == 0 )
    {
        printf( "EINT: YP outside the range of Y\n" );
        exit( 1 );
    }
    /* Create temporary array for that interpolation/extrapolation will be */
    /* performed: */
    i__1 = *n;
    for( i__ = 1; i__ <= i__1; ++i__ )
    {
        xtmp[i__ - 1] = d__[i__ + ip * d_dim1] + ( d__[i__ + ( ip + 1 ) * d_dim1]
                        - d__[i__ + ip * d_dim1] ) / ( y[ip + 1] - y[ip] ) * ( *yp - y[
                                    ip] );
    }
    /* Search the nearest grid point to the 'XP': */
    i__ = 1;
    ip = 0;
L30:
    if( i__ > *n )
    {
        goto L40;
    }
    /* if 'XP' outside the range of 'X' then exit, */
    if( *xp >= x[i__] )
    {
        /* find the nearest knot, exit */
        ip = i__ - 1;
        goto L40;
    }
    ++i__;
    goto L30;
    /* increase a counter and search again, */
L40:
    /* Interpolation of 'xtmp(1:N)' if 'XP' inside the range of 'X(1:N)': */
    if( ip != 0 )
    {
        *dp = xtmp[ip - 1] + ( xtmp[ip] - xtmp[ip - 1] ) / ( x[ip + 1] - x[ip] ) *
              ( *xp - x[ip] );
    }
    else
    {
        /* Extrapolation of 'xtmp(1:N)' for a given 'XP' and knots array 'X(1:N)' */
        /* by the simplest quadratic fit: */
        a = ( ( xtmp[*n - 1] - xtmp[*n - 2] ) / ( x[*n] - x[*n - 1] ) - ( xtmp[*n -
                2] - xtmp[*n - 3] ) / ( x[*n - 1] - x[*n - 2] ) ) / ( x[*n] - x[*n
                        - 2] );
        b = ( xtmp[*n - 1] - xtmp[*n - 2] ) / ( x[*n] - x[*n - 1] ) - a * ( x[*n]
                + x[*n - 1] );
        c__ = xtmp[*n - 1] - a * x[*n] * x[*n] - b * x[*n];
        *dp = a * *xp * *xp + b * *xp + c__;
    }
    /* Exit: */
    return 0;
} /* eint */

/* ............................................................................. */
/*  Fit coefficients for "normal" silicate dust model, Fe/(Fe+Mg)=0.3 for */
/*  Rosseland and Planck mean opacities (extinction) in the case of */
/*  homogeneous spherical particles. */
/* ............................................................................. */
/*  Input parameter(s): */
/* ............................................................................. */

/*  'ross': opacity kind, */
/*        = .true. - Rosseland mean, */
/*        = .false. - Planck mean */

/* ............................................................................. */
/*  Output parameter(s): */
/* ............................................................................. */

/*    'eD': eD(5,6) opacity fit coefficients (extinction), */

/* ............................................................................. */
int nrm_h_s( int *ross, double *ed )
{
    /* Initialized data */

    double er[30]   /* was [5][6] */ = { 3.19006401785413e-12,
                                         -3.71333580736933e-12, 4.04997080931974e-13, 7.28005983960845e-14,
                                         -9.16709776405312e-17, -3.89280273285906e-9, 5.8715126950896e-9,
                                         -1.05506373600323e-9, -2.07587683535083e-10, 8.03836688553263e-13,
                                         4.54088516995579e-7, -3.49287851393541e-6, 1.10792133181219e-6,
                                         2.33773506650911e-7, -3.00202906476749e-9, 2.29132294521843e-4,
                                         9.23001367150898e-4, -5.82601311634824e-4, -1.27355043519226e-4,
                                         5.90717655258634e-6, -1.91588103585833e-4, -.0801305197566973,
                                         .160197849829283, .0354301116460647, -.00260479348963077,
                                         2.44153190819473e-4, 2.92517586013911, -12.5893536782728,
                                         -1.92550086994197, 1.65244978116957
                                       };
    double ep[30]   /* was [5][6] */ = { -6.64969066656727e-11,
                                         -3.71134628305626e-12, 2.33228177925061e-13, 1.15933380913977e-13,
                                         -5.03398974713655e-16, 4.2737369456088e-8, 4.72321713029246e-9,
                                         -6.8113840099694e-10, -3.4946755212609e-10, 4.17753047583439e-12,
                                         -1.08371821805323e-5, -2.10704968520099e-6, 7.84339065020565e-7,
                                         4.17313950448598e-7, -1.40583908595144e-8, .0013073258847462,
                                         3.11604311624702e-4, -4.36299138970822e-4, -2.40971082612604e-4,
                                         2.38329845360675e-5, -.00191556936842122, .0302186734201724,
                                         .120954274022502, .0664915248499724, -.0166789974601131,
                                         4.23062838413742e-4, -1.73587657890234, -6.38046050114383,
                                         -3.45042341508906, 6.67823366719512
                                       };

    /* Local variables */
    int i__, j;

    /* Fit coefficients for Rosseland mean opacity (extinction) */
    /* Parameter adjustments */
    ed -= 6;

    /* Function Body */
    /* Fit coefficients for Planck mean opacity (extinction) */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 5th temperature region, */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 5th temperature region, */
    //printf("Dust model: \"normal\" silicates; homogeneous spheres\n");
    for( i__ = 1; i__ <= 5; ++i__ )
    {
        for( j = 1; j <= 6; ++j )
        {
            if( *ross )
            {
                /* Rosseland mean opacities, */
                ed[i__ + j * 5] = er[i__ + j * 5 - 6];
            }
            else
            {
                /* Planck mean opacities, */
                ed[i__ + j * 5] = ep[i__ + j * 5 - 6];
            }
        }
    }
    return 0;
} /* nrm_h_s */

/* ............................................................................. */
/*  Fit coefficients for "normal" silicate dust model, Fe/(Fe+Mg)=0.3 for */
/*  Rosseland and Planck mean opacities (extinction) in the case of */
/*  homogeneous aggregates. */
/* ............................................................................. */
/*  Input parameter(s): */
/* ............................................................................. */

/*  'ross': opacity kind, */
/*        = .true. - Rosseland mean, */
/*        = .false. - Planck mean */

/* ............................................................................. */
/*  Output parameter(s): */
/* ............................................................................. */

/*    'eD': eD(5,6) opacity fit coefficients (extinction), */

/* ............................................................................. */
int nrm_h_a( int *ross, double *ed )
{
    /* Initialized data */

    double er[30]   /* was [5][6] */ = { 1.68861023303854e-11,
                                         -8.9850072680019e-12, 5.82530990776154e-13, -1.48326508937668e-13,
                                         -4.30701986706985e-16, -1.20402290627887e-8, 1.28198928214142e-8,
                                         -1.50953570991798e-9, 4.08108978612667e-10, 3.39564249503292e-12,
                                         1.77953606574835e-6, -6.93522864221904e-6, 1.56218937076688e-6,
                                         -4.51279568324355e-7, -1.07516953060505e-8, 2.12362579369808e-4,
                                         .00168403875453076, -8.01998052899398e-4, 2.55292916286856e-4,
                                         1.72441594083825e-5, 7.78492928244887e-4, -.147692895446187,
                                         .207736375394269, -.0740119036963982, -.0125379874861012,
                                         .0241868473745753, 5.29937764788582, -15.013888523115,
                                         11.6718738764544, 8.51701322511245
                                       };
    double ep[30]   /* was [5][6] */ = { -4.92069777333529e-11,
                                         -2.23226569654021e-12, 4.17660592123971e-13, 7.36941850981986e-14,
                                         -9.33742153131707e-16, 3.51613326727785e-8, 2.34420258427756e-9,
                                         -1.09660407626912e-9, -2.33461926078913e-10, 7.57125209044329e-12,
                                         -1.04115039477478e-5, -5.49552382795955e-7, 1.15365821720713e-6,
                                         2.91321994671026e-7, -2.48981597495535e-8, .00143929174351961,
                                         -2.07570458861422e-4, -5.9765296278811e-4, -1.70963348654879e-4,
                                         4.20975013057549e-5, -.00560836248243543, .114110901145235,
                                         .15142548229089, .0431209143726505, -.0358197096572059,
                                         .0347493611283224, -5.23802684273195, -6.72104055072077,
                                         1.25341599902458, 17.9030725409353
                                       };

    /* Local variables */
    int i__, j;

    /* Fit coefficients for Rosseland mean opacity (extinction) */
    /* Parameter adjustments */
    ed -= 6;

    /* Function Body */
    /* Fit coefficients for Planck mean opacity (extinction) */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 5th temperature region, */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 5th temperature region, */
    //printf("Dust model: \"normal\" silicates; homogeneous dust aggregates\n");
    for( i__ = 1; i__ <= 5; ++i__ )
    {
        for( j = 1; j <= 6; ++j )
        {
            if( *ross )
            {
                /* Rosseland mean opacities, */
                ed[i__ + j * 5] = er[i__ + j * 5 - 6];
            }
            else
            {
                /* Planck mean opacities, */
                ed[i__ + j * 5] = ep[i__ + j * 5 - 6];
            }
        }
    }
    return 0;
} /* nrm_h_a */

/* ............................................................................. */
/*  Fit coefficients for "normal" silicate dust model, Fe/(Fe+Mg)=0.3 for */
/*  Rosseland and Planck mean opacities (extinction) in the case of composite */
/*  aggregates. */
/* ............................................................................. */
/*  Input parameter(s): */
/* ............................................................................. */

/*  'ross': opacity kind, */
/*        = .true. - Rosseland mean, */
/*        = .false. - Planck mean */

/* ............................................................................. */
/*  Output parameter(s): */
/* ............................................................................. */

/*    'eD': eD(5,6) opacity fit coefficients (extinction), */

/* ............................................................................. */
int nrm_c_a( int *ross, double *ed )
{
    /* Initialized data */

    double er[30]   /* was [5][6] */ = { 7.20701447856184e-12,
                                         -2.4907659681787e-12, 1.47047692292156e-13, -7.03016585961037e-14,
                                         -2.70939930597314e-16, -5.035038549077e-9, 3.7708862230036e-9,
                                         -3.87482891475618e-10, 2.02821751746324e-10, 2.10746431618766e-12,
                                         2.26842045361197e-7, -2.19234912973936e-6, 4.04456534975749e-7,
                                         -2.17017102230874e-7, -6.42207600441133e-9, 3.12806097218514e-4,
                                         5.83335936413833e-4, -2.13826028150926e-4, 9.9001304033286e-5,
                                         9.44843848093039e-6, 1.80058512896224e-4, -.0422661131364785,
                                         .0755230656285519, -.00826824733591991, -.00371281327665396,
                                         5.19867225867212e-4, 1.51792930161834, -5.77453341827436,
                                         .0778024394658132, 1.84662967567162
                                       };
    double ep[30]   /* was [5][6] */ = { -4.76229927324027e-11,
                                         -2.01419780917042e-12, 3.0017038055868e-13, 4.83186183366502e-14,
                                         -6.01503795230963e-16, 3.23115304363536e-8, 2.43303301704539e-9,
                                         -7.25143652779537e-10, -1.56443323825868e-10, 4.5775427780804e-12,
                                         -8.98454373102764e-6, -9.74542613966394e-7, 6.81446617689516e-7,
                                         2.23303922683611e-7, -1.37464170006e-8, .0011978903527625,
                                         9.36919615518259e-5, -3.12657620965884e-4, -1.70154802757033e-4,
                                         2.05252303643339e-5, 1.41738348367326e-4, .0429796005017331,
                                         .0865739688529015, .0715076192965753, -.0127405068642357,
                                         .0019193409307739, -1.93487570913044, -4.11421919689133,
                                         -8.03761464382478, 5.66279740952716
                                       };

    /* Local variables */
    int i__, j;

    /* Fit coefficients for Rosseland mean opacity (extinction) */
    /* Parameter adjustments */
    ed -= 6;

    /* Function Body */
    /* Fit coefficients for Planck mean opacity (extinction) */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 5th temperature region, */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 5th temperature region, */
    //printf("Dust model: \"normal\" silicates; composite dust aggregates\n");
    for( i__ = 1; i__ <= 5; ++i__ )
    {
        for( j = 1; j <= 6; ++j )
        {
            if( *ross )
            {
                /* Rosseland mean opacities, */
                ed[i__ + j * 5] = er[i__ + j * 5 - 6];
            }
            else
            {
                /* Planck mean opacities, */
                ed[i__ + j * 5] = ep[i__ + j * 5 - 6];
            }
        }
    }
    return 0;
} /* nrm_c_a */

/* ............................................................................. */
/*  Fit coefficients for "iron-rich" silicate dust model, Fe/(Fe+Mg)=0.4 for */
/*  Rosseland and Planck mean opacities (extinction) in the case of */
/*  homogeneous spherical particles. */
/* ............................................................................. */
/*  Input parameter(s): */
/* ............................................................................. */

/*  'ross': opacity kind, */
/*        = .true. - Rosseland mean, */
/*        = .false. - Planck mean */

/* ............................................................................. */
/*  Output parameter(s): */
/* ............................................................................. */

/*    'eD': eD(5,6) opacity fit coefficients (extinction), */

/* ............................................................................. */
int irs_h_s( int *ross, double *ed )
{
    /* Initialized data */

    double er[30]   /* was [5][6] */ = { 5.7601981357577e-12,
                                         -4.99769242535922e-12, 5.12323092131981e-13, 2.18800655107819e-14,
                                         -8.07771637816195e-17, -5.66838675003818e-9, 7.59080537623659e-9,
                                         -1.29960038970606e-9, -5.84337549441558e-11, 6.9565630029198e-13,
                                         8.30337800213717e-7, -4.35964811951971e-6, 1.32446896467955e-6,
                                         5.80076458925913e-8, -2.66757554277098e-9, 2.04146163684104e-4,
                                         .00112173944288055, -6.73319917371393e-4, -2.26453533385684e-5,
                                         5.63354515903305e-6, -1.77447081534454e-4, -.10072601112787,
                                         .176434307754734, .00326534361175135, -.00246214277093693,
                                         2.11770185099498e-4, 3.6878091307137, -13.5596059076829,
                                         1.69682934809634, 1.52636093726865
                                       };
    double ep[30]   /* was [5][6] */ = { -6.35517551097894e-11,
                                         -3.99054808930408e-12, 4.23592172055043e-13, 1.03007824797934e-13,
                                         -5.07440298515937e-16, 4.11226694501098e-8, 5.05310547896248e-9,
                                         -1.10532072036976e-9, -3.14505673133739e-10, 4.30806156797121e-12,
                                         -1.06062336214121e-5, -2.22408956189724e-6, 1.15791165287928e-6,
                                         3.78718718884228e-7, -1.49005526499236e-8, .00130671183384587,
                                         3.13929052700822e-4, -5.9691242367995e-4, -2.17573779858773e-4,
                                         2.59836392325083e-5, -.0019618111469326, .0344865312784342,
                                         .152941991504775, .0575577983185305, -.0184990920136232,
                                         3.66050010135324e-4, -2.01187462059437, -8.58634798903256,
                                         -2.02130563003175, 7.26442191429906
                                       };

    /* Local variables */
    int i__, j;

    /* Fit coefficients for Rosseland mean opacity (extinction) */
    /* Parameter adjustments */
    ed -= 6;

    /* Function Body */
    /* Fit coefficients for Planck mean opacity (extinction) */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 5th temperature region, */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 5th temperature region, */
    //printf("Dust model: \"iron-rich\" silicates; homogeneous spheres\n");
    for( i__ = 1; i__ <= 5; ++i__ )
    {
        for( j = 1; j <= 6; ++j )
        {
            if( *ross )
            {
                /* Rosseland mean opacities, */
                ed[i__ + j * 5] = er[i__ + j * 5 - 6];
            }
            else
            {
                /* Planck mean opacities, */
                ed[i__ + j * 5] = ep[i__ + j * 5 - 6];
            }
        }
    }
    return 0;
} /* irs_h_s */

/* ............................................................................. */
/*  Fit coefficients for "iron-rich" silicate dust model, Fe/(Fe+Mg)=0.4 for */
/*  Rosseland and Planck mean opacities (extinction) in the case of */
/*  homogeneous aggregates. */
/* ............................................................................. */
/*  Input parameter(s): */
/* ............................................................................. */

/*  'ross': opacity kind, */
/*        = .true. - Rosseland mean, */
/*        = .false. - Planck mean */

/* ............................................................................. */
/*  Output parameter(s): */
/* ............................................................................. */

/*    'eD': eD(5,6) opacity fit coefficients (extinction), */

/* ............................................................................. */
int irs_h_a( int *ross, double *ed )
{
    /* Initialized data */

    double er[30]   /* was [5][6] */ = { 7.72639728356779e-12,
                                         -5.39749898970236e-12, 6.60406670336159e-13, -2.33899135385353e-14,
                                         -3.17922057748607e-16, -6.44080151348334e-9, 8.11505188904135e-9,
                                         -1.61644832093921e-9, 7.06927420757404e-11, 2.41375714896697e-12,
                                         7.97866868723018e-7, -4.57761180939179e-6, 1.58678357831901e-6,
                                         -8.98412919246258e-8, -7.34197574322242e-9, 2.25883090984006e-4,
                                         .00114345774728591, -7.76788395443505e-4, 6.21507631333035e-5,
                                         1.11264442431855e-5, 7.25480550488905e-4, -.0978898757466869,
                                         .193581659006369, -.0217355364350702, -.00628811292824788,
                                         .0122051600622987, 3.51782822672046, -14.2469784180394,
                                         4.55053117028592, 4.2703125052222
                                       };
    double ep[30]   /* was [5][6] */ = { -5.63594999938697e-11,
                                         -3.56750876770514e-12, 4.46380347955089e-13, 6.25274066877062e-14,
                                         -6.99946491795733e-16, 3.71451774259654e-8, 4.4624421523035e-9,
                                         -1.14262235245685e-9, -2.01506580979103e-10, 5.67273543670362e-12,
                                         -9.91789085614209e-6, -1.90441507450207e-6, 1.17745875827923e-6,
                                         2.54218142577747e-7, -1.8556933234777e-8, .00127218972995149,
                                         2.29778613121725e-4, -6.01246324800964e-4, -1.50393927880021e-4,
                                         3.08276173039628e-5, -.0036189352939031, .0440416079300803,
                                         .152170793836831, .0388871968614808, -.0243329166513556,
                                         .0173619167582948, -2.31559089154565, -8.36542813568644,
                                         .0450982708771335, 11.2607539943696
                                       };

    /* Local variables */
    int i__, j;

    /* Fit coefficients for Rosseland mean opacity (extinction) */
    /* Parameter adjustments */
    ed -= 6;

    /* Function Body */
    /* Fit coefficients for Planck mean opacity (extinction) */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 5th temperature region, */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 5th temperature region, */
    //printf("Dust model: \"iron-rich\" silicates; homogeneous dust aggregates\n");
    for( i__ = 1; i__ <= 5; ++i__ )
    {
        for( j = 1; j <= 6; ++j )
        {
            if( *ross )
            {
                /* Rosseland mean opacities, */
                ed[i__ + j * 5] = er[i__ + j * 5 - 6];
            }
            else
            {
                /* Planck mean opacities, */
                ed[i__ + j * 5] = ep[i__ + j * 5 - 6];
            }
        }
    }
    return 0;
} /* irs_h_a */

/* ............................................................................. */
/*  Fit coefficients for "iron-rich" silicate dust model, Fe/(Fe+Mg)=0.4 for */
/*  Rosseland and Planck mean opacities (extinction) in the case of composite */
/*  aggregates. */
/* ............................................................................. */
/*  Input parameter(s): */
/* ............................................................................. */

/*  'ross': opacity kind, */
/*        = .true. - Rosseland mean, */
/*        = .false. - Planck mean */

/* ............................................................................. */
/*  Output parameter(s): */
/* ............................................................................. */

/*    'eD': eD(5,6) opacity fit coefficients (extinction), */

/* ............................................................................. */
int irs_c_a( int *ross, double *ed )
{
    /* Initialized data */

    double er[30]   /* was [5][6] */ = { 1.69718972871675e-11,
                                         -6.94375347617142e-12, 2.15423123300413e-12, -1.53228592726268e-14,
                                         -1.90340462215016e-16, -1.21998488943724e-8, 1.0029623044894e-8,
                                         -5.04005652039218e-9, 4.92876842625018e-11, 1.54287786660063e-12,
                                         1.93536758125125e-6, -5.49498202994399e-6, 4.69679087503714e-6,
                                         -6.73038576343371e-8, -4.97946233406153e-9, 1.66188782516588e-4,
                                         .00135478657540836, -.00217615792442986, 5.02152454110172e-5,
                                         7.85141889125417e-6, -3.81731756583378e-5, -.120651633250931,
                                         .505806507849164, -.0180098161036177, -.00335902561018642,
                                         2.76801205127708e-4, 4.35206756800406, -41.8745489893471,
                                         3.99640879074968, 1.66403764989818
                                       };
    double ep[30]   /* was [5][6] */ = { -5.04975573012723e-11,
                                         -2.84324563106125e-12, 2.50213657686044e-13, 9.05652406698726e-14,
                                         -5.93836462006964e-16, 3.47295030021792e-8, 3.43435803167343e-9,
                                         -7.26370420955544e-10, -2.77723357901886e-10, 4.6838348665875e-12,
                                         -9.79492648574967e-6, -1.32874934767691e-6, 8.25426710793917e-7,
                                         3.33848011897829e-7, -1.47239788122946e-8, .0013004022706089,
                                         7.39284258260507e-5, -4.51586611989657e-4, -1.90725939425124e-4,
                                         2.30940509311539e-5, -.00181306680219879, .0634803174529273,
                                         .120127510474273, .0496177910255966, -.0157858987410152,
                                         5.13261299896949e-4, -3.02044626872119, -5.54325826392903,
                                         -1.20153037129148, 6.56777392849503
                                       };

    /* Local variables */
    int i__, j;

    /* Fit coefficients for Rosseland mean opacity (extinction) */
    /* Parameter adjustments */
    ed -= 6;

    /* Function Body */
    /* Fit coefficients for Planck mean opacity (extinction) */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 5th temperature region, */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 5th temperature region, */
    //printf("Dust model: \"iron-rich\" silicates; composite dust aggregates\n");
    for( i__ = 1; i__ <= 5; ++i__ )
    {
        for( j = 1; j <= 6; ++j )
        {
            if( *ross )
            {
                /* Rosseland mean opacities, */
                ed[i__ + j * 5] = er[i__ + j * 5 - 6];
            }
            else
            {
                /* Planck mean opacities, */
                ed[i__ + j * 5] = ep[i__ + j * 5 - 6];
            }
        }
    }
    return 0;
} /* irs_c_a */

/* ............................................................................. */
/*  Fit coefficients for "iron-poor" silicate dust model, Fe/(Fe+Mg)=0 for */
/*  Rosseland and Planck mean opacities (extinction) in the case of */
/*  homogeneous spherical particles. */
/* ............................................................................. */
/*  Input parameter(s): */
/* ............................................................................. */

/*  'ross': opacity kind, */
/*        = .true. - Rosseland mean, */
/*        = .false. - Planck mean */

/* ............................................................................. */
/*  Output parameter(s): */
/* ............................................................................. */

/*    'eD': eD(5,6) opacity fit coefficients (extinction), */

/* ............................................................................. */
int ips_h_s( int *ross, double *ed )
{
    /* Initialized data */

    double er[30]   /* was [5][6] */ = { 3.00658051669719e-12,
                                         -1.97259390203938e-12, 1.6853302497342e-13, 6.04125759038766e-14,
                                         -9.95717001478127e-17, -2.63154481829747e-9, 3.3639755865301e-9,
                                         -5.02191662104894e-10, -1.80575722027018e-10, 8.34292133110325e-13,
                                         4.92257291893745e-9, -2.13035111086644e-6, 5.9830807272656e-7,
                                         2.15594092859513e-7, -2.91317607660158e-9, 2.62302100896287e-4,
                                         5.8664326934511e-4, -3.54139964409472e-4, -1.27353304604103e-4,
                                         5.30437772788307e-6, -1.21087027799125e-4, -.0446872071903881,
                                         .111785864483419, .0397412595455471, -.00213405804655453,
                                         4.48716952118912e-4, 1.60360533954925, -9.02203683840924,
                                         -3.15688727136694, 1.61185826559431
                                       };
    double ep[30]   /* was [5][6] */ = { -7.62495034669013e-11,
                                         -2.08817975056004e-12, 4.55478517863122e-14, 5.77110185903943e-14,
                                         -3.57521081391269e-16, 4.8138140778987e-8, 2.77595756494202e-9,
                                         -2.4295051425259e-10, -1.89643620784973e-10, 2.97294385961353e-12,
                                         -1.16414113322383e-5, -1.28917595517889e-6, 3.80173868432801e-7,
                                         2.47521007681076e-7, -1.00417000376078e-8, .00131102314677719,
                                         1.89740387075683e-4, -2.56477546533858e-4, -1.57195774544663e-4,
                                         1.7204727555092e-5, -.00180871641248512, .0293545307083072,
                                         .0847456608016088, .0492650962434666, -.0119523016015378,
                                         6.7524714237124e-4, -1.38141401076848, -4.50160901769459,
                                         -2.99569196780794, 5.29996631480414
                                       };


    /* Local variables */
    int i__, j;

    /* Fit coefficients for Rosseland mean opacity (extinction) */
    /* Parameter adjustments */
    ed -= 6;

    /* Function Body */
    /* Fit coefficients for Planck mean opacity (extinction) */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 5th temperature region, */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 5th temperature region, */
    //printf("Dust model: \"iron-poor\" silicates; homogeneous spheres\n");
    for( i__ = 1; i__ <= 5; ++i__ )
    {
        for( j = 1; j <= 6; ++j )
        {
            if( *ross )
            {
                /* Rosseland mean opacities, */
                ed[i__ + j * 5] = er[i__ + j * 5 - 6];
            }
            else
            {
                /* Planck mean opacities, */
                ed[i__ + j * 5] = ep[i__ + j * 5 - 6];
            }
        }
    }
    return 0;
} /* ips_h_s */

/* ............................................................................. */
/*  Fit coefficients for "iron-poor" silicate dust model, Fe/(Fe+Mg)=0 for */
/*  Rosseland and Planck mean opacities (extinction) in the case of */
/*  homogeneous aggregates. */
/* ............................................................................. */
/*  Input parameter(s): */
/* ............................................................................. */

/*  'ross': opacity kind, */
/*        = .true. - Rosseland mean, */
/*        = .false. - Planck mean */

/* ............................................................................. */
/*  Output parameter(s): */
/* ............................................................................. */

/*    'eD': eD(5,6) opacity fit coefficients (extinction), */

/* ............................................................................. */
int ips_h_a( int *ross, double *ed )
{
    /* Initialized data */

    double er[30]   /* was [5][6] */ = { 3.9876690691785e-11,
                                         -2.1711905581049e-11, 1.82985315295776e-12, -8.05198016715616e-14,
                                         -9.73535924542553e-16, -3.01219020238261e-8, 3.00228652654332e-8,
                                         -4.41708307565184e-9, 1.79046803997717e-10, 7.52166814380431e-12,
                                         5.77520635928109e-6, -1.57651765131816e-5, 4.27780234609545e-6,
                                         -1.5626629350842e-7, -2.35802897829936e-8, 5.96152490173934e-5,
                                         .00372607865913943, -.00207005122509878, 7.81710782006007e-5,
                                         3.8173115333209e-5, .00423188073215978, -.330731648461098,
                                         .499311098121487, -.0294224614020919, -.0309473698100117,
                                         .0245541430111114, 11.5232997774915, -36.089498663223,
                                         13.1249047206802, 17.699724191644
                                       };
    double ep[30]   /* was [5][6] */ = { 1.18235221619919e-11,
                                         4.54156560960751e-12, 7.25253521267534e-13, 9.44170736690998e-14,
                                         -1.19216455127025e-15, 1.02022447988636e-8, -8.70656030600515e-9,
                                         -1.81874953197265e-9, -2.89483768978003e-10, 9.83305964350091e-12,
                                         -9.94087795995219e-6, 6.72319644758312e-6, 1.82391722383996e-6,
                                         3.46086590595832e-7, -3.32236505461873e-8, .00205810606354174,
                                         -.00261848001140506, -8.96451046938099e-4, -1.86858322081096e-4,
                                         5.87525102093395e-5, -.00650673267299652, .50597898461601,
                                         .205104310731812, .0321138011065329, -.0544333376857938,
                                         .0350084639895791, -21.8764543973822, -1.67577204662189,
                                         12.1847428124429, 29.3820268460826
                                       };


    /* Local variables */
    int i__, j;

    /* Fit coefficients for Rosseland mean opacity (extinction) */
    /* Parameter adjustments */
    ed -= 6;

    /* Function Body */
    /* Fit coefficients for Planck mean opacity (extinction) */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 5th temperature region, */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 5th temperature region, */
    //printf("Dust model: \"iron-poor\" silicates; homogeneous dust aggregates\n");
    for( i__ = 1; i__ <= 5; ++i__ )
    {
        for( j = 1; j <= 6; ++j )
        {
            if( *ross )
            {
                /* Rosseland mean opacities, */
                ed[i__ + j * 5] = er[i__ + j * 5 - 6];
            }
            else
            {
                /* Planck mean opacities, */
                ed[i__ + j * 5] = ep[i__ + j * 5 - 6];
            }
        }
    }
    return 0;
} /* ips_h_a */

/* ............................................................................. */
/*  Fit coefficients for "iron-poor" silicate dust model, Fe/(Fe+Mg)=0 for */
/*  Rosseland and Planck mean opacities (extinction) in the case of composite */
/*  dust aggregates. */
/* ............................................................................. */
/*  Input parameter(s): */
/* ............................................................................. */

/*  'ross': opacity kind, */
/*        = .true. - Rosseland mean, */
/*        = .false. - Planck mean */

/* ............................................................................. */
/*  Output parameter(s): */
/* ............................................................................. */

/*    'eD': eD(5,6) opacity fit coefficients (extinction), */

/* ............................................................................. */
int ips_c_a( int *ross, double *ed )
{
    /* Initialized data */

    double er[30]   /* was [5][6] */ = { 7.00848522113819e-12,
                                         -2.34008494922127e-12, 1.07369093347642e-13, -7.26185432947517e-14,
                                         -1.96218020716864e-16, -5.38589091535874e-9, 3.8357901565285e-9,
                                         -3.67064066072209e-10, 1.93822304483831e-10, 1.44371440578819e-12,
                                         5.7560737665603e-7, -2.35889261211091e-6, 4.76397692731733e-7,
                                         -2.04231275245388e-7, -4.1032886405935e-9, 2.30327333546414e-4,
                                         6.38516652690171e-4, -2.97818033284845e-4, 1.04980224671869e-4,
                                         5.60507588086593e-6, -8.22083223050224e-5, -.0503436633369645,
                                         .0988228392396842, -.0201847825087, 7.57770858114792e-4,
                                         3.69445521733393e-4, 1.80714258284096, -7.89749805432507,
                                         2.65221396709558, .951373329780637
                                       };
    double ep[30]   /* was [5][6] */ = { -6.22408677562333e-11,
                                         -1.89825723717914e-12, 2.3781647824411e-13, 3.75715998081986e-14,
                                         -2.14972270927091e-16, 4.0262989995999e-8, 2.48653050776984e-9,
                                         -6.55089116422171e-10, -1.10762431195546e-10, 1.53656290155567e-12,
                                         -1.02489365882874e-5, -1.11198026031581e-6, 7.21372280697123e-7,
                                         1.31743869545228e-7, -4.37491668963704e-9, .00123410669620415,
                                         1.37549910094186e-4, -3.91545688342924e-4, -7.95520071286138e-5,
                                         6.59347035059836e-6, -.00160861573302469, .0360059623487543,
                                         .11019424246455, .0290920098238345, -.00113065151550762,
                                         6.36434053917017e-4, -1.64569511441852, -6.36071177949543,
                                         -1.43249124741396, 2.7592514606883
                                       };


    /* Local variables */
    int i__, j;

    /* Fit coefficients for Rosseland mean opacity (extinction) */
    /* Parameter adjustments */
    ed -= 6;

    /* Function Body */
    /* Fit coefficients for Planck mean opacity (extinction) */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 5th temperature region, */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 5th temperature region, */
    //printf("Dust model: \"iron-poor\" silicates; composite aggregates\n");
    /* Set up output parameters: */
    for( i__ = 1; i__ <= 5; ++i__ )
    {
        for( j = 1; j <= 6; ++j )
        {
            if( *ross )
            {
                /* Rosseland mean opacities, */
                ed[i__ + j * 5] = er[i__ + j * 5 - 6];
            }
            else
            {
                /* Planck mean opacities, */
                ed[i__ + j * 5] = ep[i__ + j * 5 - 6];
            }
        }
    }
    /* Exit: */
    return 0;
} /* ips_c_a */

/* ............................................................................. */
/*  Fit coefficients for "iron-poor" silicate dust model, Fe/(Fe+Mg)=0 for */
/*  Rosseland and Planck mean opacities (extinction) in the case of composite */
/*  5-layered spherical particles. */
/* ............................................................................. */
/*  Input parameter(s): */
/* ............................................................................. */

/*  'ross': opacity kind, */
/*        = .true. - Rosseland mean, */
/*        = .false. - Planck mean */

/* ............................................................................. */
/*  Output parameter(s): */
/* ............................................................................. */

/*    'eD': eD(5,6) opacity fit coefficients (extinction), */

/* ............................................................................. */
int ips_c_5( int *ross, double *ed )
{
    /* Initialized data */

    double er[30]   /* was [5][6] */ = { -2.79703516002897e-12,
                                         -3.71409613106896e-12, 2.34075927636491e-13, -1.01800844150439e-13,
                                         -8.21504861578549e-17, 2.99903218454126e-9, 5.15697887841035e-9,
                                         -5.98389237952855e-10, 2.82978926717624e-10, 2.47507275791509e-12,
                                         -1.86639771356542e-6, -2.69368563616806e-6, 6.18463391194746e-7,
                                         -3.10240611167179e-7, -1.51457032675916e-8, 4.43116074420988e-4,
                                         6.15462610994137e-4, -3.20161849864215e-4, 1.67831302727872e-4,
                                         3.56293530471352e-5, .00168691259807248, -.0416611063882709,
                                         .0863122988673855, -.0427972786642571, -.0229644576797283,
                                         .00236109236817865, 1.4810199621333, -5.78138633671746,
                                         5.04907160395485, 5.68279807703259
                                       };
    double ep[30]   /* was [5][6] */ = { -7.36489754038067e-11,
                                         -1.70934788512322e-12, 1.39562396421684e-13, -3.84957782562793e-15,
                                         -6.71733100328753e-16, 4.64194685916225e-8, 2.09527115986019e-9,
                                         -3.73800275084069e-10, 6.2080817382009e-12, 2.0722415806478e-12,
                                         -1.10260947084459e-5, -8.57256889521031e-7, 4.09096625424709e-7,
                                         4.08263907043388e-9, 7.55698359430833e-9, .00116709474370211,
                                         8.21108412834742e-5, -2.2142358931887e-4, -9.00298905399179e-6,
                                         -4.35171365095976e-5, .00488782650671213, .0296539924474562,
                                         .0611883310727851, .00583500314497411, .0746289306922593,
                                         .00968106067481123, -1.13719115032885, -2.70601432557118,
                                         .0174866854900613, -21.900852569315
                                       };

    /* Local variables */
    int i__, j;

    /* Fit coefficients for Rosseland mean opacity (extinction) */
    /* Parameter adjustments */
    ed -= 6;

    /* Function Body */
    /* Fit coefficients for Planck mean opacity (extinction) */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    //printf("Dust model: \"iron-poor\" silicates; composite  5-layered spheres\n");
    /* Set up output parameters: */
    for( i__ = 1; i__ <= 5; ++i__ )
    {
        for( j = 1; j <= 6; ++j )
        {
            if( *ross )
            {
                /* Rosseland mean opacities, */
                ed[i__ + j * 5] = er[i__ + j * 5 - 6];
            }
            else
            {
                /* Planck mean opacities, */
                ed[i__ + j * 5] = ep[i__ + j * 5 - 6];
            }
        }
    }
    /* Exit: */
    return 0;
} /* ips_c_5 */

/* ............................................................................. */
/*  Fit coefficients for "iron-poor" silicate dust model, Fe/(Fe+Mg)=0 for */
/*  Rosseland and Planck mean opacities (extinction) in the case of */
/*  composite spherical particles. */
/* ............................................................................. */
/*  Input parameter(s): */
/* ............................................................................. */

/*  'ross': opacity kind, */
/*        = .true. - Rosseland mean, */
/*        = .false. - Planck mean */

/* ............................................................................. */
/*  Output parameter(s): */
/* ............................................................................. */

/*    'eD': eD(5,6) opacity fit coefficients (extinction), */

/* ............................................................................. */
int ips_c_s( int *ross, double *ed )
{
    /* Initialized data */

    double er[30]   /* was [5][6] */ = { 3.63835105143983e-11,
                                         -3.15467725353657e-12, 3.05043095219605e-13, -5.11040414125191e-14,
                                         -8.21504861578549e-17, -2.41785294686923e-8, 4.50093627394633e-9,
                                         -7.67755302507182e-10, 1.36749247287027e-10, 2.47507275791509e-12,
                                         4.86478724760649e-6, -2.39731121423556e-6, 7.78808644026713e-7,
                                         -1.42748156825152e-7, -1.51457032675916e-8, -2.61510400168426e-4,
                                         5.49155786487583e-4, -3.93896857785426e-4, 7.29629767399327e-5,
                                         3.56293530471352e-5, .0316265770662144, -.0350623289221934,
                                         .101563268813365, -.0165846142501944, -.0229644576797283,
                                         .0883862204249974, 1.26108394204894, -6.99722599821573,
                                         2.33256252774021, 5.68279807703259
                                       };
    double ep[30]   /* was [5][6] */ = { -3.41519090504848e-11,
                                         -5.5121962033524e-13, 1.16932386253542e-13, 8.17757049965684e-15,
                                         -6.71733100328753e-16, 2.13852239343546e-8, 7.19099343397864e-10,
                                         -3.27982472912081e-10, -3.47386375901682e-11, 2.0722415806478e-12,
                                         -5.33727686471584e-6, -2.55320370665289e-7, 3.84843073428646e-7,
                                         5.84134188822958e-8, 7.55698359430833e-9, 6.06901846786552e-4,
                                         -3.51495462968882e-5, -2.22958043659065e-4, -4.42040035304802e-5,
                                         -4.35171365095976e-5, .0252006314266762, .0389747405277225,
                                         .0645036999423646, .016375762258038, .0746289306922593,
                                         .111411915643134, -1.39765319065388, -3.28387965890002,
                                         -.853109936284488, -21.900852569315
                                       };

    /* Local variables */
    int i__, j;

    /* Fit coefficients for Rosseland mean opacity (extinction) */
    /* Parameter adjustments */
    ed -= 6;

    /* Function Body */
    /* Fit coefficients for Planck mean opacity (extinction) */
    /* 1st temperature region */
    /* 2nd temperature region */
    /* 3rd temperature region */
    /* 4th temperature region */
    /* 1st temperature region */
    /* 2nd temperature region */
    /* 3rd temperature region */
    /* 4th temperature region, */
    //printf("Dust model: \"iron-poor\" silicates; composite spheres\n");
    /* Set up output parameters: */
    for( i__ = 1; i__ <= 5; ++i__ )
    {
        for( j = 1; j <= 6; ++j )
        {
            if( *ross )
            {
                /* Rosseland mean opacities, */
                ed[i__ + j * 5] = er[i__ + j * 5 - 6];
            }
            else
            {
                /* Planck mean opacities, */
                ed[i__ + j * 5] = ep[i__ + j * 5 - 6];
            }
        }
    }
    /* Exit: */
    return 0;
} /* ips_c_s */

/* ............................................................................. */
/*  Fit coefficients for "iron-poor" silicate dust model, Fe/(Fe+Mg)=0 for */
/*  Rosseland and Planck mean opacities (extinction) in the case of porous */
/*  composite spherical particles. */
/* ............................................................................. */
/*  Input parameter(s): */
/* ............................................................................. */

/*  'ross': opacity kind, */
/*        = .true. - Rosseland mean, */
/*        = .false. - Planck mean */

/* ............................................................................. */
/*  Output parameter(s): */
/* ............................................................................. */

/*    'eD': eD(5,6) opacity fit coefficients (extinction), */

/* ............................................................................. */
int ips_p_s( int *ross, double *ed )
{
    /* Initialized data */

    double er[30]   /* was [5][6] */ = { 6.16325982329344e-11,
                                         -5.80807258958069e-12, 4.63137627746193e-13, 5.18726914273965e-14,
                                         -6.36242594401e-16, -3.95567622182725e-8, 7.69071377086988e-9,
                                         -1.1539263844744e-9, -1.41793672891967e-10, 2.27869443274476e-11,
                                         7.76710831193065e-6, -3.73362220126263e-6, 1.14229256770936e-6,
                                         1.55142036439867e-7, -1.15739341732255e-7, -4.55605687444511e-4,
                                         7.48673706393613e-4, -5.52919825151213e-4, -8.27373698525786e-5,
                                         2.1718034913193e-4, .0485053543175252, -.0351377373047415,
                                         .130524763171563, .0228876670722336, -.139928160766288,
                                         .277317740164441, 1.1667305021944, -7.43780095534084,
                                         -1.19404116580805, 33.7974021623102
                                       };
    double ep[30]   /* was [5][6] */ = { -4.01211730126533e-11,
                                         2.70348361838629e-13, 1.13457492402838e-13, -1.33875976650634e-15,
                                         6.62279938487018e-15, 2.63163452725145e-8, -4.294221814398e-10,
                                         -3.35269211056638e-10, -9.75361365330163e-12, -5.84029216435355e-11,
                                         -6.8015372785473e-6, 4.14070085265024e-7, 4.24402149483608e-7,
                                         3.77766210661819e-8, 2.10425525088402e-7, 7.44664310341164e-4,
                                         -2.46079635400353e-4, -2.58694273941247e-4, -3.48999709775006e-5,
                                         -3.87759004379217e-4, .0373848509773533, .073637359921497,
                                         .0744782095414529, .01358544047349, .365313363904957,
                                         .301898096742562, -2.26582087568527, -2.90706234915815,
                                         -.127754000600243, -87.1316397730807
                                       };


    /* Local variables */
    int i__, j;

    /* Fit coefficients for Rosseland mean opacity (extinction) */
    /* Parameter adjustments */
    ed -= 6;

    /* Function Body */
    /* Fit coefficients for Planck mean opacity (extinction) */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    //printf("Dust model: \"iron-rich\" silicates; porous composite spherical particles\n");
    /* Set up output parameters: */
    for( i__ = 1; i__ <= 5; ++i__ )
    {
        for( j = 1; j <= 6; ++j )
        {
            if( *ross )
            {
                /* Rosseland mean opacities, */
                ed[i__ + j * 5] = er[i__ + j * 5 - 6];
            }
            else
            {
                /* Planck mean opacities, */
                ed[i__ + j * 5] = ep[i__ + j * 5 - 6];
            }
        }
    }
    /* Exit: */
    return 0;
} /* ips_p_s */

/* ............................................................................. */
/*  Fit coefficients for "normal" silicate dust model, Fe/(Fe+Mg)=0.3 for */
/*  Rosseland and Planck mean opacities (extinction) in the case of compact */
/*  5-layered spherical particles. */
/* ............................................................................. */
/*  Input parameter(s): */
/* ............................................................................. */

/*  'ross': opacity kind, */
/*        = .true. - Rosseland mean, */
/*        = .false. - Planck mean */

/* ............................................................................. */
/*  Output parameter(s): */
/* ............................................................................. */

/*    'eD': eD(5,6) opacity fit coefficients (extinction), */

/* ............................................................................. */
int nrm_c_5( int *ross, double *ed )
{
    /* Initialized data */

    double er[30]   /* was [5][6] */ = { 5.08949712869433e-12,
                                         -5.35931875543137e-12, 2.62306381508425e-13, 3.27041849431648e-15,
                                         3.08229893598817e-15, -1.53718970829345e-9, 7.16101597203086e-9,
                                         -6.58245880380291e-10, -1.60318902477784e-11, -1.78022161514338e-11,
                                         -1.12486539158315e-6, -3.59007641244716e-6, 6.63943455038746e-7,
                                         2.68510919996057e-8, 3.41691637706396e-8, 4.15532260223064e-4,
                                         7.89100566557223e-4, -3.32883795128953e-4, -1.97469723429693e-5,
                                         -2.15715627049837e-5, .00209187007242247, -.0549608891017917,
                                         .085717047819729, .00841133294515589, .0108331370494338,
                                         .00272590783978286, 1.87200525396931, -5.19841594568187,
                                         -.310510712962614, -2.1401641153696
                                       };
    double ep[30]   /* was [5][6] */ = { -7.14949444274683e-11,
                                         -1.67884045460503e-12, 1.55327591989545e-13, -1.03624135991621e-14,
                                         -1.67515994048708e-15, 4.56493008909558e-8, 1.93188486891451e-9,
                                         -4.10321918887199e-10, 2.6385121755664e-11, 8.60655825209691e-12,
                                         -1.10539435401238e-5, -6.79454401316653e-7, 4.40283479754537e-7,
                                         -2.0762269754789e-8, -6.93702079042461e-9, .00118753618113963,
                                         4.69783308833343e-6, -2.3166851981471e-4, 7.32598938961178e-6,
                                         -3.5291428876989e-5, .00565505491673554, .0432350670809456,
                                         .0610008288910487, -8.29368808539319e-5, .0841125399790784,
                                         .0112334152485423, -1.69471571838041, -2.20328351321696,
                                         .993171165391605, -26.0846220035654
                                       };

    /* Local variables */
    int i__, j;



    /* Fit coefficients for Rosseland mean opacity (extinction) */
    /* Parameter adjustments */
    ed -= 6;

    /* Function Body */
    /* Fit coefficients for Planck mean opacity (extinction) */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    //printf("Dust model: \"normal\" silicates; composite spherical particles\n");
    /* Set up output parameters: */
    for( i__ = 1; i__ <= 5; ++i__ )
    {
        for( j = 1; j <= 6; ++j )
        {
            if( *ross )
            {
                /* Rosseland mean opacities, */
                ed[i__ + j * 5] = er[i__ + j * 5 - 6];
            }
            else
            {
                /* Planck mean opacities, */
                ed[i__ + j * 5] = ep[i__ + j * 5 - 6];
            }
        }
    }
    /* Exit: */
    return 0;
} /* nrm_c_5 */

/* ............................................................................. */
/*  Fit coefficients for "normal" silicate dust model, Fe/(Fe+Mg)=0.3 for */
/*  Rosseland and Planck mean opacities (extinction) in the case of composite */
/*  spherical particles. */
/* ............................................................................. */
/*  Input parameter(s): */
/* ............................................................................. */

/*  'ross': opacity kind, */
/*        = .true. - Rosseland mean, */
/*        = .false. - Planck mean */

/* ............................................................................. */
/*  Output parameter(s): */
/* ............................................................................. */

/*    'eD': eD(5,6) opacity fit coefficients (extinction), */

/* ............................................................................. */
int nrm_c_s( int *ross, double *ed )
{
    /* Initialized data */

    double er[30]   /* was [5][6] */ = { 4.78854076388234e-11,
                                         -5.93517193620454e-12, 3.96881262106136e-13, 2.21622914715417e-14,
                                         3.08229893598817e-15, -3.05050729390064e-8, 7.9960206137062e-9,
                                         -9.72863087619805e-10, -5.94635291659859e-11, -1.78022161514338e-11,
                                         5.81824214006995e-6, -4.03270370353943e-6, 9.53169040316939e-7,
                                         6.38107930515063e-8, 3.41691637706396e-8, -2.83923316707453e-4,
                                         8.89931041863554e-4, -4.61234769343198e-4, -3.28353311308322e-5,
                                         -2.15715627049837e-5, .0314253145824216, -.0648757583594739,
                                         .111408530920425, .00909104468384773, .0108331370494338,
                                         .0887898350638988, 2.265422189081, -7.02120870412906,
                                         .15880156890083, -2.1401641153696
                                       };
    double ep[30]   /* was [5][6] */ = { -3.41819741402517e-11,
                                         -1.12830247095837e-12, 1.89108843073233e-13, -3.81360510301176e-13,
                                         -1.67515994048708e-15, 2.23645236101969e-8, 1.335553570315e-9,
                                         -4.95790312358432e-10, 1.03235732895043e-9, 8.60655825209691e-12,
                                         -5.89928594921228e-6, -4.48097965263261e-7, 5.37577883121461e-7,
                                         -1.10333822789504e-6, -6.93702079042461e-9, 6.93401573122865e-4,
                                         -3.76149993308007e-5, -2.88918973503794e-4, 5.85483209514903e-4,
                                         -3.5291428876989e-5, .024777055232815, .047470232609802,
                                         .0763039862991397, -.154423150177907, .0841125399790784,
                                         .111591386809632, -1.82169470029816, -3.53244895002719,
                                         17.926078183983, -26.0846220035654
                                       };

    /* Local variables */
    int i__, j;

    /* Fit coefficients for Rosseland mean opacity (extinction) */
    /* Parameter adjustments */
    ed -= 6;

    /* Function Body */
    /* Fit coefficients for Planck mean opacity (extinction) */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    //printf("Dust model: \"normal\" silicates; composite spheres\n");
    /* Set up output parameters: */
    for( i__ = 1; i__ <= 5; ++i__ )
    {
        for( j = 1; j <= 6; ++j )
        {
            if( *ross )
            {
                /* Rosseland mean opacities, */
                ed[i__ + j * 5] = er[i__ + j * 5 - 6];
            }
            else
            {
                /* Planck mean opacities, */
                ed[i__ + j * 5] = ep[i__ + j * 5 - 6];
            }
        }
    }
    /* Exit: */
    return 0;
} /* nrm_c_s */

/* ............................................................................. */
/*  Fit coefficients for "normal" silicate dust model, Fe/(Fe+Mg)=0.3 for */
/*  Rosseland and Planck mean opacities (extinction) in the case of porous */
/*  composite spherical particles. */
/* ............................................................................. */
/*  Input parameter(s): */
/* ............................................................................. */

/*  'ross': opacity kind, */
/*        = .true. - Rosseland mean, */
/*        = .false. - Planck mean */

/* ............................................................................. */
/*  Output parameter(s): */
/* ............................................................................. */

/*    'eD': eD(5,6) opacity fit coefficients (extinction), */

/* ............................................................................. */
int nrm_p_s( int *ross, double *ed )
{
    /* Initialized data */

    double er[30]   /* was [5][6] */ = { 7.85371519593748e-11,
                                         -8.87299168944718e-12, 5.38247846353663e-13, -7.55524770696284e-15,
                                         -1.30828373044176e-14, -4.80006707485116e-8, 1.1195446958988e-8,
                                         -1.27651771705338e-9, 2.33980770211242e-11, 9.9783418342877e-11,
                                         8.81328697797383e-6, -5.15886099896442e-6, 1.20032006666088e-6,
                                         -3.01991726632572e-8, -2.9869558304736e-7, -4.53668079636133e-4,
                                         9.82016234606357e-4, -5.4883443988553e-4, 2.29013764931138e-5,
                                         4.22351796843159e-4, .0476159582199885, -.0471566068685918,
                                         .120263771157534, -.00818191117398483, -.244253836247334,
                                         .277785544793629, 1.34553778217146, -5.42723873159659,
                                         2.63507025221571, 53.997661463508
                                       };
    double ep[30]   /* was [5][6] */ = { -4.58654906818365e-11,
                                         3.91290008494475e-14, 1.99643686652162e-13, -7.82028779667088e-14,
                                         9.36497786743931e-15, 3.13480653537745e-8, -3.63498200190023e-10,
                                         -5.18907766097996e-10, 2.06759983260227e-10, -8.00404767157475e-11,
                                         -8.35471192685874e-6, 5.60196221829381e-7, 5.72588528255506e-7,
                                         -2.05102104040486e-7, 2.79452359608931e-7, 9.15549311875373e-4,
                                         -3.45029186519145e-4, -3.11614174394111e-4, 1.02405546738682e-4,
                                         -4.99840375368722e-4, .0364545274269526, .0933545520942711,
                                         .0802500034686812, -.0264197796694802, .453874784636414,
                                         .301945983086209, -3.01214115674458, -2.40199489461792,
                                         4.83951587103424, -106.308402481092
                                       };

    /* Local variables */
    int i__, j;

    /* Fit coefficients for Rosseland mean opacity (extinction) */
    /* Parameter adjustments */
    ed -= 6;

    /* Function Body */
    /* Fit coefficients for Planck mean opacity (extinction) */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    //printf("Dust model: \"normal\" silicates; porous composite spheres\n");
    /* Set up output parameters: */
    for( i__ = 1; i__ <= 5; ++i__ )
    {
        for( j = 1; j <= 6; ++j )
        {
            if( *ross )
            {
                /* Rosseland mean opacities, */
                ed[i__ + j * 5] = er[i__ + j * 5 - 6];
            }
            else
            {
                /* Planck mean opacities, */
                ed[i__ + j * 5] = ep[i__ + j * 5 - 6];
            }
        }
    }
    /* Exit: */
    return 0;
} /* nrm_p_s */

/* ............................................................................. */
/*  Fit coefficients for "iron-rich" silicate dust model, Fe/(Fe+Mg)=0.4 for */
/*  Rosseland and Planck mean opacities (extinction) in the case of composite */
/*  compact spherical particles. */
/* ............................................................................. */
/*  Input parameter(s): */
/* ............................................................................. */

/*  'ross': opacity kind, */
/*        = .true. - Rosseland mean, */
/*        = .false. - Planck mean */

/* ............................................................................. */
/*  Output parameter(s): */
/* ............................................................................. */

/*    'eD': eD(5,6) opacity fit coefficients (extinction), */

/* ............................................................................. */
int irs_c_s( int *ross, double *ed )
{
    /* Initialized data */

    double er[30]   /* was [5][6] */ = { 3.38105553485455e-11,
                                         -9.33849985456763e-12, 6.01276706343005e-13, 7.65229254992693e-16,
                                         1.49293993587802e-14, -2.02838511585602e-8, 1.24935575368973e-8,
                                         -1.44233134195667e-9, 2.46287271557838e-12, -9.82795556754154e-11,
                                         2.84877650568732e-6, -6.27490514530631e-6, 1.37594297584878e-6,
                                         -1.04907678327515e-8, 2.51654206970038e-7, 1.22714002652235e-4,
                                         .00139635734816913, -6.44792574567779e-4, 1.39235031579021e-5,
                                         -3.18748794293237e-4, .0118510085000898, -.11361648748866,
                                         .147358324017058, -.00688309740787277, .212460479770846,
                                         .0982198926271953, 3.99912701111438, -9.13464156449306,
                                         2.261062921392, -52.8047276482448
                                       };
    double ep[30]   /* was [5][6] */ = { -5.54781995920463e-11,
                                         -1.75271970941438e-12, 2.6738072461238e-13, 2.80139428238772e-14,
                                         5.65983780170079e-15, 3.7604745371584e-8, 2.08588528672575e-9,
                                         -7.02838675855814e-10, -9.3235744224089e-11, -4.52779932946938e-11,
                                         -1.00387845744382e-5, -7.43208094438225e-7, 7.54715549033486e-7,
                                         1.25247698258547e-7, 1.45019976976705e-7, .00119556198105876,
                                         -1.58225900002028e-5, -4.01284196762128e-4, -7.80450767416168e-5,
                                         -2.3170269259738e-4, .0072962291583653, .0566447875027636,
                                         .102575992311186, .0211668231124049, .18192448184292,
                                         .109663478851364, -2.38289344711759, -4.97886338012167,
                                         .0566889340414748, -35.1624944667169
                                       };

    /* Local variables */
    int i__, j;

    /* Fit coefficients for Rosseland mean opacity (extinction) */
    /* Parameter adjustments */
    ed -= 6;

    /* Function Body */
    /* Fit coefficients for Planck mean opacity (extinction) */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    //printf("Dust model: \"iron-rich\" silicates; composite spheres\n");
    /* Set up output parameters: */
    for( i__ = 1; i__ <= 5; ++i__ )
    {
        for( j = 1; j <= 6; ++j )
        {
            if( *ross )
            {
                /* Rosseland mean opacities, */
                ed[i__ + j * 5] = er[i__ + j * 5 - 6];
            }
            else
            {
                /* Planck mean opacities, */
                ed[i__ + j * 5] = ep[i__ + j * 5 - 6];
            }
        }
    }
    /* Exit: */
    return 0;
} /* irs_c_s */

/* ............................................................................. */
/*  Fit coefficients for "iron-rich" silicate dust model, Fe/(Fe+Mg)=0.4 for */
/*  Rosseland and Planck mean opacities (extinction) in the case of compact */
/*  5-layered sphericla particles. */
/* ............................................................................. */
/*  Input parameter(s): */
/* ............................................................................. */

/*  'ross': opacity kind, */
/*        = .true. - Rosseland mean, */
/*        = .false. - Planck mean */

/* ............................................................................. */
/*  Output parameter(s): */
/* ............................................................................. */

/*    'eD': eD(5,6) opacity fit coefficients (extinction), */

/* ............................................................................. */
int irs_c_5( int *ross, double *ed )
{
    /* Initialized data */

    double er[30]   /* was [5][6] */ = { 1.70508948351477e-11,
                                         -8.13531566799258e-12, 4.75062926575866e-13, 4.93616807759143e-15,
                                         -3.97322091747243e-15, -9.7487815841611e-9, 1.08881343069455e-8,
                                         -1.15799932983925e-9, -1.09122307820087e-11, 3.02096189805582e-11,
                                         6.86841201060741e-7, -5.47675940524962e-6, 1.12655013483057e-6,
                                         7.19688026167049e-9, -8.6448934229256e-8, 2.85420693378615e-4,
                                         .001219871525574, -5.40677696871614e-4, 1.83969458834133e-6,
                                         1.09980600256632e-4, .00467027871016589, -.0966934069009319,
                                         .128291627860611, -.00250033083691768, -.0483957313087191,
                                         .00571961882492061, 3.35832159655028, -8.01189130848149,
                                         1.61075348102171, 7.89707541733308
                                       };
    double ep[30]   /* was [5][6] */ = { -6.47972548162755e-11,
                                         -2.00937566079048e-12, 5.60943163643822e-11, 8.01929008945014e-15,
                                         5.547882156451e-15, 4.21525305378917e-8, 2.32343408108912e-9,
                                         -1.24246570547719e-7, -3.21935520870997e-11, -4.45469973774392e-11,
                                         -1.06267375522626e-5, -8.11911225464655e-7, 1.08602993003868e-4,
                                         5.19531322741465e-8, 1.43179952681586e-7, .00120631667027662,
                                         -6.07902377383124e-6, -.0467555501212897, -3.45304239783009e-5,
                                         -2.29480193872413e-4, .00567895411217888, .0546390379960075,
                                         9.89466902884033, .00904196525890367, .18064867058766,
                                         .0193858771554221, -2.32537279817566, -816.5506674504,
                                         1.01172494080519, -34.8981382167346
                                       };

    /* Local variables */
    int i__, j;

    /* Fit coefficients for Rosseland mean opacity (extinction) */
    /* Parameter adjustments */
    ed -= 6;

    /* Function Body */
    /* Fit coefficients for Planck mean opacity (extinction) */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    //printf("Dust model: \"iron-rich\" silicates; compact 5-layered spheres\n");
    /* Set up output parameters: */
    for( i__ = 1; i__ <= 5; ++i__ )
    {
        for( j = 1; j <= 6; ++j )
        {
            if( *ross )
            {
                /* Rosseland mean opacities, */
                ed[i__ + j * 5] = er[i__ + j * 5 - 6];
            }
            else
            {
                /* Planck mean opacities, */
                ed[i__ + j * 5] = ep[i__ + j * 5 - 6];
            }
        }
    }
    /* Exit: */
    return 0;
} /* irs_c_5 */

/* ............................................................................. */
/*  Fit coefficients for "iron-rich" silicate dust model, Fe/(Fe+Mg)=0.4 for */
/*  Rosseland and Planck mean opacities (extinction) in the case of porous */
/*  5-layered spherical particles. */
/* ............................................................................. */
/*  Input parameter(s): */
/* ............................................................................. */

/*  'ross': opacity kind, */
/*        = .true. - Rosseland mean, */
/*        = .false. - Planck mean */

/* ............................................................................. */
/*  Output parameter(s): */
/* ............................................................................. */

/*    'eD': eD(5,6) opacity fit coefficients (extinction), */

/* ............................................................................. */
int irs_p_5( int *ross, double *ed )
{
    /* Initialized data */

    double er[30]   /* was [5][6] */ = { 8.96773074857445e-12,
                                         -1.00059186545087e-11, 4.29165746710068e-13, -2.06107052640973e-14,
                                         -2.90096647131548e-18, -4.52346007828537e-9, 1.31015565493775e-8,
                                         -1.07643520003061e-9, 6.73949147957524e-11, -6.53490849918787e-12,
                                         -5.14999243071951e-7, -6.39496683907595e-6, 1.07072790630826e-6,
                                         -9.0580411485153e-8, 4.6665337261259e-8, 3.81710740418527e-4,
                                         .00135906147931384, -5.18451622215369e-4, 6.51898800406398e-5,
                                         -1.25342723299598e-4, .00662657430083621, -.0982256036580519,
                                         .120554616636895, -.0240303268395795, .152064247253868,
                                         .00776645724385527, 3.33404126191471, -6.14129505789404,
                                         4.9008931785266, -44.8939661684724
                                       };
    double ep[30]   /* was [5][6] */ = { -6.89956740572676e-11,
                                         -2.13039301488055e-12, 3.72610228925694e-13, 2.46022245735189e-15,
                                         1.20592372746624e-14, 4.41735257676424e-8, 2.45268159317063e-9,
                                         -9.18600007827935e-10, -2.68117733461386e-11, -9.24919691382196e-11,
                                         -1.08772892714465e-5, -8.35335761563827e-7, 9.29591457329738e-7,
                                         6.5615588467925e-8, 2.79801643892125e-7, .00119499989856874,
                                         -2.67662552025424e-5, -4.69567004516968e-4, -5.08130832339838e-5,
                                         -4.11688178661673e-4, .0104885901605351, .0633425961606103,
                                         .114879683458859, .0133652293166528, .280919930581346,
                                         .027981056254553, -2.46205624927029, -5.26990396362187,
                                         1.6479728128063, -28.3809618086616
                                       };

    /* Local variables */
    int i__, j;

    /* Fit coefficients for Rosseland mean opacity (extinction) */
    /* Parameter adjustments */
    ed -= 6;

    /* Function Body */
    /* Fit coefficients for Planck mean opacity (extinction) */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    //printf("Dust model: \"iron-rich\" silicates; porous 5-layered spheres\n");
    /* Set up output parameters: */
    for( i__ = 1; i__ <= 5; ++i__ )
    {
        for( j = 1; j <= 6; ++j )
        {
            if( *ross )
            {
                /* Rosseland mean opacities, */
                ed[i__ + j * 5] = er[i__ + j * 5 - 6];
            }
            else
            {
                /* Planck mean opacities, */
                ed[i__ + j * 5] = ep[i__ + j * 5 - 6];
            }
        }
    }
    /* Exit: */
    return 0;
} /* irs_p_5 */

/* ............................................................................. */
/*  Fit coefficients for "iron-poor" silicate dust model, Fe/(Fe+Mg)=0 for */
/*  Rosseland and Planck mean opacities (extinction) in the case of porous */
/*  5-layered spherical particles. */
/* ............................................................................. */
/*  Input parameter(s): */
/* ............................................................................. */

/*  'ross': opacity kind, */
/*        = .true. - Rosseland mean, */
/*        = .false. - Planck mean */

/* ............................................................................. */
/*  Output parameter(s): */
/* ............................................................................. */

/*    'eD': eD(5,6) opacity fit coefficients (extinction), */

/* ............................................................................. */
int ips_p_5( int *ross, double *ed )
{
    /* Initialized data */

    double er[30]   /* was [5][6] */ = { -1.11273466842134e-11,
                                         -4.3864935836449e-12, 3.11973513365184e-13, -1.47889064517314e-14,
                                         -6.36242594401e-16, 8.45467152887459e-9, 5.87553836312308e-9,
                                         -7.81333888580475e-10, 3.71128462723842e-11, 2.27869443274476e-11,
                                         -3.10107327781121e-6, -2.91861320517099e-6, 7.87235736665606e-7,
                                         -3.50776662753613e-8, -1.15739341732255e-7, 5.33370752643551e-4,
                                         6.13225956804579e-4, -3.93375417709984e-4, 1.72038855015232e-5,
                                         2.1718034913193e-4, .00349839344699195, -.0320815807348939,
                                         .0994699809579733, -.0025094316976995, -.139928160766288,
                                         .005744949380228, 1.12775533786856, -5.985155774304,
                                         1.38619339830858, 33.7974021623102
                                       };
    double ep[30]   /* was [5][6] */ = { -8.29208232001774e-11,
                                         -1.38555904483831e-12, 1.5232269442255e-13, -1.27424572482406e-12,
                                         6.62279938487018e-15, 5.20116523211783e-8, 1.64236953942682e-9,
                                         -4.04052715053511e-10, 3.47630944149498e-9, -5.84029216435355e-11,
                                         -1.21304181159164e-5, -5.96778918866169e-7, 4.46733580634883e-7,
                                         -3.74936967508991e-6, 2.10425525088402e-7, .00122860492094876,
                                         3.37500082588048e-6, -2.43942256054794e-4, .00200641509260141,
                                         -3.87759004379217e-4, .00725910757183928, .041330941712239,
                                         .0664544372119637, -.531831149799181, .365313363904957,
                                         .0128869482389276, -1.32552897783752, -2.69130796594824,
                                         57.6428786572292, -87.1316397730807
                                       };

    /* Local variables */
    int i__, j;


    /* Fit coefficients for Rosseland mean opacity (extinction) */
    /* Parameter adjustments */
    ed -= 6;

    /* Function Body */
    /* Fit coefficients for Planck mean opacity (extinction) */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    //printf("Dust model: \"iron-poor\" silicates; porous 5-layered spheres\n");
    /* Set up output parameters: */
    for( i__ = 1; i__ <= 5; ++i__ )
    {
        for( j = 1; j <= 6; ++j )
        {
            if( *ross )
            {
                /* Rosseland mean opacities, */
                ed[i__ + j * 5] = er[i__ + j * 5 - 6];
            }
            else
            {
                /* Planck mean opacities, */
                ed[i__ + j * 5] = ep[i__ + j * 5 - 6];
            }
        }
    }
    /* Exit: */
    return 0;
} /* ips_p_5 */

/* ............................................................................. */
/*  Fit coefficients for "normal" silicate dust model, Fe/(Fe+Mg)=0.3 for */
/*  Rosseland and Planck mean opacities (extinction) in the case of porous */
/*  5-layered spherical particles. */
/* ............................................................................. */
/*  Input parameter(s): */
/* ............................................................................. */

/*  'ross': opacity kind, */
/*        = .true. - Rosseland mean, */
/*        = .false. - Planck mean */

/* ............................................................................. */
/*  Output parameter(s): */
/* ............................................................................. */

/*    'eD': eD(5,6) opacity fit coefficients (extinction), */

/* ............................................................................. */
int nrm_p_5( int *ross, double *ed )
{
    /* Initialized data */

    double er[30]   /* was [5][6] */ = { -3.42512260664181e-12,
                                         -6.39519672284482e-12, 3.58333252702902e-13, -2.07904677131994e-14,
                                         -1.30828373044176e-14, 4.00643345707715e-9, 8.32587601858491e-9,
                                         -8.81289429556535e-10, 5.8677724840142e-11, 9.9783418342877e-11,
                                         -2.36634357360831e-6, -4.01815578974051e-6, 8.67113875506433e-7,
                                         -6.63459139353054e-8, -2.9869558304736e-7, 5.06330578089306e-4,
                                         8.27355223991723e-4, -4.20124993705012e-4, 4.04113784646693e-5,
                                         4.22351796843159e-4, .00409097272925876, -.0483890387342808,
                                         .101450295374589, -.01155325068306, -.244253836247334,
                                         .0060177875765669, 1.60756061479057, -5.48430544923485,
                                         2.89704668567564, 53.997661463508
                                       };
    double ep[30]   /* was [5][6] */ = { -7.78528782774519e-11,
                                         -1.62343151233391e-12, 1.5627583476775e-13, -3.05426999846083e-14,
                                         9.36497786743931e-15, 4.92509361904375e-8, 1.8358493032799e-9,
                                         -4.20354714202562e-10, 7.72593517572306e-11, -8.00404767157475e-11,
                                         -1.16987010630897e-5, -5.97102252247488e-7, 4.6768448742788e-7,
                                         -6.16264365628349e-8, 2.79452359608931e-7, .00121215805115239,
                                         -3.54389014170137e-5, -2.53842721861715e-4, 2.32827286610477e-5,
                                         -4.99840375368722e-4, .00883586501144021, .0521482016285399,
                                         .0670254394966715, -.00411669467032501, .453874784636414,
                                         .0154425119227787, -1.80886247230953, -2.16049699341054,
                                         2.23872527151849, -106.308402481092
                                       };

    /* Local variables */
    int i__, j;

    /* Fit coefficients for Rosseland mean opacity (extinction) */
    /* Parameter adjustments */
    ed -= 6;

    /* Function Body */
    /* Fit coefficients for Planck mean opacity (extinction) */
    /* 1st temperature regions, */
    /* 2nd temperature regions, */
    /* 3rd temperature regions, */
    /* 4th temperature regions, */
    /* 1st temperature regions, */
    /* 2nd temperature regions, */
    /* 3rd temperature regions, */
    /* 4th temperature regions, */
    //printf("Dust model: \"normal\" silicates; porous 5-layered spheres\n");
    /* Set up output parameters: */
    for( i__ = 1; i__ <= 5; ++i__ )
    {
        for( j = 1; j <= 6; ++j )
        {
            if( *ross )
            {
                /* Rosseland mean opacities, */
                ed[i__ + j * 5] = er[i__ + j * 5 - 6];
            }
            else
            {
                /* Planck mean opacities, */
                ed[i__ + j * 5] = ep[i__ + j * 5 - 6];
            }
        }
    }
    /* Exit: */
    return 0;
} /* nrm_p_5 */

/* ............................................................................. */
/*  Fit coefficients for "iron-rich" silicate dust model, Fe/(Fe+Mg)=0.4 for */
/*  Rosseland and Planck mean opacities (extinction) in the case of porous */
/*  composite spherical particles. */
/* ............................................................................. */
/*  Input parameter(s): */
/* ............................................................................. */

/*  'ross': opacity kind, */
/*        = .true. - Rosseland mean, */
/*        = .false. - Planck mean */

/* ............................................................................. */
/*  Output parameter(s): */
/* ............................................................................. */

/*    'eD': eD(5,6) opacity fit coefficients (extinction), */

/* ............................................................................. */
int irs_p_s( int *ross, double *ed )
{
    /* Initialized data */

    double er[30]   /* was [5][6] */ = { 2.68810001584323e-11,
                                         -1.41448526625583e-11, 4.89432507733348e-13, -1.09694487093443e-13,
                                         -2.90096647131548e-18, -1.12477333823967e-8, 1.78857661984583e-8,
                                         -1.18479013761268e-9, 3.20753068449201e-10, -6.53490849918787e-12,
                                         -1.01566610086506e-6, -8.34447302544632e-6, 1.12743324344216e-6,
                                         -3.77103037922897e-7, 4.6665337261259e-8, 7.19092035096105e-4,
                                         .00166564397599198, -5.13682572822325e-4, 2.25890434374501e-4,
                                         -1.25342723299598e-4, -.00340209389403125, -.109455596095692,
                                         .107619609550656, -.0687472517167857, .152064247253868,
                                         .241084737867738, 3.38446486439366, -3.25573585597726,
                                         9.68700809982378, -44.8939661684724
                                       };
    double ep[30]   /* was [5][6] */ = { -9.38221635967739e-11,
                                         -3.14048020738633e-13, 2.98137289493519e-13, 7.3237247695491e-15,
                                         1.20592372746624e-14, 6.51531135580471e-8, -7.6988007707677e-12,
                                         -7.76249490370792e-10, -3.99940104538424e-11, -9.24919691382196e-11,
                                         -1.71960674810085e-5, 4.97519361287919e-7, 8.33111875808792e-7,
                                         7.61246665638358e-8, 2.79801643892125e-7, .00192789340102626,
                                         -3.9265195831664e-4, -4.41327484073404e-4, -5.44567135496901e-5,
                                         -4.11688178661673e-4, -9.90219555706369e-4, .112649942798147,
                                         .10942434723916, .0138692387601316, .280919930581346,
                                         .248460261889448, -4.03276741578672, -3.8837275854887,
                                         1.55063616069495, -28.3809618086616
                                       };

    /* Local variables */
    int i__, j;

    /* Fit coefficients for Rosseland mean opacity (extinction) */
    /* Parameter adjustments */
    ed -= 6;

    /* Function Body */
    /* Fit coefficients for Planck mean opacity (extinction) */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    /* 1st temperature region, */
    /* 2nd temperature region, */
    /* 3rd temperature region, */
    /* 4th temperature region, */
    //printf("Dust model: \"iron-rich\" silicates; porous composite spherical particles\n");
    /* Set up output parameters: */
    for( i__ = 1; i__ <= 5; ++i__ )
    {
        for( j = 1; j <= 6; ++j )
        {
            if( *ross )
            {
                /* Rosseland mean opacities, */
                ed[i__ + j * 5] = er[i__ + j * 5 - 6];
            }
            else
            {
                /* Planck mean opacities, */
                ed[i__ + j * 5] = ep[i__ + j * 5 - 6];
            }
        }
    }
    /* Exit: */
    return 0;
} /* irs_p_s */



