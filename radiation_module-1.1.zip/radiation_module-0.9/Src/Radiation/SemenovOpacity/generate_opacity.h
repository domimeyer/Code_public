#ifndef GENERATE_OPACITY_H
#define GENERATE_OPACITY_H

int init_d( int *ross, char *model, char *top, char *shape, double *ed, int model_len, int top_len, int shape_len );
int init_g( int *ross, double *eg );
int init_g2( char *filepath, double *eg );

int cop( double *ed, double *eg, double *rho_in__, double *t_in__, double *akext );
int gop( double *eg, double *rho_in__, double *t_in__, double *ak );
int bint( double *xa, int *n, double *x, double *res, double *ri );
int eint( int *n, double *x, int *m, double *y, double *d__, double *xp, double *yp, double *dp );
int nrm_h_s( int *ross, double *ed );
int nrm_h_a( int *ross, double *ed );
int nrm_c_a( int *ross, double *ed );
int irs_h_s( int *ross, double *ed );
int irs_h_a( int *ross, double *ed );
int irs_c_a( int *ross, double *ed );
int ips_h_s( int *ross, double *ed );
int ips_h_a( int *ross, double *ed );
int ips_c_a( int *ross, double *ed );
int ips_c_5( int *ross, double *ed );
int ips_c_s( int *ross, double *ed );
int ips_p_s( int *ross, double *ed );
int nrm_c_5( int *ross, double *ed );
int nrm_c_s( int *ross, double *ed );
int nrm_p_s( int *ross, double *ed );
int irs_c_s( int *ross, double *ed );
int irs_c_5( int *ross, double *ed );
int irs_p_5( int *ross, double *ed );
int ips_p_5( int *ross, double *ed );
int nrm_p_5( int *ross, double *ed );
int irs_p_s( int *ross, double *ed );

#endif
