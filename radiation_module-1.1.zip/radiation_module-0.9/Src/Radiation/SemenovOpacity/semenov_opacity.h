/**
Copyright (C) 2011-2013 Stefan Kolb.
Copyright (C) 2012-2013  Markus Flaig.

This file is part of the radiation module for the code PLUTO.

The radiation module is free software: you can redistribute it
and/or modify it under the terms of the GNU General Public
License as published by the Free Software Foundation, either
version 2 of the License, or (at your option) any later version.

The radiation module is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty
of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the radiation module. If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef SEMINOV_OPACITY_H
#define SEMINOV_OPACITY_H

typedef struct
{
    int nT;                          /** Number of temperature points */
    double T0;                       /** First temperature point */
    double T1;                       /** Last temperature point */
    int nrho;                        /** Number of density points */
    double rho0;                     /** First density point */
    double rho1;                     /** Last density point */
    char top[1];                     /** Grain topology = ['h','c','p'] */
    char model[3];                   /** Dust model = ['nrm','ips','irs'] */
    char shape[1];                   /** Shape of dust particles = ['s','a','5'] */
    double *opacity_tabel_planck;    /** Pointer to Planck opacity table */
    double *opacity_table_rosseland; /** Pointer to Rosseland opacity table */
} SemenovOpaciytInfo;

void SemenovOpacityInit();
void SemenovOpacityReadOptions();
void SemenovOpacityFinalise();
double SemenovPlanckOpacity( double rho, double T );
double SemenovRosselandOpacity( double rho, double T );
#endif
