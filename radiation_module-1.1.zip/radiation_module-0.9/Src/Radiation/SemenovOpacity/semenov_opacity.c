/**
Copyright (C) 2011-2013 Stefan Kolb.
Copyright (C) 2012-2013  Markus Flaig.

This file is part of the radiation module for the code PLUTO.

The radiation module is free software: you can redistribute it
and/or modify it under the terms of the GNU General Public
License as published by the Free Software Foundation, either
version 2 of the License, or (at your option) any later version.

The radiation module is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty
of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the radiation module. If not, see <http://www.gnu.org/licenses/>.
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "radiation.h"
#include "error.h"
#include "semenov_opacity.h"
#include "generate_opacity.h"

// Check if density and temperature are in allowed range
#define SEM_OPAC_CHECK  1

SemenovOpaciytInfo opacity_info = {.opacity_tabel_planck = NULL, .opacity_table_rosseland = NULL};

/**
    Initializes all necessary structures needed for the semenov opacity
*/
void SemenovOpacityInit()
{
    double ed[30], eg_total[2 * 5041], *eg_planck, *eg_rosseland, *eg = NULL;
    double T, dT, rho, drho;
    int it, irho, ross;
    double akext;
    double *opacity_table = NULL;
    char file_path[512];

    eg_planck = &eg_total[0];
    eg_rosseland = &eg_total[5041];

//  opacity_info.nT   = 2048;
//  opacity_info.T0   = 1.000e+01;
//  opacity_info.T1   = 9.999e+03;
//  opacity_info.nrho = 2048;
//  opacity_info.rho0 = 1.000e-16;
//  opacity_info.rho1 = 9.999e-09;
//  opacity_info.top[0] = 'h';
//  strncpy(opacity_info.model,"nrm",3);
//  opacity_info.shape[0] = 's';

    SemenovOpacityReadOptions();

    opacity_info.opacity_tabel_planck = NULL;
    opacity_info.opacity_table_rosseland = NULL;

    if( prank == 0 )
    {
        /*
            NOTE
            The define SEMENOV_OPACITY_PATH is added to the compiler command line. To modify the define or change something
            look at the file Src/Radiation/makefile. We changed the CFLAGS if the semenov opacity is chosen.
        */
        sprintf( file_path, "%s/%s", SEMENOV_OPACITY_PATH, "kP_h2001.dat" );
        init_g2( file_path, eg_planck );
        sprintf( file_path, "%s/%s", SEMENOV_OPACITY_PATH, "kR_h2001.dat" );
        init_g2( file_path, eg_rosseland );
    }
    MPI_Bcast( &opacity_info, sizeof( SemenovOpaciytInfo ), MPI_CHAR, 0, MPI_COMM_WORLD );
    MPI_Bcast( eg_total, 2 * 5041, MPI_DOUBLE, 0, MPI_COMM_WORLD );

    /* Allocate memory for opacity tables */
    opacity_info.opacity_tabel_planck = malloc( opacity_info.nT * opacity_info.nrho * sizeof( double ) );
    CHECK_ALLOCATED_MEMORY( opacity_info.opacity_tabel_planck );
    opacity_info.opacity_table_rosseland = malloc( opacity_info.nT * opacity_info.nrho * sizeof( double ) );
    CHECK_ALLOCATED_MEMORY( opacity_info.opacity_table_rosseland );

    for( ross = 0; ross <= 1; ross++ )
    {
        opacity_table = ross == 1 ? opacity_info.opacity_table_rosseland : opacity_info.opacity_tabel_planck;
        eg = ross == 1 ? eg_rosseland : eg_planck;

        /* Initialization of all necessary data for a chosen dust model: */
        init_d( &ross, opacity_info.model, opacity_info.top, opacity_info.shape, ed, ( int )3, ( int )1, ( int )1 );

        rho = opacity_info.rho0;
        drho = exp( log( opacity_info.rho1 / opacity_info.rho0 ) / ( opacity_info.nrho - 1 ) );
        for( irho = 1; irho <= opacity_info.nrho; ++irho )
        {

            T = opacity_info.T0;
            dT = exp( log( opacity_info.T1 / opacity_info.T0 ) / ( opacity_info.nT - 1 ) );
            for( it = 1; it <= opacity_info.nT; ++it )
            {
                /*
                    Calculation of Rosseland or Planck mean opacities using a chosen density,
                    temperature, silicate dust model, shape of the grains and their topology:
                */
                cop( ed, eg, &rho, &T, &akext );
                opacity_table[opacity_info.nrho * ( irho - 1 ) + ( it - 1 )] = akext;
                T *= dT;
            }
            rho *= drho;
        }
    }
}

/**
    Reads the necessary parameters for generating the opacities from the file pluto.ini.
    A possible set of options could be.

    \verbatim
    [Radiation Semenov Opacity]

    semenov-opacity-nT      2048
    semenov-opacity-T0      1.000e+01
    semenov-opacity-T1      9.999e+03
    semenov-opacity-nrho    2048
    semenov-opacity-rho0    1.000e-16
    semenov-opacity-rho1    9.999e-09
    semenov-opacity-top     h
    semenov-opacity-model   nrm
    semenov-opacity-shape   s
    \endverbatim
    More information can be found on the web page <a href="http://www.mpia.de/homes/henning/Dust_opacities/Opacities/opacities.htmll"></a>
    or in the comments of the file SemenovOpacity/generate_opacity.c.
*/
void SemenovOpacityReadOptions()
{
    char opacity_option_string[256];
    char *option_value;

    if( prank == 0 )
    {
        strcpy( opacity_option_string, "semenov-opacity-nT" );
        if( ParQuery( opacity_option_string ) )
        {
            opacity_info.nT = atoi( ParGet( opacity_option_string, 1 ) );
        }
        else
        {
            ERROR( "%s not found in pluto.ini", opacity_option_string );
        }

        strcpy( opacity_option_string, "semenov-opacity-T0" );
        if( ParQuery( opacity_option_string ) )
        {
            opacity_info.T0 = atof( ParGet( opacity_option_string, 1 ) );
        }
        else
        {
            ERROR( "%s not found in pluto.ini", opacity_option_string );
        }

        strcpy( opacity_option_string, "semenov-opacity-T1" );
        if( ParQuery( opacity_option_string ) )
        {
            opacity_info.T1 = atof( ParGet( opacity_option_string, 1 ) );
        }
        else
        {
            ERROR( "%s not found in pluto.ini", opacity_option_string );
        }

        strcpy( opacity_option_string, "semenov-opacity-nrho" );
        if( ParQuery( opacity_option_string ) )
        {
            opacity_info.nrho = atoi( ParGet( opacity_option_string, 1 ) );
        }
        else
        {
            ERROR( "%s not found in pluto.ini", opacity_option_string );
        }

        strcpy( opacity_option_string, "semenov-opacity-rho0" );
        if( ParQuery( opacity_option_string ) )
        {
            opacity_info.rho0 = atof( ParGet( opacity_option_string, 1 ) );
        }
        else
        {
            ERROR( "%s not found in pluto.ini", opacity_option_string );
        }

        strcpy( opacity_option_string, "semenov-opacity-rho1" );
        if( ParQuery( opacity_option_string ) )
        {
            opacity_info.rho1 = atof( ParGet( opacity_option_string, 1 ) );
        }
        else
        {
            ERROR( "%s not found in pluto.ini", opacity_option_string );
        }

        strcpy( opacity_option_string, "semenov-opacity-top" );
        if( ParQuery( opacity_option_string ) )
        {
            option_value = ParGet( opacity_option_string, 1 );
            if( strlen( option_value ) == 1 )
            {
                opacity_info.top[0] = option_value[0];
            }
            else
            {
                ERROR( "Expected a string with one character for option %s", opacity_option_string );
            }
        }
        else
        {
            ERROR( "%s not found in pluto.ini", opacity_option_string );
        }

        strcpy( opacity_option_string, "semenov-opacity-model" );
        if( ParQuery( opacity_option_string ) )
        {
            option_value = ParGet( opacity_option_string, 1 );
            if( strlen( option_value ) == 3 )
            {
                strncpy( opacity_info.model, option_value, 3 );
            }
            else
            {
                ERROR( "Expected a string with 3 characters for option %s", opacity_option_string );
            }
        }
        else
        {
            ERROR( "%s not found in pluto.ini", opacity_option_string );
        }

        strcpy( opacity_option_string, "semenov-opacity-shape" );
        if( ParQuery( opacity_option_string ) )
        {
            option_value = ParGet( opacity_option_string, 1 );
            if( strlen( option_value ) == 1 )
            {
                opacity_info.shape[0] = option_value[0];
            }
            else
            {
                ERROR( "Expected a string with one character for option %s", opacity_option_string );
            }
        }
        else
        {
            ERROR( "%s not found in pluto.ini", opacity_option_string );
        }
    }
}

/**
    Frees the memory allocated for the semenov opacities
*/
void SemenovOpacityFinalise()
{
    if( opacity_info.opacity_tabel_planck )
    {
        free( opacity_info.opacity_tabel_planck );
    }

    if( opacity_info.opacity_table_rosseland )
    {
        free( opacity_info.opacity_table_rosseland );
    }
}

/**
    Computes and returns the Planck mean opacity in cgs units.

    \param[in]  rho     Density in cgs units
    \param[in]  T       Temperature in cgs units
*/
double SemenovPlanckOpacity( double rho, double T )
{
    double dT, drho, irho0, iT0;
    int irhom, irhop, iTm, iTp;


    drho = exp( log( opacity_info.rho1 / opacity_info.rho0 ) / ( opacity_info.nrho - 1 ) );
    dT   = exp( log( opacity_info.T1   / opacity_info.T0 ) / ( opacity_info.nT   - 1 ) );

    irho0 = log( rho / opacity_info.rho0 ) / log( drho ) + 1.0;
    iT0   = log( T  / opacity_info.T0 ) / log( dT ) + 1.0;

    irhom = ( int )( irho0 );
    iTm   = ( int )( iT0 );
    irhop = irhom + 1;
    iTp   = iTm + 1;

#ifdef SEM_OPAC_CHECK
    if( ( iTm   < 1 ) || ( iTp   > opacity_info.nT ) )
    {
        print( "SEM_OPAC_PLANCK): Temperature out of range (T = %e).\n", T );
        QUIT_PLUTO( 1 );
    }
    if( ( irhom < 1 ) || ( irhop > opacity_info.nrho ) )
    {
        print( "SEM_OPAC_PLANCK): Density out of range (rho = %e).\n", rho );
        QUIT_PLUTO( 1 );
    }
#endif /* SEM_OPAC_CHECK */


    return
        ( iT0 - iTm ) * ( irho0 - irhom ) * opacity_info.opacity_tabel_planck[opacity_info.nrho * ( irhop - 1 ) + ( iTp - 1 )] +
        ( iT0 - iTm ) * ( irhop - irho0 ) * opacity_info.opacity_tabel_planck[opacity_info.nrho * ( irhom - 1 ) + ( iTp - 1 )] +
        ( iTp - iT0 ) * ( irho0 - irhom ) * opacity_info.opacity_tabel_planck[opacity_info.nrho * ( irhop - 1 ) + ( iTm - 1 )] +
        ( iTp - iT0 ) * ( irhop - irho0 ) * opacity_info.opacity_tabel_planck[opacity_info.nrho * ( irhom - 1 ) + ( iTm - 1 )];
}

/**
    Computes and returns the Rosseland mean opacity in cgs units.

    \param[in]  rho     Density in cgs units
    \param[in]  T       Temperature in cgs units
*/
double SemenovRosselandOpacity( double rho, double T )
{
    double dT, drho, irho0, iT0;
    int irhom, irhop, iTm, iTp;


    drho = exp( log( opacity_info.rho1 / opacity_info.rho0 ) / ( opacity_info.nrho - 1 ) );
    dT   = exp( log( opacity_info.T1   / opacity_info.T0 ) / ( opacity_info.nT   - 1 ) );

    irho0 = log( rho / opacity_info.rho0 ) / log( drho ) + 1.0;
    iT0   = log( T  / opacity_info.T0 ) / log( dT ) + 1.0;

    irhom = ( int )( irho0 );
    iTm   = ( int )( iT0 );
    irhop = irhom + 1;
    iTp   = iTm + 1;

#ifdef SEM_OPAC_CHECK
    if( ( iTm   < 1 ) || ( iTp   > opacity_info.nT ) )
    {
        print( "SEM_OPAC_ROSS): Temperature out of range (T = %e).\n", T );
        QUIT_PLUTO( 1 );
    }
    if( ( irhom < 1 ) || ( irhop > opacity_info.nrho ) )
    {
        print( "SEM_OPAC_ROSS): Density out of range (rho = %e).\n", rho );
        QUIT_PLUTO( 1 );
    }
#endif /* SEM_OPAC_CHECK */


    return
        ( iT0 - iTm ) * ( irho0 - irhom ) * opacity_info.opacity_table_rosseland[opacity_info.nrho * ( irhop - 1 ) + ( iTp - 1 )] +
        ( iT0 - iTm ) * ( irhop - irho0 ) * opacity_info.opacity_table_rosseland[opacity_info.nrho * ( irhom - 1 ) + ( iTp - 1 )] +
        ( iTp - iT0 ) * ( irho0 - irhom ) * opacity_info.opacity_table_rosseland[opacity_info.nrho * ( irhop - 1 ) + ( iTm - 1 )] +
        ( iTp - iT0 ) * ( irhop - irho0 ) * opacity_info.opacity_table_rosseland[opacity_info.nrho * ( irhom - 1 ) + ( iTm - 1 )];
}
